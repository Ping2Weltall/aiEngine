/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : sprio.c                                                     */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 15.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur Engine & HTML Generator                              */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 13.06.2004  : ALH           : Konstanten als const deklariert             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_priod_version        = "1.0.0";                            //
const char *modul_priod                = "aIEnginePrioD";                    //
const char *modul_priod_date           = __DATE__;                           //
const char *modul_priod_time           = __TIME__;                           //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_LOG_LIB			1

#define SERVER_NAME	modul_priod                                          //
#define SERVER_VERSION	modul_priod_version                                  //
#define MY_QUEUE_ID	AIENGINE_PROG_QUEUE_ID | MSG_PROG_PRIO               //
#define MY_RCV_BUF	prio_msgbuf                                          //
/*---------------------------------------------------------------------------*/
/* System Headerdateien                                                      */
/*...........................................................................*/
#include <sys/time.h>                                                        //
#include <sys/resource.h>                                                    //
#include <signal.h>                                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
extern char *aIEngine_Start_Prog;
extern char *aIEngine_IP_Addresse;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool NewPrio(struct ipc_prio_msg *ipc_prio_msg);                      //
bool start_prog(struct ipc_prog_start_msg *ipc_prog_start_msg);              //
bool kill_prog(struct ipc_prog_kill_msg *ipc_prog_kill_msg);                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     :                                                           */
/* Rueckgabewert : int ( Immer 0 = OK)                                       */
/*...........................................................................*/
int main(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Start %s" },
      { AIE_LOG_ERROR, "%s: Fehler beim Oeffnen der Inputqueue %s" },
      { AIE_LOG_WARN,  "Couldn't change Queue %d - never mind" },
      { AIE_LOG_ERROR, "Priod - msgrcv Queue[%x] %s" },
      { AIE_LOG_ERROR, "Unbekanntes Telegramm %c" }
   };
   pid_t server_pid;
    int msqid;
    key_t key;
    struct MY_RCV_BUF rbuf;

    aIEngine_Start_Prog = "PrioD";
    aIEngine_IP_Addresse = "Lokal";

    aie_star_line(79, '#');
    printf("# %s Version %s\n# Build : %s %s\n", SERVER_NAME, SERVER_VERSION, 
	                                   modul_priod_date, modul_priod_time);
    printf("# Author: Alexander J. Herrmann\n");
    printf("#");
    aie_star_line(78, '-');
    key = MY_QUEUE_ID;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
    
    if (__builtin_expect(
	     ((msqid = msgget(key, IPC_CREAT | 0666)) < 0),false))
    {
        // %s: Fehler beim Oeffnen der Inputqueue %s
        aie_sys_log(1, modul_priod, strerror(errno));
        printf("%s:%s(%d) Fehler beim Oeffnen der Inputqueue\n", modul_priod, 
	                                                   __FILE__, __LINE__);
    }
    else
    {
       struct msqid_ds buf;
       struct msqid_ds change_buf;
       if (__builtin_expect(
		(msgctl(msqid, IPC_STAT, &buf) == 0),true))
       {
           memcpy(&change_buf, &buf, sizeof(change_buf));
	   change_buf.msg_qbytes = 65000;
           if (__builtin_expect(
		    (msgctl(msqid, IPC_SET, &change_buf) == 0),true))
           {
           }
	   else
           {
              // Couldn't change Queue %d - never mind
	      aie_sys_log(2, msqid);
              printf("# Couldn't change Queue %d - never mind.\n", msqid);
           }
           if (__builtin_expect(
		    (msgctl(msqid, IPC_STAT, &buf) == 0), true))
           {
	       printf("# Message Queue:	%d\n"
		      "# Owner: 	%d\n"
		      "# Creator: 	%d\n"
                      "# Size: 		%ld bytes\n" , msqid, 
		      (int)buf.msg_perm.cuid,
		      (int)buf.msg_perm.uid, 
		      buf.msg_qbytes);
	       printf("# Telegrammgroesse = %d Bytes\n", sizeof(rbuf));
           }
       }
       if (__builtin_expect(((server_pid = fork()) == 0),true))
       {
	  setsid();
	  // Faster than fast :)
          setpriority(PRIO_PROCESS, (unsigned int)getpid(), -20);
          while (1)
          {
             if (__builtin_expect(
		      (msgrcv(msqid, &rbuf, sizeof(rbuf), 0, 0) < 0) ,false))
             {
                 // Priod - msgrcv Queue[%x] %s", 
		 aie_sys_log(3, key, strerror(errno));
                 printf("%s(%d) Priod - msgrcv Queue[%x] %s\n", 
		       __FILE__, __LINE__, (int)key, strerror(errno));
                 break;
             }
             else
             {
                switch(rbuf.mtype)
                {
		    case MSG_PROG_PRIO:
                    {
                       NewPrio(&rbuf.ipc_prio_msg);
                    }
		    break;
		    case MSG_PROG_START:
                    {
                       start_prog(&rbuf.ipc_prog_start_msg);
                    }
		    break;
		    case MSG_PROG_KILL:
                    {
                       kill_prog(&rbuf.ipc_prog_kill_msg);
                    }
		    break;
		    default:
		    {
		       // Unbekanntes Telegramm %c
		       aie_sys_log(4, rbuf.mtype);
		       printf("%s(%d): Unbekanntes Telegramm %ld\n", __FILE__, __LINE__, rbuf.mtype);
		    }
                    break;
	        }
             }
          }
       }
       else
       {
	  printf("# Running as Pid %d\n", server_pid);
          #ifndef __CYGWIN__
	  // TODO: wo ist save_server_pid abgeblieben
             //save_server_pid(SERVER_NAME, server_pid);
          #endif
	  printf("#");
          aie_star_line(78, '-');
          printf("# %s - Version: %s\n", AIENGINE_LANGNAME, AIENGINE_VERSION);
          aie_star_line(79, '#');
       }
    }
    return(0);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : NewPrio                                                   */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool NewPrio(struct ipc_prio_msg *ipc_prio_msg)
{
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "NewPrio" },
      { AIE_LOG_SERVER_INFO, "Signal fuer %s[%d]" }
   };
   #endif
   bool rc = true;
    
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   #ifndef __CYGWIN__
   //char *prog = ipc_prio_msg->cgi_name;
   setpriority(PRIO_PROCESS, (unsigned int)ipc_prio_msg->pid, 
                             ipc_prio_msg->new_prio);
   if (ipc_prio_msg->want_signal)
   {
      // Signal; back that we have finished 
      kill(ipc_prio_msg->pid, SIGUSR1);
      // Signal fuer %s[%d]
      #if AIENGINE_LOG_TRACE_SERVER_TRACE
      aie_sys_log(1, ipc_prio_msg->prog_name, ipc_prio_msg->new_prio);
      #endif
   }
#if 0
      int new_prio = ipc_prio_msg->new_prio;
      id_t pid = ipc_prio_msg->pid;

      setpriority(PRIO_PROCESS, pid, new_prio);
#endif
   #else
      ipc_prio_msg = ipc_prio_msg;
   #endif

   return(rc);
}
/*---------------------------------------------------------------------------*/
bool start_prog(struct ipc_prog_start_msg *ipc_prog_start_msg)
{
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "start_prog [%s]" },
      { AIE_LOG_SERVER_INFO, "Programm starten %s" }
   };
   #endif
   char *prog = ipc_prog_start_msg->prog;
    
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0, prog);
   #endif
   if (*prog != '\0')
   {
      // TODO: Pfad hier dynamisch !
         char progname[AIE_LEN_PROG_NAME + 1];
         //printf("%s(%d): Programm starten %s\n", __FILE__, __LINE__, prog);
         sprintf(progname, "/aIEngine/server/%s -r &", prog);
         // Programm starten %s
         #if AIENGINE_LOG_TRACE_SERVER_TRACE
         aie_sys_log(1, progname);
         #endif
         system(progname);
   }
   return(true);
}

bool kill_prog(struct ipc_prog_kill_msg *ipc_prog_kill_msg)
{
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "kill_prog [%s]" },
      { AIE_LOG_SERVER_INFO, "Programm Kill %s Pid[%d]" }
   };
   #endif

   char *prog = ipc_prog_kill_msg->prog;
   pid_t pid = ipc_prog_kill_msg->pid;
    
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0, prog);
   #endif
   if (*prog != '\0')
   {
         //printf("%s(%d): Programm Kill %s Pid[%d]\n", __FILE__, __LINE__, 
	 //                                             prog, pid);
         // Programm Kill %s Pid[%d]
         #if AIENGINE_LOG_TRACE_SERVER_TRACE
         aie_sys_log(1, prog, pid);
         #endif
	 kill(pid, SIGHUP);
   }
   return(true);
}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_priod_size      = __LINE__;                                //
/* -------------------------------- EOF ------------------------------------ */

