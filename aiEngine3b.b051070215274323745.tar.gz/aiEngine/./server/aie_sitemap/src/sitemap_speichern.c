/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : sitemap_speichern.c                                         */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 31.05.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Server fuer @Secur(tm) Internet Engine & HTML Generator                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Back to the roots und c++ overhaed vermeiden*/
/*.............+...............+.............................................*/
/* 13.06.2004  : ALH           : Konstanten als const deklariert             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sitemap_speichern_version      = "1.0.0";                  //
const char *modul_sitemap_speichern              = "Speichern";              //
const char *modul_sitemap_speichern_date         = __DATE__;                 //
const char *modul_sitemap_speichern_time         = __TIME__;                 //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_CLIENT_LIB			1			     //
#define AIENGINE_USE_SQL_WRAP_LIB		1			     //
#define AIENGINE_USE_DB_LIB		 	1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <ctype.h>                                                           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "sitemap_speichern.h"                                               //
#include "srv_sitemap.h"                                                     //
#include "sitemap_fkt.h"                                                     //
#include "sitemap_server_reply.h"                                            //
#include "sitemap_define.h"                                                  //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sitemap_sql_meta_db;                  //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer des Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool sitemap_url_sql_speichern_update(struct                          //
                                             ipc_sitemap_server_save_msg     //
                                            *ipc_sitemap_server_save_msg);   //
static bool select_sitemap_info(struct aie_sql_data *aie_sql_data,           //
                                char *url, char *path);                      //
static int aie_select_sitemap_info_callback(void *pArg, int nArg,            //
                                            char **azArg, char **azCol);     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static char SitemapUrlPathRunCount[AIE_SITEMAP_RUN_COUNT_LEN + 1];
static char SitemapUrlPathRunTime[AIE_SITEMAP_RUN_TIME_LEN + 1];
static bool hasCallbackData = false;                                         //
                                                                             //
/*****************************************************************************/

void sitemap_url_speichern(int msgid, 
	                   struct ipc_sitemap_server_save_msg 
			          *ipc_sitemap_server_save_msg)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "sitemap_url_speichern" },
      { AIE_LOG_WARN,  "Nicht SQL gespeichert [%s]" },
   };
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   strcpy(SitemapUrlPathRunCount, "1");
   memset(SitemapUrlPathRunTime, '\0', sizeof(SitemapUrlPathRunTime));
   strncpy(SitemapUrlPathRunTime, ipc_sitemap_server_save_msg->run_time,
	                          AIE_SITEMAP_RUN_TIME_LEN);
   if (__builtin_expect(
	    (!sitemap_url_sql_speichern_update(ipc_sitemap_server_save_msg)),
	                                                                false))
   {
      // Nicht SQL gespeichert [%s]
      aie_sys_log(1, ipc_sitemap_server_save_msg->url);
      send_sitemap_server_speichern_reply(msgid, 
                                          ipc_sitemap_server_save_msg->url,
	                                  AIE_STATUS_SITEMAP_SPEICHERN_FAIL);
   }
   else
   {
      send_sitemap_server_speichern_reply(msgid, 
	                                  ipc_sitemap_server_save_msg->url,
	                                  AIE_STATUS_SITEMAP_SPEICHERN_OK);
   }
} 

static bool sitemap_url_sql_speichern_update(struct ipc_sitemap_server_save_msg 
                                                   *ipc_sitemap_server_save_msg)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "sitemap_url_sql_speichern_update" },
      { AIE_LOG_WARN,  "Update Fehler [%s] [%s]" },
      { AIE_LOG_WARN,  "Insert Fehler [%s] [%s]" },
      { AIE_LOG_ERROR, "Sitemap Speichern/Update - Datenbank Fehler %s" }
   };
   char *timestamp = aie_get_time_stamp();
   bool rc;
   struct aie_sql_meta_feld_value_list sql_meta_feld_value_list[] =
   {
      { is_aie_SitemapInfoUrlSqlFld, 	ipc_sitemap_server_save_msg->url   },
//      { is_aie_SitemapAgentSqlFld, ipc_sitemap_server_msg->agent	},
      { is_aie_SitemapInfoPathSqlFld, 	ipc_sitemap_server_save_msg->path  },
      { is_aie_SitemapInfoRunTimeSqlFld, SitemapUrlPathRunTime 	   },
      { is_aie_SitemapInfoSizeSqlFld, 	ipc_sitemap_server_save_msg->size  },
      { is_aie_SitemapInfoLastAccessSqlFld, timestamp 			   },
      { is_aie_RunCountSqlFld, 		SitemapUrlPathRunCount 		   }
   };
   struct aie_sql_meta_where_value_list sql_meta_where_value_list[] =
   {
      { AIE_SQL_WHERE, 
	 is_aie_SitemapInfoUrlSqlFld, 	
	 AIE_SQL_WHERE_EQUAL, 
	 ipc_sitemap_server_save_msg->url
      },
      { AIE_SQL_WHERE_AND,
	 is_aie_SitemapInfoPathSqlFld,
 	 AIE_SQL_WHERE_EQUAL,
	 ipc_sitemap_server_save_msg->path  
      }
   };
   struct aie_sql_meta_insert sql_meta_insert =
   {
      AIE_DB_TABLE_ID_SITEMAP_INFO,
      true,
      sql_meta_feld_value_list,
      sizeof(sql_meta_feld_value_list) / 
      sizeof(struct aie_sql_meta_feld_value_list),
      false, 
      &aiengine_sitemap_sql_meta_db
   };
   struct aie_sql_meta_update sql_meta_update =
   {
      AIE_DB_TABLE_ID_SITEMAP_INFO,
      true,
      sql_meta_feld_value_list,
      sizeof(sql_meta_feld_value_list) / 
      sizeof(struct aie_sql_meta_feld_value_list),
      sql_meta_where_value_list,
      sizeof(sql_meta_where_value_list) / 
      sizeof(struct aie_sql_meta_where_value_list),
      false, 
      &aiengine_sitemap_sql_meta_db
   };
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   // Workaround a little no matter bug
   if (*(ipc_sitemap_server_save_msg->path + 
	    strlen(ipc_sitemap_server_save_msg->path) - 1) == '&')
   {
      *(ipc_sitemap_server_save_msg->path + 
	    strlen(ipc_sitemap_server_save_msg->path) - 1) = '\0';
   }
   hasCallbackData = false;
   if (select_sitemap_info(aiengine_sitemap_sql_meta_db.aie_sql_data,
                           ipc_sitemap_server_save_msg->url,
                           ipc_sitemap_server_save_msg->path))
   {
      if (!(rc = aie_sql_meta_table_update(&sql_meta_update)))
      {
         // Update Fehler [%s] [%s]
         aie_sys_log(1, ipc_sitemap_server_save_msg->url,
                        ipc_sitemap_server_save_msg->path);
      }
   }
   else
   {
      if (!(rc = aie_sql_meta_table_insert(&sql_meta_insert)))
      {
          // Insert Fehler [%s] [%s]
          aie_sys_log(2, ipc_sitemap_server_save_msg->url,
                         ipc_sitemap_server_save_msg->path);
      }
   }
   if (!rc)
   {
      // Sitemap Speichern/Update - Datenbank Fehler %s
      aie_sys_log(3, aie_sql_meta_error(&aiengine_sitemap_sql_meta_db));
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static int aie_select_sitemap_info_callback(void *pArg, int nArg, char **azArg,
		                                       char **azCol)
{
   register int i;
   pArg = pArg;
   hasCallbackData = true;
   for(i = 0; i < nArg; i++)
   {
      if (strcmp(azCol[i], is_aie_RunCountSqlFld) == 0)
      {
         if (azArg[i] != NULL)
         {
            sprintf(SitemapUrlPathRunCount, "%ld", atol(azArg[i]) + 1);
         }
      }
      else if (strcmp(azCol[i], is_aie_SitemapInfoRunTimeSqlFld) == 0)
      {
         if (azArg[i] != NULL)
         {
            sprintf(SitemapUrlPathRunTime, "%ld", 
		           (atol(azArg[i]) + atol(SitemapUrlPathRunTime)) / 2);
         }
      }
   }
   return(0);
}

static bool select_sitemap_info(struct aie_sql_data *aie_sql_data,
                                char *url, char *path)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "select_sitemap_info" },
      { AIE_LOG_ERROR, "Out of Memory?" },
      { AIE_LOG_ERROR, "Datenbank nicht initialisiert!" }
   };
   if (aie_sql_data != NULL)
   {
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_select_sitemap_info_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = NULL;
         sprintf(sql_cmd, "SELECT %s FROM %s "
	                  "WHERE %s='%s' "
			  " AND  %s='%s' ",
                                   is_aie_RunCountSqlFld,
				   AIE_DB_TABLE_SITEMAP_INFO,
				   is_aie_SitemapInfoUrlSqlFld,
				   url, 
				   is_aie_SitemapInfoPathSqlFld,
				   path);
         if (!aie_sql_run(aie_sql_data))
         {
            aie_sql_meta_log_error(&aiengine_sitemap_sql_meta_db, sql_cmd, __FILE__,
		                                                  __LINE__);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(1);
      }
   }
   else
   {
      // Datenbank nicht initialisiert!
      aie_sys_log(2);
   }
   return(hasCallbackData);
}
/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
int   modul_sitemap_speichern_size         = __LINE__;                       //
/* -------------------------------- EOF ------------------------------------ */

