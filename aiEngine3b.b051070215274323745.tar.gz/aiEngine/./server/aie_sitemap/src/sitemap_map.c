/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : server.c                                                    */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 12.05.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sitemaps_map_version      = "1.0.0";                       //
const char *modul_sitemaps_map_name         = "SitemapMap";                  //
const char *modul_sitemaps_map_date         = __DATE__;                      //
const char *modul_sitemaps_map_time         = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_CLIENT_LIB			1			     //
#define AIENGINE_USE_SQL_WRAP_LIB		1			     //
#define AIENGINE_USE_DB_LIB			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "sitemaps.h"                                                        //
#include "sitemap_server_reply.h"                                            //
#include "sitemap_map.h"                                                     //
#include "sitemap_define.h"                                                  //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sitemap_sql_meta_db;                  //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct sitemap_url_select_callback_data
{
   int msgid;
   char *url;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static int aie_select_sitemap_url_info_callback(void *pArg, int nArg,        //
                                                char **azArg,                //
		                                char **azCol);               //
static bool select_sitemap_url_info(struct sitemap_url_select_callback_data  //
                                         *sitemap_url_select_callback_data); //
									     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static bool hasCallbackData = false;                                         //
                                                                             //
/*****************************************************************************/

void generate_sitemap(int msgid, struct ipc_sitemap_server_msg
                                       *ipc_sitemap_server_msg)
{
   struct sitemap_url_select_callback_data sitemap_url_select_callback_data;
   ipc_sitemap_server_msg = ipc_sitemap_server_msg;
   //sys_log("%s(%d): Generate Sitemap", __FILE__, __LINE__);
   generate_sitemap_header(msgid, MSG_SITEMAP_SERVER_MAP_REQUEST,
	                          ipc_sitemap_server_msg);
   sitemap_url_select_callback_data.msgid = msgid;
   sitemap_url_select_callback_data.url = ipc_sitemap_server_msg->url;
   hasCallbackData = false;
   if (!select_sitemap_url_info(&sitemap_url_select_callback_data))
   {
      char buffer[AIE_SITEMAP_LINE_LEN + 1];
      char *ts = aie_get_time_stamp();
      char year[5];
      char month[3];
      char day[3];
      strncpy(year, ts, 4);
      strncpy(month, ts+4, 2);
      strncpy(day, ts+6, 2);

      sprintf(buffer, "<url>\n<loc>http://%s/</loc>\n", 
	                                        ipc_sitemap_server_msg->url);
      send_sitemap_server_line_reply(msgid, buffer, false);
      sprintf(buffer, "<lastmod>%s-%s-%s</lastmod>\n", year, month, day);
      send_sitemap_server_line_reply(msgid, buffer, false);
      sprintf(buffer, "<changefreq>monthly</changefreq>\n");
      send_sitemap_server_line_reply(msgid, buffer, false);
      sprintf(buffer, "<priority>1.0</priority>\n");
      send_sitemap_server_line_reply(msgid, buffer, false);
      send_sitemap_server_line_reply(msgid, "</url>", false);
   }
   send_sitemap_server_line_reply(msgid, SITEMAP_FOOTER, true);
}

static bool select_sitemap_url_info(struct sitemap_url_select_callback_data 
                                           *sitemap_url_select_callback_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "select_sitemap_url_info" },
      { AIE_LOG_ERROR, "Out of Memory?" },
      { AIE_LOG_ERROR, "Datenbank nicht initialisiert!" }
   };
   struct aie_sql_data *aie_sql_data = aiengine_sitemap_sql_meta_db.aie_sql_data;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (aie_sql_data != NULL)
   {
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_select_sitemap_url_info_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = sitemap_url_select_callback_data;
         sprintf(sql_cmd, "SELECT %s, %s, %s, %s, %s FROM %s "
	                  "WHERE %s='%s' "
			  " ORDER BY %s ",
                                   /*is_aie_SitemapInfoUrlSqlFld,*/
                                   is_aie_SitemapInfoPathSqlFld,
                                   is_aie_SitemapInfoSizeSqlFld,
                                   is_aie_SitemapInfoLastAccessSqlFld,
                                   is_aie_SitemapInfoRunTimeSqlFld,
                                   is_aie_RunCountSqlFld,
				   AIE_DB_TABLE_SITEMAP_INFO,
				   is_aie_SitemapInfoUrlSqlFld,
				   sitemap_url_select_callback_data->url,
                                   is_aie_SitemapInfoPathSqlFld);
         if (!aie_sql_run(aie_sql_data))
         {
            aie_sql_meta_log_error(&aiengine_sitemap_sql_meta_db, sql_cmd, __FILE__,
		                                                  __LINE__);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(1);
      }
   }
   else
   {
      // Datenbank nicht initialisiert!
      aie_sys_log(2);
   }
   return(hasCallbackData);
}
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static int aie_select_sitemap_url_info_callback(void *pArg, int nArg, 
                                                char **azArg,
		                                char **azCol)
{
   static long maxAccessed = 0;
   long Accessed = 0;
   char buffer[AIE_SITEMAP_LINE_LEN + 1];
   register int i;
   struct sitemap_url_select_callback_data *callback_data = 
            (struct sitemap_url_select_callback_data *)
	       ((struct aie_sql_data *)pArg)->data;
   hasCallbackData = true;
   send_sitemap_server_line_reply(callback_data->msgid, "<url>\n", false);
   for(i = 0; i < nArg; i++)
   {
      *buffer = '\0';
      if (strcmp(azCol[i], is_aie_SitemapInfoPathSqlFld) == 0)
      {
         if (azArg[i] != NULL)
         {
            sprintf(buffer, "<loc>http://%s%s</loc>\n", 
	                                        callback_data->url,
						azArg[i]);
	 }
      }
      else if (strcmp(azCol[i], is_aie_SitemapInfoLastAccessSqlFld) == 0)
      {
         if (azArg[i] != NULL)
         {
            char year[5];
            char month[3];
            char day[3];
	    *(year + sizeof(year)-1) = '\0';
	    *(month + sizeof(month)-1) = '\0';
	    *(day + sizeof(day)-1) = '\0';
            strncpy(year, azArg[i], 4);
            strncpy(month, azArg[i]+4, 2);
            strncpy(day, azArg[i]+6, 2);
            sprintf(buffer, "<lastmod>%s-%s-%s</lastmod>\n", year, month, day);
	 }
      }
      else if (strcmp(azCol[i], is_aie_RunCountSqlFld) == 0)
      {
         if (azArg[i] != NULL)
         {
            //sprintf(buffer, "<requested>%s</requested>\n", azArg[i]);
            //sprintf(buffer, "<!-- Requested %s Times -->\n", azArg[i]);
	    if ((Accessed = atol(azArg[i])) > maxAccessed)
	    {
	       maxAccessed = Accessed;
	    }
         }
      }
      else if (strcmp(azCol[i], is_aie_SitemapInfoRunTimeSqlFld) == 0)
      {
         if (azArg[i] != NULL)
         {
            //sprintf(buffer, "<downloadtime>%s</downloadtime>\n", azArg[i]);
            //sprintf(buffer, "<!-- Downloadtime: %s -->\n", azArg[i]);
         }
      }
      else if (strcmp(azCol[i], is_aie_SitemapInfoSizeSqlFld) == 0)
      {
         if (azArg[i] != NULL)
         {
            if (atol(azArg[i]) > 0)
	    {
               //sprintf(buffer, "<!-- Size: %s -->\n", azArg[i]);
               //sprintf(buffer, "<size>%s</size>\n", azArg[i]);
	    }
         }
      }
      if (__builtin_expect((*buffer != '\0'),true))
      {
         send_sitemap_server_line_reply(callback_data->msgid, buffer, false);
      }
   }
   sprintf(buffer, "<changefreq>monthly</changefreq>\n");
   send_sitemap_server_line_reply(callback_data->msgid, buffer, false);
   sprintf(buffer, "<priority>%1.2f</priority>\n", (float)((float)Accessed / 
	                                                (float)maxAccessed));
   send_sitemap_server_line_reply(callback_data->msgid, buffer, false);
   send_sitemap_server_line_reply(callback_data->msgid, "</url>\n", false);
   return(0);
}

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_sitemaps_map_size         = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
