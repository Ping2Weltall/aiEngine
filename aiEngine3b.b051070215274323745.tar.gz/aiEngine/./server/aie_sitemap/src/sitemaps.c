/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : server.c                                                    */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 12.05.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sitemaps_version          = "1.0.0";                       //
const char *modul_sitemaps_name             = "Sitemaps";                    //
const char *modul_sitemaps_date             = __DATE__;                      //
const char *modul_sitemaps_time             = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_CLIENT_LIB			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "sitemaps.h"                                                        //
#include "sitemap_server_reply.h"                                            //
#include "sitemap_tags.h"                                                    //
#include "sitemap_define.h"                                                  //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

void generate_sitemap_header(int msgid, int typ,
                                    struct ipc_sitemap_server_msg
			                   *ipc_sitemap_server_msg)
{
   char buffer[AIE_SITEMAP_LINE_LEN + 1];
   send_sitemap_server_line_reply(msgid, XML_HEADER, false);
   send_sitemap_server_line_reply(msgid, XML_COMMENT_START, false);
   send_sitemap_server_line_reply(msgid, AIENGINE_LANGNAME" - ", false);
   send_sitemap_server_line_reply(msgid, AIENGINE_VERSION"\n", false);
   send_sitemap_server_line_reply(msgid, aIEngine_Copyright_1, false);
   send_sitemap_server_line_reply(msgid, "\nServer: aIEngineSitemapD\n", false);
   send_sitemap_server_line_reply(msgid, "Homepage: http://www.aIEngine.org\n", false);
   send_sitemap_server_line_reply(msgid, 
                              "Author: Alexander J. Herrmann\n", false);
   send_sitemap_server_line_reply(msgid, 
	                       "Email: Alexander@aIEngine.org\n", false);
   send_sitemap_server_line_reply(msgid, "\nGenerating: Site Map", false);
   switch (typ)
   {
      case MSG_SITEMAP_SERVER_INDEX_REQUEST:
	 {
            send_sitemap_server_line_reply(msgid, "Index\n", false);
	 }
	 break;
      case MSG_SITEMAP_SERVER_MAP_REQUEST:
	 {
            send_sitemap_server_line_reply(msgid, "\n", false);
	 }
	 break;
   }
   sprintf(buffer, "Processing: %s\n",  ipc_sitemap_server_msg->url);
   send_sitemap_server_line_reply(msgid, buffer, false);
   sprintf(buffer, "Output: %s\n",  ipc_sitemap_server_msg->result);
   send_sitemap_server_line_reply(msgid, buffer, false);
   sprintf(buffer, "Generated for: %s\n",  ipc_sitemap_server_msg->agent);
   send_sitemap_server_line_reply(msgid, buffer, false);
   sprintf(buffer, "Feeding to: %s:%s\n\n",  ipc_sitemap_server_msg->ip,
                                           ipc_sitemap_server_msg->port);
   send_sitemap_server_line_reply(msgid, buffer, false);
   sprintf(buffer, "Timestamp: %s\n", aie_get_time_stamp());
   send_sitemap_server_line_reply(msgid, buffer, false);
   send_sitemap_server_line_reply(msgid, XML_COMMENT_END, false);
   if (typ == MSG_SITEMAP_SERVER_MAP_REQUEST)
   {
      send_sitemap_server_line_reply(msgid, SITEMAP_HEADER, false);
   }
   else if (typ == MSG_SITEMAP_SERVER_INDEX_REQUEST)
   {
      send_sitemap_server_line_reply(msgid, SITEINDEX_HEADER, false);
   }
}
/*---------------------------------------------------------------------------*/

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_sitemaps_size             = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
