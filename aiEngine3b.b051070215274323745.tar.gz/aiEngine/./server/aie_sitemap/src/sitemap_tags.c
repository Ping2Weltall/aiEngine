/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : server.c                                                    */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 12.05.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sitemaps_tags_version          = "1.0.0";                  //
const char *modul_sitemaps_tags_name             = "SitemapTags";            //
const char *modul_sitemaps_tags_date             = __DATE__;                 //
const char *modul_sitemaps_tags_time             = __TIME__;                 //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_CLIENT_LIB			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "sitemaps.h"                                                        //
#include "sitemap_tags.h"                                                    //
#include "sitemap_server_reply.h"                                            //
#include "sitemap_define.h"                                                  //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

void aie_sitemap_environment_tag(int msgid, int level, const char *version, 
                                 struct aie_sitemap_environment 
                                        *sitemap_environment)
{
   char *buffer = aie_malloc(AIE_SITEMAP_LINE_LEN + 1);
   if (buffer != NULL)
   {
      memset(buffer, '\0', AIE_SITEMAP_LINE_LEN + 1);
      send_sitemap_server_line_reply(msgid, "<environment>\n", false);
      if (__builtin_expect((level == AIE_SITEMAP_TAGS_TOP_LEVEL), false))
      {
         sprintf(buffer, "<generator>%s - %s</generator>\n", AIENGINE_LANGNAME, 
	                                           AIENGINE_VERSION); 
         send_sitemap_server_line_reply(msgid, buffer, false);
	 if (__builtin_expect(((version != NULL) && (*version != '\0')), true))
	 {
            sprintf(buffer, "<version>%s</version>\n", version);
            send_sitemap_server_line_reply(msgid, buffer, false);
	 }
         if (__builtin_expect(
	                (*sitemap_environment->server_software != '\0'),true))
         {
            sprintf(buffer, "<server>%s</server>\n", 
	                              sitemap_environment->server_software);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         send_sitemap_server_line_reply(msgid, 
	                          "<ossystem>686-pc-linux-gnu</ossystem>\n", 
				  false); 
         send_sitemap_server_line_reply(msgid, "<language>", false);
         send_sitemap_server_line_reply(msgid, "de, ch, deutsch", false);
         send_sitemap_server_line_reply(msgid, "</language>\n", false);
      }
      else
      {
         if (__builtin_expect((*sitemap_environment->generator != '\0'),true))
         {
            sprintf(buffer, "<generator>%s</generator>\n", 
                                     sitemap_environment->generator); 
            send_sitemap_server_line_reply(msgid, buffer, false);
	 }
         if (__builtin_expect((*sitemap_environment->language != '\0'),true))
         {
            sprintf(buffer, "<language>%s</language>\n", 
		                            sitemap_environment->language);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect(
	       (*sitemap_environment->server_software != '\0'),true))
         {
            sprintf(buffer, "<server>%s</server>\n", 
	                              sitemap_environment->server_software);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect(
	       (*sitemap_environment->operating_system != '\0'),true))
         {
            sprintf(buffer, "<ossystem>%s</ossystem>\n", 
	                              sitemap_environment->operating_system);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
      }
      aie_sitemap_company_tag(msgid, level, 
                                  &sitemap_environment->sitemap_company);
      aie_sitemap_webmaster_tag(msgid, level, 
                                    &sitemap_environment->sitemap_webmaster);
      aie_sitemap_robot_tag(msgid, level, &sitemap_environment->sitemap_robot);
      send_sitemap_server_line_reply(msgid, "</environment>\n", false);
      aie_free(buffer);
   }
}

void aie_sitemap_webmaster_tag(int msgid, int level,
                                      struct aie_sitemap_webmaster 
				             *sitemap_webmaster)
{
   if (__builtin_expect(((*sitemap_webmaster->name != '\0') ||
	                 (level == AIE_SITEMAP_TAGS_TOP_LEVEL)) ,true))
   {
      char *buffer = aie_malloc(AIE_SITEMAP_LINE_LEN + 1);
      if (buffer != NULL)
      {
         memset(buffer, '\0', AIE_SITEMAP_LINE_LEN + 1);
         send_sitemap_server_line_reply(msgid, "<webmaster>\n", false);
         if (__builtin_expect((level == AIE_SITEMAP_TAGS_TOP_LEVEL), false))
         {
            send_sitemap_server_line_reply(msgid, 
	                          "<name>Alexander J. Herrmann</name>\n", 
				  false);
            send_sitemap_server_line_reply(msgid, 
	                          "<email>Alexander@aiengine.org</email>\n", 
				  false);
         }
         else
         {
            if (__builtin_expect((*sitemap_webmaster->name != '\0'),true))
            {
               sprintf(buffer, "<name>%s</name>\n", sitemap_webmaster->name);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_webmaster->email != '\0'),true))
            {
               sprintf(buffer, "<email>%s</email>\n", sitemap_webmaster->email);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
         }
         send_sitemap_server_line_reply(msgid, "</webmaster>\n", false);
         aie_free(buffer);
      }
   }
}

void aie_sitemap_company_tag(int msgid, int level, struct aie_sitemap_company 
						          *company)
{
   if (__builtin_expect(((*company->name != '\0') ||
	                 (level == AIE_SITEMAP_TAGS_TOP_LEVEL)),true))
   {
      send_sitemap_server_line_reply(msgid, "<company>\n", false);
      if (__builtin_expect((level == AIE_SITEMAP_TAGS_TOP_LEVEL), false))
      {
         send_sitemap_server_line_reply(msgid, "<name>aIEngine.org</name>", false);
      }
      else
      {
         char *buffer = aie_malloc(AIE_SITEMAP_LINE_LEN + 1);
         if (buffer != NULL)
         {
            memset(buffer, '\0', AIE_SITEMAP_LINE_LEN + 1);
            if (__builtin_expect((*company->name != '\0'),true))
            {
               sprintf(buffer, "<name>%s</name>\n", company->name);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            aie_free(buffer);
         }
      }
      aie_sitemap_departement_tag(msgid, level,
	                                 &company->sitemap_department);
      send_sitemap_server_line_reply(msgid, "</company>\n", false);
   }
}

void aie_sitemap_departement_tag(int msgid, int level,
	                                 struct aie_sitemap_department
					        *sitemap_department)
{
   if (__builtin_expect(
	      ((*sitemap_department->name != '\0') ||
	       (level == AIE_SITEMAP_TAGS_TOP_LEVEL)),true))
   {
      char *buffer = aie_malloc(AIE_SITEMAP_LINE_LEN + 1);
      if (buffer != NULL)
      {
         memset(buffer, '\0', AIE_SITEMAP_LINE_LEN + 1);
         send_sitemap_server_line_reply(msgid, "<department>\n", false);
         if (__builtin_expect((level == AIE_SITEMAP_TAGS_TOP_LEVEL), false))
         {
            send_sitemap_server_line_reply(msgid, 
	                             "<name>aIEngine Generator Host</name>", 
				     false);
         }
         else
         {
            if (__builtin_expect(
	      (*sitemap_department->name != '\0'),true))
            {
               sprintf(buffer, "<name>%s</name>\n", sitemap_department->name);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
         }
         aie_sitemap_contact_tag(msgid, level, 
                                &sitemap_department->sitemap_contact);
         send_sitemap_server_line_reply(msgid, "</department>\n", false);
         aie_free(buffer);
      }
   }
}

void aie_sitemap_contact_tag(int msgid, int level, 
                                    struct aie_sitemap_contact 
				           *sitemap_contact)
{

   if (__builtin_expect(((*sitemap_contact->email != '\0') ||
	                 (level == AIE_SITEMAP_TAGS_TOP_LEVEL)),true))
   {
      send_sitemap_server_line_reply(msgid, "<contact>\n", false);
      if (__builtin_expect((level == AIE_SITEMAP_TAGS_TOP_LEVEL), false))
      {
         send_sitemap_server_line_reply(msgid, 
	                             "<email>info@aiengine.org</email>\n", 
				     false);
         send_sitemap_server_line_reply(msgid, 
	                             "<street>129/110 Soi Kantang 7</street>\n",
				     false);
         send_sitemap_server_line_reply(msgid, "<zip>92000</zip>\n", false);
         send_sitemap_server_line_reply(msgid, "<town>Trang</town>\n", false);
         send_sitemap_server_line_reply(msgid, 
                                     "<province>Ampue Muang</province>\n",
				     false);
         send_sitemap_server_line_reply(msgid, 
                                  "<country>Thailand</country>\n", false);
         send_sitemap_server_line_reply(msgid, "<phone>06-2701801</phone>\n", 
                                    false);
         send_sitemap_server_line_reply(msgid, "<fax>n.a.</fax>\n", false);
      }
      else
      {
         char *buffer = aie_malloc(AIE_SITEMAP_LINE_LEN + 1);
         if (buffer != NULL)
         {
            memset(buffer, '\0', AIE_SITEMAP_LINE_LEN + 1);
            if (__builtin_expect((*sitemap_contact->email != '\0'),true))
            {
               sprintf(buffer, "<email>%s</email>\n", sitemap_contact->email);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_contact->street != '\0'),true))
            {
               sprintf(buffer, "<street>%s</street>\n", sitemap_contact->street);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_contact->zip != '\0'),true))
            {
               sprintf(buffer, "<zip>%s</zip>\n", sitemap_contact->zip);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_contact->town != '\0'),true))
            {
               sprintf(buffer, "<town>%s</town>\n", sitemap_contact->town);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_contact->province != '\0'),true))
            {
               sprintf(buffer, "<province>%s</province>\n", 
	                                         sitemap_contact->province);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_contact->country != '\0'),true))
            {
               sprintf(buffer, "<country>%s</country>\n", 
		                                    sitemap_contact->country);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_contact->phone != '\0'),true))
            {
               sprintf(buffer, "<phone>%s</phone>\n", sitemap_contact->phone);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            if (__builtin_expect((*sitemap_contact->fax != '\0'),true))
            {
               sprintf(buffer, "<fax>%s</fax>\n", sitemap_contact->fax);
               send_sitemap_server_line_reply(msgid, buffer, false);
            }
            aie_free(buffer);
         }
      }
      send_sitemap_server_line_reply(msgid, "</contact>\n", false);
   }
}

void aie_sitemap_robot_tag(int msgid, int level, 
                           struct aie_sitemap_robot *sitemap_robot)
{
   send_sitemap_server_line_reply(msgid, "<robot>\n", false);
   if (__builtin_expect((level == AIE_SITEMAP_TAGS_TOP_LEVEL), false))
   {
      send_sitemap_server_line_reply(msgid, 
	         "<title>@Secur Sitemap Generators - Sitemap Deamon</title>\n",
		 false);
      send_sitemap_server_line_reply(msgid, 
                        "<description>"
			"Generates Sitemaps Index "
			"and Sitemaps on the fly."
			"</description>\n", false);
      send_sitemap_server_line_reply(msgid, 
	                       "<publisher>aIEngine.org</publisher>\n", false);
   }
   else
   {
      char *buffer = aie_malloc(AIE_SITEMAP_LINE_LEN + 1);
      if (buffer != NULL)
      {
         memset(buffer, '\0', AIE_SITEMAP_LINE_LEN + 1);
         if (__builtin_expect((*sitemap_robot->title != '\0'),true))
         {
            sprintf(buffer, "<title>%s</title>\n", sitemap_robot->title);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->description != '\0'),true))
         {
            sprintf(buffer, "<description>%s</description>\n", 
		                          sitemap_robot->description);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->publisher != '\0'),true))
         {
            sprintf(buffer, "<publisher>%s</publisher>\n", 
		                            sitemap_robot->publisher);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->robots != '\0'),true))
         {
            sprintf(buffer, "<scope>%s</scope>\n", sitemap_robot->robots);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->channel != '\0'),true))
         {
            sprintf(buffer, "<channel>%s</channel>\n", 
		                             sitemap_robot->channel);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->classification != '\0'),true))
         {
            sprintf(buffer, "<classification>%s</classification>\n", 
		                      sitemap_robot->classification);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->audience != '\0'),true))
         {
            sprintf(buffer, "<audience>%s</audience>\n", 
		                            sitemap_robot->audience);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->info != '\0'),true))
         {
            sprintf(buffer, "<info>%s</info>\n", sitemap_robot->info);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->resource_typ != '\0'),true))
         {
            sprintf(buffer, "<resource>%s</resource>\n", 
		                         sitemap_robot->resource_typ);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         if (__builtin_expect((*sitemap_robot->revisit_after != '\0'),true))
         {
            sprintf(buffer, "<revisit>%s</revisit>\n", 
		                        sitemap_robot->revisit_after);
            send_sitemap_server_line_reply(msgid, buffer, false);
         }
         aie_free(buffer);
      }
   }
   send_sitemap_server_line_reply(msgid, "</robot>\n", false);
}

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_sitemaps_tags_size        = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
