/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_server_init.c                                           */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.09.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 21.08.2005  : ALH           : Init Anpassung an Version 2.5.5             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_server_init_version       = "1.0.2";                       //
const char *modul_server_init_name          = "ServerInit";                  //
const char *modul_server_init_date          = __DATE__;                      //
const char *modul_server_init_time          = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_SQL_WRAP_LIB		1			     //
#define AIENGINE_USE_DB_LIB			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //

/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "sitemap_fkt.h"                                                     //
#include "sitemap_server_init.h"                                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sitemap_sql_meta_db;                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static struct aie_sql_data *InitSitemapDB(void);                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
#if 0
struct aie_sql_db_init_sequence
{
   const char *pragma;
   const char *value;
} ff_sql_db_init_sequence[] =
{
   { "PRAGMA default_temp_store = %s", "MEMORY" },
   { "PRAGMA synchronous = %s", "OFF" },
   { "PRAGMA cache_size = %s", "3000" },
};
unsigned int size_aktuell_db_init_sequence = sizeof(aktuell_db_init_sequence) /
                                      sizeof(struct aktuell_db_init_sequence);
                                                                             //
#endif   
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : int (0 = success)                                         */
/*...........................................................................*/

bool sitemap_server_init(struct tel_server_init *is_tel_server_init)
{
   //bool rc = true;
   // is_tel_server_init->msg_typ - Typ der Initialisierung
   return(is_tel_server_init == is_tel_server_init);
   //return(rc);
}

bool sitemap_server_socket_start(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "sitemap_server_socket_start" },
      { AIE_LOG_ERROR, "Sitemapserver: Socket start mit Null Ptr" }
   };
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (is_tel_server_fkt == NULL)
   {
      // Sitemapserver: Socket start mit Null Ptr
      aie_sys_log(1);
      return(false);
   }
   else
   {
      if ((InitSitemapDB()) == NULL)
      {
         return(false);
      }
   }
   return(true);
}

static struct aie_sql_data *InitSitemapDB(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "InitSitemapDB" },
      { AIE_LOG_ERROR, "Datenbank Fehler beim Oeffnen \"%s\"" },
      { AIE_LOG_SERVER_INFO, "Datenbank [%s] nun offen!" }
   };
   struct aie_sql_data *aie_sql_data = NULL;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if ((aie_sql_data = aie_sql_meta_attach_db(AIE_DB_ID_SITEMAPS, 
		                              &aiengine_sitemap_sql_meta_db)) == NULL)
   {
      // Datenbank Fehler beim Oeffnen \"%s\"
      aie_sys_log(1, AIENGINE_DATABASE);
   }
   else
   {
      aie_sql_data->callback = NULL;
      aie_sql_data->data = NULL;
      aie_sql_data->sql_rc = 0;
      // Datenbank [%s] nun offen!", 
      aie_sys_log(2, AIENGINE_DATABASE);
   }
   return(aie_sql_data);
}

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_server_init_size          = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
