/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : sitemap_index.c                                             */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 12.05.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sitemap_index_version       = "1.0.0";                     //
const char *modul_sitemap_index_name          = "SitemapIndex";              //
const char *modul_sitemap_index_date          = __DATE__;                    //
const char *modul_sitemap_index_time          = __TIME__;                    //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_CLIENT_LIB			1			     //
#define AIENGINE_USE_SQL_WRAP_LIB		1			     //
#define AIENGINE_USE_DB_LIB			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "sitemaps.h"                                                        //
#include "sitemap_server_reply.h"                                            //
#include "sitemap_tags.h"                                                    //
#include "sitemap_index.h"                                                   //
#include "sitemap_define.h"                                                  //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sitemap_sql_meta_db;                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct sitemap_url_select_callback_data
{
   int msgid;
   char *url;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool select_sitemap_index_info(struct sitemap_url_select_callback_data 
                                           *sitemap_url_select_callback_data);
static int aie_select_sitemap_index_info_callback(void *pArg, int nArg, 
                                                char **azArg,
		                                char **azCol);
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static bool hasCallbackData = false;                                         //
static unsigned long anzahlUrl = 0;                                          //
                                                                             //
/*****************************************************************************/

void generate_sitemapindex(int msgid, struct ipc_sitemap_server_msg
                                       *ipc_sitemap_server_msg)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "generate_sitemapindex" },
      { AIE_LOG_ERROR, "No Sitemap Index data" }
   };
   struct sitemap_url_select_callback_data sitemap_url_select_callback_data;
   char buffer[AIE_SITEMAP_LINE_LEN + 1];
   char *ts = aie_get_time_stamp();
   char year[5];
   char month[3];
   char day[3];
   int level = AIE_SITEMAP_TAGS_TOP_LEVEL;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif

   memset(year, '\0', sizeof(year));
   memset(month, '\0', sizeof(month));
   memset(day, '\0', sizeof(day));
   strncpy(year, ts, 4);
   strncpy(month, ts+4, 2);
   strncpy(day, ts+6, 2);

   generate_sitemap_header(msgid, MSG_SITEMAP_SERVER_INDEX_REQUEST,
	                          ipc_sitemap_server_msg);
   aie_sitemap_environment_tag(msgid, level, modul_sitemap_index_version,
	                       &ipc_sitemap_server_msg->sitemap_environment);
   level++;
   sitemap_url_select_callback_data.msgid = msgid;
   sitemap_url_select_callback_data.url = ipc_sitemap_server_msg->url;
   anzahlUrl = 0; 
   hasCallbackData = false;
   if (select_sitemap_index_info(&sitemap_url_select_callback_data))
   {
      send_sitemap_server_line_reply(msgid, "<sitemap>\n", false);
      sprintf(buffer, "<loc>http://%s%s</loc>\n", 
	           ipc_sitemap_server_msg->url, AIE_SITEMAP_NAME);
      send_sitemap_server_line_reply(msgid, buffer, false);
      sprintf(buffer, "<lastmod>%s-%s-%sT00:00:00+01:00</lastmod>\n", year, 
		                                                    month, 
								    day);
      send_sitemap_server_line_reply(msgid, buffer, false);
      sprintf(buffer, "<size>%ld</size>\n", anzahlUrl);
      send_sitemap_server_line_reply(msgid, buffer, false);
      aie_sitemap_environment_tag(msgid, level, NULL,
	                       &ipc_sitemap_server_msg->sitemap_environment);
      send_sitemap_server_line_reply(msgid, "</sitemap>\n", false);
   }
   else
   {
      send_sitemap_server_line_reply(msgid, 
	    "<!-- No Sitemap Data availible at the moment. -->\n", false);
      // No Sitemap Index data
      aie_sys_log(1);
   }
   send_sitemap_server_line_reply(msgid, SITEINDEX_FOOTER, true);
}

static bool select_sitemap_index_info(struct sitemap_url_select_callback_data 
                                           *sitemap_url_select_callback_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "select_sitemap_index_info" },
      { AIE_LOG_ERROR, "Out of Memory?" },
      { AIE_LOG_ERROR, "Datenbank nicht initialisiert!" }
   };
   struct aie_sql_data *aie_sql_data = aiengine_sitemap_sql_meta_db.aie_sql_data;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (aie_sql_data != NULL)
   {
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_select_sitemap_index_info_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = NULL;
         sprintf(sql_cmd, "SELECT count(Url) FROM %s "
	                  "WHERE %s='%s' ",
				   AIE_DB_TABLE_SITEMAP_INFO,
				   is_aie_SitemapInfoUrlSqlFld,
				   sitemap_url_select_callback_data->url);
	 //sys_log("%s(%d): SQL[%s]", __FILE__, __LINE__, sql_cmd);
         if (!aie_sql_run(aie_sql_data))
         {
            aie_sql_meta_log_error(&aiengine_sitemap_sql_meta_db, sql_cmd, __FILE__,
		                                                  __LINE__);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(1);
      }
   }
   else
   {
      // Datenbank nicht initialisiert!
      aie_sys_log(2);
   }
   return(hasCallbackData);
}
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static int aie_select_sitemap_index_info_callback(void *pArg, int nArg, 
                                                char **azArg,
		                                char **azCol)
{
   register int i;
   pArg = pArg;
   //sys_log("%s(%d): Where here ... i=%d azArg=%s col=%s", 
   //	               __FILE__, __LINE__, nArg,
   //	              azArg[0], azCol[0]);
   hasCallbackData = true;
   for(i = 0; i < nArg; i++)
   {
      if (strcmp(azCol[i], "count(Url)") == 0)
      {
         if (azArg[i] != NULL)
         {
	    anzahlUrl = atol(azArg[i]);
	 }
      }
   }
   return(0);
}
/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_sitemap_index_size        = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
