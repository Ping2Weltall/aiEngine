/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : server.c                                                    */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 12.05.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_server_version            = "1.0.0";                       //
const char *modul_server_name               = "aIEngineSitemapD";            //
const char *modul_server_date               = __DATE__;                      //
const char *modul_server_time               = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_SOCKETS			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //

#define AIE_SERVER_RUN_DIR 	        AIENGINE_SUB_DATA_DIR \
                                        //"/data/generator/sitemaps/"
#define AIE_SERVER_BASIS_DIR		AIENGINE_ROOT_DATA_DIR
#define AIE_SERVER_SOCKET		SOCKET_SITEMAP_ADDRESS_BASE
#define AIE_SERVER_LANGNAME		AIENGINE_LANGNAME
#define AIE_SERVER_COPYRIGHT            aIEngine_Copyright_1 
#define AIE_SERVER_AUTHOR		"Alexander J. Herrmann"
#define SERVER_RUN_PRIORITY		AIE_SERVER_STANDARD_RUN_PRIORITY
#define SERVER_RECEIVE_TEL_TIMEOUT	10

#define SERVER_RECEIVE_TEL_BUF		sitemap_server_msgbuf
//#define CALLBACK_RECEIVE_TEL_FUNKTION	do_datenverarbeitung
#define SERVER_TEL_STOP			MSG_SITEMAP_SERVER_STOP
#define SERVER_TEL_START		MSG_SITEMAP_SERVER_START

/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <sys/types.h>                                                       //
#include <sys/ipc.h>                                                         //
#include <sys/msg.h>                                                         //
#include <sys/time.h>                                                        //
#include <sys/resource.h>                                                    //
#include <unistd.h>                                                          //
#include <stdio.h>                                                           //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "srv_sitemap.h"                                                     //
#include "sitemaps.h"                                                        //
#include "sitemap_index.h"                                                   //
#include "sitemap_map.h"                                                     //
#include "sitemap_speichern.h"                                               //
#include "sitemap_server_init.h"                                             //
#include "sitemap_server_reply.h"                                            //
#include "sitemap_server_exit.h"                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static int do_datenverarbeitung(struct tel_server_fkt *is_tel_server_fkt);   //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
   
struct tel_server_dispatch_list tel_server_dispatch_list[] =
{
   {
      MSG_SITEMAP_SERVER_INDEX_REQUEST, 
      &do_datenverarbeitung	
   },
   {
      MSG_SITEMAP_SERVER_MAP_REQUEST, 
      &do_datenverarbeitung	
   },
   {
      MSG_SITEMAP_SERVER_URL_SPEICHERN, 
      &do_datenverarbeitung	
   }
};
const unsigned int size_tel_server_dispatch_list = 
                                     sizeof(tel_server_dispatch_list) /
                                     sizeof(struct tel_server_dispatch_list);
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : int (0 = success)                                         */
/*...........................................................................*/
AIE_SERVER_MAIN
{
   struct SERVER_RECEIVE_TEL_BUF rbuf;
   int rc_usr_fkt = -1;
   struct tel_server_init is_tel_server_init =
   {
      AIE_SERVER_USERID,
      AIE_SERVER_GROUPID,
      AIE_SERVER_LANGNAME,
      modul_server_name,
      modul_server_version,
      modul_server_date,
      modul_server_time,
      AIE_SERVER_AUTHOR,
      AIE_SERVER_COPYRIGHT,
      AIE_SERVER_RUN_DIR,
      AIE_SERVER_BASIS_DIR,
      sitemap_server_init,
      MSG_SITEMAP_SERVER_START,
      sitemap_server_socket_start,
      MSG_SITEMAP_SERVER_STOP,
      sitemap_server_socket_stop,
      sitemap_server_exit,
      tel_server_dispatch_list,
      size_tel_server_dispatch_list,
      &rc_usr_fkt,
      AIE_SERVER_SOCKET,
      SERVER_RUN_PRIORITY,
      SERVER_RECEIVE_TEL_TIMEOUT,
      (void *)&rbuf,
      sizeof(rbuf),
      0,
      __FILE__,
      __LINE__,
      NULL /* *tel_server_fkt */
   };
   if (aie_server_fkt_init(argc, argv, &is_tel_server_init))
   {    
      aie_server_fkt_run(&is_tel_server_init);
      aie_server_fkt_exit(&is_tel_server_init);
   }
   return(0);
}

/*---------------------------------------------------------------------------*/

static int do_datenverarbeitung(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "do_datenverarbeitung" },
      { AIE_LOG_ERROR, "Unbekanntes Telegramm %d" }
   };
   int msgid = is_tel_server_fkt->socket->msgid;
   struct SERVER_RECEIVE_TEL_BUF *rbuf;
   int rc = RC_SERVER_TEL_UNKNOWN;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   rbuf = (struct SERVER_RECEIVE_TEL_BUF *)is_tel_server_fkt->buf;

   switch(is_tel_server_fkt->socket->mtype)
   {
      case MSG_SITEMAP_SERVER_INDEX_REQUEST: 
      {
	 struct ipc_sitemap_server_msg *ipc_sitemap_server_msg = 
	              &rbuf->m.ipc_sitemap_server_msg;
         generate_sitemapindex(msgid, ipc_sitemap_server_msg);
	 rc = RC_SERVER_TEL_USER_FKT;
	 is_tel_server_fkt->socket->exit_server = false;
      }
      break;
      case MSG_SITEMAP_SERVER_MAP_REQUEST:
      {
	 struct ipc_sitemap_server_msg *ipc_sitemap_server_msg = 
	              &rbuf->m.ipc_sitemap_server_msg;
         generate_sitemap(msgid, ipc_sitemap_server_msg);
	 rc = RC_SERVER_TEL_USER_FKT;
	 is_tel_server_fkt->socket->exit_server = false;
      }
      break;
      case MSG_SITEMAP_SERVER_URL_SPEICHERN:
      {
	 struct ipc_sitemap_server_save_msg *ipc_sitemap_server_save_msg = 
	              &rbuf->m.ipc_sitemap_server_save_msg;
         sitemap_url_speichern(msgid, ipc_sitemap_server_save_msg);
	 rc = RC_SERVER_TEL_USER_FKT;
	 is_tel_server_fkt->socket->exit_server = false;
      }
      break;
      default:
      {
         // Unbekanntes Telegramm %d
         aie_sys_log(1, is_tel_server_fkt->socket->mtype);
         rc = RC_SERVER_TEL_MSG_UNKNOWN;
	 is_tel_server_fkt->socket->exit_server = true;
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_server_size               = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
