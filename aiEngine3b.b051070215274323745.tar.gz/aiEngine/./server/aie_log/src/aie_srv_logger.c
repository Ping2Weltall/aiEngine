/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : aie_logger.c                                                */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 15.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Ermittelt Schluesselworter aus den vorgegebenen URL's                     */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Der Modulname (CGI) wird nun mit gelogt     */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 14.06.2004  : ALH           : Konstanten als const deklariert             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_logger_version        = "1.0.0";                           //
const char *modul_logger                = "aIEngineLogD";                    //
const char *modul_logger_date           = __DATE__;                          //
const char *modul_logger_time           = __TIME__;                          //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_LOG_LIB			1

#define SERVER_NAME	modul_logger                                         //
#define SERVER_VERSION	modul_logger_version                                 //
/*---------------------------------------------------------------------------*/
/* System Header Dateien                                                     */
/*...........................................................................*/
#include <sys/types.h>                                                       //
#include <sys/ipc.h>                                                         //
#include <sys/msg.h>                                                         //
#include <unistd.h>                                                          //
#include <stdio.h>                                                           //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool write_log_msg(struct aie_ipc_log_msg *ipc_log_msg);              //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     :                                                           */
/* Rueckgabewert : int - immer 0 ( 0 = OK)                                   */
/*...........................................................................*/
int main(void)
{
    int msqid;
    key_t key;
    struct aie_log_msgbuf rbuf;
    pid_t server_pid;
    aie_star_line(79, '#');
    printf("# %s Version %s\n# Build : %s %s\n", SERVER_NAME, SERVER_VERSION, 
	                                         modul_logger_date, 
						 modul_logger_time);
    printf("# Author: Alexander J. Herrmann\n");
    printf("# (C) 2003-05, @Secur - Alexander J. Herrmann\n");
    printf("#");
    aie_star_line(78, '-');
    key = AIENGINE_PROG_QUEUE_ID;
    key |= MSG_PROG_LOG;
    if (__builtin_expect(
	     ((msqid = msgget(key, IPC_CREAT | 0666)) < 0),false))
    {
	printf("%s(%d): Fehler beim Oeffnen der Queue: %s\n", __FILE__, 
	                                                      __LINE__, 
							      strerror(errno));
        perror("Fehler beim Oeffnen der Inputqueue");
    }
    else
    {
       struct msqid_ds buf;
       struct msqid_ds change_buf;
       if (__builtin_expect(
		(msgctl(msqid, IPC_STAT, &buf) == 0),true))
       {
           memcpy(&change_buf, &buf, sizeof(change_buf));
	   change_buf.msg_qbytes = 65000;
           if (__builtin_expect((msgctl(msqid, IPC_SET, &change_buf) != 0),
		                                                        false))
           {
	      printf("%s(%d): msgctl: %s\n", __FILE__, __LINE__, 
		                                             strerror(errno));
              printf("# Couldn't change Queue %d - never mind.\n", msqid);
           }
           if (__builtin_expect(
		    (msgctl(msqid, IPC_STAT, &buf) == 0),true))
           {
	       printf("# Message Queue: \t%d\n"
		      "# Owner: \t%d\n"
		      "# Creator: \t%d\n"
                      "# Size: \t%ld bytes\n"
		      "# MsgSize: \t%d", msqid, 
		      (int)buf.msg_perm.cuid,
		      (int)buf.msg_perm.uid,
		      buf.msg_qbytes, (int)sizeof(rbuf));
           }
       }
       if (__builtin_expect(((server_pid = fork()) == 0),true))
       {
	  printf("%s(%d): id[%d] Warten auf Logmsg\n", __FILE__, __LINE__, 
		                                      msqid);
	  setsid();
	  //setgid(AIE_SERVER_GROUPID);
	  //setuid(AIE_SERVER_USERID);
          while (1)
          {
	 // printf("%s(%d): id[%d] Warten auf Logmsg\n", __FILE__, __LINE__, 
	//	                                      msqid);
             if (__builtin_expect(
		      (msgrcv(msqid, &rbuf, sizeof(rbuf), 0, 0) < 0),false))
             {
		printf("%s(%d): id[%d] msgrcv: %s\n", __FILE__, __LINE__, 
		                                      msqid, 
		                                      strerror(errno));
                 break;
             }
             else
             {
	  //printf("%s(%d): id[%d] Logmsg empfangen\n", __FILE__, __LINE__, 
	//	                                      msqid);
                switch(rbuf.mtype)
                {
		    case MSG_PROG_LOG:
                    {
                       write_log_msg(&rbuf.ipc_log_msg);
                    }
                    break;
	        }

             }
          }
       }
       else
       {
          printf("# Running as Pid %d\n", server_pid);
          printf("#");
          aie_star_line(78, '-');
          printf("# %s - Version: %s\n", AIENGINE_LANGNAME, AIENGINE_VERSION);
          aie_star_line(79, '#');
	  // TODO: save_server_pid obsolete?
	  //save_server_pid(SERVER_NAME, server_pid);
       }
    }
    return(0);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : write_log_msg                                             */
/* Parameter     :                                                           */
/* Rueckgabewert : bool (true = OK)                                          */
/*...........................................................................*/
static bool write_log_msg(struct aie_ipc_log_msg *ipc_log_msg)
{
   bool rc = true;
   FILE *fptr;
   char *file_path = ipc_log_msg->logfile;
   char *modul = ipc_log_msg->log_prog;
   char *ip = ipc_log_msg->log_ip;
   char *outp = ipc_log_msg->log_msg;
   char *sptr = outp;
   while (*sptr != '\0')
   {
      if (*sptr == '\n')
      {
	 *sptr = ' ';
      }
      else
      {
	 if (*sptr < ' ')
	 {
	    *sptr = '?';
	 }
      }
      sptr++;
   }

   if (__builtin_expect(
	    ((fptr = aie_open_append_text_file(file_path)) != NULL),true))
   {
      fprintf(fptr, "%s@%s-%s[%s]\n", aie_get_time_stamp(), modul, ip, outp);
      aie_close_file(fptr);
   }
   else
   {
      printf("%s(%d): Fehler log[%s]\n", __FILE__, __LINE__, file_path);
      rc = false;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_logger_size           = __LINE__;                          //
/* -------------------------------- EOF ------------------------------------ */

