/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : aIEngine KeyServer                                          */
/* Include     : keys.hpp                                                    */
/* Server      : aIEngineKeyD                                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 19.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator        */
/* Keyserverdemon - zustaendig fuer ver-/entschluesselung.                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/* 14.06.2004  : ALH           : Konstanten als const deklariert             */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef KEYS_SRV_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define KEYS_SRV_H
#define KEY_PATH	"/aIEngine/data/aiengine/keys/"
#define KEY_PRIVATE	KEY_PATH"privat"
#define KEY_PUBLIC 	KEY_PATH"public"


#define AIE_SERVER_RUN_DIR 	        AIENGINE_SUB_DATA_DIR \
                                        //"/data/generator/sitemaps/"
#define AIE_SERVER_BASIS_DIR		AIENGINE_ROOT_DATA_DIR
#define AIE_SERVER_SOCKET		SOCKET_KEYS_ADDRESS_BASE
#define AIE_SERVER_LANGNAME		AIENGINE_LANGNAME
#define AIE_SERVER_COPYRIGHT            aIEngine_Copyright_1 
#define AIE_SERVER_AUTHOR		"Alexander J. Herrmann"
#define SERVER_RUN_PRIORITY		(AIE_SERVER_STANDARD_RUN_PRIORITY - 1)
#define SERVER_RECEIVE_TEL_TIMEOUT	10

#define SERVER_RECEIVE_TEL_BUF		key_server_msgbuf
//#define CALLBACK_RECEIVE_TEL_FUNKTION	do_datenverarbeitung
#define SERVER_TEL_STOP			MSG_KEY_SERVER_STOP
#define SERVER_TEL_START		MSG_KEY_SERVER_START
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
//#include AIENGINE_CRYPTO_INCLUDE

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

