/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : aIEngine KeyServer                                          */
/* Include     : keys.h                                                      */
/* Server      : aIEngineKeyD                                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 19.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator        */
/* Keyserverdemon - zustaendig fuer ver-/entschluesselung.                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/* 14.06.2004  : ALH           : Konstanten als const deklariert             */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_KEYS_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_KEYS_H

#define KEY_COMBINED			0	
#define KEY_SPLIT			1

#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#include AIENGINE_CRYPTO_INCLUDE
#include AIENGINE_ZIP_INCLUDE

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
bool init_keyfunktions(void);
const char *do_code_string(const char *s);
char *do_decode_string(const char *s);
//bool load_create_keys(const char *public_key_file, 
//                      const char *private_key_file);
struct is_coded_string *rsa_encode (unsigned char *in, unsigned int len);
unsigned char *rsa_decode(struct is_coded_string *is_coded_string);
//char *hash_crc(unsigned long crcDA, char *file, int line);
char *make_secret_mykey(char **secret_key);
void free_secret_mykey(char **secret_key);
void create_send_challenge(int msgid, char *from_cgi, char *plain);
unsigned long GetKeyId(struct tm *tm);
//void create_send_password_hash(int msgid, const char *from_cgi, 
//                          const char *plain, const char *challenge);

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

