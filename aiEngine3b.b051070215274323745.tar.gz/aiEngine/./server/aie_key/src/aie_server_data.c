/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_server_data.c                                           */
/* Server      : aIEngineKeyD                                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 20.08.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aie_server_data_version   = "1.0.0";                       //
const char *modul_aie_server_data           = "ServerData";                  //
const char *modul_aie_server_data_date      = __DATE__;                      //
const char *modul_aie_server_data_time      = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aiengine_server.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "keys.h"                                                            //
#include "aie_server_data.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
unsigned char *tmp_out_buf = NULL;
unsigned char *tmp_private_out = NULL;
unsigned char *tmp_public_out = NULL;
struct mykeys mykeys;                                                        //
long key_limit = 2048; // 1024;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

bool get_temp_key_storage(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "get_temp_key_storage" },
      { AIE_LOG_WARN, "Temp Speicher nicht NULL!" },
      { AIE_LOG_ERROR, "get_temp_key_storage malloc failed!" }
   };
   bool rc = true;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((tmp_out_buf != NULL) ||
                         (tmp_private_out != NULL) ||
                         (tmp_public_out != NULL)) , false))
   {
      // Temp Speicher nicht NULL!
      aie_sys_log(1);
      free_temp_key_storage();
   }
   if (__builtin_expect(
	    ((tmp_out_buf = aie_malloc(SIZE_KEY_STORAGE_OUT_BUF_LEN + 1)) 
	                                                             != NULL),
	                                                                 true))
   {
      if (__builtin_expect(
	    ((tmp_private_out = 
	                    aie_malloc(SIZE_KEY_STORAGE_PRIVATE_OUT_LEN + 1)) 
	                                                     != NULL), true))
      {
         if (__builtin_expect(
	       ((tmp_public_out =
		              aie_malloc(SIZE_KEY_STORAGE_PUBLIC_OUT_LEN + 1)) 
	                                                     == NULL), false))
         {
	    // get_key_temp_storage malloc failed!
            aie_sys_log(2);
	    rc = false;
         }
      }
      else
      {
         // get_key_temp_storage malloc failed!
         aie_sys_log(2);
	 rc = false;
      }
   }
   else
   {
      // get_key_temp_storage malloc failed!
      aie_sys_log(2);
      rc = false;
   }
   if (__builtin_expect((rc == false), false))
   {
      free_temp_key_storage();
   }
   return(rc);
}

void free_temp_key_storage(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "free_temp_key_storage" },
      { AIE_LOG_WARN,  "Temp Speicher NULL! %p %p %p" }
   };
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((tmp_out_buf == NULL) ||
                         (tmp_private_out == NULL) ||
                         (tmp_public_out == NULL)) , false))
   {
      // Temp Speicher NULL! %p %p %p
      aie_sys_log(1, tmp_out_buf, tmp_private_out, tmp_public_out);
   }
   if (__builtin_expect((tmp_out_buf != NULL), true))
   {
      aie_free(tmp_out_buf);
      tmp_out_buf = NULL;
   }
   if (__builtin_expect((tmp_private_out != NULL), true))
   {
      aie_free(tmp_private_out);
      tmp_private_out = NULL;
   }
   if (__builtin_expect((tmp_public_out != NULL), true))
   {
      aie_free(tmp_public_out);
      tmp_public_out = NULL;
   }
}
/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
int   modul_aie_server_data_size      = __LINE__;                            //
/* -------------------------------- EOF ------------------------------------ */
