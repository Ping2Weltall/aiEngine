/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : keys_srv.c                                                  */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 15.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet die Krypto Bibliothek                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/* 14.06.2004  : ALH           : Konstanten als const deklariert             */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 14.02.2005  : ALH           : Anpassungen an Cygwin                       */
/*             :               : User und Gruppen ID nicht setzten           */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_keys_srv_version        = "1.5.0";                         //
const char *modul_keys_srv_name           = "aIEngineKeyD";                  //
const char *modul_keys_srv_date           = __DATE__;                        //
const char *modul_keys_srv_time           = __TIME__;                        //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
//#define MY_SOCKET	SOCKET_KEYS_ADDRESS_BASE

#define modul_server_version            modul_keys_srv_version
#define modul_server_name               modul_keys_srv_name
#define modul_server_date               modul_keys_srv_date
#define modul_server_time               modul_keys_srv_time

/*---------------------------------------------------------------------------*/
/* System Include's fuer das Modul                                           */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aiengine_server.h"                                                 //
#include "aiengine_sockets.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "keys_srv.h"                                                        //
#include "keys.h"                                                            //
#include "hash_table.h"                                                      //
#include "aie_server_init.h"                                                 //
#include "aie_server_reply.h"                                                //
#include "aie_server_exit.h"                                                 //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static int do_datenverarbeitung(struct tel_server_fkt *is_tel_server_fkt);   //
static void code_decode(int msgid, int request, char *from_cgi, char *input);

/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/

struct tel_server_dispatch_list tel_server_dispatch_list[] =
{
   {
      MSG_KEY_SERVER_REQUEST_CODE,
      &do_datenverarbeitung	
   },
   {
      MSG_KEY_SERVER_REQUEST_DECODE,
      &do_datenverarbeitung	
   },
   {
      MSG_KEY_SERVER_GET_CHALLENGE,
      &do_datenverarbeitung	
   },
   {
      MSG_KEY_SERVER_HASH_PASSWORD,
      &do_datenverarbeitung	
   },
};
const unsigned int size_tel_server_dispatch_list = 
                                     sizeof(tel_server_dispatch_list) /
                                     sizeof(struct tel_server_dispatch_list);
                                                                             //
/*****************************************************************************/


AIE_SERVER_MAIN
{
   struct SERVER_RECEIVE_TEL_BUF rbuf;
   int rc_usr_fkt = -1;
   struct tel_server_init is_tel_server_init =
   {
      AIE_SERVER_USERID,
      AIE_SERVER_GROUPID,
      AIE_SERVER_LANGNAME,
      modul_server_name,
      modul_server_version,
      modul_server_date,
      modul_server_time,
      AIE_SERVER_AUTHOR,
      AIE_SERVER_COPYRIGHT,
      AIE_SERVER_RUN_DIR,
      AIE_SERVER_BASIS_DIR,
      keyd_server_init,
      SERVER_TEL_START,
      keyd_server_socket_start,
      SERVER_TEL_STOP,
      keyd_server_socket_stop,
      keyd_server_exit,
      tel_server_dispatch_list,
      size_tel_server_dispatch_list,
      &rc_usr_fkt,
      AIE_SERVER_SOCKET,
      SERVER_RUN_PRIORITY,
      SERVER_RECEIVE_TEL_TIMEOUT,
      (void *)&rbuf,
      sizeof(rbuf),
      0, // Internes Steuerflag 
      __FILE__,
      __LINE__,
      NULL /* *tel_server_fkt */
   };
   if (aie_server_fkt_init(argc, argv, &is_tel_server_init))
   {    
      aie_server_fkt_run(&is_tel_server_init);
      aie_server_fkt_exit(&is_tel_server_init);
   }
   return(0);
}
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static int do_datenverarbeitung(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: do_datenverarbeitung" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_datenverarbeitung: request [%c]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_datenverarbeitung: done [%c]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: GET_CHALLENGE" },
      { AIE_LOG_SERVER_INFO, "Keyserver: HASH_PASSWORD" },
      { AIE_LOG_ERROR, "Keyserver: do_datenverarbeitung: "
	               "Unbekanntes Telegramm: %d" },
      { AIE_LOG_ERROR, "Keyserver: do_datenverarbeitung: "
	               "Parameter == NULL Ptr" },
      { AIE_LOG_ERROR, "Keyserver: do_datenverarbeitung: Socket == NULL Ptr" }
   };
   struct SERVER_RECEIVE_TEL_BUF *rbuf;
   int rc = RC_SERVER_TEL_UNKNOWN;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((is_tel_server_fkt != NULL) &&
	                (is_tel_server_fkt->socket != NULL), true))
   {
      int msgid = is_tel_server_fkt->socket->msgid;
      rbuf = (struct SERVER_RECEIVE_TEL_BUF *)is_tel_server_fkt->buf;
      switch(is_tel_server_fkt->socket->mtype)
      {
         case MSG_KEY_SERVER_REQUEST_CODE:
         case MSG_KEY_SERVER_REQUEST_DECODE:
         {
	    char *to_code = rbuf->m.ipc_key_server_msg.buf;
	    char *from_cgi = rbuf->m.ipc_key_server_msg.cgi_name;
            #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
	    // Keyserver: do_datenverarbeitung: we have a request ... [%c]
            aie_sys_log(1, is_tel_server_fkt->socket->mtype);
            #endif
	    code_decode(msgid, rbuf->mtype, from_cgi, to_code);
            #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
	    // Keyserver: do_datenverarbeitung: done ... [%c]
            aie_sys_log(2, is_tel_server_fkt->socket->mtype);
            #endif
         }
         break;
         case MSG_KEY_SERVER_GET_CHALLENGE:
         {
	    char *plain = rbuf->m.ipc_key_server_msg.buf;
	    char *from_cgi = rbuf->m.ipc_key_server_msg.cgi_name;
            #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
	    // Keyserver: GET_CHALLENGE
            aie_sys_log(3);
            #endif
            create_send_challenge(msgid, from_cgi, plain);
         }
         break;
         case MSG_KEY_SERVER_HASH_PASSWORD:
         {
	    char *plain = rbuf->m.ipc_key_server_hash_password_msg.password;
	    char *challenge = rbuf->m.ipc_key_server_hash_password_msg.challenge;
	    char *from_cgi = rbuf->m.ipc_key_server_hash_password_msg.cgi_name;
            #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
	    // Keyserver: HASH_PASSWORD
            aie_sys_log(4);
            #endif
            create_send_password_hash(msgid, from_cgi, plain, challenge);
         }
         break;
         default:
         {
            // Keyserver: do_datenverarbeitung: Unbekanntes Telegramm: %d
            aie_sys_log(5, rbuf->mtype);
         }
      }
   }
   else
   {
      if (__builtin_expect((is_tel_server_fkt != NULL), false))
      {
         // Keyserver: do_datenverarbeitung: Parameter == NULL Ptr
         aie_sys_log(6);
      }
      else
      {
         // Keyserver: do_datenverarbeitung: Socket == NULL Ptr
         aie_sys_log(7);
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void code_decode(int msgid, int request, char *from_cgi, char *input)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: code_decode" },
      { AIE_LOG_SERVER_INFO, "Keyserver: code_decode: do_code_string ..." },
      { AIE_LOG_SERVER_INFO, "Keyserver: code_decode: do_decode_string ..." },
      { AIE_LOG_ERROR, "Keyserver: code_decode: Unbekannte Funktion: %d" }
   };
   const char *output = "Fehler";
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   switch(request)
   {
      case MSG_KEY_SERVER_REQUEST_CODE:
      {
            #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
            // Keyserver: code_decode: do_code_string ...
               aie_sys_log(1);
            #endif
            output = do_code_string(input);
      }
      break;
      case MSG_KEY_SERVER_REQUEST_DECODE:
      {
            #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
            // Keyserver: code_decode: do_decode_string ...
            aie_sys_log(2);
            #endif
            output = do_decode_string(input);
      }
      break;
      default:
      {
         // Keyserver: code_decode: Unbekannte Funktion: %d
         aie_sys_log(3, request);
      }
   }
   send_key_server_reply(msgid, from_cgi, output);
}
/*---------------------------------------------------------------------------*/


/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_keys_srv_size           = __LINE__;                        //
/* -------------------------------- EOF ------------------------------------ */

