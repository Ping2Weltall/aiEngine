/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_server_init.c                                           */
/* Server      : aIEngineKeyD                                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.09.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 21.08.2005  : ALH           : Anpassung an Version 3.0.0                  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_server_init_version       = "1.0.0";                       //
const char *modul_server_init_name          = "ServerInit";                  //
const char *modul_server_init_date          = __DATE__;                      //
const char *modul_server_init_time          = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aiengine_server.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_server_init.h"                                                 //
#include "aie_server_data.h"                                                 //
#include "hash_table.h"                                                      //
#include "keys_srv.h"                                                        //
#include "keys.h"                                                            //
#include "key_chain.h"                                                       //
#include "key_db.h"                                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sql_meta_db;                          //
extern struct mykeys mykeys;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
//static struct aie_sql_data *InitDB(void);
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static bool save_new_key = false;
#if 0
struct aie_sql_db_init_sequence
{
   const char *pragma;
   const char *value;
} ff_sql_db_init_sequence[] =
{
   { "PRAGMA default_temp_store = %s", "MEMORY" },
   { "PRAGMA synchronous = %s", "OFF" },
   { "PRAGMA cache_size = %s", "3000" },
};
unsigned int size_aktuell_db_init_sequence = sizeof(aktuell_db_init_sequence) /
                                      sizeof(struct aktuell_db_init_sequence);
                                                                             //
#endif   
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : int (0 = success)                                         */
/*...........................................................................*/

bool keyd_server_init(struct tel_server_init *is_tel_server_init)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,       "keyd_server_init Typ: %d" },
      { AIE_LOG_ERROR,       "Keyserver: Fehler beim starten!" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Server Prefork" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Server Key Change new[%x]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Server !key_db_find" },
      { AIE_LOG_SERVER_INFO, "Keyserver: key_chain_new_key_append == OK" },
      { AIE_LOG_ERROR,       "Keyserver: Problem bei new_key_append!" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Server Pastfork" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Server Save Key" },
      { AIE_LOG_ERROR,       "Keyserver: Unbekannte Initialisierung [%d]" },
      { AIE_LOG_ERROR,       "keyserver_init mit Parameter == NULL Ptr" }
   };
   bool rc = true;
   if (__builtin_expect((is_tel_server_init != NULL), true))
   {
      #if AIENGINE_LOG_TRACE_SERVER_TRACE
      aie_sys_log(0, is_tel_server_init->msg_typ);
      #endif
      switch(is_tel_server_init->msg_typ)
      {
         case AIE_SERVER_INIT_TYP_SERVER:
	 {
            fill_hash_table();
            if (__builtin_expect((init_keyfunktions() != true), false))
            {
               printf("%s(%d): Fehler beim starten!\n", __FILE__, __LINE__);
               // Keyserver: Fehler beim starten!
               aie_sys_log(1);
               rc = false;
            }
	 }
	 break;
         case AIE_SERVER_INIT_TYP_PREFORK:
	 {
            time_t t = time(NULL);
            struct tm *tm = localtime(&t);
	    unsigned long key_id = GetKeyId(tm);
            #if AIENGINE_LOG_TRACE_SERVER_TRACE
            // Keyserver: Server Prefork
            aie_sys_log(2);
            #endif
	    if (__builtin_expect((mykeys.key_id != key_id), false))
	    {
               #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
               // Keyserver: Server Key Change new[%x]
               aie_sys_log(3, key_id);
               #endif
               if (__builtin_expect((!key_chain_find(key_id, &mykeys)),
			                                             false))
	       {

		  char *hash_key_id = NULL;
		  hash_key_id = hash_crc(key_id);
                  if (__builtin_expect((!key_db_find(hash_key_id, &mykeys)),
			                                             false))
	          {
                     #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
                     // Keyserver: Server !key_db_find
                     aie_sys_log(4);
                     #endif
                     if (__builtin_expect((key_chain_new_key_append(key_id, 
			                                  &mykeys)), true))

		     {
                        #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
			// Keyserver: key_chain_new_key_append == OK
                        aie_sys_log(5);
                        #endif
	                save_new_key = true;
		     }
		     else
		     {
			// Keyserver: Problem bei new_key_append!
                        aie_sys_log(6);
		     }
		  }
	       }
	       mykeys.key_id = key_id;
	    }
	 }
	 break;
         case AIE_SERVER_INIT_TYP_PASTFORK:
	 {
            #if AIENGINE_LOG_TRACE_SERVER_TRACE
            // Keyserver: Server Pastfork
            aie_sys_log(7);
            #endif
	    if (__builtin_expect((save_new_key == true),false))
	    {
               #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
               // Keyserver: Server Save Key
               aie_sys_log(8);
               #endif
	       do_db_save_key(&mykeys);
	       save_new_key = false;
	    }
	 }
	 break;
         default:
	 {
            // Keyserver: Unbekannte Initialisierung [%d]
            aie_sys_log(9, is_tel_server_init->msg_typ);
            rc = false;
	 }
      }
   }
   else
   {
      // keyserver_init mit Parameter == NULL Ptr
      aie_sys_log(10);
      rc = false;
   }
   return(rc);
}

bool keyd_server_socket_start(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "keyd_server_socket_start" },
      { AIE_LOG_ERROR, "Socket start mit Null Ptr" }
   };
   #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((is_tel_server_fkt == NULL), false))
   {
      //  Socket start mit Null Ptr
      aie_sys_log(1);
      return(false);
   }
   return(true);
}


/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_server_init_size          = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
