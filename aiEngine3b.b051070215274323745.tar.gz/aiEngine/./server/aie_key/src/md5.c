/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : keys.c                                                      */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 15.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet die Krypto Bibliothek                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 27.02.2005  : ALH           : Anpassungen an Libtomcrypr 1.0r1            */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 14.06.2004  : ALH           : Konstanten als const deklariert             */
/*.............+...............+.............................................*/
/* 10.06.2004  : ALH           : Anpassung aller malloc,free,strdup an lib   */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_keys_version        = "1.0.0";                             //
const char *modul_keys                = "Key's";                             //
const char *modul_keys_date           = __DATE__;                            //
const char *modul_keys_time           = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define swap_hi_lo(a) { char t = *a; *a = *(a + 1); *(a + 1) = t; }          //
#define MAX_SECRET_KEY       512                                             //
#define CRC_SIZE_OFFSET		8                                            //
/*---------------------------------------------------------------------------*/
/* System Include's fuer das Modul                                           */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include AIENGINE_ZIP_INCLUDE
#include "keys.h"                                                            //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
extern char *is_hex;                                                         //
extern char *cgiQueryString;                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
extern struct mykeys mykeys;                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
union int_2_str                                                              //
{                                                                            //
   unsigned int z;                                                           //
   char str[4];                                                              //
};                                                                           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static char *hash_crc(unsigned long crc);                                            //
static char *hash_4_me(char *s);                                             //
static char *oops_stoned(char *s);                                           //
static bool register_algs(void);                                             //
static bool load_my_keys(const char *public_key_file,                        //
                         const char *private_key_file);                      //
static bool init_key_generator(const char *secret);                          //
static bool make_new_keypair(const char *public_key_file,                    //
                             const char *private_key_file);                  //
static bool make_challenge(char *from_cgi, char *plain, unsigned char *key_buf,
                                                   unsigned long *key_size);
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static char stoned[4];                                                       //
static int     errnum;                                                       //
static prng_state prng;                                                      //
static int prng_idx;
static int hash_idx;
static int md5_idx;

static const char *is_hash_hi =              "UgetmEaiSlAnd[*]?";            //
static const char *is_hash_lo =              "AlexIsBorEd!u4>$!";            //
union int_2_str int_2_str;                                                   //
const unsigned char lparam[] = AIENGINE_LANGNAME;
const unsigned long lparamlen = sizeof(lparam);
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void free_secret_mykey(char **secret_key)
{
   if (__builtin_expect((*secret_key != NULL),true))
   {
      aie_free(*secret_key);
      *secret_key = NULL;
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
const char *do_code_string(const char *s)
{
   struct is_coded_string *is_coded_string;
   static char is_coded[1024];
   const char *rc_ptr = s;
   register unsigned int x;
   char *sptr;
   unsigned long crc = crc32(0L, Z_NULL, 0);
   unsigned int len = strlen(s);
#if aie_do_uri_zip
   int rc;
   unsigned long compress_len = compressBound(len);
   Bytef *compress_buf = (Bytef *)aie_malloc(compress_len + 4);
#endif
   zeromem(is_coded, sizeof(is_coded));
#if aie_do_uri_zip
   //sys_log("Compress Buffer size = %d [%s]", compress_len, s);
   if (__builtin_expect(
	    ((rc = 
	      compress2(compress_buf + 4, 
		        &compress_len, 
			(Bytef *)s, len, 9)) != Z_OK),false))
   {
      sys_log("%s(%d): Error compress %s", __FILE__, __LINE__, zError(rc));
   }
   else
   {
         //sys_log("Buffer New = %d Compared to %d [%d:%d]", (unsigned int)compress_len, len, int_2_str.z, (unsigned int)*(compress_buf));
      int_2_str.z = compress_len;
      memcpy(compress_buf, int_2_str.str, 4);
      is_coded_string = rsa_encode ((unsigned char *)compress_buf, compress_len + 4);
#else 
      is_coded_string = rsa_encode ((unsigned char *)s, len);
#endif
      if (__builtin_expect((is_coded_string == NULL),false))
      {
         sys_log("%s(%d): Fehler NULL PTR:[%s]", __FILE__, __LINE__, s);
         //strcpy(is_coded, "ERROR!");
      }
      else
      {
          char *is_crc; 
          crc = crc32(crc, (Bytef *)is_coded_string->s, is_coded_string->len);
          is_crc = hash_crc(crc);
          //sys_log("%s(%d) Size coded[%d] Crc32[%.8x] myHash[%s]", __FILE__, __LINE__, is_coded_string->len, crc, is_crc);
	  //sys_log("%s(%d): Crc32 Info [%s] [%d]", __FILE__, __LINE__, is_crc, is_coded_string->len);
          memcpy(is_coded, is_crc, CRC_SIZE_OFFSET);
          for (x = 0; x < is_coded_string->len;x++)
          {
            char smallbuf[5];
            sprintf (smallbuf, "%.2x", *(is_coded_string->s + x) ^ 128 );
            if (__builtin_expect(((float)((float)x/3) == (int)(x/3)),false))
            {
              swap_hi_lo(smallbuf);
            }
            if (__builtin_expect(((sptr = hash_4_me(smallbuf)) == NULL),false))
            {
               sys_log("Fehler beim codieren %s(%d)", __FILE__, __LINE__);
               //strcpy(is_coded, "ERROR!");
            }
            else
            {
               if (__builtin_expect(((x * 2) > (sizeof(is_coded) - 3)),false))
               {
               }
               else
               {
                  memcpy(is_coded + (x * 2) + CRC_SIZE_OFFSET, sptr, 2);
               }
            }
         }
         aie_free(is_coded_string->s);
         //sys_log("Compress rc=%d", compress2(compress_buf, &compress_len, (Bytef *)is_coded, strlen(is_coded), 9));
         ////sys_log("Buffer New = %d Compared to %d [%s]", compress_len, strlen(is_coded), compress_buf);
	 rc_ptr = is_coded;
      }
#if aie_do_uri_zip
   }
   aie_free(compress_buf);
#endif
   //sys_log("%s(%d) Return [%s]", __FILE__, __LINE__, rc_ptr);
   return(rc_ptr);
   //return(is_coded);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *do_decode_string(const char *s)
{
   //static unsigned char is_decoded[1024];
   static Bytef                is_decoded[1024];
   int len = strlen(s);

   zeromem(is_decoded, sizeof(is_decoded));
   if (__builtin_expect((len <= CRC_SIZE_OFFSET),false))
   {
      sys_log("%s(%d): Fehlerhafter String[%s] Len[%d]", 
	                                          __FILE__, __LINE__, s, len);
   }
   else
   {
      unsigned char *buffer = (unsigned char *)aie_malloc(strlen(s));
      struct is_coded_string is_coded_string;
      unsigned char *sptr = buffer;
      int y;
      char *ptr_rsa_decode;
      char *is_crc;
      char has_crc[CRC_SIZE_OFFSET + 1];
      unsigned long crc = crc32(0L, Z_NULL, 0);

      zeromem(has_crc, sizeof(has_crc));
      memcpy(has_crc, s, CRC_SIZE_OFFSET);
      //for(int z = (CRC_SIZE_OFFSET); *(s + z) != '\0'; z +=2)
      for(int z = (CRC_SIZE_OFFSET); z < len ; z +=2)
      {
         char smallbuf[4];
         zeromem(smallbuf, sizeof(smallbuf));
         strncpy(smallbuf, s + z, 2);

         strncpy(smallbuf, oops_stoned(smallbuf), 2);
         if (__builtin_expect(
		  ((float)((float)(z-CRC_SIZE_OFFSET)/3) == 
		   (int)((int)((z-CRC_SIZE_OFFSET)/3))), false))
         {
            swap_hi_lo(smallbuf);
         }
         y = hextoint(smallbuf);
         *(sptr) = (unsigned char)(y ^ 128);
         sptr++;
      }
      is_coded_string.len = ((strlen(s) - CRC_SIZE_OFFSET) / 2);
      is_coded_string.s = buffer;
      crc = crc32(crc, (Bytef *)is_coded_string.s, is_coded_string.len);
      if (__builtin_expect((strcmp(is_crc = hash_crc(crc), has_crc)),false))
      {
	// sys_log("%s(%d): Crc32 Fehler [%s][%s] Info[%s]", __FILE__, __LINE__, is_crc, has_crc, s);
	 sys_log("%s(%d): Crc32 Fehler [%s][%s] ", __FILE__, __LINE__, is_crc, has_crc);
      }
      //sys_log("%s(%d) Size to decod[%d] Crc32[%x] Hashed[%s] hasCrc[%s]", __FILE__, __LINE__, is_coded_string.len, crc, is_crc, has_crc);
      if (__builtin_expect(
	       ((ptr_rsa_decode = 
		 (char *)rsa_decode(&is_coded_string)) != NULL),true))
      {
#if aie_do_uri_zip
	 int rc;
	 unsigned long decompress_len = sizeof(is_decoded);
	 unsigned long data_len; // = (int)*ptr_rsa_decode;
	 memcpy(int_2_str.str, ptr_rsa_decode, 4);
	 data_len = int_2_str.z;
         //sys_log("%s(%d) uncompress [%d] Bytes ", __FILE__, __LINE__, data_len);
#else
         strncpy((char *)is_decoded,
               ptr_rsa_decode,
               sizeof(is_decoded) - 1);
#endif
#if aie_do_uri_zip
	 if (__builtin_expect(
		  ((rc = 
		    uncompress(is_decoded, 
		               &decompress_len, 
			       (Bytef *)(ptr_rsa_decode + 4), 
		                                    data_len) != Z_OK)),false))
         {
	    sys_log("%s(%d): Error decompress %s", __FILE__, __LINE__, 
		                                   zError(rc));
	 }
#endif
      }
      aie_free(buffer);
   }
   return((char *)is_decoded);
}
/*---------------------------------------------------------------------------*/

static char *hash_crc(unsigned long crc)
{
   unsigned int x;
   char *sptr;
   char crc_s[sizeof(unsigned long)*2+1];
   static char is_crc[sizeof(unsigned long)*2+1];

   sprintf(crc_s, "%.8lx", crc);
   for (x = 0; x < sizeof(crc_s); x += 2)
   {
       char smallbuf[5];
       strncpy(smallbuf, (crc_s + x), 2);
       *(smallbuf + 3) = '\0';
       if (__builtin_expect(((float)((float)x/3) == (int)(x/3)),false))
       {
          swap_hi_lo(smallbuf);
       }
       if (__builtin_expect(((sptr = hash_4_me(smallbuf)) == NULL),false))
       {
          sys_log("%s(%d): Fehler beim codieren", __FILE__, __LINE__);
       }
       else
       {
          memcpy(is_crc + (x), sptr, 2);
       }
   }
   *(is_crc + sizeof(is_crc) - 1) = '\0';
   return(is_crc);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *hash_4_me(char *s)
{
   *(stoned + 2) = '\0';
   for (int z = 0; z < 16; z++)
   {
      if (__builtin_expect((*s == *(is_hex + z)),false))
      {
         *stoned = *(md5_hash_lo + z);
      }
      if (__builtin_expect((*(s + 1) == *(is_hex + z)),false))
      {
         *(stoned + 1) = *(md5_hash_hi + z);
      }
   }
    if (__builtin_expect((strlen(stoned) < 2),false))
    {
       exit(1);
    }
   return(stoned);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *oops_stoned(char *s)
{
   static char smoked[4];
   //zeromem(smoked, sizeof(smoked));
   *(smoked + 2) = '\0';
   for (int z = 0; z < 16; z++)
   {
      if (__builtin_expect((*s == *(is_hash_lo + z)),false))
      {
         *smoked = *(is_hex + z);
      }
      if (__builtin_expect((*(s + 1) == *(is_hash_hi + z)),false))
      {
         *(smoked + 1) = *(is_hex + z);
      }
   }
   return(smoked);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool init_keyfunktions(const char *secret)
{
   bool rc = true;
   if (__builtin_expect((init_key_generator(secret)==true),true))
   {
      rc = register_algs();
   }
   else
   {
      sys_log("%s(%d): Fehler Startup", __FILE__, __LINE__);
      rc = false;
   }
   //prng_idx = find_prng ("yarrow");  
   hash_idx = find_hash("sha1");
   prng_idx = find_prng("sprng");
   md5_idx = find_prng("sprng");
   //ltc_mp = tfm_desc;
   //sys_log("%s(%d): Init Keygenerator prng %d", __FILE__, __LINE__, prng_idx);
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool load_create_keys(const char *public_key_file, const char *private_key_file)
{
   bool rc = true;

    
  //sys_log("%s(%d): In Load Create Keys", __FILE__, __LINE__);
   if (!file_exist(public_key_file) || !file_exist(private_key_file))
   {
      sys_log("%s(%d): Need new Keypair", __FILE__, __LINE__);
      if (__builtin_expect(
	       (!make_new_keypair(public_key_file, private_key_file)),false))
      {
         rc = false;
      }
      else
      {
	 sys_log("%s(%d): Neues Schluesselpaar %s/%s erstellt", __FILE__, 
	                                                        __LINE__, 
							    public_key_file,
							    private_key_file); 
      }
   }
   if (rc)
   {
       rc = load_my_keys(public_key_file, private_key_file);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool load_my_keys(const char *public_key_file, 
                         const char *private_key_file)
{
   unsigned char in[4096], out[4096];
   FILE *fptr;
   bool rc = true;
   unsigned long out_len;
   unsigned int key_size;

   struct key_load_info
   {
      rsa_key *key;
      const char *file;
   } key_load_info[] =
   {
      { &mykeys.public_key, public_key_file },
      { &mykeys.private_key, private_key_file }
   };
   for(unsigned int z = 0;z < sizeof(key_load_info) / 
	                      sizeof(struct key_load_info);z++)
   {
      rsa_key *key = key_load_info[z].key;
      out_len = sizeof(out);

      if (__builtin_expect(
	       ((fptr = fopen(key_load_info[z].file, "rb")) != NULL),true))
      {
        zeromem (in, sizeof (in));
        key_size = fread(in, 1, sizeof(in), fptr);
        fclose(fptr);
        if (__builtin_expect(
		 ((errnum = 
		   base64_decode(in, key_size, out, &out_len)) 
		                                           != CRYPT_OK),false))
        {
           sys_log("%s(%d): Error: %s", __FILE__, __LINE__, 
		                                     error_to_string (errnum));
           return(false);
        }

        if (__builtin_expect(
		 ((errnum = 
		     rsa_import(out, out_len, key)) != CRYPT_OK),false))
        {
           sys_log ("%s(%d): Error: %s", __FILE__, __LINE__, 
		                                     error_to_string (errnum));
           return(false);
        }
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static bool register_algs(void)
{
   bool rc = true;

   ltc_mp = tfm_desc;
   //if (__builtin_expect((register_prng(&yarrow_desc) == -1),false))
   //{
   //  sys_log("%s(%d): Error registering yarrow PRNG", __FILE__, __LINE__);
   //  rc = false;
   // }
   if (register_prng(&sprng_desc) == -1) 
   {
      sys_log("%s(%d): Error registering sprng", __FILE__, __LINE__);
      rc = false;
   }
   /* register a math library (in this case TomFastMath) */
    if (register_hash(&sha1_desc) == -1) 
    {
       sys_log("%s(%d): Error registering sha1", __FILE__, __LINE__);
       rc = false;
    }
    /* register the hash */
    if (register_hash(&md5_desc) == -1) 
    {
       sys_log("%s(%d): Error registering MD5.", __FILE__, __LINE__);
       rc = false;
    }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool init_key_generator(const char *secret)
{
  // int z;
  // unsigned int y;
  bool rc = true;
  //struct tm *tm;
  //char str[80];
  //time_t t;
  #ifdef NOT_LINUX
  randomize();
  #endif
  secret = secret;
#if 0
  //sys_log("%s(%d): Init Keygenerator", __FILE__, __LINE__);
  if (__builtin_expect(((errnum = yarrow_start (&prng)) != CRYPT_OK),false))
  {
    sys_log ("%s(%d): yarrow_start: %s", __FILE__, __LINE__, 
	                                             error_to_string (errnum));
    rc = false;
  }
  //sys_log("%s(%d): Init Keygenerator OK", __FILE__, __LINE__);

  for (z = 0;z < 10 && rc;z++)
  {
     char ent[6];
     zeromem(ent, sizeof(ent));
     for (y = 0;y < sizeof(ent); y++)
     {
        *(ent + y) = (char )(rand() % 255);
     }
     if (__builtin_expect(
	      ((errnum = 
		yarrow_add_entropy ((unsigned char *)ent, 
		                    sizeof(ent), &prng)) != CRYPT_OK),false))
     {
       sys_log ("%s(%d): yarrow_add_entropy: %s", __FILE__, __LINE__,  
	                                             error_to_string (errnum));
       rc = false;
     }
     if (__builtin_expect(
	      ((errnum = 
		yarrow_add_entropy ((unsigned char *)secret, 
	                    sizeof(secret), &prng)) != CRYPT_OK),false))
     {
       sys_log ("%s(%d): yarrow_add_entropy: %s", __FILE__, __LINE__, 
	                                             error_to_string (errnum));
       rc = false;
     }
     t = time(NULL);
     tm = localtime(&t);
     strcpy(str, asctime(tm));

     //sys_log("%s(%d): Entropy Add 2", __FILE__, __LINE__);
     if (__builtin_expect(
	      ((errnum = 
		yarrow_add_entropy ((unsigned char *)str, 
		                    strlen(str), 
				    &prng)) != CRYPT_OK),false))
     {
       sys_log ("%s(%d): yarrow_add_entropy: %s", __FILE__, __LINE__, 
	                                             error_to_string (errnum));
       rc = false;
     }
  }
  //sys_log("%s(%d): Entropy Add OK", __FILE__, __LINE__);
  if (__builtin_expect(((errnum = yarrow_ready (&prng)) != CRYPT_OK),false))
  {
      sys_log ("%s(%d): yarrow_ready: %s", __FILE__, __LINE__, 
	                                             error_to_string (errnum));
       rc = false;
  } 
  //sys_log("%s(%d): Init Keygenerator OK", __FILE__, __LINE__);
#endif
  return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool make_new_keypair(const char *public_key_file, 
                             const char *private_key_file)
{
   rsa_key key;
   long limit = 2048; // 1024;
   FILE *fptr;
   bool rc = true;

   sys_log("%s(%d): Erstelle neues Keypair", __FILE__, __LINE__);
   if (__builtin_expect(
	    ((errnum =
              rsa_make_key (&prng, find_prng ("sprng"), limit / 8, 65537,
               &key)) != CRYPT_OK),false))
   {
       sys_log("%s(%d): Error: %s", __FILE__, __LINE__, 
	                            error_to_string (errnum));
       return(false);
   }
   else
   {
       unsigned char out[5000];
       unsigned char base64_out[5000];
       unsigned long sizeout;
       unsigned long size_base64out;
       //sys_log("%s(%d): Write new Keypair", __FILE__, __LINE__);

       zeromem (out, sizeof (out));
       zeromem (base64_out, sizeof (base64_out));

       sizeout = sizeof(out);
       size_base64out = sizeof(base64_out);
       rsa_export(out, &sizeout, PK_PRIVATE, &key);
       if (__builtin_expect(((errnum =
                base64_encode(out,  sizeout,
                        base64_out, &size_base64out)) != CRYPT_OK),false))
             {
                 sys_log ("4:Error: %s(%d): %s", __FILE__, __LINE__, error_to_string (errnum));
                 return(false);
             }
             zeromem(out, sizeof(out));
             if (__builtin_expect(
		      ((fptr = fopen(private_key_file, "wb")) != NULL),true))
             {
                fprintf(fptr, "%s", (char *)base64_out);
                fclose(fptr);
             }
	     else
             {
		sys_log("Problem Datei: [%s] %s(%d)", private_key_file, __FILE__, __LINE__);
	     }
             zeromem (out, sizeof (out));
             zeromem (base64_out, sizeof (base64_out));

             sizeout = sizeof(out);
             size_base64out = sizeof(base64_out);
             rsa_export(out, &sizeout, PK_PUBLIC, &key);
             if (__builtin_expect(((errnum =
                                       base64_encode(out,  sizeout,
                                                     base64_out, 
						     &size_base64out)) 
		                                    != CRYPT_OK),false))
             {
                 sys_log ("%s(%d): Error:  %s", __FILE__, __LINE__, 
		                                  error_to_string (errnum));
                 return(false);
             }
             if (__builtin_expect(
		      ((fptr = fopen(public_key_file, "wb")) != NULL),true))
             {
                fprintf(fptr, "%s", (char *)base64_out);
                fclose(fptr);
             }
	     else
             {
		sys_log("%s(%d): Problem Datei: [%s] ", __FILE__, __LINE__,
		                                        public_key_file);
	     }
   }
   rsa_free (&key);
  return(rc);
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : struct is_coded_string *                                  */
/*...........................................................................*/
struct is_coded_string *rsa_encode (unsigned char *in, unsigned int len)
{
   static struct is_coded_string is_coded_string;
   unsigned char out[4096];
   unsigned long y;
   //rsa_key *key;

   zeromem(out, sizeof(out));
   //key = &mykeys.public_key;
   y = sizeof (out);
   //if (__builtin_expect(((errnum = rsa_exptmod ((unsigned char *)in,
                                               // len,
                                               // out, &y,
			                       // PK_PUBLIC, 
                                               // key)) != CRYPT_OK),false))
   if (__builtin_expect(((errnum = rsa_encrypt_key ((unsigned char *)in,
                                                len,
                                                out, &y,
			                        lparam, lparamlen,
	       NULL, /* PRNG state */
	       prng_idx, /* prng idx */
	       hash_idx, /* hash idx */
               &mykeys.public_key)) != CRYPT_OK),false))
   {
            sys_log ("%s(%d): Len = %d Error: %s", __FILE__, __LINE__, len, 
						    error_to_string (errnum));
            return(NULL);
   }
   is_coded_string.len = y;
   is_coded_string.s = (unsigned char *)aie_malloc(y + 1);
   memcpy(is_coded_string.s, out, y);
   return(&is_coded_string);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : unsigned char *                                           */
/*...........................................................................*/
unsigned char *rsa_decode(struct is_coded_string *is_coded_string)
{
   static unsigned char out[4096];
   unsigned long x;
   int res = 0;
   //rsa_key *key;

   //key = &mykeys.private_key;

   x = sizeof(out);
   //sys_log ("%s(%d): Input Len = %d out=[%s]", __FILE__, __LINE__, 
//	is_coded_string->len, is_coded_string->s);
   //if (__builtin_expect(((errnum = rsa_exptmod (is_coded_string->s, 
		                               //is_coded_string->len, out, &x, 
		                               //PK_PRIVATE,
		                               //key)) != CRYPT_OK),false))
   if (__builtin_expect(((errnum = rsa_decrypt_key(is_coded_string->s, 
		                                is_coded_string->len, out, &x, 
		                                lparam, lparamlen, 
	    hash_idx, /* hash idx */
	    &res, /* validity of data */
            &mykeys.private_key )) != CRYPT_OK),false))
   {
      sys_log("%s(%d):Error: %s", __FILE__, __LINE__, 
		                                     error_to_string (errnum));
      return(NULL);
   }
   //sys_log ("%s(%d): Output Len = %d out=[%s] res=%d", __FILE__, __LINE__, 
	                                              //x, out, res);
   *(out + x) = '\0';
   return(&out[0]);
}
/*---------------------------------------------------------------------------*/
void create_send_challenge(int msgid, char *from_cgi, char *plain)
{
   unsigned char key_buf[1024];
   unsigned long key_size = sizeof(key_buf);
   zeromem (key_buf, sizeof (key_buf));
   if (__builtin_expect(make_challenge(from_cgi, plain, 
	                             key_buf, &key_size), true))
   {
      //unsigned char pt[8], ct[8]; //, key[8];
      //symmetric_key skey;
      //int err;
      //sys_log("%s(%d): We have a key %d len", __FILE__, __LINE__, key_size);
      /* ... key is loaded appropriately in ``key'' ... */
      /* ... load a block of plaintext in ``pt'' ... */
      /* schedule the key */
   }
   else
   {
      sys_log("%s(%d): Fehler beim erstellen des Schluessels", __FILE__, 
	                                                       __LINE__);
   }
   send_key_server_reply(msgid, from_cgi, (char *)key_buf);
}
/*---------------------------------------------------------------------------*/
static bool make_challenge(char *from_cgi, char *plain, unsigned char *key_buf,
                                                   unsigned long *key_size)
{
   int err;
   //, hash_idx, prng_idx, 
   //int res;
   unsigned long new_key_len = *key_size;
   unsigned char pt[MAXBLOCKSIZE], pt2[MAXBLOCKSIZE];
   unsigned char hash_out[MAXBLOCKSIZE];
   //unsigned char challange[MAXBLOCKSIZE];
   unsigned long hash_len = sizeof(hash_out);

   memset(pt2, '\0', sizeof(pt2));
   *key_size = 0;
   sprintf((char *)pt, "%s%s", from_cgi, plain);

   if (__builtin_expect((
	       (err = hash_memory(md5_idx, pt, strlen((char *)pt), hash_out, 
		           &hash_len)) != CRYPT_OK), false))
   {
       sys_log("%s(%d): Error hashing data: %s\n", error_to_string(err));
       return(false);
   }
   else
   {
      unsigned long l2 = sizeof(hash_out) - hash_len - 1;
      if (__builtin_expect((
	       (err = hash_memory(hash_idx, hash_out, hash_len,
				  (hash_out + hash_len - 1), 
				  &l2)) != CRYPT_OK), false))
      {
          sys_log("%s(%d): Error hashing data: %s\n", error_to_string(err));
          return(false);
      }
      else
      {
         //sys_log("%s(%d): Hash Len = %d [%s]", __FILE__, __LINE__, l2 + hash_len - 1, hash_out);
         zeromem (key_buf, sizeof (new_key_len));

         if (__builtin_expect(((errnum =
                   base64_encode(hash_out,  l2 + hash_len - 1,
                           key_buf, &new_key_len)) != CRYPT_OK),false))
         {
              sys_log ("4:Error: %s(%d): %s", __FILE__, __LINE__, error_to_string (errnum));
         }
	 else
	 {
	    unsigned char *sptr = key_buf;
	    unsigned char *sptr_new = key_buf;
            *key_size = 0;
	    for (register unsigned int x = 0; x < new_key_len; x++)
	    {
	       if (((*sptr >= 'a') && (*sptr <= 'z')) ||
		   ((*sptr >= 'A') && (*sptr <= 'Z')) ||
		   ((*sptr >= '0') && (*sptr <= '9')))
	       {
		  *sptr_new = *sptr;
		  *sptr_new++;
                  *key_size += 1;
	       }
	       do
	       {
	          sptr++;
	       } while (*sptr == *sptr_new);
	    }
	    *sptr_new = '\0';
	 }
      }
   }
   //*key_size = new_key_len;
   return(true);
}

bool verify_md5(char *from_cgi, char *md5, char *plain, 
                                                    char *challenge)
{
   sys_log("%s(%d): verify_md5 CGI[%s] MD5[%s] plain[%s] challenge[%s]", 
	 __FILE__, __LINE__, from_cgi, md5, plain, challenge);
   return(true);
}


/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_keys_size           = __LINE__;                            //
/* -------------------------------- EOF ------------------------------------ */

