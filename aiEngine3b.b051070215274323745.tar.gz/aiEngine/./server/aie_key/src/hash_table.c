/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : hash_table.c                                                */
/* Server      : aIEngineKeyD                                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 08.09.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_hash_table_version        = "1.0.0";                       //
const char *modul_hash_table_name           = "KeyDB";                       //
const char *modul_hash_table_date           = __DATE__;                      //
const char *modul_hash_table_time           = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define TM_YEAR_BASE	1900
#define size_hash_table 	366
#ifndef __isleap
/* Nonzero if YEAR is a leap year (every 4 years,
   except every 100th isn't, and every 400th is).  */
# define __isleap(year)	\
  ((year) % 4 == 0 && ((year) % 100 != 0 || (year) % 400 == 0))
#endif

/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aiengine_server.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_server_reply.h"                                                //
#include "hash_table.h"
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
extern char *is_hex;                                                         //
extern int md5_idx;
extern int sha256_idx;

const char *is_hash_hi;                                               //
const char *is_hash_lo;                                               //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct hash_table
{
   char c1;
   char c2;
   char lo[17];
   char hi[17];
   char key_id1[17];
   char key_id2[17];
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
//static bool hasCallbackData = false;
//static struct aie_sql_data *InitDB(void);
static void get_day_mon(int yday, int year, int *day, int *mon);
//static int get_yday(struct tm *tp);
static bool TestKeyId(int year, int max_yday, char *lo_new, char *hi_new);
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static char stoned[4];                                                       //
const char hash_char[] = "abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const unsigned int size_hash_char = sizeof(hash_char);
struct hash_table hash_table[size_hash_table];
/* How many days come before each month (0-12).  */
static const unsigned short int __mon_yday[2][13] =
  {
    /* Normal years.  */
    { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 },
    /* Leap years.  */
    { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 }
  };
#if 0
struct aie_sql_db_init_sequence
{
   const char *pragma;
   const char *value;
} ff_sql_db_init_sequence[] =
{
   { "PRAGMA default_temp_store = %s", "MEMORY" },
   { "PRAGMA synchronous = %s", "OFF" },
   { "PRAGMA cache_size = %s", "3000" },
};
unsigned int size_aktuell_db_init_sequence = sizeof(aktuell_db_init_sequence) /
                                      sizeof(struct aktuell_db_init_sequence);
                                                                             //
#endif   
                                                                             //
/*****************************************************************************/
//#include <stdlib.h>
//#include <string.h>
//#include <time.h>

static void get_day_mon(int yday, int year, int *day, int *mon)
{
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: get_day_mon yday %d year %d" },
      { AIE_LOG_SERVER_INFO, "Keyserver: get_day_mon: Found %d %d" }
   };
   aie_sys_log(0, yday, year);
   #endif
  *mon = 12;
  *day = 31;
  for (register signed int z = 1; z < 13; z++)
  {
    //printf("%d %d<%d\n", z, yday, 
//	                    __mon_yday[__isleap (year + TM_YEAR_BASE)][z]);
     if ((yday) < (__mon_yday[__isleap (year + TM_YEAR_BASE)][z]))
     {
	*mon = z - 1;
	*day = (yday-__mon_yday[__isleap (year + TM_YEAR_BASE)][z-1])+1;
        #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
	//Keyserver: get_day_mon: Found %d %d
        aie_sys_log(1, *day, *mon);
        #endif
	break;
     }
  }
}

#if 0
static int get_yday(struct tm *tp)
{
  int year_requested = tp->tm_year;
  /* Ensure that mon is in range, and set year accordingly.  */
  int mon_remainder = tp->tm_mon % 12;
  int negative_mon_remainder = mon_remainder < 0;
  int mon_years = tp->tm_mon / 12 - negative_mon_remainder;
  int year = year_requested + mon_years;

  /* Calculate day of year from year, month, and day of month.
     The result need not be in range.  */
  int yday = ((__mon_yday[__isleap (year + TM_YEAR_BASE)]
	       [mon_remainder + 12 * negative_mon_remainder])
	      + tp->tm_mday - 1);
  return(yday);
}
#endif

void fill_hash_table(void)
{
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: fill_hash_table" },
      { AIE_LOG_SERVER_INFO, "Keyserver Hash Doppelt %d [%s] %d [%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Hash Id Doppelt %d [%c] %d [%c]" }
   };
   #endif
   register unsigned int z;
   register unsigned int y;
   char *lo;
   char *hi;
   time_t t = time(NULL);
   int year = localtime(&t)->tm_year;
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   aie_sys_log(0);
   #endif
   srand(t);
   for (z = 0; z < (unsigned int)((size_hash_table - 1) + __isleap(year + TM_YEAR_BASE)); z++)
   {
      unsigned int a;
      int ok;
      //unsigned int dopple = 0;
      do
      {
         lo = hash_table[z].lo;
         hi = hash_table[z].hi;
         memset(lo, '\0', 17);
         memset(hi, '\0', 17);
         for  (y = 0; y < 16; y++)
         {
	    char x_hi;
	    char x_lo;
	    char *sptr_lo;
	    char *sptr_hi;
	    do
	    {
	       ok = 0;
	       if ((z == 0) || (rand()%15 == 1))
	       {
	          x_lo = hash_char[rand()%(size_hash_char-1)];
	       }
	       else
	       {
		  if ((rand()%4) == 1)
		  {
		     if ((rand()%2) == 1)
		     {
	                x_lo = tolower(*(hash_table[z-1].hi + rand()%16));
		     }
		     else
		     {
	                x_lo = toupper(*(hash_table[z-1].lo + rand()%16));
		     }
		  }
		  else
		  {
		     if ((rand()%2) == 1)
		     {
	                x_lo = tolower(*(hash_table[z-1].lo + rand()%16));
		     }
		     else
		     {
	                x_lo = tolower(*(hash_table[z-1].hi + rand()%16));
		     }
		  }
	       }
	       if ((z == 0) || (rand()%15 == 1))
	       {
	          x_hi = hash_char[rand()%(size_hash_char-1)];
	       }
	       else
	       {
		  if ((rand()%4) == 1)
		  {
		     if ((rand()%2) == 1)
		     {
	                x_hi = toupper(*(hash_table[z-1].lo + rand()%16));
		     }
		     else
		     {
	                x_hi = tolower(*(hash_table[z-1].hi + rand()%16));
		     }
		  }
		  else
		  {
		     if ((rand()%2) == 1)
		     {
	                x_hi = toupper(*(hash_table[z-1].hi + rand()%16));
		     }
		     else
		     {
	                x_hi = tolower(*(hash_table[z-1].lo + rand()%16));
		     }
		  }
	       }
	       sptr_lo = lo;
	       if (__builtin_expect(((x_lo != x_hi) &&
	           (tolower(x_lo) != tolower(x_hi))), true))
	       {
	          ok = 1;
	          while (*sptr_lo != '\0')
	          {
	             if ((tolower(*sptr_lo) == tolower(x_lo)) ||
	                 (tolower(*sptr_lo) == tolower(x_hi)))
	             {
		        ok = 0;
		        break;
	             }
	             sptr_lo++;
	          }
	          if (ok)
	          {
	             sptr_hi = hi;
	             while (*sptr_hi != '\0')
	             {
	                if ((tolower(*sptr_hi) == tolower(x_hi)) ||
	                    (tolower(*sptr_hi) == tolower(x_lo)))
	                {
		           ok = 0;
		           break;
	                }
	                sptr_hi++;
	             }
	                if (ok)
	                {
	                   *sptr_lo = x_lo;
	                   sptr_lo++;
	                   *sptr_hi = x_hi;
	                   sptr_hi++;
			}
	          }
	       }
	    } while (!ok);
         }
	 if (strcmp(lo, hi) != 0)
	 {
	    char c1 = hash_table[z].c1 = lo[rand()%16];
	    char c2 = hash_table[z].c2 = hi[rand()%16];
	    ok = 1;
	    for (a = 0; a < z; a++)
	    {
	       if (__builtin_expect((((strcmp(hash_table[a].lo, lo) == 0) ||
	                              (strcmp(hash_table[a].hi, hi) == 0) ||
	                              (strcmp(hash_table[a].lo, hi) == 0) ||
	                              (strcmp(hash_table[a].hi, lo) == 0))), 
			                                                false))
	       {
	          // Keyserver Hash Doppelt %d [%s] %d [%s]
                  #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
		  aie_sys_log(1,  a, hash_table[a].lo, z, lo);
                  #endif
	          ok = 0;
	          break;
	       }
	       else
	       {
		  if (__builtin_expect(((c1 == hash_table[a].c1) &&
		                        (c2 == hash_table[a].c2)), false))
		  {
	             // Keyserver: Hash Id Doppelt %d [%c] %d [%c]
                     #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
	             aie_sys_log(2, a, c1, z, c2);
                     #endif
	             ok = 0;
	             break;
		  }
	       }
	    }
	    if (ok)
	    {
	       ok = TestKeyId(year, z, hash_table[z].lo, hash_table[z].hi);
	    }
	 }
	 else
	 {
            ok = 0;
	 }
      } while (!ok);
   }
#if 0
   printf("#define size_hash_table	%d\n", size_hash_table);
   printf("struct hash_table hash_table[size_hash_table] =\n");
   printf("{\n");
   for (z = 0; z < size_hash_table; z++)
   {
      printf(" /* %3d */ { '%c', '%c', \"%s\", \"%s\" }", z, 
	                                            hash_table[z].c1, 
	                                            hash_table[z].c2,
	                                            hash_table[z].lo, 
	                                            hash_table[z].hi );
      if (z < size_hash_table - 1)
      {
	 printf(",\n");
      }
      else
      {
	 printf("\n");
      }
   }
   printf("};\n");
#endif
}


bool TestKeyId(int year, int max_yday, char *lo_new, char *hi_new)
{
   bool rc = true;
   struct tm tm;
   struct tm *tm_2 = NULL;
   time_t t;
   static char key_id1[17]; //[sizeof(unsigned long)*2+1];
   static char key_id2[17]; //[sizeof(unsigned long)*2+1];
   unsigned long KeyId1;
   unsigned long KeyId2;
   memset(&tm, '\0', sizeof(struct tm));
   memset(key_id1, '\0', sizeof(key_id1));
   memset(key_id2, '\0', sizeof(key_id2));
   tm.tm_year = year;
   is_hash_hi = hi_new;
   is_hash_lo = lo_new;
   get_day_mon(max_yday, tm.tm_year, &tm.tm_mday, &tm.tm_mon);
   t = mktime(&tm);
   tm_2 = localtime(&t);
   KeyId1 = ((0) << 31) +
          ((tm_2->tm_wday) << 28) +
          ((tm_2->tm_mon + 1) << 24) +
          ((tm_2->tm_yday + 1) << 15)+
          ((tm_2->tm_year) << 5) +
          (tm_2->tm_mday + 1);
   KeyId2 = ((1) << 31) +
          ((tm_2->tm_wday) << 28) +
          ((tm_2->tm_mon + 1) << 24) +
          ((tm_2->tm_yday + 1) << 15)+
          ((tm_2->tm_year) << 5) +
          (tm_2->tm_mday + 1);
   strncpy(key_id1, hash_crc(KeyId1), sizeof(key_id1)-1);
   strncpy(key_id2, hash_crc(KeyId2), sizeof(key_id2)-1);
  //printf("%3d %3d - %d:%d %d %s %s\n", tm_2->tm_yday, 
   //        get_yday(tm_2),
	//tm_2->tm_mday, tm_2->tm_mon, tm_2->tm_wday, key_id1, key_id2);
   for (tm.tm_mon = 0; (tm.tm_mon < 12) && rc; tm.tm_mon++)
   {
      for (tm.tm_mday = 1; tm.tm_mday <=31; tm.tm_mday++)
      {
	 int day;
	 int mon;
         t = mktime(&tm);
         tm_2 = localtime(&t);
          if ((max_yday == tm_2->tm_yday))
          {
	     break;
          }
         KeyId1 = ((0) << 31) +
          ((tm_2->tm_wday) << 28) +
          ((tm_2->tm_mon + 1) << 24) +
          ((tm_2->tm_yday + 1) << 15)+
          ((tm_2->tm_year) << 5) +
          (tm_2->tm_mday + 1);
         KeyId2 = ((1) << 31) +
          ((tm_2->tm_wday) << 28) +
          ((tm_2->tm_mon + 1) << 24) +
          ((tm_2->tm_yday + 1) << 15)+
          ((tm_2->tm_year) << 5) +
          (tm_2->tm_mday + 1);
	 if (KeyId1 == KeyId2)
	 {
	    printf("Key 1 und 2 koennen nicht gleich sein!\n");
	    exit(1);
	 }
	 if (strcmp(key_id1, hash_crc(KeyId1)) == 0)
	 {
	    printf("%d Key ID1 collision\n", __isleap(year + TM_YEAR_BASE));
            rc = false;
	 }
	 else if (strcmp(key_id2, hash_crc(KeyId2)) == 0)
	 {
	    printf("Key ID2 collision\n");
            rc = false;
	    break;
	 }
         get_day_mon(tm.tm_yday, year, &day, &mon);
	 //printf("%d-%s-%s\n", get_yday(&tm), is_hash_lo, is_hash_hi);
	 //printf("%3d %3d - %d:%d %d:%d -%s - %s\n", get_yday(&tm), tm_2->tm_yday, tm.tm_mday, tm.tm_mon, day, mon, hash_crc(KeyId1), hash_crc(KeyId2));
	 if ((day != tm.tm_mday) || (mon != tm.tm_mon))
	 {
	    printf("Conversion error ! %d != %d || %d != %d\n", 
	      day, tm.tm_mday, mon, tm.tm_mon);
	    exit(1);
	 }
#if 0
         printf("%s %s %d %d %d %d %d %d %lX\n", lo_new, hi_new, tm_2->tm_yday, 
          tm_2->tm_mon,
          tm_2->tm_mday,
          tm_2->tm_wday,
          tm_2->tm_year,
	  tm_2->tm_hour,
	  KeyId);
#endif
      }
      //if ((tm.tm_mon == 11) && (tm.tm_mday == 31))
      if ((max_yday == tm_2->tm_yday))
      {
	 break;
      }
   }
   return(rc);
}

char *select_hash(unsigned char c1, unsigned char c2)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,       "Keyserver: select_hash [%d:%d]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: select Hash %d" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Lookup Hash %c %c" },
      { AIE_LOG_ERROR,       "Keyserver: Fehler Hash initialisierung!" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Hash ini [%c][%c]" }
   };
   static char hash_id[3] = "\0\0\0";
   struct tm *tm = NULL;
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   aie_sys_log(0, c1, c2);
   #endif
   *hash_id = '\0';
   is_hash_lo = NULL;
   is_hash_hi = NULL;
   if (__builtin_expect(((c1 == 0) && (c2 == 0)), true))
   {
      time_t t = time(NULL);
      tm = localtime(&t);
      #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
      // Keyserver: select Hash %d
      aie_sys_log(1, tm->tm_yday);
      #endif
      is_hash_lo = hash_table[tm->tm_yday].lo;
      is_hash_hi = hash_table[tm->tm_yday].hi;
      hash_id[0] = hash_table[tm->tm_yday].c1;
      hash_id[1] = hash_table[tm->tm_yday].c2;
   }
   else
   {
      #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
      // Keyserver: Lookup Hash %c %c
      aie_sys_log(2, c1, c2);
      #endif
      for (register unsigned int z = 0; z < size_hash_table; z++)
      {
	 if (__builtin_expect(((c1 == hash_table[z].c1) &&
	                       (c2 == hash_table[z].c2)), false))
	 {
	    hash_id[0] = hash_table[z].c1;
	    hash_id[1] = hash_table[z].c2;
            is_hash_lo = hash_table[z].lo;
            is_hash_hi = hash_table[z].hi;
	    break;
	 }
      }
   }
   if (__builtin_expect(((is_hash_lo == NULL) || 
	                 (is_hash_hi == NULL) ||
			 (*hash_id == '\0')), false))
   {
      // Keyserver: Fehler Hash initialisierung!
      aie_sys_log(3);
   }
   else
   {
      // Keyserver: Hash ini [%c][%c]
      #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
      aie_sys_log(4, hash_id[0], hash_id[1]);
      #endif
   }
   return(hash_id);
}
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *hash_4_me(char *s)
{
   AIE_LOG_MESSAGES = 
   {
      { AIE_LOG_TRACE, "Keyserver: hash_4_me" },
      { AIE_LOG_ERROR, "Keyserver: Hash nicht initialisiert!" },
      { AIE_LOG_ERROR, "Keyserver: Interner Fehler Hashing Lo[%s]Hi[%s][%s]" }
   };
   *(stoned) = '\0';
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((is_hash_lo == NULL) || 
	                 (is_hash_hi == NULL)), false))
   {
      // Keyserver: Hash nicht initialisiert!
      aie_sys_log(1);
   }
   else
   {
      *(stoned + 2) = '\0';
      for (int z = 0; z < 16; z++)
      {
         if (__builtin_expect((*s == *(is_hex + z)),false))
         {
            *stoned = *(is_hash_lo + z);
	    //printf("Lo %d\n", z);
         }
         if (__builtin_expect((*(s + 1) == *(is_hex + z)),false))
         {
            *(stoned + 1) = *(is_hash_hi + z);
	    //printf("Hi %d\n", z);
         }
      }
      if (__builtin_expect((strlen(stoned) < 2),false))
      {
	 // Keyserver: Interner Fehler Hashing Lo[%s]Hi[%s][%s]
         aie_sys_log(2, is_hash_lo, is_hash_hi, stoned);
        exit(1);
      }
      //else
      //{
//	 printf("Stoned[%s]\n", stoned);
      //}
   }
   return(stoned);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *oops_stoned(char *s)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: oops_stoned" },
      { AIE_LOG_ERROR, "Keyserver: Hash nicht initialisiert!" }
   };
   static char smoked[4];
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   aie_sys_log(0);
   #endif
   *(smoked) = '\0';
   if (__builtin_expect(((is_hash_lo == NULL) || 
	                 (is_hash_hi == NULL)), false))
   {
      // Keyserver: Hash nicht initialisiert!
      aie_sys_log(1);
   }
   else
   {
      *(smoked + 2) = '\0';
      for (int z = 0; z < 16; z++)
      {
         if (__builtin_expect((*s == *(is_hash_lo + z)),false))
         {
            *smoked = *(is_hex + z);
         }
         if (__builtin_expect((*(s + 1) == *(is_hash_hi + z)),false))
         {
           *(smoked + 1) = *(is_hex + z);
         }
      }
   }
   return(smoked);
}
/*---------------------------------------------------------------------------*/


char *hash_crc(unsigned long crc) //, char *file, int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,       "Keyserver: hash_crc" },
      { AIE_LOG_ERROR,       "Keyserver: Fehler beim codieren" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Done CRC %s" }
   };
   unsigned int x;
   char *sptr;
   char crc_s[17]; //[sizeof(unsigned long)*2+1];
   static char is_crc[17]; //[sizeof(unsigned long)*2+1];
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   aie_sys_log(0);
   #endif
   //sys_log("%s(%d): Make CRC %s-%d", __FILE__, __LINE__, file, line);

   memset(is_crc, '\0', sizeof(is_crc));

   sprintf(crc_s, "%.8lx", crc);
   //sys_log("%s(%d): Make CRC %d %s", __FILE__, __LINE__, sizeof(unsigned long), crc_s);
   for (x = 0; x < 8/*sizeof(crc_s)*/; x += 2)
   {
       char smallbuf[5];
       strncpy(smallbuf, (crc_s + x), 2);
       *(smallbuf + 2) = '\0';
       //printf("Rund: %d %c %c\n", x, *smallbuf, *(smallbuf + 1));
       if (__builtin_expect(((float)((float)x/3) == (int)(x/3)),false))
       {
          swap_hi_lo(smallbuf);
       }
       if (__builtin_expect(((sptr = hash_4_me(smallbuf)) == NULL),false))
       {
          // Keyserver: Fehler beim codieren
          aie_sys_log(1);
       }
       else
       {
          memcpy(is_crc + (x), sptr, 2);
       }
   }
   *(is_crc + sizeof(is_crc) - 1) = '\0';
   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   // Keyserver: Done CRC %s
   aie_sys_log(2, is_crc);
   #endif
   return(is_crc);
}

void create_send_password_hash(int msgid, const char *from_cgi, 
                          const char *plain, const char *challenge)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: create_send_password_hash" },
      { AIE_LOG_ERROR, "Keyserver: Error hashing data: %s" },
      { AIE_LOG_ERROR, "Keyserver: Error hashing data: %s %s" }
   };
   int err;
   unsigned char hash_buf[MAXBLOCKSIZE];
   //unsigned long hash_size = sizeof(hash_buf);
   unsigned char pt[MAXBLOCKSIZE];
   unsigned char hash_out[MAXBLOCKSIZE];
   unsigned long hash_len = sizeof(hash_out);

   #if AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
   aie_sys_log(0);
   #endif
   *hash_buf = '\0';
   if (__builtin_expect((
	       (err = hash_memory(md5_idx, (unsigned char *)plain, 
				           strlen(plain), 
				  hash_out, &hash_len)) != CRYPT_OK), false))
   {
       // Keyserver: Error hashing data: %s
       aie_sys_log(1, error_to_string(err));
   }
   else
   {
      char *sptr = (char *)pt;
      memset(pt, '*', sizeof(pt));
      for (register unsigned int z = 0; z < hash_len; z++)
      {
	 *sptr = *(is_hex + (((*(hash_out + z)) & 0x00F0) >> 4));
	 sptr++;
	 *sptr = *(is_hex + ((*(hash_out + z)) & 0x000F));
	 sptr++;
      }
      strncpy((char *)sptr, challenge, sizeof(pt) - (hash_len * 2) - 1);
      hash_len = sizeof(hash_out);
      if (__builtin_expect((
	       (err = hash_memory(sha256_idx, pt, strlen((char *)pt), 
				  hash_out, &hash_len)) != CRYPT_OK), false))
      {
         // Keyserver: Error hashing data: %s %s
         aie_sys_log(2, error_to_string(err), pt);
      }
      else
      {
	 sptr = (char *)hash_buf;
         for (register unsigned int z = 0; z < hash_len; z++)
         {
	    *sptr = *(is_hex + (((*(hash_out + z)) & 0x00F0) >> 4));
	    sptr++;
	    *sptr = *(is_hex + ((*(hash_out + z)) & 0x000F));
	    sptr++;
         }
	 *sptr = '\0';
      }
   }
   send_key_server_reply(msgid, from_cgi, (char *)hash_buf);
}

#if 0
static int aie_select_hash_callback(void *pArg, int nArg, char **azArg,
		                                       char **azCol)
{
   struct aie_sql_data *aie_sql_data = (struct aie_sql_data *)pArg;
   struct hash_info *hash_info = (struct hash_info *)aie_sql_data->data;
   unsigned char *tmp = aie_malloc(SIZE_KEY_STORAGE_OUT_BUF_LEN + 1);
   if (__builtin_expect((tmp != NULL), true))
   {
      for(register int i = 0;i < nArg; i++)
      {
         if (__builtin_expect(
		(strcmp(azCol[i], is_aie_HashYearSqlFld) == 0), true))
         {
	 }
      }
      aie_free(tmp);
      hasCallbackData = true;
   }
   else
   {
      sys_log("%s(%d): Callback: Memory!", __FILE__, __LINE__);
   }
   return(0);
}
/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : int (0 = success)                                         */
/*...........................................................................*/
bool hash_db_find(char hash_id_1, char hash_id_2)
{
   bool rc = false;
   struct db_hash_info db_hash_info;
   struct aie_sql_data *aie_sql_data = NULL;
   if (__builtin_expect(((aie_sql_data = InitDB()) != NULL), true))
   {
      char *sql_cmd = aie_malloc(512);
      if (__builtin_expect((sql_cmd != NULL), true))
      {
	 sprintf(sql_cmd, "SELECT %s %s from %s where %s = '%c%c'",
	                   is_aie_HashYearSqlFld,
			   AIE_DB_TABLE_HASH,
			   is_aie_HashIDSqlFld,
			   hash_hash_id_1, hash_id_2);
         aie_sql_data->callback = aie_select_info_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = db_hash_info;
         hasCallbackData = false;
         if (__builtin_expect((!aie_sql_run(aie_sql_data)), false))
         {
            sys_log("%s(%d) select: %s", __FILE__, __LINE__, 
	                             aie_sql_meta_error(&aiengine_sql_meta_db));
         }
	 else if (__builtin_expect((hasCallbackData), true))
	 {
	    rc = true;
	    sys_log("%s(%d): Hash [%c%c] found!\n"
		    "SQL[%s]", __FILE__, __LINE__, 
		                                   hash_id_1, hash_id_2,
						   sql_cmd);
	 }
	 else
	 {
	    sys_log("%s(%d): Hash [%c%c] not found! [%s]\n"
		    "SQL[%s]", __FILE__, __LINE__, 
		                                   hash_id_1, hash_id_2,
						   sql_cmd);
	 }
         aie_free(sql_cmd);
      }
      else
      {
        sys_log("%s(%d): DB find No memory", __FILE__, __LINE__);
      }
      aie_sql_meta_release_db(&aiengine_sql_meta_db);
   }
   return(rc);
}

void do_db_save_hash(char hash_id_1, char hash_id_2, nt day, int year, 
                                                                char *lo, 
                                                                char *hi)
{
   if (__builtin_expect((InitDB() != NULL), true))
   {
       char KeyId[22];
       sprintf(KeyId, "%ld", mykeys->key_id);
       //sys_log("%s(%d): DB save Keypair [%s]", __FILE__, __LINE__, KeyId);
       //
             char *timestamp = get_time_stamp();
             struct aie_sql_meta_feld_value_list sql_meta_feld_value_list[] =
             {
                 { is_aie_HashDayIDSqlFld,	HashDayId 	},
                 { is_aie_HashIDSqlFld, 	HashId	 	},
                 { is_aie_HashYearSqlFld, 	HashYear	},
                 { is_aie_HashLoSqlFld,		Lo		},
                 { is_aie_HashHiSqlFld,		Hi		},
                 { is_aie_TimestampSqlFld,	timestamp 	},
		 { is_aie_RunCountSqlFld,       "0" 		}
             };
          struct aie_sql_meta_insert sql_meta_insert =
          {
                AIE_DB_TABLE_ID_HASH,
                true,
                sql_meta_feld_value_list,
                sizeof(sql_meta_feld_value_list) / 
	           sizeof(struct aie_sql_meta_feld_value_list),
                false, 
                &aiengine_sql_meta_db
             };
	     //sys_log("%s(%d): Speichere KeyId[%s]", __FILE__, __LINE__, 
		//                                   mykeys->hash_key_id);
	     if (__builtin_expect(
		      aie_sql_meta_start_transaction(&aiengine_sql_meta_db),
		                                                        true))
	     {
                if (__builtin_expect(
			 (!aie_sql_meta_table_insert(&sql_meta_insert)),false))
                {
                   sys_log("%s(%d) Insert: %s", __FILE__, __LINE__, 
	                             aie_sql_meta_error(&aiengine_sql_meta_db));
                }
	        if (__builtin_expect(
			 !aie_sql_meta_commit(&aiengine_sql_meta_db), 
		                                                       false))
	        {
                   sys_log("%s(%d) Commit: %s", __FILE__, __LINE__, 
	                             aie_sql_meta_error(&aiengine_sql_meta_db));
	        }
	     }
	     else
	     {
                   sys_log("%s(%d) Start Transaktion: %s", __FILE__, __LINE__, 
	                            aie_sql_meta_error(&aiengine_sql_meta_db));

	     }
	  }
       }
       if (__builtin_expect((aiengine_sql_meta_db.aie_sql_data != NULL), true))
       {
          //sys_log("%s(%d): Datenbank freigeben", __FILE__, __LINE__);
          aie_sql_meta_release_db(&aiengine_sql_meta_db);
       }
   }
}
#endif
/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_hash_table_size           = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */

