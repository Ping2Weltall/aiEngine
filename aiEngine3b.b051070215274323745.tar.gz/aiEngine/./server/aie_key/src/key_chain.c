/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : key_chain.c                                                 */
/* Server      : aIEngineKeyD                                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 21.08.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet die Krypto Bibliothek                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_keys_chain_version        = "1.0.0";                       //
const char *modul_keys_chain_name           = "KeyChain";                    //
const char *modul_keys_chain_date           = __DATE__;                      //
const char *modul_keys_chain_time           = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1

/*---------------------------------------------------------------------------*/
/* System Include's fuer das Modul                                           */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aiengine_server.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_server_data.h"                                                 //
#include "keys_srv.h"                                                        //
#include "keys.h"                                                            //
#include "key_chain.h"                                                       //
#include "hash_table.h"                                                      //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
extern long key_limit;
extern prng_state prng;                                                      //
extern int prng_idx;
extern int errnum;                                                           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct key_chain
{
   struct mykeys *keys;
   struct key_chain *next;
};
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static struct key_chain *key_chain_base = NULL;

                                                                             //
/*****************************************************************************/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool key_chain_find(unsigned long key_id, struct mykeys *mykeys)
{
   bool rc = false;
   struct key_chain *key_chain_ptr = NULL;
   if (__builtin_expect(((key_chain_ptr = key_chain_base) != NULL), true))
   {
      while (key_chain_ptr != NULL)
      {
	 if (__builtin_expect((key_chain_ptr->keys->key_id == key_id), true))
	 {
	    memcpy(mykeys, key_chain_ptr->keys, sizeof(struct mykeys));
	    //sys_log("%s(%d): Key found", __FILE__, __LINE__);
	    rc = true;
	    break;
	 }
	 key_chain_ptr = key_chain_ptr->next;
      }
   }
   return(rc);
}

/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool key_chain_append(struct mykeys *mykeys)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,       "Keyserver: key_chain_append" },
      { AIE_LOG_SERVER_INFO, "Keyserver: key_chain_append: Did Append" },
      { AIE_LOG_ERROR,       "Keyserver: key_chain_append: Memory Problem!" },
   };
   bool rc = false;
   struct key_chain *key_chain_ptr = (struct key_chain *)
                                       aie_malloc(sizeof(struct key_chain));
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((key_chain_ptr != NULL), true))
   {
      key_chain_ptr->keys = (struct mykeys *)aie_malloc(sizeof(struct mykeys));
      if (__builtin_expect((key_chain_ptr->keys != NULL), true))
      {
	 memcpy(key_chain_ptr->keys, mykeys, sizeof(struct mykeys));
	 if (__builtin_expect((key_chain_base == NULL), false))
	 {
            key_chain_ptr->next = key_chain_base;
	    key_chain_base = key_chain_ptr;
	    key_chain_base->next = NULL;
	 }
	 else
	 {
            struct key_chain *key_chain_ptr2 = key_chain_base;
	    key_chain_ptr->next = NULL;
	    while(key_chain_ptr2->next != NULL)
	    {
	       key_chain_ptr2 = key_chain_ptr2->next;
	    }
	    key_chain_ptr2->next = key_chain_ptr; 
	 }
	 // Keyserver: key_chain_append: Did Append
         aie_sys_log(1);
         rc = true;
      }
      else
      {
	 // Keyserver: key_chain_append: Memory Problem!
         aie_sys_log(2);
         aie_free(key_chain_ptr);	 
      }
   }
   else
   {
      // Keyserver: key_chain_append: Memory Problem!
      aie_sys_log(2);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool key_chain_find_hash(char *key_id, struct mykeys *mykeys)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: key_chain_find_hash" },
      { AIE_LOG_SERVER_INFO, "Keyserver: key_chain_find_hash: Key found" },
      { AIE_LOG_ERROR, "Keyserver: key_chain_find_hash: Key chain empty!" }
   };
   bool rc = false;
   struct key_chain *key_chain_ptr = NULL;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((key_chain_ptr = key_chain_base) != NULL), true))
   {
      while (key_chain_ptr != NULL)
      {
	 if (__builtin_expect(
		  (strcmp(hash_crc(key_chain_ptr->keys->key_id), key_id) == 0),
		                                                         true))
	 {
	    memcpy(mykeys, key_chain_ptr->keys, sizeof(struct mykeys));
	    // Keyserver: key_chain_find_hash: Key found
            aie_sys_log(1);
	    rc = true;
	    break;
	 }
#if 0
	 else
	 {
	    sys_log("%s(%d): have[%s] : [%s]", __FILE__, __LINE__, key_id,
		  hash_crc(key_chain_ptr->keys->key_id));
	 }
#endif
	 key_chain_ptr = key_chain_ptr->next;
      }
   }
   else
   {
      // Keyserver: key_chain_find_hash: Key chain empty!
      aie_sys_log(2);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

bool key_chain_new_key_append(unsigned long key_id, struct mykeys *mykeys)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: key_chain_new_key_append" },
      { AIE_LOG_ERROR, "Keyserver: key_chain_new_key_append: Error: %s" },
      { AIE_LOG_SERVER_INFO, "Keyserver: keychein_new_key_append: "
	                     "Did Append - OK" },
      { AIE_LOG_ERROR, "Keyserver: key_chain_new_key_append: Memory Problem!" }
   };
   bool rc = false;
   struct key_chain *key_chain_ptr = (struct key_chain *)
                                       aie_malloc(sizeof(struct key_chain));
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((key_chain_ptr != NULL), true))
   {
      memset(key_chain_ptr, '\0', sizeof(struct key_chain));
      key_chain_ptr->keys = (struct mykeys *)aie_malloc(sizeof(struct mykeys));
      if (__builtin_expect((key_chain_ptr->keys != NULL), true))
      {
         memset(key_chain_ptr->keys, '\0', sizeof(struct mykeys));
         if (__builtin_expect(
	          ((errnum =
                    rsa_make_key (&prng, prng_idx, key_limit / 8, 65537,
                     &key_chain_ptr->keys->private_key)) != CRYPT_OK),false))
         {
             // Keyserver: key_chain_new_key_append: Error: %s
             aie_sys_log(1, error_to_string (errnum));
             rc = false;
             aie_free(key_chain_ptr->keys);	 
             aie_free(key_chain_ptr);	 
         }
	 else
	 {
            key_chain_ptr->keys->key_id = key_id;
            strncpy(key_chain_ptr->keys->hash_key_id,
		        hash_crc(key_id), AIE_CRYPT_KEY_ID_LEN);
            key_chain_ptr->keys->key_typ = KEY_COMBINED;	 
            key_chain_ptr->next = key_chain_base;
	    key_chain_base = key_chain_ptr;
	    memcpy(mykeys, key_chain_ptr->keys, sizeof(struct mykeys));
            #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
	    // Keyserver: key_chain_new_key_append: Did Append - OK
            aie_sys_log(2);
            #endif
	    rc = true;
	 }
      }
      else
      {
	 // Keyserver: key_chain_new_key_append: Memory Problem!
         aie_sys_log(3);
         aie_free(key_chain_ptr);	 
      }
   }
   else
   {
      // Keyserver: key_chain_new_key_append: Memory Problem!
      aie_sys_log(3);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_keys_chain_size         = __LINE__;                        //
/* -------------------------------- EOF ------------------------------------ */

