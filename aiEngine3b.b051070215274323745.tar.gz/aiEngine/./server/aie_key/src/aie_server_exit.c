/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : ff_server_exit.c                                            */
/* Server      : aIEngineSitemapD                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.09.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_server_exit_version       = "1.0.0";                       //
const char *modul_server_exit_name          = "ServerExit";                  //
const char *modul_server_exit_date          = __DATE__;                      //
const char *modul_server_exit_time          = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aiengine_server.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_server_exit.h"                                                 //

/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
//extern struct aie_sql_data *aie_sql_data;                                  //
extern struct aie_sql_meta_db aiengine_sql_meta_db;                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : ff_server_exit                                            */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/

bool keyd_server_exit(struct tel_server_init *is_tel_server_init)
{
   if (is_tel_server_init->is_tel_server_fkt != NULL)
   {
      if (is_tel_server_init->is_tel_server_fkt->socket->server_pid == 0)
      {
         // do something if necessary
      }
   }
   return(true);
}
/*---------------------------------------------------------------------------*/
bool keyd_server_socket_stop(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES = 
   {
      { AIE_LOG_TRACE, "keyd_server_socket_stop" },
      { AIE_LOG_ERROR, "Keyserver: Socket Stop erhalten mit Null Ptr!" },
      { AIE_LOG_SERVER_INFO, "Keyserver: Datenbank freigeben" }
   };
   #ifndef __CYGWIN__
      // setpriority(PRIO_PROCESS, (id_t)getpid(), 1);
   #endif
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (is_tel_server_fkt == NULL)
   {
      // Keyserver: Socket Stop erhalten mit Null Ptr!
      aie_sys_log(1);
   }
   if (__builtin_expect((aiengine_sql_meta_db.aie_sql_data != NULL), false))
   {
      // Keyserver: Datenbank freigeben
      aie_sys_log(2);
      aie_sql_meta_release_db(&aiengine_sql_meta_db);
   }
   return(true);
}

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_server_exit_size          = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
