/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : keys.c                                                      */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 15.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet die Krypto Bibliothek                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 27.02.2005  : ALH           : Anpassungen an Libtomcrypr 1.0r1            */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 14.06.2004  : ALH           : Konstanten als const deklariert             */
/*.............+...............+.............................................*/
/* 10.06.2004  : ALH           : Anpassung aller malloc,free,strdup an lib   */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_keys_version        = "1.0.0";                             //
const char *modul_keys                = "Key's";                             //
const char *modul_keys_date           = __DATE__;                            //
const char *modul_keys_time           = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define MAX_SECRET_KEY       512                                             //
#define CRC_SIZE_OFFSET		8                                            //
/*---------------------------------------------------------------------------*/
/* System Include's fuer das Modul                                           */
/*...........................................................................*/

#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "keys.h"                                                            //
#include "key_chain.h"                                                       //
#include "key_db.h"                                                          //
#include "hash_table.h"                                                      //
#include "aie_server_reply.h"                                                //
#include "aie_server_data.h"                                                 //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
extern char *cgiQueryString;                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
extern struct mykeys mykeys;                                                 //
extern long key_limit;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
union int_2_str                                                              //
{                                                                            //
   unsigned int z;                                                           //
   char str[4];                                                              //
};                                                                           //
struct simple_hash
{
   char *hi;
   char *lo;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool register_algs(void);                                             //
static bool set_mykeys(char *hasKeyId);
static bool init_key_generator(void);                                        //
static bool make_challenge(char *from_cgi, char *plain, unsigned char *key_buf,
                                                   unsigned long *key_size);
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
int     errnum;                                                              //
prng_state prng;                                                      //
int prng_idx;
static int hash_idx;
int md5_idx;
int sha256_idx;
extern const char *is_hash_hi;                                               //
extern const char *is_hash_lo;                                               //
union int_2_str int_2_str;                                                   //
const unsigned char lparam[] = AIENGINE_LANGNAME;
const unsigned long lparamlen = sizeof(lparam);
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void free_secret_mykey(char **secret_key)
{
   if (__builtin_expect((*secret_key != NULL),true))
   {
      aie_free(*secret_key);
      *secret_key = NULL;
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
const char *do_code_string(const char *s)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: do_code_string" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Compress Buffer size = %d [%s]" },
      { AIE_LOG_ERROR, "Keyserver: do_code_string: Error compress %s" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Buffer New = %d Compared to %d [%d:%d]" },
      { AIE_LOG_ERROR, "Keyserver: do_code_string: Fehler NULL PTR:[%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Len Coding %d" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Hash CRC" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Size coded[%d] Crc32[%.8x] myHash[%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Hash ID [%c][%c]" },
      { AIE_LOG_ERROR, "Keyserver: do_code_string: Fehler beim codieren" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Has Key ID = %d Hash[%s] len=%d" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Buffer New = %d Compared to %d [%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_code_string: Return len=%d" },
   };
   struct is_coded_string *is_coded_string;
   static char is_coded[AIE_MAX_CRYPT_BLOCKSIZE];
   const char *rc_ptr = s;
   char *hash_id = select_hash(0,0);
   register unsigned int x;
   char *sptr;
   unsigned long crc = crc32(0L, Z_NULL, 0);
   unsigned int len = strlen(s);
#if aie_do_uri_zip
   int rc;
   unsigned long compress_len = compressBound(len);
   Bytef *compress_buf = (Bytef *)aie_malloc(compress_len + 4);
#endif
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   zeromem(is_coded, sizeof(is_coded));
   #if aie_do_uri_zip
   #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
   //   Keyserver: do_code_string: Compress Buffer size = %d [%s]
   aie_sys_log(1, compress_len, s);
   #endif
   if (__builtin_expect(
	    ((rc = 
	      compress2(compress_buf + 4, 
		        &compress_len, 
			(Bytef *)s, len, 9)) != Z_OK),false))
   {
         // Keyserver: do_code_string: s(%d): Error compress %s
	 aie_sys_log(2, zError(rc));
   }
   else
   {
      #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
      // Keyserver: do_code_string: Buffer New = %d Compared to %d [%d:%d]
      aie_sys_log(3, (unsigned int)compress_len, len, int_2_str.z, 
				   (unsigned int)*(compress_buf));
      #endif
      int_2_str.z = compress_len;
      memcpy(compress_buf, int_2_str.str, 4);
      is_coded_string = rsa_encode ((unsigned char *)compress_buf, compress_len + 4);
#else 
      is_coded_string = rsa_encode ((unsigned char *)s, len);
#endif
      if (__builtin_expect((is_coded_string == NULL),false))
      {
         // Keyserver: do_code_string: Fehler NULL PTR:[%s]
         aie_sys_log(4, s);

         strcpy(is_coded, "ERROR!");
      }
      else
      {
          char *is_crc; 
         #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
         // Keyserver: do_code_string: Len Coding %d
         aie_sys_log(5, is_coded_string->len);
         #endif
          crc = crc32(crc, (Bytef *)is_coded_string->s, is_coded_string->len);
          #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
          //   Keyserver: do_code_string: Hash CRC
          aie_sys_log(6);
          #endif
          is_crc = hash_crc(crc);
          #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
          //   Keyserver: do_code_string: Size coded[%d] Crc32[%.8x] myHash[%s]
	  aie_sys_log(7, is_coded_string->len, crc, is_crc);
          #endif
	  *is_coded = *hash_id; // *is_hash_lo;
	  *(is_coded + 1) = *(hash_id + 1);
          #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
	  //   Keyserver: do_code_string: s(%d): Hash ID [%c][%c]
	  aie_sys_log(8, *is_coded, *(is_coded + 1));
          #endif
          memcpy(is_coded + 2, is_crc, CRC_SIZE_OFFSET); // ALH 05.09.2005
          for (x = 0; x < is_coded_string->len;x++)
          {
            char smallbuf[5];
            sprintf (smallbuf, "%.2x", *(is_coded_string->s + x) ^ 128 );
            if (__builtin_expect(((float)((float)x/3) == (int)(x/3)),false))
            {
              swap_hi_lo(smallbuf);
            }
            if (__builtin_expect(((sptr = hash_4_me(smallbuf)) == NULL),false))
            {
               // Keyserver: do_code_string: Fehler beim codieren
               aie_sys_log(9);
               //strcpy(is_coded, "ERROR!");
            }
            else
            {
               if (__builtin_expect(((x * 2) > (sizeof(is_coded) - 3)),false))
               {
               }
               else
               {
                  memcpy(is_coded + (x * 2) + CRC_SIZE_OFFSET + 2, sptr, 2);
               }
            }
         }
         aie_free(is_coded_string->s);
         #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
         //   Keyserver: do_code_string: Has Key ID = %d Hash[%s] len=%d
         aie_sys_log(10, mykeys.key_id, hash_crc(mykeys.key_id), 
	                 strlen(is_coded));
         #endif
         strcat((char *)is_coded, hash_crc(mykeys.key_id));
         #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
         //   Keyserver: do_code_string: Buffer New = %d Compared to %d [%s]
	 aie_sys_log(11, compress_len, strlen(is_coded), compress_buf);
         #endif
	 rc_ptr = is_coded;
      }
#if aie_do_uri_zip
   }
   aie_free(compress_buf);
#endif
   #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
   //   Keyserver: do_code_string: Return len=%d
   aie_sys_log(12, strlen(rc_ptr));
   #endif
   return(rc_ptr);
   //return(is_coded);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *do_decode_string(const char *s)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: do_decode_string" },
      { AIE_LOG_ERROR, "Keyserver: do_decode_string: "
	                  "Fehlerhafter String[%s] Len[%d]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_decode_string: "
	                     "Aktueller Hash[%c:%c]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_decode_string: "
	                  "Decode KeyID[%s] len=%d" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_decode_string: "
	                  "Len decoding %d" },
      { AIE_LOG_ERROR, "Keyserver: do_decode_string: "
	                  "Crc32 Fehler [%s][%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_decode_string: "
	                  "Size to decod[%d] Crc32[%x] Hashed[%s] hasCrc[%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_decode_string: "
	                  "uncompress [%d] Bytes" },
      { AIE_LOG_ERROR, "Keyserver: do_decode_string: "
	                  "Error decompress: %s len[%d]" },
      { AIE_LOG_SECURITY, "Keyserver: do_decode_string: "
	                  "Finished decoding Have[%s]" },
   };
   static Bytef           is_decoded[AIE_MAX_CRYPT_BLOCKSIZE];
   int len = strlen(s);
   char hasKeyId[AIE_CRYPT_KEY_ID_LEN + 1];
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif

   memset(hasKeyId, '\0', sizeof(hasKeyId));

   len -= AIE_CRYPT_KEY_ID_LEN;

   //*(s + len) = '\0';
   
   zeromem(is_decoded, sizeof(is_decoded));
   if (__builtin_expect((len <= CRC_SIZE_OFFSET),false))
   {
      // Keyserver: do_decode_string: Fehlerhafter String[%s] Len[%d]
      aie_sys_log(1, s, len);
   }
   else
   {
      //unsigned char *buffer = (unsigned char *)aie_malloc(strlen(s));
      unsigned char *buffer = (unsigned char *)aie_malloc((len / 2) + 2);
      struct is_coded_string is_coded_string;
      unsigned char *sptr = buffer;
      int y;
      char *ptr_rsa_decode;
      char *is_crc;
      char has_crc[CRC_SIZE_OFFSET + 1];
      unsigned long crc = crc32(0L, Z_NULL, 0);

      select_hash(*s, *(s+1)); // Setzt zwei globale Variablen
      #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
      // Keyserver: do_decode_string: Aktueller Hash[%c:%c]
      aie_sys_log(2, *s, *(s+1));
      #endif
      strncpy(hasKeyId, s + len, AIE_CRYPT_KEY_ID_LEN);
      #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
      // Keyserver: do_decode_string: Decode KeyID[%s] len=%d
      aie_sys_log(3, hasKeyId, len);
      #endif
      *(buffer + (len / 2) + 1) = '\0';
      if (set_mykeys(hasKeyId))
      {
         zeromem(has_crc, sizeof(has_crc));
         memcpy(has_crc, s + 2, CRC_SIZE_OFFSET); // Geaendert ALH 05.09.2005
         //for(int z = (CRC_SIZE_OFFSET); *(s + z) != '\0'; z +=2)
         for(int z = (CRC_SIZE_OFFSET) + 2; z < len; z +=2)
         {
            char smallbuf[4];
            zeromem(smallbuf, sizeof(smallbuf));
            strncpy(smallbuf, s + z, 2);

            strncpy(smallbuf, oops_stoned(smallbuf), 2);
            if (__builtin_expect(
		  ((float)((float)(z-(CRC_SIZE_OFFSET+2))/3) == 
		   (int)((int)((z-(CRC_SIZE_OFFSET+2))/3))), false))
            {
               swap_hi_lo(smallbuf);
            }
            y = aie_hextoint(smallbuf);
            *(sptr) = (unsigned char)(y ^ 128);
            sptr++;
         }
         is_coded_string.len = ((len - (CRC_SIZE_OFFSET + 2)) / 2);
         is_coded_string.s = buffer;
         #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
         // Keyserver: do_decode_string: Len decoding %d
         aie_sys_log(4, is_coded_string.len);
         #endif
         crc = crc32(crc, (Bytef *)is_coded_string.s, is_coded_string.len); //-
                                                   //AIE_CRYPT_KEY_ID_LEN);
         if (__builtin_expect((strcmp(is_crc = hash_crc(crc), has_crc)),false))
         {
	    // Keyserver: do_decode_string: Crc32 Fehler [%s][%s]
            aie_sys_log(5, is_crc, has_crc);
         }
         #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
         // Keyserver: do_decode_string: Size to decod[%d] Crc32[%x] Hashed[%s] hasCrc[%s]
         aie_sys_log(6, is_coded_string.len, crc, is_crc, has_crc);
         #endif
         if (__builtin_expect(
	       ((ptr_rsa_decode = 
		 (char *)rsa_decode(&is_coded_string)) != NULL),true))
         {
            #if aie_do_uri_zip
	       int rc;
	       unsigned long decompress_len = sizeof(is_decoded);
	       unsigned long data_len; // = (int)*ptr_rsa_decode;
	       memcpy(int_2_str.str, ptr_rsa_decode, 4);
	       data_len = int_2_str.z;
               #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
               // Keyserver: do_decode_string: uncompress [%d] Bytes
               aie_sys_log(7, data_len);
               #endif
            #else
               strncpy((char *)is_decoded, ptr_rsa_decode, 
		                                       sizeof(is_decoded) - 1);
            #endif
            #if aie_do_uri_zip
	       if (__builtin_expect(((rc = 
		    uncompress(is_decoded, 
		               &decompress_len, 
			       (Bytef *)(ptr_rsa_decode + 4), 
		                                    data_len) != Z_OK)),false))
               {
	          // Keyserver: do_decode_string: Error decompress: %s len[%d]
                  aie_sys_log(8, zError(rc), data_len);
	       }
            #endif
         }
         aie_free(buffer);
      }
   }
   #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
   // Keyserver: do_decode_string: Finished decoding Have[%s]
   aie_sys_log(9, is_decoded);
   #endif
   return((char *)is_decoded);
}
/*---------------------------------------------------------------------------*/
static bool set_mykeys(char *hasKeyId)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: set_mykeys: Aktuell [%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: set_mykeys: Nicht Aktuell KeyId is[%s] requested[%s]" },
      { AIE_LOG_SERVER_INFO, "Keyserver: set_mykeys: Nicht in Keychain KeyId is[%s] requested[%s]" },
      { AIE_LOG_ERROR, "Keyserver: set_mykeys: Unbekannter Schluessel[%s]" }
   };
   bool rc = true;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0, hash_crc(mykeys.key_id));
   #endif
   if (__builtin_expect((strcmp(mykeys.hash_key_id, hasKeyId) != 0),false))
   {
      #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
      // Keyserver: set_mykeys: Nicht Aktuell KeyId is[%s] requested[%s]", 
      aie_sys_log(1, mykeys.hash_key_id, hasKeyId);
      #endif
      if (__builtin_expect((!key_chain_find_hash(hasKeyId, &mykeys)), false))
      {
         #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
         //  Keyserver: set_mykeys: Nicht in Keychain KeyId is[%s] requested[%s]
         aie_sys_log(2, mykeys.hash_key_id, hasKeyId);
         #endif
         if (__builtin_expect(!key_db_find(hasKeyId, &mykeys), false))
         {
             // Keyserver: set_mykeys: Unbekannter Schluessel[%s]", 
             aie_sys_log(3, hasKeyId);
	    rc = false;
	 }
      }
   }
   return(rc);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool init_keyfunktions(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: init_keyfunktions" },
      { AIE_LOG_ERROR, "Keyserver: init_keyfunctions: Fehler Startup" }
   };
   bool rc = true;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((init_key_generator()==true),true))
   {
      rc = register_algs();
   }
   else
   {
      // Keyserver: init_keyfunctions: Fehler Startup
      aie_sys_log(1);
      rc = false;
   }
   //prng_idx = find_prng ("yarrow");  
   //hash_idx = find_hash("sha1");
   //prng_idx = find_prng("sprng");
   //md5_idx = find_prng("md5");
   //ltc_mp = tfm_desc;
   //sys_log("%s(%d): Init Keygenerator prng %d", __FILE__, __LINE__, prng_idx);
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static bool register_algs(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: register_algs" },
      { AIE_LOG_ERROR, "Keyserver: register_algs: Error registering sprng" },
      { AIE_LOG_ERROR, "Keyserver: register_algs: Error registering sha1" },
      { AIE_LOG_ERROR, "Keyserver: register_algs: Error registering MD5" },
      { AIE_LOG_ERROR, "Keyserver: register_algs: Error registering sha256" }
   };
   bool rc = true;

   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   ltc_mp = tfm_desc;
   if ((prng_idx = register_prng(&sprng_desc)) == -1) 
   {
      // Keyserver: register_algs: Error registering sprng
      aie_sys_log(1);
      rc = false;
   }
   /* register a math library (in this case TomFastMath) */
    if ((hash_idx = register_hash(&sha1_desc)) == -1) 
    {
       // Keyserver: register_algs: Error registering sha1
       aie_sys_log(2);
       rc = false;
    }
    /* register the hash */
    if ((md5_idx = register_hash(&md5_desc)) == -1) 
    {
       // Keyserver: register_algs: Error registering MD5
       aie_sys_log(3);
       rc = false;
    }
    if ((sha256_idx = register_hash(&sha256_desc)) == -1) 
    {
       // Keyserver: register_algs: Error registering sha256
       aie_sys_log(4);
       rc = false;
    }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool init_key_generator(void)
{
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: init_key_generator" }
   };
   #endif
   bool rc = true;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   #ifdef NOT_LINUX
   randomize();
   #endif
   return(rc);
}
/*---------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : struct is_coded_string *                                  */
/*...........................................................................*/
struct is_coded_string *rsa_encode (unsigned char *in, unsigned int len)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: rsa_encode" },
      { AIE_LOG_ERROR, "Keyserver: rsa_encode: Len = %d Error: %s" }
   };
   static struct is_coded_string is_coded_string;
   unsigned char out[AIE_MAX_CRYPT_BLOCKSIZE];
   unsigned long y;
   rsa_key *key = &mykeys.private_key;

   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((mykeys.key_typ ==  KEY_SPLIT), false))
   {
      key = &mykeys.public_key;
   }
   zeromem(out, sizeof(out));
   y = sizeof (out);
   if (__builtin_expect(((errnum = rsa_encrypt_key ((unsigned char *)in,
                                                len,
                                                out, &y,
			                        lparam, lparamlen,
	       NULL, /* PRNG state */
	       prng_idx, /* prng idx */
	       hash_idx, /* hash idx */
               key)) != CRYPT_OK),false))
   {
      // Keyserver: rsa_encode: Len = %d Error: %s
      aie_sys_log(1, len, error_to_string (errnum));
      return(NULL);
   }
   is_coded_string.len = y;
   is_coded_string.s = (unsigned char *)aie_malloc(is_coded_string.len + 1);
   //*(is_coded_string.s + (is_coded_string.len)) = '\0';
   memcpy(is_coded_string.s, out, y);
   return(&is_coded_string);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : unsigned char *                                           */
/*...........................................................................*/
unsigned char *rsa_decode(struct is_coded_string *is_coded_string)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: rsa_decode" },
      { AIE_LOG_SERVER_INFO, "Keyserver: rsa_decode: Input Len = %d in=[%s]" },
      { AIE_LOG_ERROR, "Keyserver: rsa_decode: %s" },
      { AIE_LOG_SERVER_INFO, "Keyserver: rsa_decode: "
	                     "Output Len = %d out=[%s] res=%d" }
   };
   static unsigned char out[4096];
   unsigned long x;
   int res = 0;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   //rsa_key *key;

   //key = &mykeys.private_key;

   x = sizeof(out);
   #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
   // Keyserver: rsa_decode: Input Len = %d in=[%s]
   aie_sys_log(1, is_coded_string->len, is_coded_string->s);
   #endif
   if (__builtin_expect(((errnum = rsa_decrypt_key(is_coded_string->s, 
		                                is_coded_string->len, out, &x, 
		                                lparam, lparamlen, 
	    hash_idx, /* hash idx */
	    &res, /* validity of data */
            &mykeys.private_key )) != CRYPT_OK),false))
   {
      // Keyserver: rsa_decode: %s
      aie_sys_log(2, error_to_string (errnum));
      return(NULL);
   }
   #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
   // Keyserver: rsa_decode: Output Len = %d out=[%s] res=%d
   aie_sys_log(3, x, out, res);
   #endif
   *(out + x) = '\0';
   return(&out[0]);
}
/*---------------------------------------------------------------------------*/
void create_send_challenge(int msgid, char *from_cgi, char *plain)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: create_send_challenge" },
      { AIE_LOG_SERVER_INFO, "Keyserver: create_send_challenge: "
	                     "We have a key %d len" },
      { AIE_LOG_ERROR, "Keyserver: create_send_challenge: "
	               "Fehler beim erstellen des Schluessels" }
   };
   unsigned char key_buf[AIE_MAX_CRYPT_BLOCKSIZE];
   unsigned long key_size = sizeof(key_buf);
   zeromem (key_buf, sizeof (key_buf));
   if (__builtin_expect(make_challenge(from_cgi, plain, 
	                             key_buf, &key_size), true))
   {
      // Keyserver: create_send_challenge: We have a key %d len
      aie_sys_log(1, key_size);
   }
   else
   {
      // Keyserver: create_send_challenge: Fehler beim erstellen des Schluessels
      aie_sys_log(2);
   }
   send_key_server_reply(msgid, from_cgi, (char *)key_buf);
}
/*---------------------------------------------------------------------------*/
static bool make_challenge(char *from_cgi, char *plain, unsigned char *key_buf,
                                                   unsigned long *key_size)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: make_challenge: cgi[%s]" },
      { AIE_LOG_ERROR, "Keyserver: make_challenge: Error hashing data: %s" },
      { AIE_LOG_SERVER_INFO, "Keyserver: make_challenge: Hash Len = %d [%s]" },
      { AIE_LOG_ERROR, "Keyserver: make_challenge: Error: %s" }
   };
   int err;
   unsigned long new_key_len = *key_size;
   unsigned char pt[MAXBLOCKSIZE], pt2[MAXBLOCKSIZE];
   unsigned char hash_out[MAXBLOCKSIZE];
   unsigned long hash_len = sizeof(hash_out);

   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0, from_cgi);
   #endif
   memset(pt2, '\0', sizeof(pt2));
   *key_size = 0;
   sprintf((char *)pt, "%s%s", from_cgi, plain);

   if (__builtin_expect((
	       (err = hash_memory(md5_idx, pt, strlen((char *)pt), hash_out, 
		           &hash_len)) != CRYPT_OK), false))
   {
       // Keyserver: make_challenge: Error hashing data: %s
       aie_sys_log(1, error_to_string(err));
       return(false);
   }
   else
   {
      unsigned long l2 = sizeof(hash_out) - hash_len - 1;
      if (__builtin_expect((
	       (err = hash_memory(hash_idx, hash_out, hash_len,
				  (hash_out + hash_len - 1), 
				  &l2)) != CRYPT_OK), false))
      {
          // Keyserver: make_challenge: Error hashing data: %s
          aie_sys_log(1, error_to_string(err));
          return(false);
      }
      else
      {
         // Keyserver: make_challenge: Hash Len = %d [%s]
	 aie_sys_log(2, l2 + hash_len - 1, hash_out);
         zeromem (key_buf, sizeof (new_key_len));

         if (__builtin_expect(((errnum =
                   base64_encode(hash_out,  l2 + hash_len - 1,
                           key_buf, &new_key_len)) != CRYPT_OK),false))
         {
              // Keyserver: make_challenge: Error: %s
              aie_sys_log(3, error_to_string(err));
         }
	 else
	 {
	    unsigned char *sptr = key_buf;
	    unsigned char *sptr_new = key_buf;
            *key_size = 0;
	    for (register unsigned int x = 0; x < new_key_len; x++)
	    {
	       if (((*sptr >= 'a') && (*sptr <= 'z')) ||
		   ((*sptr >= 'A') && (*sptr <= 'Z')) ||
		   ((*sptr >= '0') && (*sptr <= '9')))
	       {
		  *sptr_new = *sptr;
		  *sptr_new++;
                  *key_size += 1;
	       }
	       do
	       {
	          sptr++;
	       } while (*sptr == *sptr_new);
	    }
	    *sptr_new = '\0';
	 }
      }
   }
   //*key_size = new_key_len;
   return(true);
}

unsigned long GetKeyId(struct tm *tm)
{
   return(((tm->tm_hour > 12)/*(rand()%2)*/ << 31) +
	  ((tm->tm_wday) << 28) + 
          ((tm->tm_mon + 1) << 24) + 
	  ((tm->tm_yday + 1) << 15)+
          ((tm->tm_year) << 5) +
	  (tm->tm_mday + 1));
}
#if 0
unsigned long GetKeyId(void)
{
   time_t t = time(NULL);
   struct tm *tm = localtime(&t);
   return(((tm->tm_hour > 12)/*(rand()%2)*/ << 31) +
	  ((tm->tm_wday) << 28) + 
          ((tm->tm_mon + 1) << 24) + 
	  ((tm->tm_yday + 1) << 15)+
          ((tm->tm_year) << 5) +
	  (tm->tm_mday + 1));
}
#endif

#if 0
void create_send_password_hash(int msgid, const char *from_cgi, 
                          const char *plain, const char *challenge)
{
   int err;
   unsigned char hash_buf[MAXBLOCKSIZE];
   //unsigned long hash_size = sizeof(hash_buf);
   unsigned char pt[MAXBLOCKSIZE];
   unsigned char hash_out[MAXBLOCKSIZE];
   unsigned long hash_len = sizeof(hash_out);

   *hash_buf = '\0';
   if (__builtin_expect((
	       (err = hash_memory(md5_idx, (unsigned char *)plain, 
				           strlen(plain), 
				  hash_out, &hash_len)) != CRYPT_OK), false))
   {
       sys_log("%s(%d): Error hashing data: %s\n", __FILE__, __LINE__,
	                                           error_to_string(err));
   }
   else
   {
      char *sptr = (char *)pt;
      memset(pt, '*', sizeof(pt));
      for (register unsigned int z = 0; z < hash_len; z++)
      {
	 *sptr = *(is_hex + (((*(hash_out + z)) & 0x00F0) >> 4));
	 sptr++;
	 *sptr = *(is_hex + ((*(hash_out + z)) & 0x000F));
	 sptr++;
      }
      strncpy((char *)sptr, challenge, sizeof(pt) - (hash_len * 2) - 1);
      hash_len = sizeof(hash_out);
      if (__builtin_expect((
	       (err = hash_memory(sha256_idx, pt, strlen((char *)pt), 
				  hash_out, &hash_len)) != CRYPT_OK), false))
      {
         sys_log("%s(%d): Error hashing data: %s\n", __FILE__, __LINE__, pt);
      }
      else
      {
	 sptr = (char *)hash_buf;
         for (register unsigned int z = 0; z < hash_len; z++)
         {
	    *sptr = *(is_hex + (((*(hash_out + z)) & 0x00F0) >> 4));
	    sptr++;
	    *sptr = *(is_hex + ((*(hash_out + z)) & 0x000F));
	    sptr++;
         }
	 *sptr = '\0';
      }
   }
   send_key_server_reply(msgid, from_cgi, (char *)hash_buf);
}
#endif
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_keys_size           = __LINE__;                            //
/* -------------------------------- EOF ------------------------------------ */

