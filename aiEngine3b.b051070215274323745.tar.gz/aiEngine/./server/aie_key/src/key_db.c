/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : key_db.c                                                    */
/* Server      : aIEngineKeyD                                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 21.08.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_key_db_version            = "1.0.0";                       //
const char *modul_key_db_name               = "KeyDB";                       //
const char *modul_key_db_date               = __DATE__;                      //
const char *modul_key_db_time               = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#ifdef aie_do_use_keys
#undef aie_do_use_keys
#endif
#define aie_do_use_keys			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aiengine_server.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_server_init.h"                                                 //
#include "aie_server_data.h"                                                 //
#include "keys_srv.h"                                                        //
#include "keys.h"                                                            //
#include "key_db.h"                                                          //
#include "key_chain.h"                                                       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des Servers                                     */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sql_meta_db;                          //
extern int errnum;
extern unsigned char *tmp_out_buf;
extern unsigned char *tmp_private_out;
extern unsigned char *tmp_public_out;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das Servers                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool hasCallbackData = false;
static struct aie_sql_data *InitDB(void);
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
#if 0
struct aie_sql_db_init_sequence
{
   const char *pragma;
   const char *value;
} ff_sql_db_init_sequence[] =
{
   { "PRAGMA default_temp_store = %s", "MEMORY" },
   { "PRAGMA synchronous = %s", "OFF" },
   { "PRAGMA cache_size = %s", "3000" },
};
unsigned int size_aktuell_db_init_sequence = sizeof(aktuell_db_init_sequence) /
                                      sizeof(struct aktuell_db_init_sequence);
                                                                             //
#endif   
                                                                             //
/*****************************************************************************/

static int aie_select_info_callback(void *pArg, int nArg, char **azArg,
		                                       char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: aie_select_info_callback" },
      { AIE_LOG_ERROR, "Keyserver: aie_select_info_callback: Error: %s" },
      { AIE_LOG_ERROR, "Keyserver: aie_select_info_callback: Out of Memory?" }
   };
   struct aie_sql_data *aie_sql_data = (struct aie_sql_data *)pArg;
   struct mykeys *mykeys = (struct mykeys *)aie_sql_data->data;
   unsigned char *tmp = aie_malloc(SIZE_KEY_STORAGE_OUT_BUF_LEN + 1);
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((tmp != NULL), true))
   {
      for(register int i = 0;i < nArg; i++)
      {
         if (__builtin_expect(
		(strcmp(azCol[i], is_aie_KeyPrivateSqlFld) == 0) ||
                (strcmp(azCol[i], is_aie_KeyPublicSqlFld) == 0), true))
         {
            if (__builtin_expect((azArg[i] != NULL), true))
	    {
               unsigned long out_len = SIZE_KEY_STORAGE_OUT_BUF_LEN;
               if (__builtin_expect((
		     (errnum = base64_decode((unsigned char*)azArg[i], 
					     strlen(azArg[i]), 
					     tmp, 
					     &out_len)) != CRYPT_OK),false))
               {
                  // Keyserver: aie_select_info_callback: Error: %s
                  aie_sys_log(1, error_to_string (errnum));
               }
	       else
	       {
                  rsa_key *key = &mykeys->private_key;
		  if (__builtin_expect(
		      (strcmp(azCol[i], is_aie_KeyPublicSqlFld) == 0), false))
		
		  {
                     key = &mykeys->public_key;
		  }
                  if (__builtin_expect(
	             ((errnum = 
		         rsa_import(tmp, out_len, key)) != CRYPT_OK),
		                                                        false))
                  {
                     // Keyserver: aie_select_info_callback: Error: %s
                     aie_sys_log(1, error_to_string (errnum));
                  }
	       }
	    }
         }
         else 
	 if (__builtin_expect((strcmp(azCol[i], is_aie_KeyIDSqlFld) == 0),
		                                                         true))
         {
            if (azArg[i] != NULL)
            {
	       mykeys->key_id = atol(azArg[i]);
	       mykeys->key_typ = KEY_SPLIT;
            }
         }
         else 
         {
            if (__builtin_expect(
                       (strcmp(azCol[i], is_aie_KeyIDHashSqlFld) == 0), true))
	    {
	       strncpy(mykeys->hash_key_id, azArg[i], AIE_CRYPT_KEY_ID_LEN); 
	    }
         }
      }
      aie_free(tmp);
      hasCallbackData = true;
   }
   else
   {
      // Keyserver: aie_select_info_callback: Out of Memory?
      aie_sys_log(2);
   }
   return(0);
}
/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : int (0 = success)                                         */
/*...........................................................................*/
bool key_db_find(char *hash_key_id, struct mykeys *mykeys)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: key_db_find" },
      { AIE_LOG_ERROR, "Keyserver: key_db_find: select: %s" },
      { AIE_LOG_SERVER_INFO, "Keyserver: key_db_find: "
	                     "Key loaded Hash[%s] Id[%ld]" },
      { AIE_LOG_SECURITY, "Keyserver: key_db_find: "
	                  "Key not found! [%s] SQL[%s]" },
      { AIE_LOG_ERROR,    "Keyserver: key_db_find: Out of Memory?" }
   };
   bool rc = false;
   struct aie_sql_data *aie_sql_data = NULL;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((aie_sql_data = InitDB()) != NULL), true))
   {
      char *sql_cmd = aie_malloc(512);
      if (__builtin_expect((sql_cmd != NULL), true))
      {
	 sprintf(sql_cmd, "SELECT %s, %s, %s, %s, %s from %s where %s = '%s'",
	                   is_aie_KeyIDHashSqlFld,
	                   is_aie_KeyIDSqlFld,
	                   is_aie_KeyIDHashSqlFld,
			   is_aie_KeyPrivateSqlFld, 
			   is_aie_KeyPublicSqlFld,
			   AIE_DB_TABLE_KEYS,
			   is_aie_KeyIDHashSqlFld,
			   hash_key_id);
         aie_sql_data->callback = aie_select_info_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = mykeys;
         hasCallbackData = false;
         if (__builtin_expect((!aie_sql_run(aie_sql_data)), false))
         {
            // Keyserver: key_db_find: select: %s
            aie_sys_log(1, aie_sql_meta_error(&aiengine_sql_meta_db));
         }
	 else if (__builtin_expect((hasCallbackData), true))
	 {
	    rc = true;
            #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
	    // Keyserver: key_db_find: Key loaded Hash[%s] Id[%ld]",
	    aie_sys_log(2, mykeys->hash_key_id, mykeys->key_id);
            #endif
            key_chain_append(mykeys);
	 }
	 else
	 {
	    // Keyserver: key_db_find: Key not found! [%s] SQL[%s]
	    aie_sys_log(3, hash_key_id, sql_cmd);
	 }
         aie_free(sql_cmd);
      }
      else
      {
        // Keyserver: key_db_find: Out of Memory?"
        aie_sys_log(4);
      }
      aie_sql_meta_release_db(&aiengine_sql_meta_db);
   }
   return(rc);
}

void do_db_save_key(struct mykeys *mykeys)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: do_db_save_key" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_db_save_key: "
	                     "DB save Keypair [%s]" },
      { AIE_LOG_ERROR, "Keyserver: do_db_save_key: %s" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_db_save_key: Speichere KeyId[%s]" },
      { AIE_LOG_ERROR, "Keyserver: do_db_save_key: Insert: %s" },
      { AIE_LOG_ERROR, "Keyserver: do_db_save_key: Commit: %s" },
      { AIE_LOG_ERROR, "Keyserver: do_db_save_key: Start Transaktion: %s" },
      { AIE_LOG_SERVER_INFO, "Keyserver: do_db_save_key: Datenbank freigeben" }
   };
   unsigned long sizeout = SIZE_KEY_STORAGE_OUT_BUF_LEN;
   unsigned long size_private_out = SIZE_KEY_STORAGE_PRIVATE_OUT_LEN;
   unsigned long size_public_out = SIZE_KEY_STORAGE_PUBLIC_OUT_LEN;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(get_temp_key_storage() && 
	                (InitDB() != NULL), true))
   {
       char KeyId[22];
       sprintf(KeyId, "%ld", mykeys->key_id);
       #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
       // Keyserver: do_db_save_key: DB save Keypair [%s]
       aie_sys_log(1, KeyId);
       #endif
       rsa_export(tmp_out_buf, &sizeout, PK_PRIVATE, &mykeys->private_key);
       if (__builtin_expect(((errnum =
                base64_encode(tmp_out_buf,  sizeout,
                        tmp_private_out, &size_private_out)) != CRYPT_OK),
		                                                        false))
       {
           // Keyserver: do_db_save_key: %s
           aie_sys_log(2, error_to_string (errnum));
       }
       else
       {
	  if (__builtin_expect((mykeys->key_typ == KEY_COMBINED), true))
	  {
             rsa_export(tmp_out_buf, &sizeout, PK_PUBLIC, &mykeys->private_key);
	  }
	  else
	  {
             rsa_export(tmp_out_buf, &sizeout, PK_PUBLIC, &mykeys->public_key);
	  }
          if (__builtin_expect(((errnum =
                                       base64_encode(tmp_out_buf,  sizeout,
                                                     tmp_public_out, 
						     &size_public_out)) 
		                                    != CRYPT_OK),false))
           {
                 // Keyserver: do_db_save_key: %s
                 aie_sys_log(2, error_to_string (errnum));
           }
	  else
	  {
             char *timestamp = aie_get_time_stamp();
             struct aie_sql_meta_feld_value_list sql_meta_feld_value_list[] =
             {
                 { is_aie_KeyIDSqlFld,		KeyId 			},
                 { is_aie_KeyIDHashSqlFld, 	mykeys->hash_key_id 	},
                 { is_aie_KeyPrivateSqlFld, 	(char *)tmp_private_out },
                 { is_aie_KeyPublicSqlFld,	(char *)tmp_public_out 	},
                 { is_aie_TimestampSqlFld,	timestamp 		},
		 { is_aie_RunCountSqlFld,       "0" 			}
             };
          struct aie_sql_meta_insert sql_meta_insert =
          {
                AIE_DB_TABLE_ID_KEYS,
                true,
                sql_meta_feld_value_list,
                sizeof(sql_meta_feld_value_list) / 
	           sizeof(struct aie_sql_meta_feld_value_list),
                false, 
                &aiengine_sql_meta_db
             };
             #if AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
             // Keyserver: do_db_save_key: Speichere KeyId[%s]
             aie_sys_log(3,  mykeys->hash_key_id);
             #endif
	     if (__builtin_expect(
		      aie_sql_meta_start_transaction(&aiengine_sql_meta_db),
		                                                        true))
	     {
                if (__builtin_expect(
			 (!aie_sql_meta_table_insert(&sql_meta_insert)),false))
                {
                   // Keyserver: do_db_save_key: Insert: %s
                   aie_sys_log(4, aie_sql_meta_error(&aiengine_sql_meta_db));
                }
	        if (__builtin_expect(
			 !aie_sql_meta_commit(&aiengine_sql_meta_db), 
		                                                       false))
	        {
                   // Keyserver: do_db_save_key: Commit: %s
                   aie_sys_log(5, aie_sql_meta_error(&aiengine_sql_meta_db));
	        }
	     }
	     else
	     {
                   // Keyserver: do_db_save_key: Start Transaktion: %s
                   aie_sys_log(6, aie_sql_meta_error(&aiengine_sql_meta_db));

	     }
	  }
       }
       if (__builtin_expect((aiengine_sql_meta_db.aie_sql_data != NULL), true))
       {
          #if AIENGINE_LOG_TRACE_DB_META_TRACE
          // Keyserver: do_db_save_key: Datenbank freigeben
          aie_sys_log(7);
          #endif
          aie_sql_meta_release_db(&aiengine_sql_meta_db);
       }
   }
   free_temp_key_storage();
}

static struct aie_sql_data *InitDB(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "Keyserver: InitDB" },
      { AIE_LOG_ERROR, "Keyserver: InitDB: "
	               "Datenbank Fehler beim Oeffnen \"%s\"" },
      { AIE_LOG_SERVER_INFO, "Keyserver: InitDB: Datenbank [%s] nun offen!" }
   };
   struct aie_sql_data *aie_sql_data = NULL;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((aiengine_sql_meta_db.aie_sql_data == NULL), true))
   {
      if ((aie_sql_data = aie_sql_meta_attach_db(AIE_DB_ID_KEYS, 
		                              &aiengine_sql_meta_db)) == NULL)
      {
         // Keyserver: InitDB: Datenbank Fehler beim Oeffnen \"%s\"
         aie_sys_log(1, AIE_DB_KEYS);
      }
      else
      {
         aie_sql_data->callback = NULL;
         aie_sql_data->data = NULL;
         aie_sql_data->sql_rc = 0;
         #if AIENGINE_LOG_TRACE_DB_META_TRACE
         // Keyserver: InitDB: Datenbank [%s] nun offen!
         aie_sys_log(2, AIE_DB_KEYS);
         #endif
      }
   }
   return(aie_sql_data);
}

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
const int   modul_key_db_size               = __LINE__;                      //
/* -------------------------------- EOF ------------------------------------ */
