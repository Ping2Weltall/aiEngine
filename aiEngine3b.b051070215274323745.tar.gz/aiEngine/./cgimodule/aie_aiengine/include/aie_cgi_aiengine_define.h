/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_cgi_register_define.h                                   */
/* CGI         : aie_aiengine.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_CGI_AIENGINE_DEFINE_H
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_CGI_AIENGINE_DEFINE_H
#define MYSELF_IS_CGI_NAME      			"aie_aiengine.cgi"
// Dispach an oder aus
#define AIENGINE_MULTI_MODULES                                               //

#define AIENGINE_CGI_APPL_NAME                     "aiengine"
#define AIENGINE_CGI_IMAGE_PATH                    "aie_images"
#define AIENGINE_CGI_MENUE_PATH                    "menue"
#define AIENGINE_CGI_IMAGE_BUTTON_PATH             "buttons"
#define AIENGINE_CGI_IMAGE_FRAME_PATH              "frame"
#define AIENGINE_CGI_IMAGE_SS_PATH                 "ss"
#define AIENGINE_CGI_IMAGE_IMP_PATH                "imp"
#define AIENGINE_CGI_IMAGE_BANNER_PATH             "banner"
#define AIENGINE_CGI_IMAGE_AD_PATH                 "ad"
#define AIENGINE_CGI_UPLOAD_PATH                   "upload"
#define AIENGINE_CGI_INSERATE_PATH                 "inserate"
#define AIENGINE_CGI_DATA_MEN_PATH                 "men"
#define AIENGINE_CGI_DATA_SUBMEN_PATH              "submen"
#define AIENGINE_CGI_DATA_BANNER_PATH              "banner"

#define AIENGINE_APPLIKATION_NAME    "<font color=red>New</font><font color=green>Art</font><font color=blue>4u</font>"
#define AIENGINE_HEADLINE            "Take a walk on the wild side ..."

#define AIENGINE_CHANNEL              "Internet Portal"
#define AIENGINE_CLASSIFICATION       "Art"
#define AIENGINE_COPYRIGHT            "&copy; 2003-05 Alexander J&ouml;rg Herrmann"
#define AIENGINE_PUBLISHER            "ECLIPSE Software &amp; Multimedia GmbH"
#define AIENGINE_AUTHOR               "Alexander J&ouml;rg Herrmann (webmaster@felixfrisch.de)"
#define AIENGINE_SITEINFO             "http://www.felixfrisch.de/robots.txt"
#define AIENGINE_TITLE                "NewArt4u"
#define AIENGINE_DESCRIPTION          "Computer, Kunst, Hosting, Web, Design, Surrealismus, WWW, BilderFreizeit, Portal"
#define AIENGINE_LANGUAGE             "deutsch, de, at, ch, com, german"
#define AIENGINE_EMAIL                "webmaster@felixfrisch.de"
#define AIENGINE_SUPPORT_EMAIL        "alexander_herrmann@yahoo.com.au"
#define AIENGINE_PAGE_TYP             "HTML"
#define AIENGINE_AUDIENCE             "all,alle"
#define AIENGINE_ROBOTS               "none"
#define AIENGINE_REPLY_TO             AIENGINE_VAR_EMAIL
#define AIENGINE_PAGE_TOPIC           AIENGINE_VAR_HOME_URL
#define AIENGINE_RESOURCE_TYP         "document"
#define AIENGINE_PROXY                "no"
#define AIENGINE_CONTENT_TYP          "text/html;charset=iso-8859-1"
#define AIENGINE_CONTENT_STYLE        "text/css"
#define AIENGINE_CONTENT_LANGUAGE     AIENGINE_VAR_LANGUAGE
#define AIENGINE_REVISIT_AFTER        "11 Days"
#define AIENGINE_EXPIRES              "$(t129666);$(y);-$(m);-$(d);"
#define AIENGINE_CREATED              "$(y);-$(m);-$(d);"
#define AIENGINE_DOCDATE              AIENGINE_VAR_ASCDATE

#define appl_menue_intro                "intro.txt"
#define appl_menue_computerkunst        "cpuart.txt"
#define appl_menue_download             "download.txt"
#define appl_menue_link                 "link.txt"

#define pic_menue_intro                 "intro.jpg"
#define pic_menue_computerkunst         "cpuart.jpg"
#define pic_menue_download              "download.jpg"
#define pic_menue_link                  "link.jpg"


#define pic_imp_intro_a                 "tab1.jpg"
#define pic_imp_intro_b                 "tab1over.jpg"
#define pic_imp_intro_s                 "tab1a.jpg"
#define pic_imp_computerkunst_a         "tab2.jpg"
#define pic_imp_computerkunst_b         "tab2over.jpg"
#define pic_imp_computerkunst_s         "tab2a.jpg"
#define pic_imp_download_a              "tab3.jpg"
#define pic_imp_download_b              "tab3over.jpg"
#define pic_imp_download_s              "tab3a.jpg"
#define pic_imp_link_a                  "tab4.jpg"
#define pic_imp_link_b                  "tab4over.jpg"
#define pic_imp_link_s                  "tab4a.jpg"

#define pic_bg_work                     "work.jpg"
#define pic_bg_work1                    "work1.jpg"
#define pic_bg_square                   "square.jpg"
//char *pic_bg_work2 =                    MK_IMAGE("work2.jpg");

#define pic_bg_top                      "top.jpg"
#define pic_bg_imp                      "imp.jpg"


#define AIENGINE_HOME_URL               "http://p15137950.pureserver.info"
#define AIENGINE_SAVE_HOME_URL          "https://p15137950.pureserver.info"
#define SPONSOR_HOME_URL                "http://www.felixfrisch.de"

#define  sAdKategorieNewart4u           "99"

#define appl_banner_aiengine             "werbung.txt"

#define pic_top_submen_head_image        MK_MENUE_IMAGE("submenhead.jpg")
#define pic_top_submen_head_h_image      MK_MENUE_IMAGE("submenheadh.jpg")
#define pic_top_men_head_image           MK_MENUE_IMAGE("top.jpg")
#define pic_top_men_head_h_image         MK_MENUE_IMAGE("toph.jpg")
#define pic_row_men_image                MK_MENUE_IMAGE("menrow.jpg")
#define pic_row_men_h_image              MK_MENUE_IMAGE("menrowh.jpg")
#define pic_col_men_image                MK_MENUE_IMAGE("mencol.jpg")
#define pic_col_men_h_image              MK_MENUE_IMAGE("mencolh.jpg")

#define IMP_AIENGINE_INTRO              1
#define IMP_AIENGINE_CPUART             2
#define IMP_AIENGINE_DOWNLOAD           3
#define IMP_AIENGINE_LINK               4
#define IMP_AIENGINE                    99

#if 0
#define AIENGINE_CGI_MAIN                                                      \
int main(void)                                                                 \
{                                                                              \
   int rc = 0;                                                                 \
   if (Init_aIEngine_CGI(AIENGINE_PROG_QUEUE_ID))                          \
   {                                                                           \
      rc = aIEngine(AIENGINE_RUN_AS_CGI, CgiMyself, StartFrameCGIVal,      \
		      StartPageCGIVal);                                        \
      aie_Free_aIEngine_cgi_variablen();                                       \
      if (!aie_mem_dump())                                                     \
      {                                                                        \
        /* aie_mem_usage(); */                                                 \
      }                                                                        \
   }                                                                           \
   else                                                                        \
   {                                                                           \
      rc = AIENGINE_INIT_FAILED;                                               \
   }                                                                           \
   return(0);                                                                  \
}
#endif
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
#endif
/* -------------------------------- EOF ------------------------------------ */

