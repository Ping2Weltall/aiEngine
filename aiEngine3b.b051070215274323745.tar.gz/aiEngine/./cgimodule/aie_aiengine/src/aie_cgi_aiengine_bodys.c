/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_cgi_aiengine_bodys.c                                    */
/* CGI         : aie_aiengine.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 14.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_mybodys_version       = "1.0.0";                                 //
char *modul_mybodys               = "Bodys";                                 //
char *modul_mybodys_date          = __DATE__;                                //
char *modul_mybodys_time          = __TIME__;                                //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_CLIENT_LIB			1			     //
#define AIENGINE_USE_CGI_CLIENT_LIB		1			     //
#define AIENGINE_USE_CGI_LIB			1			     //
#define AIENGINE_USE_WIN_CGI_LIB		1			     //
#define AIENGINE_USE_SERVER_LIB			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
#define AIENGINE_USE_SOCKETS			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_aiengine_cgivar.h"                                         //
#include "aie_cgi_aiengine_cgival.h"                                         //
#include "aie_cgi_aiengine_bodys.h"                                          //
#include "aie_cgi_aiengine_serial.h"                                         //
#include "aie_cgi_aiengine_sql.h"                                            //
#include "aie_cgi_aiengine_user.h"                                           //
#include "aie_cgi_aiengine_watchdog.h"                                       //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *ht_table_b0;                                                    //
extern char *ht_table_100p;                                                  //
extern char *ht_table_dashed_frame;                                          //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static void body_headline(const char *text);                                 //
static void body_footline(void);                                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
                                                                             //
/*****************************************************************************/
void server_start_stop_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "server_start_stop_page" },
      { AIE_LOG_SECURITY, "Benutzer %s hat nicht gen�gend Zugriffsrechte um "
	                  "den System Server [%s] zu %s" },
      { AIE_LOG_SECURITY_INFO, "Server %s %s von Benutzer %s" }
   };
   char *ServerName = aie_GetCharCGIValue(cgi_parameter, is_aie_ServerStartStopNameCGIVar);
   char *BenutzerName = aie_GetCharCGIValue(cgi_parameter, is_aie_UserCGIVar);
   int Funktion = aie_GetIntCGIValue(cgi_parameter, is_aie_ServerStartStopCmdCGIVar);

   aie_sys_log(0);
   if (strcmp(ServerName, "httpd") == 0)
   {
      if (Funktion)
      {
        html_static("Fehler: You should not try to stop the Webserver with this programm!\n");
      }
      else
      {
        html_static("Fehler: The Webserver is allready running ..\n");
      }
   }
   else
   {
      int msg_typ;
      char *strFkt;
      pid_t pid = -1;
      u64 user_rights = aie_get_benutzer_rechte(BenutzerName, false);
      if (Funktion)
      {
        strFkt = "stoppen";
	msg_typ = MSG_PROG_KILL;
        pid = aie_GetIntCGIValue(cgi_parameter,
	                         is_aie_ServerStartStopPidCGIVar);
      }
      else
      {
        strFkt = "starten";
	msg_typ = MSG_PROG_START;
      }
      if (AIE_USER_CAN_START_SERVER(user_rights) || 
	  AIE_USER_CAN_STOP_SERVER(user_rights) ||
	  AIE_USER_CAN_SYSTEM_SERVER(user_rights)) 
      {
	 if (!AIE_USER_CAN_SYSTEM_SERVER(user_rights) && 
	                            (strncmp(ServerName, "aIEngine", 8) == 0))
	 {
            // Benutzer %s hat nicht gen�gend Zugriffsrechte um "
	    // "den System Server [%s] zu %s", 
            aie_sys_log(1, BenutzerName, ServerName, strFkt);
            html_vt(aie_log_msg_select(1), BenutzerName, ServerName, strFkt);
	 }
	 else
	 {
	    // Server %s %s von Benutzer %s
            aie_sys_log(2, ServerName, strFkt, BenutzerName);
	    if (aie_send_prog_start_stop_message(ServerName, pid, msg_typ))
	    {
	       html_vt(">#ServerStartStop# %s %s\n", strFkt, ServerName);
	    }
	 }
      }
      else
      {
         // Benutzer %s hat nicht gen�gend Zugriffsrechte um "
	 // "den System Server [%s] zu %s", 
         aie_sys_log(1, BenutzerName, ServerName, strFkt);
         html_vt(aie_log_msg_select(1), BenutzerName, ServerName, strFkt);
      }
   }
   html_static("!\n");
}

void show_version(void)
{
   //sys_log("%s(%d): Versionsinformation", __FILE__, __LINE__);
   //show_aiengine_version(false);
}

void serial_pool_info_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "serial_pool_info_page" }
   };
    char *Seriennummer = aie_GetCharCGIValue(cgi_parameter, 
	                                      is_aie_SucheSeriennummerCGIVar);  
   char *Modul = aie_GetCharCGIValue(cgi_parameter, is_aie_SucheModulCGIVar);  
   char *Freigabe = aie_GetCharCGIValue(cgi_parameter, is_aie_SucheFreigabeCGIVar);  
   aie_sys_log(0);
   if(!list_serial_pool(Seriennummer, Modul, Freigabe))
   {
      html_vt(">\tKeine Serial Pool Info verfuegbar\n");
   }
}

void serial_modul_info_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "serial_modul_info_page" }
   };
   char *Modul = aie_GetCharCGIValue(cgi_parameter, is_aie_SucheModulCGIVar);  
   char *UserID = aie_GetCharCGIValue(cgi_parameter, is_aie_SucheUserIDCGIVar);  
   char *Freigabe = aie_GetCharCGIValue(cgi_parameter, is_aie_SucheFreigabeCGIVar);  
   aie_sys_log(0);
   if(!list_module(Modul, UserID, Freigabe))
   {
      html_vt(">\tKeine Installierte Module Info verfuegbar\n");
   }
}

void status_info_page(struct aie_cgi_parameter *cgi_parameter)
{
   cgi_parameter = cgi_parameter;
   send_taskliste();
   //html_vt(">\tKeine Info verfuegbar\n");
}

void performance_info_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "performance_info_page [%s]" },
      { AIE_LOG_ERROR, "Fehler: %s" }
   };
#ifndef AIENGINE_PERFORMANCE_LOGFILE
   #warning Es wurde keine Performance Logdatei spezifiziert!
   char *target_file = "/aIEngine/data/logs/performance.log";
#else
   char *target_file = AIENGINE_PERFORMANCE_LOGFILE;
#endif
    bool hasError = false;
    char buffer[255];
    aie_sys_log(0, target_file);
    cgi_parameter = cgi_parameter;
    //sys_log("%s(%d): Auswerten[%s]", __FILE__, __LINE__, target_file);
    if (!aie_file_exist(target_file))
    {
       sprintf(buffer, "Performance Datei %s nicht gefunden!", 
	                                                  target_file);
       hasError = true;
    }
    else
    {
       FILE *fptr;
       if ((fptr = fopen(target_file, "rt")) == NULL)
       {
	  sprintf(buffer,
		"Performance Datei %s konnte nicht geoeffnet werden!", 
		                                             target_file);
	  hasError = true;
       }
       else
       {
	  while (!feof(fptr))
          {
	     fgets(buffer, sizeof(buffer), fptr);
	     if (!feof(fptr))
	     {
	        html_vt("%s", buffer);
	     }
	  }
	  fclose(fptr);
       }
       hasError = false;
    }
    if (hasError)
    {   
       html_vt("Fehler: %s\n", buffer);
       aie_sys_log(1, buffer);
    }
}

void logfile_info_page(struct aie_cgi_parameter *cgi_parameter)
{
   char *target_file = "/aIEngine/data/logs/aIEngine_Error.log";
   unsigned int StartLine = aie_GetIntCGIValue(cgi_parameter,  
	                           is_aie_LogfileLineStartCGIVar);
    char *SuchenNach = aie_GetCharCGIValue(cgi_parameter, 
	                                      is_aie_SucheLogfileTextCGIVar);  
    bool hasError = false;
    char buffer[1024];
    struct aie_suchen_liste *suchen_liste_base = NULL;
    if (SuchenNach != NULL)
    {
       suchen_liste_base = aie_make_suchen_liste(SuchenNach, &suchen_liste_base);
    }
    //sys_log("%s(%d): Logfile Poll", __FILE__, __LINE__);
    //sys_log("%s(%d): Auswerten[%s]", __FILE__, __LINE__, target_file);
    if (!aie_file_exist(target_file))
    {
       sprintf(buffer, "Logfile Datei %s nicht gefunden!", 
	                                                  target_file);
       hasError = true;
    }
    else
    {
       FILE *fptr;
       if ((fptr = fopen(target_file, "rt")) == NULL)
       {
	  sprintf(buffer,
		"Logfile Datei %s konnte nicht geoeffnet werden!", 
		                                             target_file);
	  hasError = true;
       }
       else
       {
	  register unsigned int isLine = 0;
	  register unsigned int z = 0;
	  char *msg;
	  char source[50] = "???";
	  char modul[50] = "???";
	  int line = -1;
          char *hasVonDate = aie_GetCharCGIValue(cgi_parameter, 
	                                         is_aie_SucheLogfileVonCGIVar);
          char *hasBisDate = aie_GetCharCGIValue(cgi_parameter, 
	                                         is_aie_SucheLogfileBisCGIVar);
          char stamp_date_von[15] = "20??????000000";
          char stamp_date_bis[15] = "20??????235959";
          if ((hasVonDate != NULL) && (*hasVonDate != '\0'))
          {
	     memcpy(stamp_date_von + 2, hasVonDate + 6 , 2);
     	     memcpy(stamp_date_von + 4, hasVonDate + 3 , 2);
	     memcpy(stamp_date_von + 6, hasVonDate + 0 , 2);
	  }
	  else
	  {
	     hasVonDate = NULL;
	  }
          if ((hasBisDate != NULL) && (*hasBisDate != '\0'))
	  {
	     memcpy(stamp_date_bis + 2, hasBisDate + 6 , 2);
	     memcpy(stamp_date_bis + 4, hasBisDate + 3 , 2);
	     memcpy(stamp_date_bis + 6, hasBisDate + 0 , 2);
	  }
	  else
	  {
	     hasBisDate = NULL;
	  }
	  if (StartLine == 0)
	  {
             html_t(">ColCount: 6\n");
	     html_t(">\tZeit\tIP / Typ\tModul\tSource\tZeile\tMitteilung\n");
	  }
	  while (!feof(fptr))
          {
	     fgets(buffer, sizeof(buffer), fptr);
	     if (!feof(fptr))
	     {
		if ((StartLine == 0) || (isLine >= StartLine))
		{
		   static bool last_do_list = false;
		   bool do_list = true;
		   if (*buffer == '2')
		   {
		      if (hasVonDate != NULL)
		      {
                         if (strncmp(buffer, stamp_date_von, 8) < 0)
		         {
			    do_list = false;
		         }
		      } 
		      else
		      {
			 do_list = true;
		      }
		      if (hasBisDate != NULL)
		      {
                         if (strncmp(buffer, stamp_date_bis, 8) > 0)
		         {
			    do_list = false;
		         }
		      }
		      if (do_list && (suchen_liste_base != NULL))
		      {
			 do_list = aie_suche_liste_in_textline(buffer, 
			                                    suchen_liste_base);
		      }
		   }
		   else
		   {
		      do_list = last_do_list;
		   }
		   last_do_list = last_do_list;
		   if (do_list && ((msg = strchr(buffer, ':')) != NULL))
		   {
		      char *sptr, *sptr2;
		      line = -1;
	              memset(source, '\0', sizeof(source));
	              memset(modul, '\0', sizeof(modul));
		      *msg = '\0';
		      msg++;
		      if ((sptr = strchr(buffer + 15, '[')) != NULL)
		      {
		         *sptr = '\0';
		         sptr++;
		         if ((sptr2 = strchr(sptr, '(')) != NULL)
		         {
		            *sptr2 = '\0';
		            sptr2++;
		            line = atoi(sptr2);
			    if ((sptr2 = strchr(sptr, '/')) != NULL)
			    {
		               strncpy(source, sptr2 + 1, sizeof(source) - 1);
			    }
			    else
			    {
		               strncpy(source, sptr, sizeof(source) - 1);
			    }
		         }
			 sptr = msg + strlen(msg) - 2;
			 if ((sptr > msg) && (*sptr == ']'))
			 {
			     *sptr = '\0';
			 }
		         if (*(buffer + 14) == '@')
		         {
		            *(buffer + 14) = '\0';
		         }
			 sptr = source + strlen(source) + 1;
			 while (sptr > source)
			 {
			    if (*sptr == '.')
			    {
			       *sptr = '\0';
			       break;
			    }
			    sptr--;
			 }
			 if ((sptr = strchr(buffer + 15, '-')) != NULL)
			 {
			    *sptr = '\0';
			    sptr++;
			 }
			 else
			 {
			    sptr = "*Unbekannt*";
			 }
			 strncpy(modul, buffer + 15, sizeof(modul) - 1);
	                 html_vt(">\t%s\t%s\t%s\t%s\t %d\t%s\n", buffer, 
			                                           sptr,  
							 modul, 
			                                 source, line, msg);
		         if (z > 1000)
		         {
		            html_vt(">\t\t\t!!!!\t!!!!\t!!!!\tNur %d Zeilen wurden angezeigt!\n", z + 1);
		            break;
		         }
		      }
		   }
		   else
		   {
		      if (do_list)
		      {
		         html_vt(">\t\t%d -->\t%s\t%s\t %d\t%s\n", 
			                                    isLine + 1, 
							    modul, 
			                                    source, line, 
							    buffer);
		      }
		   }
		   if (do_list)
		   {
		      z++;
		   }
		}
		isLine++;
	     }
	  }
	  fclose(fptr);
	  html_vt(">Logfile Line: %d\n", isLine);
       }
    }
    if (hasError)
    {   
       html_vt("Fehler: %s\n", buffer);
    }
    if (suchen_liste_base != NULL)
    {
       aie_free_suchen_liste(&suchen_liste_base);
    }
}


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void body_headline_tbl_start(const char *text)
{
   html_static("<div id=\"body_frame\" style=\"position:absolute;z-index:0;visibility:visible;filter:alpha(enabled=1,opacity=95);left:0px; top:0px;\">");
   body_headline(text);
   TBL_STD_ROW_COL_START
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void body_footline_tbl_end(void)
{
   TBL_STD_COL_ROW_END
   body_footline();
   html_static("</div>");
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void frame_tbl(int nr, const char *text)
{
   if (nr == BODY_TBL_BODY_R)
   {
      eTABLE
   }
   else
   {
      bTABLEwv("780", ht_table_b0);
      if (nr == HEAD_TBL_TOP)
      {
         bTR
         bTDcshacbg("6", "20", AIE_MK_FRAME_IMAGE("mft.jpg"));
         TBL_STD_COL_ROW_END
      }
      bTR
      bTDwacbg("10", AIE_MK_FRAME_IMAGE("mfl.jpg"));
      NBSP
      eTD
      bTDwacbg("5", AIE_MK_FRAME_IMAGE("titellt.jpg"));
      NBSP
      eTD
      switch(nr)
      {
          case HEAD_TBL_TOP:
            {
               bTDcshacbg("1", "90", AIE_MK_FRAME_IMAGE("titeltxt.jpg"));
               bFONTs("+2");
               bB
               NBSP
               html_t(text);
               eB
               eFONT
               eTD
            }
          break;
          case BODY_TBL_START:
            {
               bTDcshacbg("1", "40", AIE_MK_FRAME_IMAGE("titelpt.jpg"));
               NBSP
               eTD
            }
            break;
          case BODY_TBL_END:
            {
               bTDcshacbg("1", "40", AIE_MK_FRAME_IMAGE("titelpb.jpg"));
               NBSP
               eTD
            }
            break;
      }
   }
   if (nr ==  BODY_TBL_BODY_L)
   {
      bTDwacbg("750", AIE_MK_FRAME_IMAGE("1px.jpg"));
      //bTABLE
      bTABLEwv("750", ht_table_b0);
   }
   else
   {
      bTDwacbg("5", AIE_MK_FRAME_IMAGE("titelrt.jpg"));
      NBSP
      eTD
      bTDwacbg("10", AIE_MK_FRAME_IMAGE("mfr.jpg"));
      NBSP
      if (nr == BODY_TBL_END)
      {
         eTR
         bTR
         bTDcshacbg("6", "20", AIE_MK_FRAME_IMAGE("mfb.jpg"));
      }
      TBL_STD_COL_ROW_TABLE_END
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void body_headline(const char *text)
{
   frame_tbl(HEAD_TBL_TOP, text);
   frame_tbl(BODY_TBL_START, NULL);
   frame_tbl(BODY_TBL_BODY_L, NULL);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void body_footline(void)
{
   frame_tbl(BODY_TBL_BODY_R, NULL);
   frame_tbl(BODY_TBL_END, NULL);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void page_not_found(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "page_not_found" },
      { AIE_LOG_CGI_INFO, "Agent is %s" }
   };
   if (AIE_AGENT_AIENGINE && (cgi_parameter != NULL))
   {
      struct aie_cgi_variables *cgi_vars_ptr = cgi_parameter->cgi_variables;
      const char *cgiRemoteAddr = 
	                     aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_ADDR);
      html_static("Unerlaubter Zugriff auf unbekannte Seite! \n"
	      "Logfile Eintrag vorgenommen! \n");
      html_vt("Verantwortliche IP: %s\n", cgiRemoteAddr);
      while(cgi_vars_ptr != NULL)
      {
	 html_vt("%s=%s\n", cgi_vars_ptr->nam, cgi_vars_ptr->val);
	 cgi_vars_ptr = cgi_vars_ptr->next;
      }
   }
   else
   {
      const char *support_email = 
	       aie_GetStandardAsecurVariableValue(AIENGINE_VAR_SUPPORT_EMAIL);
      const char *cgiUserAgent = 
	                   aie_get_aIEngine_env(AIENGINE_ENV_HTTP_USER_AGENT);
      char *sptr;
      // Agent is %s
      aie_sys_log(1, cgiUserAgent);
      if (__builtin_expect(
       ((sptr = 
	    aie_GetCharCGIValue(cgi_parameter, isCodedCGIVar)) != NULL),false))
      {
         html_static("Never should reach!<br>");
         HR
         html_vt("Should have used:[%s]", sptr);
         HR
         #ifdef aie_use_keys
            html_vt("Decoded:[%s]", do_decode_string(sptr));
         #else
	    html_static("Keine Verschluesselung compiliert!");
         #endif
         HR
      }
      else
      {
         char *cgiRequestUri = 
	                   aie_strdup(
		            aie_get_aIEngine_env(AIENGINE_ENV_REQUEST_URI));
         int len = cgiRequestUri != NULL ? strlen(cgiRequestUri) : 0;

         if ((len > 4) && ((strcmp((cgiRequestUri + len - 4), ".ida") == 0) ||
                        (strcmp((cgiRequestUri + len - 4), ".exe") == 0)))
         {
            //my_version(true);
         }
         else
         {
            body_headline_tbl_start(cgi_parameter->Titel);
            bCENTER
            bFONT_s1
            bB
            html_static("Unbekannte Seite");
            eB
            BR2
            eFONT
            html_static("Die von Ihnen gew&uuml;nschte Seite:");
            BR2
            NBSP
            NBSP
            bFONTc("red");
            if (len > 50)
            {
               *(cgiRequestUri + 47) = '\0';
               strcat(cgiRequestUri, "...");
            }
            html_t(cgiRequestUri);
            eFONT
            BR2
            html_static("ist leider auf unserem Server nicht verf&uuml;gbar!");
            BR2
            html_vt("<a href=\"mailto:%s\">", support_email);
            html_static("Support");
            NBSP
            html_vt("(%s)", support_email);
            eA
            BR2
            eCENTER
            TBL_STD_COL_CHANGE
            NBSP
            body_footline_tbl_end();
            HR
         }
      }
      #ifdef aie_use_keys
   //if ((sptr != NULL) && (*sptr != '\0'))
   //{
   //   html_vt("\n\n%s\n", sptr);
   //}
      #endif
      BR2
      HR
   }
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_mybodys_size          = __LINE__;                                //
/* -------------------------------- EOF ------------------------------------ */

