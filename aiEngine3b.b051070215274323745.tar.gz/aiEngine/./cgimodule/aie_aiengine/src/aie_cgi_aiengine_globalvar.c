/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : globalvar.cpp                                               */
/* CGI         : aie_aiengine.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_globalvar_version    = "1.0.0";                                  //
char *modul_globalvar            = "GlobalVar";                              //
char *modul_globalvar_date       = __DATE__;                                 //
char *modul_globalvar_time       = __TIME__;                                 //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_CGI_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_aiengine_define.h"                                         //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *aiengine_CGI_Myself;                                            //
extern char *aiengine_HomeUrl;                                               //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
char WhoMade[40];                                                            //
char LinkedFrom[132];                                                        //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/

/*****************************************************************************/

AIE_STRUCT_CGI_GLOBALE_VARIABLEN =
{
   { AIENGINE_VAR_CGI_MYSELF,           MYSELF_IS_CGI_NAME        },
   { AIENGINE_VAR_GLOBAL_APPL_NAME,     AIENGINE_APPLIKATION_NAME },
   { AIENGINE_VAR_CHANNEL,              AIENGINE_CHANNEL          },
   { AIENGINE_VAR_CLASSIFICATION,       AIENGINE_CLASSIFICATION   },
   { AIENGINE_VAR_COPYRIGHT,            AIENGINE_COPYRIGHT        },
   { AIENGINE_VAR_PUBLISHER,            AIENGINE_PUBLISHER        },
   { AIENGINE_VAR_AUTHOR,               AIENGINE_AUTHOR           },
   //{ AIENGINE_VAR_HOME_URL,             aiengine_HomeUrl          },
   { AIENGINE_VAR_HOME_URL,             "."          },
   { AIENGINE_VAR_SITEINFO,             AIENGINE_SITEINFO         },
   { AIENGINE_VAR_TITLE,                AIENGINE_TITLE            },
   { AIENGINE_VAR_DESCRIPTION,          AIENGINE_DESCRIPTION      },
   { AIENGINE_VAR_LANGUAGE,             AIENGINE_LANGUAGE         },
   { AIENGINE_VAR_EMAIL,                AIENGINE_EMAIL            },
   { AIENGINE_VAR_SUPPORT_EMAIL,        AIENGINE_SUPPORT_EMAIL    },
   { AIENGINE_VAR_PAGE_TYP,             AIENGINE_PAGE_TYP         },
   { AIENGINE_VAR_AUDIENCE,             AIENGINE_AUDIENCE         },
   { AIENGINE_VAR_ROBOTS,               AIENGINE_ROBOTS           },
   { AIENGINE_VAR_REPLY_TO,             AIENGINE_REPLY_TO         },
   { AIENGINE_VAR_PAGE_TOPIC,           AIENGINE_PAGE_TOPIC       },
   { AIENGINE_VAR_RESOURCE_TYP,         AIENGINE_RESOURCE_TYP     },
   { AIENGINE_VAR_PROXY,                AIENGINE_PROXY            },
   { AIENGINE_VAR_CONTENT_TYP,          AIENGINE_CONTENT_TYP      },
   { AIENGINE_VAR_CONTENT_STYLE,        AIENGINE_CONTENT_STYLE    },
   { AIENGINE_VAR_CONTENT_LANGUAGE,     AIENGINE_CONTENT_LANGUAGE },
   { AIENGINE_VAR_REVISIT_AFTER,        AIENGINE_REVISIT_AFTER    },
   { AIENGINE_VAR_EXPIRES,              AIENGINE_EXPIRES          },
   { AIENGINE_VAR_CREATED,              AIENGINE_CREATED          },
   { AIENGINE_VAR_DOCDATE,              AIENGINE_DOCDATE          },
   //{ AIENGINE_VAR_CGI_MYSELF,           aiengine_CGI_Myself       }
};
AIE_INT_VAR_SIZE_CGI_GLOBALE_VARIABLEN;

AIE_STRUCT_CGI_STATIC_VARIABLES =
{
   { AIENGINE_VAR_DATA_ROOT,              AIENGINE_CGI_DATA_ROOT            },
   { AIENGINE_VAR_DATA_DIR,               AIENGINE_CGI_DATA_DIR             },
   { AIENGINE_VAR_HTDOCS_ROOT,            AIENGINE_CGI_HTDOCS_ROOT          },
   { AIENGINE_VAR_HTDOCS_DIR,             AIENGINE_CGI_HTDOCS_DIR           },
   { AIENGINE_VAR_APPL_NAME,              AIENGINE_CGI_APPL_NAME            },
   { AIENGINE_VAR_IMAGE_PATH,             AIENGINE_CGI_IMAGE_PATH           },
   { AIENGINE_VAR_MENUE_PATH,             AIENGINE_CGI_MENUE_PATH           },
   { AIENGINE_VAR_IMAGE_BUTTON_PATH,      AIENGINE_CGI_IMAGE_BUTTON_PATH    },
   { AIENGINE_VAR_IMAGE_FRAME_PATH,       AIENGINE_CGI_IMAGE_FRAME_PATH     },
   { AIENGINE_VAR_IMAGE_SS_PATH,          AIENGINE_CGI_IMAGE_SS_PATH        },
   { AIENGINE_VAR_IMAGE_BANNER_PATH,      AIENGINE_CGI_IMAGE_BANNER_PATH    },
   { AIENGINE_VAR_IMAGE_AD_PATH,          AIENGINE_CGI_IMAGE_AD_PATH        },
   { AIENGINE_VAR_IMAGE_IMP_PATH,         AIENGINE_CGI_IMAGE_IMP_PATH       },
   { AIENGINE_VAR_UPLOAD_PATH,            AIENGINE_CGI_UPLOAD_PATH          },
   { AIENGINE_VAR_INSERATE_PATH,          AIENGINE_CGI_INSERATE_PATH        },
   { AIENGINE_VAR_DATA_PATH,              AIENGINE_VARS_DATA_PATH           },
   { AIENGINE_VAR_HTDOCS_PATH,            AIENGINE_VARS_HTDOCS_PATH         },
   { AIENGINE_VAR_IMAGE_UPLOAD_PATH,      AIENGINE_VARS_IMAGE_UPLOAD_PATH   },
   { AIENGINE_VAR_MEN_PATH,               AIENGINE_CGI_DATA_MEN_PATH        },
   { AIENGINE_VAR_SUBMEN_PATH,            AIENGINE_CGI_DATA_SUBMEN_PATH     },
   { AIENGINE_VAR_BANNER_PATH,            AIENGINE_CGI_DATA_BANNER_PATH     },
   { AIENGINE_VAR_DATA_MEN_PATH,          AIENGINE_VARS_DATA_MEN_PATH       },
   { AIENGINE_VAR_DATA_SUBMEN_PATH,       AIENGINE_VARS_DATA_SUBMEN_PATH    },
   { AIENGINE_VAR_DATA_BANNER_PATH,       AIENGINE_VARS_DATA_BANNER_PATH    }
};
AIE_INT_VAR_SIZE_CGI_STATIC_VARIABLES;


AIE_STRUCT_META_HEAD_INFO =
{
   { HTEQUIV, 
      aIEngine_cfg_var_content_language,
      aIEngine_ini_val_content_language
   },
   { HTEQUIV,
      aIEngine_cfg_var_content_type,
      aIEngine_ini_val_content_type
   },
   { HTEQUIV,
      aIEngine_cfg_var_content_style_type,
      aIEngine_ini_val_content_style_type
   },
   { HTEQUIV,
      aIEngine_cfg_var_reply_to,
      aIEngine_ini_val_reply_to 
   },
   //{ HTNAME,  
   //aIEngine_cfg_var_channel,            
   //aIEngine_ini_val_channel 
   //},
   { HTNAME,
      aIEngine_cfg_var_copyright,
      aIEngine_ini_val_copyright
   },
   { HTNAME,
      aIEngine_cfg_var_description,
      aIEngine_ini_val_description
   },
   { HTNAME,
      aIEngine_cfg_var_classification,
      aIEngine_ini_val_classification
   },
   { HTNAME,
      aIEngine_cfg_var_resource_type,
      aIEngine_ini_val_resource_type
   },
   { HTNAME,
      aIEngine_cfg_var_robots, 
      aIEngine_ini_val_robots 
   },
   { HTNAME, 
      aIEngine_cfg_var_revisit_after,
      aIEngine_ini_val_revisit_after
   },
   { HTNAME,
      aIEngine_cfg_var_siteinfo,
      aIEngine_ini_val_siteinfo
   },
   { HTNAME,
      aIEngine_cfg_var_page_topic,
      aIEngine_ini_val_home_url
   },
   { HTNAME,
      aIEngine_cfg_var_page_type,
      aIEngine_ini_val_page_type
   },
   { HTNAME,
      aIEngine_cfg_var_generator,
      aIEngine_ini_val_generator
   },
   { HTNAME,
      aIEngine_cfg_var_publisher,
      aIEngine_ini_val_publisher
   },
   { HTNAME,
      aIEngine_cfg_var_author,
      aIEngine_ini_val_author
   },
   { HTNAME,
      aIEngine_cfg_var_email,
      aIEngine_ini_val_email
   },
   { HTNAME,
      aIEngine_cfg_var_audience,
      aIEngine_ini_val_audience
   },
   { HTNAME,
      aIEngine_cfg_var_expires,
      aIEngine_ini_val_expires
   },
   { HTNAME,
      aIEngine_cfg_var_created,
      aIEngine_ini_val_created
   },
   { HTNAME,
      aIEngine_cfg_var_proxy_keep_alive,
      aIEngine_ini_val_proxy_keep_alive
   },
   { HTNAME,
      aIEngine_cfg_var_date,
      aIEngine_ini_val_date
   },
   { HTNAME,
      aIEngine_cfg_var_language,
      aIEngine_ini_val_language
   },
   { HTNAME,
      aIEngine_cfg_var_linked_from,
      AIENGINE_VAR_LINKED_FROM
   },
   { HTNAME,
      aIEngine_cfg_var_made_4_ip,
      AIENGINE_VAR_REMOTE_IP
   }
};
AIE_INT_VAR_SIZE_META_HEAD_INFO;

AIE_STRUCT_BODY_TAG =
{
   { "BGCOLOR", "#C0FFC0" },
   { "TEXT",    "#000000" },
   { "LINK",    "#000000" },
   { "VLINK",   "#551a8b" },
   { "ALINK",   "#0000ee" }
};
AIE_INT_VAR_SIZE_BODY_TAG;

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_globalvar_size       = __LINE__;                                 //
/* -------------------------------- EOF ------------------------------------ */

