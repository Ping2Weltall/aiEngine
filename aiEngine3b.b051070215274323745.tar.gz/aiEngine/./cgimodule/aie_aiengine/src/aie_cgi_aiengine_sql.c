/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_cgi_aiengine_sql.c                                      */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 16.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_aie_cgi_aiengine_sql_version      = "2.0.1";                     //
char *modul_aie_cgi_aiengine_sql              = "OpenSQL";                   //
char *modul_aie_cgi_aiengine_sql_date         = __DATE__;                    //
char *modul_aie_cgi_aiengine_sql_time         = __TIME__;                    //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SQL_WRAP_LIB		1			     //
#define AIENGINE_USE_DB_LIB			1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <unistd.h>                                                         //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aie_crc32.h"
/*---------------------------------------------------------------------------*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_aiengine_sql.h"                                            //
#include "aie_cgi_aiengine_shared.h"                                         //
#include "aie_cgi_aiengine_cgivar.h"                                         //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *cgiRequestUri;                                                  //
extern char *cgiRemoteAddr;
extern char *cgiUserAgent;
extern struct aie_sql_meta_db ff_sql_meta_db;
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
bool hasData = false;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct free_sql_callback_data
{
   FILE *tmp_fptr;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static int aie_select_sql_callback(void *pArg, int nArg,                     //
                                           char **azArg, char **azCol);      //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
/*****************************************************************************/

void free_sql_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "free_sql_page" },
      { AIE_LOG_SECURITY_INFO, "SQL von Benutzer %s Datenbasis[%s] SQL[%s]" },
      { AIE_LOG_ERROR,    "Temporaere Datei [%s] konnte nicht geoeffnet werden!" },
      { AIE_LOG_ERROR,    "DB Fehler %s[%s]" },
      { AIE_LOG_WARN,     "Kein SQL Statement?!" },
      { AIE_LOG_ERROR,    "Nicht genug Hauptspeicher fuer Puffer?!" },
      { AIE_LOG_ERROR,    "Problem beim initialisieren der Datenbank" },
      { AIE_LOG_ERROR,    "Datenbasis [%s] nicht gefunden!" }
   };
   static struct free_sql_callback_data free_sql_callback_data;
   char *sql_cmd = aie_GetCharCGIValue(cgi_parameter, 
	                               is_aie_SQLStatementCGIVar);
   char *BenutzerName = aie_GetCharCGIValue(cgi_parameter, is_aie_UserCGIVar);
   char *Datenbasis = aie_GetCharCGIValue(cgi_parameter, 
	                                  is_aie_DatenbasisCGIVar);
   char *Session = aie_GetCharCGIValue(cgi_parameter, is_aie_SessionCGIVar);
   int DatenbankID = aie_GetIntCGIValue(cgi_parameter,  
	                                is_aie_DatenbankIDCGIVar);
   struct aie_sql_data *aie_sql_data = NULL; 
   struct aie_sql_meta_db *sql_meta_db = NULL;
   bool hasError = false;
   char tmp_file[AIE_SESSION_NAME_BUF_LEN];

   aie_sys_log(0);

   sync();
   free_sql_callback_data.tmp_fptr = NULL;

   // TODO: Die Referenz sollte nicht statisch sein 
   // SQL von Benutzer %s Datenbasis[%s] SQL[%s]
   aie_sys_log(1, BenutzerName, Datenbasis, sql_cmd);
   if ((sql_meta_db = get_meta_db_from_name(Datenbasis)) != NULL)
   {
      sprintf(tmp_file, "/aIEngine/temp/data/%s", Session); 
      if ((free_sql_callback_data.tmp_fptr = fopen(tmp_file, "w+t")) == 
		                                                          NULL)
      {
	 // Temporaere Datei konnte nicht geoeffnet werden!
         aie_sys_log(2, tmp_file);
         html_vt("Fehler: %s\n", aie_log_msg_select(2));
      }
      else
      {
	 if (!setvbuf(free_sql_callback_data.tmp_fptr, NULL, _IOFBF, 1024000))
	 {
            if ((aie_sql_data = aie_sql_meta_attach_db(DatenbankID, 
                                       sql_meta_db)) != NULL)
            {
               if (sql_cmd != NULL)
               {
                  aie_sql_data->callback = aie_select_sql_callback;
                  aie_sql_data->sql_cmd = sql_cmd;
                  aie_sql_data->data = (void *)&free_sql_callback_data;
                  if (!aie_sql_run(aie_sql_data))
                  {
		     // TODO: sqlite3 ref entfernen 
                     // DB Fehler %s[%s]
                     aie_sys_log(3, 
                                 sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
                     html_vt("Fehler: %s\n", 
		               sqlite3_errmsg(aie_sql_data->sql_db_data->db));
		     hasError = true;
                  }
                  else
  	          {
	             if (!hasData)
	             {
	   	        html_vt("Fehler: "
	 	   	  "Ihr SQL lieferte eine leere Datenmenge!");
	                hasError = true;
	             }
	          }
               }
               else
               {
	          // Kein SQL Statement?!
                  aie_sys_log(4);
	          hasError = true;
               }
               aie_sql_meta_release_db(sql_meta_db);
	       if (!hasError && hasData)
	       {
	          char buffer[512];
	          rewind(free_sql_callback_data.tmp_fptr);
	          while (!feof(free_sql_callback_data.tmp_fptr))
	          {
	             fgets(buffer, sizeof(buffer)-1,
		                             free_sql_callback_data.tmp_fptr);
	             if (!feof(free_sql_callback_data.tmp_fptr))
		     {
		        html_vt("%s", buffer);
		     }
	          }
	          //rewind(free_sql_callback_data.tmp_fptr);
	       }
	    }
	    else
	    {
	       // Nicht genug Hauptspeicher fuer Puffer?!
               aie_sys_log(5);
	       html_vt("Fehler: %s", aie_log_msg_select(5));
	    }
            fclose(free_sql_callback_data.tmp_fptr);
	    unlink(tmp_file);
         }
         else
         {
            // Problem beim initialisieren der Datenbank
            aie_sys_log(6);
	    html_vt("Fehler: %s", aie_log_msg_select(6));
         }
      }
   }
   else
   {
      // Datenbasis [%s] nicht gefunden!
      aie_sys_log(7, Datenbasis);
      html_vt("Fehler: Datenbasis [%s] nicht gefunden!", Datenbasis);
   }
}

static int aie_select_sql_callback(void *pArg, int nArg, char **azArg,
		                                       char **azCol)
{
   register int i;
   static long isRow = 0;
   char *sptr;
   struct aie_sql_data *aie_sql_data = (struct aie_sql_data *)pArg;
   struct free_sql_callback_data *free_sql_callback_data = 
                        (struct free_sql_callback_data *)aie_sql_data->data;
   FILE *fptr = free_sql_callback_data->tmp_fptr;
   if (!hasData)
   {
      fprintf(fptr, ">ColCount: %d\n>>\tZeile", nArg + 1); 
      for(i = 0; i < nArg; i++)
      {
	 fprintf(fptr, "\t");
	 fprintf(fptr, "%s", azCol[i]);
      }
      //html_vt("%s\n", out_buffer);
      fprintf(fptr, "\n");
      hasData = true;
   }
   isRow++;
   fprintf(fptr, ">\t%ld\t", isRow);
   for(i = 0; i < nArg; i++)
   {
      if (i > 0)
      {
         fprintf(fptr, "\t");
      }
      if (azArg[i] != NULL)
      {
	 if (strlen(azArg[i]) > 512)
	 {
	    strcpy(azArg[i] +  510, "..");
	 }
	 sptr = azArg[i];
	 while (*sptr != '\0')
	 {
	    if ((*sptr == '\t') || (*sptr == '\n'))
	    {
	       *sptr = ' ';
	    }
	    fprintf(fptr, "%c", *sptr);
	    sptr++;
	 }
         //fprintf(fptr, "%s", azArg[i]);
      }
      else
      {
         fprintf(fptr, "*");
      }
   }
   //html_vt("%s\t\n", out_buffer);
   fprintf(fptr, "\t\n");
   return(0);
}

/* --------------               aIEngine.de                    ------------- */
int   modul_aie_cgi_aiengine_sql_size    = __LINE__;                         //
/* -------------------------------- EOF ------------------------------------ */

