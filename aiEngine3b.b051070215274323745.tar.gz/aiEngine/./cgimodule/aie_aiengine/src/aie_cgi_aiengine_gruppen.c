/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_cgi_aiengine_gruppen.c                                  */
/* CGI         : aie_aiengine.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 20.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_cgi_gruppen_version   = "2.0.1";                                 //
char *modul_cgi_gruppen           = "Gruppen";                               //
char *modul_cgi_gruppen_date      = __DATE__;                                //
char *modul_cgi_gruppen_time      = __TIME__;                                //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_DB_LIB			1			     //
#define AIENGINE_USE_SQL_WRAP_LIB		1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <unistd.h>                                                         //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aie_crc32.h"
/*---------------------------------------------------------------------------*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_aiengine_user.h"                                           //
#include "aie_cgi_aiengine_gruppen.h"                                        //
#include "aie_cgi_aiengine_init.h"                                           //
#include "aie_cgi_aiengine_callback.h"                                       //
#include "aie_cgi_aiengine_cgivar.h"                                         //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern bool hasCallbackData;
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool list_gruppen(char *UserId);                                      //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/

                                                                             //
/*****************************************************************************/

void user_gruppen_info_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "user_gruppen_info_page" }
   };
   char *UserId = aie_GetCharCGIValue(cgi_parameter, 
	                              is_aie_SucheUserIDCGIVar);
   aie_sys_log(0);
   if (!list_gruppen(UserId))
   {
      html_vt(">\tKeine Gruppen verfuegbar\n");
   }
}

static bool list_gruppen(char *UserId)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "list_gruppen" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR,    "Out of Memory?" },
      { AIE_LOG_ERROR,    "Problem beim initialisieren der Datenbank" }
   };
   struct aie_sql_data *aie_sql_data = NULL; 

   aie_sys_log(0);
   if ((aie_sql_data = Init_aie_BackgroundDB()) != NULL)
   {
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_select_info_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = NULL;
         sprintf(sql_cmd, "SELECT %s, %s, %s"
				" FROM %s ", 
				   is_aie_UserGruppeSqlFld,
                                   is_aie_BerechtigungSqlFld,
                                   is_aie_SperreSqlFld,
					AIE_DB_TABLE_USER_GRUPPEN);
         if (UserId != NULL)
	 {
	    strcat(sql_cmd, " WHERE ");
	    strcat(sql_cmd, is_aie_UserGruppeSqlFld);
	    strcat(sql_cmd, " IN (SELECT ");
	    strcat(sql_cmd, is_aie_UserGruppeSqlFld);
	    strcat(sql_cmd, " FROM ");
	    strcat(sql_cmd, AIE_DB_TABLE_USER_GRUPPEN);
	    strcat(sql_cmd, " WHERE ");
	    strcat(sql_cmd, is_aie_UserIdSqlFld);
	    strcat(sql_cmd, "  = '");
	    strcat(sql_cmd, UserId);
	    strcat(sql_cmd, "')");
	 }
         if (!aie_sql_run(aie_sql_data))
         {
	    // TODO: sqlite3 ref entfernen 
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
	    html_vt("Fehler: %s\n", 
                                 sqlite3_errmsg(aie_sql_data->sql_db_data->db));
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
      Exit_aie_BackgroundDB();
   }
   else
   {
      // Problem beim initialisieren der Datenbank
      aie_sys_log(3);
      html_vt("Fehler: %s", aie_log_msg_select(3));
   }
   return(hasCallbackData);
}

/* --------------               aIEngine.de                    ------------- */
int   modul_cgi_gruppen_size      = __LINE__;                                //
/* -------------------------------- EOF ------------------------------------ */

