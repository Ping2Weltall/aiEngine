/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_cgi_aiengine_user.c                                     */
/* CGI         : aie_aiengine.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 19.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_cgi_user_version      = "2.0.1";                                 //
char *modul_cgi_user              = "Register";                              //
char *modul_cgi_user_date         = __DATE__;                                //
char *modul_cgi_user_time         = __TIME__;                                //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1			     //
#define AIENGINE_USE_SQL_WRAP_LIB		1			     //
#define AIENGINE_USE_DB_LIB			1			     //
#define AIENGINE_USE_CGI_LIB			1			     //
#define AIENGINE_USE_WIN_CGI_LIB		1			     //
#define AIENGINE_USE_LOG_LIB			1			     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <unistd.h>                                                         //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include "aie_crc32.h"

/*---------------------------------------------------------------------------*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_aiengine_user.h"                                           //
#include "aie_cgi_aiengine_init.h"                                           //
#include "aie_cgi_aiengine_callback.h"                                       //
#include "aie_cgi_aiengine_cgivar.h"                                         //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern bool hasCallbackData;
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool list_benutzer(char *UserId, char *Modul, char *Seriennummer);    //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/

                                                                             //
/*****************************************************************************/

void user_berechtigungen_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "user_berechtigungen_page" },
      { AIE_LOG_SECURITY_INFO, "Benutzer Rechte [%s]=[%LX]" },
      { AIE_LOG_ERROR, "Benutzer ID leer?!" }
   };
   char *UserId = aie_GetCharCGIValue(cgi_parameter, is_aie_UserCGIVar);
   u64 UserRights = 0L;

   aie_sys_log(0);
   if (UserId != NULL)
   {
      UserRights = aie_get_benutzer_rechte(UserId, true);
      // Benutzer Rechte [%s]=[%LX]
      aie_sys_log(1, UserId, UserRights);
   }
   else
   {
      // Benutzer ID leer?!
      aie_sys_log(2);
   }
   html_vt(">#UserMagicNumber# 0x%LX\n", UserRights);
}

void user_info_page(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "user_info_page" },
      { AIE_LOG_WARN,  "Es wurden keine Benutzer gefunden" }
   };
   char *UserId = aie_GetCharCGIValue(cgi_parameter, is_aie_SucheUserIDCGIVar);
    char *Seriennummer = aie_GetCharCGIValue(cgi_parameter, 
	                                      is_aie_SucheSeriennummerCGIVar);  
   char *Modul = aie_GetCharCGIValue(cgi_parameter, is_aie_SucheModulCGIVar);  
   aie_sys_log(0);
   if (!list_benutzer(UserId, Modul, Seriennummer))
   {
      // Es wurden keine Benutzer gefunden
      aie_sys_log(1);
      html_vt("Fehler: %s\n", aie_log_msg_select(1));
   }
}

static bool list_benutzer(char *UserId, char *Modul, char *Seriennummer)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "list_benutzer" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR,    "Out of Memory?" },
      { AIE_LOG_ERROR,    "Problem beim initialisieren der Datenbank" }
   };
   struct aie_sql_data *aie_sql_data = NULL; 

   u64 UserRights = 0L;

   aie_sys_log(0);
   if (UserId != NULL)
   {
      UserRights = aie_get_benutzer_rechte(UserId, false);
   }
   if ((aie_sql_data = Init_aie_BackgroundDB()) != NULL)
   {
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_select_info_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = NULL;
         sprintf(sql_cmd, "SELECT %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
	                        " %s, %s, %s, %s, %s, %s, %s, %s, %s, %s"
				" FROM %s ", 
                                        is_aie_UserIdSqlFld, 
					is_aie_UserGruppeSqlFld,
					is_aie_SperreSqlFld,
					is_aie_BerechtigungSqlFld,
                                        is_aie_UserPasswortSqlFld, 
                                        is_aie_FirmaSqlFld, 
                                        is_aie_VornameSqlFld, 
                                        is_aie_NachnameSqlFld, 
                                        is_aie_StrasseSqlFld, 
                                        is_aie_PostleitzahlSqlFld, 
                                        is_aie_OrtSqlFld, 
                                        is_aie_EmailSqlFld, 
                                        is_aie_InstallDateSqlFld, 
                                        is_aie_SeriennummerSqlFld, 
                                        is_aie_ModulNameSqlFld, 
                                        is_aie_FreigabeSqlFld, 
                                        is_aie_LastRunSqlFld, 
                                        is_aie_LastUpdateSqlFld, 
                                        is_aie_RunCountSqlFld, 
                                        is_aie_ValidUntilDateSqlFld, 
					AIE_DB_TABLE_USER);
         if (UserId != NULL)
	 {
	    strcat(sql_cmd, " WHERE ");
	    strcat(sql_cmd, is_aie_UserIdSqlFld);
	    if (!AIE_USER_CAN_ANSICHT_BENUTZER(UserRights))
	    {
	       strcat(sql_cmd, "  = '");
	    }
	    else
	    {
	       strcat(sql_cmd, "  LIKE '");
	    }
	    strcat(sql_cmd, UserId);
	    if (!AIE_USER_CAN_ANSICHT_BENUTZER(UserRights))
	    {
	       strcat(sql_cmd, "' ");
	    }
	    else
	    {
	       strcat(sql_cmd, "%%' ");
	    }
	 }
         if (Modul != NULL)
	 {
	    if (UserId == NULL)
	    {
	       strcat(sql_cmd, " WHERE ");
	    }
	    else
	    {
	       strcat(sql_cmd, " AND ");
	    }
	    strcat(sql_cmd, is_aie_ModulNameSqlFld);
	    strcat(sql_cmd, "  LIKE '");
	    strcat(sql_cmd, Modul);
	    strcat(sql_cmd, "%%' ");
	 }
         if (Seriennummer != NULL)
	 {
	    if ((UserId == NULL) && (Modul == NULL))
	    {
	       strcat(sql_cmd, " WHERE ");
	    }
	    else
	    {
	       strcat(sql_cmd, " AND ");
	    }
	    strcat(sql_cmd, is_aie_SeriennummerSqlFld);
	    strcat(sql_cmd, "  LIKE '");
	    strcat(sql_cmd, Seriennummer);
	    strcat(sql_cmd, "%%' ");
	 }
	 //sys_log("%s(%d): SQL CMD[%s]", __FILE__, __LINE__, sql_cmd);
         if (!aie_sql_run(aie_sql_data))
         {
	    // TODO: sqlite3 ref entfernen
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
	    html_vt("Fehler: %s\n", 
                                 sqlite3_errmsg(aie_sql_data->sql_db_data->db));
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
      Exit_aie_BackgroundDB();
   }
   else
   {
      // Problem beim initialisieren der Datenbank
      aie_sys_log(3);
      html_vt("Fehler: %s\n", aie_log_msg_select(3));
   }
   return(hasCallbackData);
}

/* --------------               aIEngine.de                    ------------- */
int   modul_cgi_user_size         = __LINE__;                                //
/* -------------------------------- EOF ------------------------------------ */

