/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : mybodys.c                                                   */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_mybodys_version       = "1.0.0";                                 //
char *modul_mybodys               = "Bodys";                                 //
char *modul_mybodys_date          = __DATE__;                                //
char *modul_mybodys_time          = __TIME__;                                //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                   1                            //
#define AIENGINE_USE_CLIENT_LIB                 1                            //
#define AIENGINE_USE_CGI_LIB                    1                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_banner.h"                                         //
#include "aie_cgi_register_cgivar.h"                                         //
#include "aie_cgi_register_cgival.h"                                         //
#include "aie_cgi_register_define.h"                                         //
#include "aie_cgi_register_bodys.h"                                          //
#include "aie_cgi_register_header.h"                                         //
#include "aie_cgi_register_frames.h"                                         //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *ht_table_b0;                                                    //
extern char *ht_table_100p;                                                  //
extern char *ht_table_dashed_frame;                                          //
//extern char *cgiCookie;                                                      //
//extern char *cgiRemoteAddr;                                                  //
//extern char *cgiUserAgent;                                                   //
//extern char *cgiRequestUri;                                                  //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct aiengine_menue_auswahl                                                //
{                                                                            //
   int fkt_nr;                                                               //
   char *text;                                                               //
   void (*fkt)(AIE_CGI_STANDARD_FKT_PARAMETER);                              //
};                                                                           //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
//static struct aiengine_menue_auswahl *get_menue_auswahl(AIE_CGI_STANDARD_FKT_PARAMETER,
//                          struct aiengine_menue_auswahl *menue_auswahl,
//                          int size_menue_auswahl);
static void body_headline(const char *text);                                 //
static void body_footline(void);                                             //
//static void link_page_register(AIE_CGI_STANDARD_FKT_PARAMETER);
//static void link_page_besucher(AIE_CGI_STANDARD_FKT_PARAMETER);
//static void link_page_meine(AIE_CGI_STANDARD_FKT_PARAMETER);
//static void intro_page_wer(AIE_CGI_STANDARD_FKT_PARAMETER);
//static void intro_page_wie(AIE_CGI_STANDARD_FKT_PARAMETER);
//static void intro_page_was(AIE_CGI_STANDARD_FKT_PARAMETER);
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void body_headline_tbl_start(const char *text)
{
   html_static("<div id=\"body_frame\" style=\"position:absolute;z-index:0;visibility:visible;filter:alpha(enabled=1,opacity=95);left:0px; top:0px;\">");
   body_headline(text);
   TBL_STD_ROW_COL_START
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void body_footline_tbl_end(void)
{
   TBL_STD_COL_ROW_END
   body_footline();
   html_static("</div>");
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void frame_tbl(int nr, const char *text)
{
   nr = nr;
   text = text;
#if 0
   if (nr == BODY_TBL_BODY_R)
   {
      eTABLE
   }
   else
   {
      bTABLEwv("780", ht_table_b0);
      if (nr == HEAD_TBL_TOP)
      {
         bTR
         bTDcshacbg("6", "20", MK_FRAME_IMAGE("mft.jpg"));
         TBL_STD_COL_ROW_END
      }
      bTR
      bTDwacbg("10", MK_FRAME_IMAGE("mfl.jpg"));
      NBSP
      eTD
      bTDwacbg("5", MK_FRAME_IMAGE("titellt.jpg"));
      NBSP
      eTD
      switch(nr)
      {
          case HEAD_TBL_TOP:
            {
               bTDcshacbg("1", "90", MK_FRAME_IMAGE("titeltxt.jpg"));
               bFONTs("+2");
               bB
               NBSP
               html_t(text);
               eB
               eFONT
               eTD
            }
          break;
          case BODY_TBL_START:
            {
               bTDcshacbg("1", "40", MK_FRAME_IMAGE("titelpt.jpg"));
               NBSP
               eTD
            }
            break;
          case BODY_TBL_END:
            {
               bTDcshacbg("1", "40", MK_FRAME_IMAGE("titelpb.jpg"));
               NBSP
               eTD
            }
            break;
      }
   }
   if (nr ==  BODY_TBL_BODY_L)
   {
      bTDwacbg("750", MK_FRAME_IMAGE("1px.jpg"));
      //bTABLE
      bTABLEwv("750", ht_table_b0);
   }
   else
   {
      bTDwacbg("5", MK_FRAME_IMAGE("titelrt.jpg"));
      NBSP
      eTD
      bTDwacbg("10", MK_FRAME_IMAGE("mfr.jpg"));
      NBSP
      if (nr == BODY_TBL_END)
      {
         eTR
         bTR
         bTDcshacbg("6", "20", MK_FRAME_IMAGE("mfb.jpg"));
      }
      TBL_STD_COL_ROW_TABLE_END
   }
#endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void body_headline(const char *text)
{
   frame_tbl(HEAD_TBL_TOP, text);
   frame_tbl(BODY_TBL_START, NULL);
   frame_tbl(BODY_TBL_BODY_L, NULL);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void body_footline(void)
{
   frame_tbl(BODY_TBL_BODY_R, NULL);
   frame_tbl(BODY_TBL_END, NULL);
}
/*---------------------------------------------------------------------------*/
#if 0
static struct aiengine_menue_auswahl *get_menue_auswahl(AIE_CGI_STANDARD_FKT_PARAMETER,
                          struct aiengine_menue_auswahl *menue_auswahl,
                          int size_menue_auswahl)
{
   menue_auswahl = menue_auswahl;
   size_menue_auswahl = size_menue_auswahl;
   struct aiengine_menue_auswahl *ptr_menue_auswahl = NULL;
   int MenueItem = GetIntCGIValue(AIE_CGI_STANDARD_PARAMETER, isMenueCGIVar);

   for(int i = 0;(i < size_menue_auswahl) && (MenueItem != 0); i++)
   {
      if (menue_auswahl->fkt_nr == MenueItem)
      {
         ptr_menue_auswahl = menue_auswahl;
         break;
      }
      menue_auswahl++;
   }
   return(ptr_menue_auswahl);
   return(NULL);
}
#endif

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void body_top_util_page(void)
{
#if 0
   const char *global_engine_name = 
               GetStandardAsecurVariableValue(AIENGINE_VAR_GLOBAL_ENGINE_NAME);
   int col = 0;

   struct preload_images
   {
      const char *image;
      struct preload_images *next;
   } *preload_images_base = NULL, *preload_images_ptr;
   unsigned int size_appl_imp_body_links;
   struct imp_body_links *appl_ibl;
      if (__builtin_expect(((appl_ibl = 
	  getRegistered_imp_body_links(&size_appl_imp_body_links)) != NULL),
	                                                                 true))
      {
         for (unsigned int i=0; i < size_appl_imp_body_links; i++)
         {
            const char *image;
            image = appl_ibl->img_1;
            if (preload_images_base == NULL)
            {
               preload_images_ptr = preload_images_base = 
		  (struct preload_images*)
		                     aie_malloc(sizeof(struct preload_images));
               preload_images_ptr->next = NULL;
            }
            else
            {
               preload_images_ptr = preload_images_base;
               while (preload_images_ptr != NULL)
               {
                  if (strcmp(preload_images_ptr->image, image) == 0)
                  {
                     break;
                  }
                  preload_images_ptr = preload_images_ptr->next;
               }
               if (preload_images_ptr == NULL)
               {
                  preload_images_ptr = 
		     (struct preload_images*)
		                     aie_malloc(sizeof(struct preload_images));
                  preload_images_ptr->next = preload_images_base;
                  preload_images_base = preload_images_ptr;
               }
            }
            if (preload_images_ptr != NULL)
            {
               preload_images_ptr->image = image;
            }
            appl_ibl++;
         }
      }
      body_headline_tbl_start(global_engine_name);
      TBL_STD_ROW_COL_START
      bTABLE
      bTR
      bTDc2
      applikation_version_signiture(false);
      TBL_STD_COL_ROW_CHANGE
      bTR
      bTDc2
      bCENTER
      ShowEngineInfo();
      eCENTER
      HR
      TBL_STD_COL_ROW_CHANGE
      while ((preload_images_ptr = preload_images_base) != NULL)
      {
         //char image[40];
         //strcpy(image, path_images_imp);
         //strcat(image, preload_images_ptr->image);
         //html_image(image, preload_images_ptr->image, NULL, 0);
         html_image(MK_IMP_IMAGE(preload_images_ptr->image), preload_images_ptr->image, NULL, 0);
         preload_images_base = preload_images_ptr->next;
         aie_free(preload_images_ptr);
         if (col == 1)
         {
            TBL_STD_COL_ROW_CHANGE
            col = 0;
         }
         else
         {
            TBL_STD_COL_CHANGE
            col++;
         }
      }
      TBL_STD_COL_ROW_CHANGE
      html_pic_point();
      TBL_STD_COL_CHANGE
      html_pic_big_point();
      TBL_STD_COL_ROW_TABLE_END
      BR
   TBL_STD_COL_ROW_END
   body_footline_tbl_end();
#endif
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void page_not_found(AIE_CGI_STANDARD_FKT_PARAMETER)
{
#if 0
   if (AIE_AGENT_AIENGINE)
   {
      struct cgi_vars *cgi_vars_ptr = cgi_vars_base;
      html_vt("Unerlaubter Zugriff auf unbekannte Seite! \n"
	      "Logfile Eintrag vorgenommen! \n"
	      "Verantwortliche IP: %s\n", cgiRemoteAddr);
      while(cgi_vars_ptr != NULL)
      {
	 html_vt("%s=%s\n", cgi_vars_ptr->nam, cgi_vars_ptr->val);
	 cgi_vars_ptr = cgi_vars_ptr->next;
      }
   }
   else
   {
      const char *support_email = GetStandardAsecurVariableValue(AIENGINE_VAR_SUPPORT_EMAIL);
      char *sptr;
      sys_log("%s(%d) Agent is %s", __FILE__, __LINE__, cgiUserAgent);
      if (__builtin_expect(
       ((sptr = GetCharCGIValue(AIE_CGI_STANDARD_PARAMETER, isCodedCGIVar)) != NULL),false))
      {
         html_static("Never should reach!<br>");
         HR
         html_vt("Should have used:[%s]", sptr);
         HR
         #ifdef aie_use_keys
            html_vt("Decoded:[%s]", do_decode_string(sptr));
         #else
	    html_static("Keine Decodierung mit einprogrammiert!");
         #endif
         HR
      }
      else
      {
         int len = strlen(cgiRequestUri);
         if ((len > 4) && ((strcmp((cgiRequestUri + len - 4), ".ida") == 0) ||
                        (strcmp((cgiRequestUri + len - 4), ".exe") == 0)))
         {
            my_version(true);
         }
         else
         {
            body_headline_tbl_start("Hello there!");
            bCENTER
            bFONT_s1
            bB
            html_static("Unbekannte Seite");
            eB
            BR2
            eFONT
            html_static("Die von Ihnen gew&uuml;nschte Seite:");
            BR2
            NBSP
            NBSP
            bFONTc("red");
            if (len > 50)
            {
               *(cgiRequestUri + 47) = '\0';
               strcat(cgiRequestUri, "...");
            }
            html_t(cgiRequestUri);
            eFONT
            BR2
            html_static("ist leider auf unserem Server nicht verf&uuml;gbar!");
            BR2
            html_vt("<a href=\"mailto:%s\">", support_email);
            html_static("Support");
            NBSP
            html_vt("(%s)", support_email);
            eA
            BR2
            eCENTER
            TBL_STD_COL_CHANGE
            NBSP
            body_footline_tbl_end();
            HR
         }
      }
      #ifdef aie_use_keys
   //if ((sptr != NULL) && (*sptr != '\0'))
   //{
   //   html_vt("\n\n%s\n", sptr);
   //}
      #endif
      BR2
      HR
   }
#endif
}
/*---------------------------------------------------------------------------*/

/* --------------               aIEngine.org                   ------------- */
int   modul_mybodys_size          = __LINE__;                                //
/* -------------------------------- EOF ------------------------------------ */

