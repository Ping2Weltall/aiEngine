/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : dispatch.cpp                                                */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
//main_dispatch
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                   1                            //
#define AIENGINE_USE_CLIENT_LIB                 1                            //
#define AIENGINE_USE_CGI_LIB                    1                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_cgival.h"                                         //
#include "aie_cgi_register_define.h"                                         //
#include "aie_cgi_register_frames.h"                                         //
#include "aie_cgi_register_module.h"                                         //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// struct page_cgi_dispatch page_cgi_dispatch[]          (siehe unten)       //
// int size_page_cgi_dispatch                            ( "     "   )       //
// struct frame_cgi_dispatch page_cgi_dispatch[]         (siehe unten)       //
// int size_frame_cgi_dispatch                           ( "     "   )       //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

AIE_STRUCT_PAGE_CGI_DISPATCH =
{
    { isBannerPageCGIVal,                 AIENGINE_MODUL_GLOBAL   },
    { isIndexPageCGIVal,                  AIENGINE_MODUL_GLOBAL   },
    { isMainPageCGIVal,                   AIENGINE_MODUL_GLOBAL   },
    { isWorkPageCGIVal,                   AIENGINE_MODUL_GLOBAL   },
    { isIntroMenPageCGIVal,               AIENGINE_MODUL_GLOBAL   },
    { isIntroWorkPageCGIVal,              AIENGINE_MODUL_GLOBAL   },
    { isIntroIndexPageCGIVal,             AIENGINE_MODUL_GLOBAL   },
    { isCPUArtWorkPageCGIVal,             AIENGINE_MODUL_GLOBAL   },
    { isComputerkunstMenPageCGIVal,       AIENGINE_MODUL_GLOBAL   },
    { isComputerkunstIndexPageCGIVal,     AIENGINE_MODUL_GLOBAL   },
    { isDownloadWorkPageCGIVal,           AIENGINE_MODUL_GLOBAL   },
    { isDownloadIndexPageCGIVal,          AIENGINE_MODUL_GLOBAL   },
    { isDownloadMenPageCGIVal,            AIENGINE_MODUL_GLOBAL   },
    { isLinkIndexPageCGIVal,              AIENGINE_MODUL_GLOBAL   },
    { isLinkWorkPageCGIVal,               AIENGINE_MODUL_GLOBAL   },
    { isLinkMenPageCGIVal,                AIENGINE_MODUL_GLOBAL   },
    { isIntroWorkPageCGIVal,              AIENGINE_MODUL_GLOBAL   },
    { isCPUArtWorkPageCGIVal,             AIENGINE_MODUL_GLOBAL   },
    { isDownloadWorkPageCGIVal,           AIENGINE_MODUL_GLOBAL   },
    { isLinkWorkPageCGIVal,               AIENGINE_MODUL_GLOBAL   }
};
AIE_INT_VAR_SIZE_PAGE_CGI_DISPATCH;
//int size_page_cgi_dispatch = sizeof(page_cgi_dispatch)/sizeof(struct page_cgi_dispatch);


//struct frame_cgi_dispatch frame_cgi_dispatch[] =
AIE_STRUCT_FRAME_CGI_DISPATCH =
{
    { SFrameSetTopIntro,            AIENGINE_MODUL_GLOBAL },
    { SFrameSetTopCPUArt,           AIENGINE_MODUL_GLOBAL },
    { SFrameSetTopDownload,         AIENGINE_MODUL_GLOBAL },
    { SFrameSetTopLink,             AIENGINE_MODUL_GLOBAL },
    { SFrameSetIntroIndex,          AIENGINE_MODUL_GLOBAL },
    { SFrameSetIntroMain,           AIENGINE_MODUL_GLOBAL },
    { SFrameSetIntroWork,           AIENGINE_MODUL_GLOBAL },
    { SFrameSetComputerkunstIndex,  AIENGINE_MODUL_GLOBAL },
    { SFrameSetComputerkunstMain,   AIENGINE_MODUL_GLOBAL },
    { SFrameSetComputerkunstWork,   AIENGINE_MODUL_GLOBAL },
    { SFrameSetDownloadIndex,       AIENGINE_MODUL_GLOBAL },
    { SFrameSetDownloadMain,        AIENGINE_MODUL_GLOBAL },
    { SFrameSetDownloadWork,        AIENGINE_MODUL_GLOBAL },
    { SFrameSetLinkIndex,           AIENGINE_MODUL_GLOBAL },
    { SFrameSetLinkMain,            AIENGINE_MODUL_GLOBAL },
    { SFrameSetLinkWork,            AIENGINE_MODUL_GLOBAL }
};
AIE_INT_VAR_SIZE_FRAME_CGI_DISPATCH;
//int size_frame_cgi_dispatch = sizeof(frame_cgi_dispatch)/sizeof(struct frame_cgi_dispatch);

//struct module_2_cgi_prog module_2_cgi_prog[] =
AIE_STRUCT_MODULE_2_CGI_PROG =
{
   { AIENGINE_MODUL_GLOBAL,     AIENGINE_CGI_MODUL_GLOBAL         }
};
AIE_INT_VAR_SIZE_MODULE_2_CGI_PROG;
//int size_module_2_cgi_prog = sizeof(module_2_cgi_prog) /
//                             sizeof(struct module_2_cgi_prog);

/* --------------               aIEngine.org                   ------------- */
int  modul_dispatch_size       = __LINE__;                                   //
/* -------------------------------- EOF ------------------------------------ */
