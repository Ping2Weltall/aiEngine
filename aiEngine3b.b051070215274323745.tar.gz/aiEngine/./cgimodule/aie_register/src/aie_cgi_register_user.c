/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_register_user.c                                         */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 05.02.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_register_user_version  = "1.0.1";                                //
char *modul_register_user          = "RegisterUser";                         //
char *modul_register_user_date     = __DATE__;                               //
char *modul_register_user_time     = __TIME__;                               //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                  1
#define AIENGINE_USE_CLIENT_LIB                1
#define AIENGINE_USE_DB_LIB                    1
#define AIENGINE_USE_SQL_WRAP_LIB              1
#define AIENGINE_USE_CGI_LIB                   1
#define AIENGINE_USE_LOG_LIB                   1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <unistd.h>                                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_register.h"                                       //
#include "aie_cgi_register_cgivar.h"                                         //
#include "aie_cgi_register_util.h"                                           //
#include "aie_cgi_register_user.h"
#include "aie_cgi_register_init.h"
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
//extern char *cgiUserAgent;
extern struct aie_sql_meta_db aiengine_sql_meta_db;
//extern struct aie_wingui_screen_feld_var aie_registrierung_feld_2_var[];
//extern unsigned int aie_size_registrierung_feld_2_var;
extern struct aie_wingui_screen_feld_var aie_benutzer_feld_2_var[];
extern unsigned int aie_size_benutzer_feld_2_var;
extern bool UserhasUserRecord;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
static char *DBUserPasswort = NULL;
static char *UserValidUntil = NULL;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/

struct callback_data
{
   void *data;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool do_update_benutzer(AIE_CGI_STANDARD_FKT_PARAMETER,               //
                                      struct aie_sql_data *aie_sql_data);    //
static bool check_benutzer_daten(AIE_CGI_STANDARD_FKT_PARAMETER);            //
static bool check_user_name_availible(const char *Username,                  //
                                      const char *Passwort,                  //
                               struct aie_sql_data *aie_sql_data);           //
static int aie_user_record_callback(void *pArg, int nArg,                    //
                                           char **azArg, char **azCol);      //
static bool do_register_benutzer(AIE_CGI_STANDARD_FKT_PARAMETER,             //
                               struct aie_wingui_screen_feld_var             //
			                                  *aie_feld_2_var,   //
                               unsigned int aie_size_feld_2_var);            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void neuer_benutzer_page(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   static char crc_control[25];
   registrierung_header(AIE_CGI_STANDARD_PARAMETER);
   if (check_benutzer_daten(AIE_CGI_STANDARD_PARAMETER))
   {
      char *FreigabeCRC = 
	 aie_wingui_GetScreenValueFromCGIVar(isFreigabeCGIVar,
	                                   aie_benutzer_feld_2_var,
					   aie_size_benutzer_feld_2_var);
      char *Seriennummer = 
	 aie_wingui_GetScreenValueFromCGIVar(isSeriennummerCGIVar,
	                                   aie_benutzer_feld_2_var,
					   aie_size_benutzer_feld_2_var);
     if ((Seriennummer == NULL) || (FreigabeCRC == NULL))
     {
	html_vt("Fehler: %s(%d): "
	        "Interner Fehler oder ungueltiger Aufruf [%p]:[%p]!", 
              __FILE__, __LINE__,
	      Seriennummer, FreigabeCRC);
     }
     else
     {
         memset(crc_control, '\0', sizeof(crc_control));
         sprintf(crc_control, "%.8lX", 
	                       aie_crc32(0x666, Seriennummer, 
				            strlen(Seriennummer))); 
           if ((strcmp(crc_control, FreigabeCRC) != 0))
	   {
	      html_vt("Fehler: Die Pruefsumme ist inkorrekt!");
   	   }
	   else
           {
	      if ((do_register_benutzer(AIE_CGI_STANDARD_PARAMETER, aie_benutzer_feld_2_var,
                                                aie_size_benutzer_feld_2_var)))
	      {
	         html_vt(">>Freigabe=%s ", crc_control);
	         html_static(">> Benutzer wurde angelegt!\n");
	      }
	      else
	      {
	         html_static(" - Der Benutzer wurde nicht registriert!");
	      }
	   }
       }  
   }
   registrierung_footer();
}

void change_benutzer_page(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   static char crc_control[25];
   registrierung_header(AIE_CGI_STANDARD_PARAMETER);
   if (check_benutzer_daten(AIE_CGI_STANDARD_PARAMETER))
   {
      char *FreigabeCRC = 
	 aie_wingui_GetScreenValueFromCGIVar(isFreigabeCGIVar,
	                                   aie_benutzer_feld_2_var,
					   aie_size_benutzer_feld_2_var);
      char *Seriennummer = 
	 aie_wingui_GetScreenValueFromCGIVar(isSeriennummerCGIVar,
	                                   aie_benutzer_feld_2_var,
					   aie_size_benutzer_feld_2_var);
     if ((Seriennummer == NULL) || (FreigabeCRC == NULL))
     {
	html_vt("Fehler: %s(%d): "
	        "Interner Fehler oder ungueltiger Aufruf [%p]:[%p]!", 
              __FILE__, __LINE__,
	      Seriennummer, FreigabeCRC);
     }
     else
     {
         memset(crc_control, '\0', sizeof(crc_control));
         sprintf(crc_control, "%.8lX", 
	                       aie_crc32(0x666, Seriennummer, 
				            strlen(Seriennummer))); 
           if ((strcmp(crc_control, FreigabeCRC) != 0))
	   {
	      html_vt("Fehler: Die Pruefsumme ist inkorrekt!");
   	   }
	   else
           {
              struct aie_sql_data *aie_sql_data = NULL; 
              if ((aie_sql_data = InitBackgroundDB()) != NULL)
	      {
                 aie_sql_meta_start_transaction(&aiengine_sql_meta_db);
	         if (do_update_benutzer(AIE_CGI_STANDARD_PARAMETER, aie_sql_data))
	         {
                    aie_sql_meta_commit(&aiengine_sql_meta_db);
	            html_vt(">>Freigabe=%s ", crc_control);
	            html_static(">> Benutzer wurde geaendert!\n");
	         }
	         else
	         {
                    aie_sql_meta_rollback(&aiengine_sql_meta_db);
	            html_static(" - Der Benutzer wurde nicht geaendert!");
	         }
                 ExitBackgroundDB();
	      }
	      else
	      {
                 html_static("Fehler: Problem beim initialisieren der Regestrierungsdatenbank. Bitte versuchen Sie es sp�ter erneut.");
	      }
	   }
       }  
   }
   registrierung_footer();
}

static bool check_benutzer_daten(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   bool rc = true;
   char *result;
   register unsigned int i;
   for (i = 0;(i < aie_size_benutzer_feld_2_var) && rc; i++)
   {

      if (*aie_benutzer_feld_2_var[i].CGIVar != '.')
      {
            if ((result = aie_CGIValuePtr(aie_benutzer_feld_2_var[i].CGIVar))
		                                                    != NULL)
            {
               char *Feldname = aie_wingui_GetScreenCGIVar2FeldName(
				      aie_benutzer_feld_2_var[i].CGIVar,
	                              aie_benutzer_feld_2_var,
	                              aie_size_benutzer_feld_2_var);
               if(__builtin_expect((Feldname == NULL), false))
               {
	          html_vt("Fehler: Interner Progammfehler! Var[%s]\n", 
				      aie_benutzer_feld_2_var[i].CGIVar);
	          rc = false;
               }
               else
	       {
	          html_vt(">\t\t%-*s \t%s\n", (30 - strlen(Feldname)),
				      Feldname,
		                              result);
	          aie_benutzer_feld_2_var[i].Value = aie_strdup(result);
		  //sys_log("%s(%d): Variable gesetzt %s=%s\n", __FILE__, 
		//	                                      __LINE__,
		//	aie_benutzer_feld_2_var[i].CGIVar, result);
	       }
            }
            else
            {
	       if (aie_benutzer_feld_2_var[i].required)
	       {
	          html_vt("!\t\t%s \t%s\n", 
				      aie_benutzer_feld_2_var[i].Feld,
		     result);
	          rc = false;
	      }
           }
      }
   }
   if (!rc)
   {
      html_vt("Fehler: Es wurden nicht alle notwendigen Felder ausgef�llt!");
   }
   return(rc);
}

bool insert_user_record(const char *Seriennummer, const char *Username,
                                                   const char *Passwort,
						   char *timestamp,
                               struct aie_wingui_screen_feld_var             //
			                                  *aie_feld_2_var,   //
                               unsigned int aie_size_feld_2_var,             //
                                      struct aie_sql_data *aie_sql_data)
{
   bool rc = false;
   //char *isGruppe =
//	 aie_wingui_GetScreenValueFromCGIVar(isGruppeCGIVar,
//	                                   aie_feld_2_var,
//					   aie_size_feld_2_var);
   char *isFirma =
	 aie_wingui_GetScreenValueFromCGIVar(isFirmaCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isVorname =
	 aie_wingui_GetScreenValueFromCGIVar(isVornameCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isNachname =
	 aie_wingui_GetScreenValueFromCGIVar(isNachnameCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isStrasse =
	 aie_wingui_GetScreenValueFromCGIVar(isStrasseCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isPostleitzahl =
	 aie_wingui_GetScreenValueFromCGIVar(isPostleitzahlCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isOrt =
	 aie_wingui_GetScreenValueFromCGIVar(isOrtCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isEmail =
	 aie_wingui_GetScreenValueFromCGIVar(isEmailCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isModulName =
	 aie_wingui_GetScreenValueFromCGIVar(isModulNameCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char *isFreigabe =
	 aie_wingui_GetScreenValueFromCGIVar(isFreigabeCGIVar,
	                                   aie_feld_2_var,
					   aie_size_feld_2_var);
   char berechtigung[64];
   struct aie_sql_meta_insert sql_meta_insert =
   {
      AIE_DB_TABLE_ID_USER,
      true,
      NULL, 0,
      false,
      &aiengine_sql_meta_db
   };
   struct aie_sql_meta_feld_value_list sql_meta_feld_value_list[] =
   {
      { is_aie_UserIdSqlFld, 		Username },
      { is_aie_UserGruppeSqlFld, 	"FelixFrisch" },
      { is_aie_SperreSqlFld, 		"0" },
      { is_aie_BerechtigungSqlFld, 	berechtigung },
      { is_aie_UserPasswortSqlFld, 	Passwort },
      { is_aie_FirmaSqlFld, 		isFirma },
      { is_aie_VornameSqlFld, 		isVorname },
      { is_aie_NachnameSqlFld, 		isNachname },
      { is_aie_StrasseSqlFld, 		isStrasse },
      { is_aie_PostleitzahlSqlFld, 	isPostleitzahl },
      { is_aie_OrtSqlFld, 		isOrt },
      { is_aie_EmailSqlFld, 		isEmail },
      { is_aie_InstallDateSqlFld, 	timestamp },
      { is_aie_SeriennummerSqlFld, 	Seriennummer },
      { is_aie_ModulNameSqlFld, 	isModulName },
      { is_aie_FreigabeSqlFld, 		isFreigabe },
      { is_aie_LastRunSqlFld, 		timestamp },
      { is_aie_LastUpdateSqlFld, 	timestamp },
      { is_aie_RunCountSqlFld, 		"0" },
      { is_aie_ValidUntilDateSqlFld, 	"20060101" }
   };
   sprintf(berechtigung, "%lX", AIE_BERECHTIGUNG_USER_STANDARD);
   sql_meta_insert.sql_meta_feld_value_list = sql_meta_feld_value_list;
   sql_meta_insert.size_sql_meta_feld_value_list =
                                           sizeof(sql_meta_feld_value_list) /
                                 sizeof(struct aie_sql_meta_feld_value_list);
   if (aie_sql_meta_table_insert(&sql_meta_insert))
   {
      rc = true;
      html_static("\nNeuer Benutzer wurde angelegt:\n");
      html_vt("\tBenutzer:\t%s\n", Username);
      html_vt("\tPasswort:\t%s\n", Passwort);
      html_static("Bitte beachten Sie das Sie das Softwaremodul nur mit dieser Benutzeranmeldung verwenden koennen!\n");
      html_static("Wenn Sie weitere Module installieren koennen Sie bei der Registrierung den gleichen Benutzernamen sowie das gleiche Passwort zu verwenden.\n\n");
   }
   else
   {
      char db_error[256];
      sprintf(db_error, "Fehler: Datenbank Fehler \"%s\": %s\n",
      AIE_DB_AIENGINE,
      sqlite3_errmsg(aie_sql_data->sql_db_data->db));
      if (strstr(db_error, "not an error") == NULL)
      {
         html_vt("%s", db_error);
      }
   }
   return(rc);
}

bool do_update_benutzer(AIE_CGI_STANDARD_FKT_PARAMETER,                      //
                                      struct aie_sql_data *aie_sql_data)     //
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "do_update_benutzer" },
      { AIE_LOG_SECURITY_INFO, "Update Benutzer[%s] " },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" },
   };
   char *sql_cmd;
   bool rc = false;
   struct aie_sql_2_cgi_var sql_2_cgi_var[] =
   {
      { is_aie_FirmaSqlFld, 		isFirmaCGIVar },
      { is_aie_VornameSqlFld, 		isVornameCGIVar },
      { is_aie_NachnameSqlFld, 		isNachnameCGIVar },
      { is_aie_StrasseSqlFld, 		isStrasseCGIVar },
      { is_aie_PostleitzahlSqlFld, 	isPostleitzahlCGIVar },
      { is_aie_OrtSqlFld, 		isOrtCGIVar },
      { is_aie_EmailSqlFld, 		isEmailCGIVar }
   };
   unsigned int size_sql_2_cgi_var = sizeof(sql_2_cgi_var) /
                                 sizeof(struct aie_sql_2_cgi_var);
   aie_CGIValueVar(Username, isUserIdCGIVar);
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if ((Username != NULL) && ((sql_cmd = (char *)aie_malloc(10240)) != NULL))
   {
      bool first = true;
      register unsigned int z;
      sprintf(sql_cmd, "UPDATE %s SET ", AIE_DB_TABLE_USER);
      for (z = 0; z < size_sql_2_cgi_var;z++)
      {
	 aie_CGIValueVar(value, sql_2_cgi_var[z].CgiVar);
	 if (value != NULL)
	 {
	    if (first)
	    {
	       first = false;
	    }
	    else
	    {
	       strcat(sql_cmd, ", ");
	    }
	    strcat(sql_cmd, sql_2_cgi_var[z].SqlVar);
	    strcat(sql_cmd, " ='");
	    strcat(sql_cmd, value);
	    strcat(sql_cmd, "'");
	 }
      }
      if (!first)
      {
          strcat(sql_cmd, ", ");
      }
      strcat(sql_cmd, is_aie_LastUpdateSqlFld);
      strcat(sql_cmd, " ='");
      strcat(sql_cmd, aie_get_time_stamp());
      strcat(sql_cmd, "'");
      strcat(sql_cmd, " WHERE ");
      strcat(sql_cmd, is_aie_UserIdSqlFld);
      strcat(sql_cmd, " ='");
      strcat(sql_cmd, Username);
      strcat(sql_cmd, "'");
      aie_sql_data->callback = NULL;
      aie_sql_data->sql_cmd = sql_cmd;
      // Update Benutzer [%s]
      aie_sys_log(1, sql_cmd);
      if (aie_sql_run(aie_sql_data))
      {
         rc = true;
         html_vt("\nDer Benutzer %s wurde geaendert:\n", Username);
         html_vt("\tBenutzer:\t%s\n", Username);
      }
      else
      {
         char db_error[256];
         sprintf(db_error, "Fehler: Datenbank Fehler \"%s\": %s\n",
         AIE_DB_AIENGINE,
         sqlite3_errmsg(aie_sql_data->sql_db_data->db));
         if (strstr(db_error, "not an error") == NULL)
         {
	    // TODO: sqlite3 ref entfernen
            aie_sys_log(2, sqlite3_errmsg(aie_sql_data->sql_db_data->db), 
		                                                    sql_cmd);
            html_vt("%s", db_error);
         }
      }
      aie_free(sql_cmd);
   }
   else
   {
      if (__builtin_expect((Username != NULL), true))
      {
         aie_sys_log(3);
      }
   }
   return(rc);
}

static bool do_register_benutzer(AIE_CGI_STANDARD_FKT_PARAMETER,             //
                               struct aie_wingui_screen_feld_var             //
			                                  *aie_feld_2_var,   //
                               unsigned int aie_size_feld_2_var)             //
{
   bool rc = false;
   struct aie_sql_data *aie_sql_data = NULL; 
   if ((aie_sql_data = InitBackgroundDB()) != NULL)
   {
       aie_CGIValueVar(Seriennummer, isSeriennummerCGIVar);
       if (check_is_registert(Seriennummer, aie_sql_data))
       {
          html_vt("Fehler: Diese Seriennummer wurde bereits registriert!");
       }
       else
       {
          aie_CGIValueVar(Freigabe, isFreigabeCGIVar);
	  if (check_serial_in_pool_ok(Seriennummer, Freigabe, aie_sql_data))
	  {
             aie_CGIValueVar(ModulName, isModulNameCGIVar);
             aie_CGIValueVar(Username, isUserIdCGIVar);
             aie_CGIValueVar(Passwort, isPasswortCGIVar);
             aie_sql_meta_start_transaction(&aiengine_sql_meta_db);
	     if (check_user_name_availible(Username, Passwort, aie_sql_data) &&
                 (!UserhasUserRecord) &&
	         ((rc = insert_user_registration_records(Seriennummer,
						    ModulName, 
						    Username, Passwort, 
						    aie_feld_2_var, 
						    aie_size_feld_2_var,
						       aie_sql_data)) == true))
	     {
                 aie_sql_meta_commit(&aiengine_sql_meta_db);
	     }
	     else
	     {
                 aie_sql_meta_rollback(&aiengine_sql_meta_db);
	     }
	  }
      }
      ExitBackgroundDB();
   }
   else
   {
      html_static("Fehler: Problem beim initialisieren der Regestrierungsdatenbank. Bitte versuchen Sie es sp�ter erneut.");
   }
   return(rc);
}

static int aie_user_record_callback(void *pArg, int nArg,
                                           char **azArg, char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_user_record_callback" },
      { AIE_LOG_ERROR, "Keine Callback Daten!" },
      { AIE_LOG_DB_ERROR, "Unbekannte Spalte[%s]" }
   };
   struct aie_sql_data *callback_aie_sql_data = (struct aie_sql_data *)pArg;
   struct callback_data *callback_data = 
                          (struct callback_data *)callback_aie_sql_data->data;
   UserhasUserRecord = true;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if(callback_data == NULL)
   {
      // Keine Callback Daten!
      aie_sys_log(1);
   }
   else
   {
      for(int i=0; i<nArg; i++)
      {
	 if (strcmp(azCol[i], is_aie_UserPasswortSqlFld) == 0)
	 {
            DBUserPasswort = aie_strdup(azArg[i]);
	 }
	 else if (strcmp(azCol[i], is_aie_ValidUntilDateSqlFld) == 0)
	 {
	    UserValidUntil = aie_strdup(azArg[i]);
	 }
	 else
	 {
	    // Unbekannte Spalte[%s]
            aie_sys_log(2, azCol[i]);
	 }
      }
   }
   return(0);
}

static bool check_user_name_availible(const char *Username, 
                                      const char *Passwort,
                                      struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "check_user_name_availible" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" }
   };
   bool rc = false;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if ((Username != NULL) && (Passwort != NULL))
   {
      struct callback_data callback_data;
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_user_record_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = (void *)&callback_data;

         sprintf(sql_cmd, "SELECT %s, %s FROM %s WHERE %s='%s'", 
	                                         is_aie_UserPasswortSqlFld, 
			                         is_aie_ValidUntilDateSqlFld,
						 AIE_DB_TABLE_USER,
	                                         is_aie_UserIdSqlFld,
						 Username);
         if (!aie_sql_run(aie_sql_data))
         {
            // TODO: sqlite3 ref entfernen
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
      if(!UserhasUserRecord)
      {
	 rc = true;
      }
      else
      {
	 if ((DBUserPasswort != NULL) &&
	       (strcmp(DBUserPasswort, Passwort) == 0))
	 {
	    rc = true;
	 }
	 else
	 {
            html_vt("Fehler: Der Benutzername %s ist leider schon vergeben. Aendern Sie bitte Ihren Wunsch Benutzernamen oder wenn es Ihr bisheriger Benutzername ist geben Sie Ihr aktuelles Passwort ein.", Username);
	 }
         if (DBUserPasswort != NULL)
         {
	    aie_free(DBUserPasswort);
         }
         if (UserValidUntil)
	 {
            aie_free(UserValidUntil);
	 }
      }
   }
   return(rc);
}
bool insert_user_registration_records(const char *Seriennummer, 
                                        const char *ModulName,
					const char *Username, 
					const char *Passwort,
                               struct aie_wingui_screen_feld_var
			                                  *aie_feld_2_var,
                               unsigned int aie_size_feld_2_var,
                                        struct aie_sql_data *aie_sql_data)
{
   char *timestamp = aie_get_time_stamp();
   bool rc = false;
   if ((!UserhasUserRecord &&
	   insert_user_record(Seriennummer, Username, Passwort,
	                                      timestamp, 
					      aie_feld_2_var, 
					      aie_size_feld_2_var,
					      aie_sql_data)) &&
       update_serial_information(Seriennummer, ModulName, timestamp,
	                                                     aie_sql_data))
   {
      rc = true;
   }
   return(rc);
}
/* --------------               aIEngine.de                    ------------- */
int   modul_register_user_size       = __LINE__;                             //
/* -------------------------------- EOF ------------------------------------ */

