/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : init.cpp                                                    */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                   1                            //
#define AIENGINE_USE_CLIENT_LIB                 1                            //
#define AIENGINE_USE_DB_LIB                     1                            //
#define AIENGINE_USE_SQL_WRAP_LIB               1                            //
#define AIENGINE_USE_CGI_LIB                    1                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_init.h"                                           //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sql_meta_db;                          //
                                                                             //
AIE_EXTERN_CGI_GLOBALE_VARIABLEN;
                                                                             //
AIE_EXTERN_STATIC_VARIABLES; 
                                                                             //
AIE_EXTERN_META_HEAD_INFO                                                    //
                                                                             //
AIE_EXTERN_HTML_KEYWORDS;
                                                                             //
//AIE_EXTERN_IMP_BODY_LINKS;
                                                                             //
//AIE_EXTERN_STANDARD_IMP;
                                                                             //
AIE_EXTERN_PAGE_JAVASCRIPT;
                                                                             //
//AIE_EXTERN_CGI_VAR_REMOTE_2_LOCAL;
                                                                             //
//AIE_EXTERN_KNOWN_MENUES;
                                                                             //
AIE_EXTERN_PAGE_REC;
                                                                             //
AIE_EXTERN_BASIC_REC;
                                                                             //
AIE_EXTERN_KNOWN_FRAMES;
                                                                             //
AIE_EXTERN_MODULE_2_CGI_PROG;
                                                                             //
AIE_EXTERN_PAGE_CGI_DISPATCH;
                                                                             //
AIE_EXTERN_FRAME_CGI_DISPATCH;
                                                                             //
AIE_EXTERN_FOLLOW_CGI_VARS;
                                                                             //
//AIE_EXTERN_SUB_MEN_PATHS;
                                                                             //
//AIE_EXTERN_CGI_VERSION_INFO;
                                                                             //
AIE_EXTERN_BODY_TAG;
                                                                             //
//AIE_EXTERN_AD_FILES;
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

bool Init_CGI(struct aie_cgi_parameter *cgi_parameter)
{
   bool rc = false;
   cgi_parameter = cgi_parameter;
   //aIEngine_SetProgQueueID(queue_id);

   AIE_FKT_REGISTER_HTML_KEYWORDS;
   AIE_FKT_REGISTER_META_HEAD_INFO;
   //AIE_FKT_REGISTER_AD_FILES;
   // AIE_FKT_REGISTER_IMP_BODY_LINKS;
   //AIE_FKT_REGISTER_STANDARD_IMP;
   AIE_FKT_REGISTER_PAGE_JAVASCRIPT;
   //AIE_FKT_REGISTER_CGI_VAR_REMOTE_2_LOCAL;
   //AIE_FKT_REGISTER_KNOWN_MENUES;
   AIE_FKT_REGISTER_PAGE_REC;
   //AIE_FKT_REGISTER_BASIC_REC;
   AIE_FKT_REGISTER_KNOWN_FRAMES;
   AIE_FKT_REGISTER_MODULE_2_CGI_PROG;
   AIE_FKT_REGISTER_PAGE_CGI_DISPATCH;
   AIE_FKT_REGISTER_FRAME_CGI_DISPATCH;
   //AIE_FKT_REGISTER_FOLLOW_CGI_VARS;
   //AIE_FKT_REGISTER_SUB_MEN_PATHS;
   //AIE_FKT_REGISTER_CGI_VERSION_INFO;
   AIE_FKT_REGISTER_BODY_TAG;
   if (__builtin_expect((AIE_FKT_INIT_CGI_GLOBALE_VARIABLEN), true))
   {
      aie_SetStaticAsecurVariablesFromStruct(aie_static_variablen, 
	                                 aie_size_static_variablen);
      rc = true;
   }
   return(rc);
}

struct aie_sql_data *InitBackgroundDB(void)
{
   return(aie_sql_meta_attach_db(AIE_DB_ID_AIENGINE, &aiengine_sql_meta_db));
}

bool ExitBackgroundDB(void)
{
   return(aie_sql_meta_release_db(&aiengine_sql_meta_db));
}

bool Exit_CGI(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   aie_Free_aIEngine_cgi_variablen();
   return(true);
}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int  modul_init_size             = __LINE__;                                 //
/* -------------------------------- EOF ------------------------------------ */
