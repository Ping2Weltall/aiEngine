/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : myheader.c                                                  */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_myheader_version       = "1.0.0";                                //
char *modul_myheader               = "Header";                               //
char *modul_myheader_date          = __DATE__;                               //
char *modul_myheader_time          = __TIME__;                               //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                   1                            //
#define AIENGINE_USE_CLIENT_LIB                 1                            //
#define AIENGINE_USE_CGI_LIB                    1                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_cgivar.h"                                         //
#include "aie_cgi_register_cgival.h"                                         //
#include "aie_cgi_register_frames.h"                                         //
#include "aie_cgi_register_header.h"                                         //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *cgiUserAgent;                                                   //
extern char *cgiCookie;                                                      //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/





bool do_extern_modul_header(const char *whichFrame, const char *whichPage, 
                            AIE_CGI_STANDARD_FKT_PARAMETER)
{
   //const char *home_url = GetStandardAsecurVariableValue(AIENGINE_VAR_HOME_URL);
   if (whichFrame == NULL)
   {
      bJAVASCRIPT
      #if 0
      html_static("function asecur_error_handler(a)\n");
      html_static("{\n");
      html_static("   var error_url = '/cgi-bin/ff.cgi&error=' + a;");
      html_static("window.open(error_url,"
                             "\"TheWindow\","
                             "\"toolbar=no,"
                              "width=100,height=500"
                              "directories=no,"
                              "status=no,"
                              "scrollbars=yes,"
                              "resize=yes,"
                              "menubar=no\");");
      html_static("}\n\n");
      #endif
      html_static("function click()\n");
      html_static("{\n");
      html_static("   if (event.button==2)\n");
      html_static("   { \n");
      html_static("      var is_ie = (document.all)? 1 : 0;\n");
      html_static("      if (is_ie)\n");
      html_static("      {\n");
      html_static("         document.execCommand('refresh');\n");
      html_static("      }\n");
      html_static("      else\n");
      html_static("      {\n");
      html_static("         alert('');document.location = self.location;\n");
      html_static("      };\n");
      html_static("   }\n");
      html_static("}\n");
      html_static("document.onmousedown=click\n");
      //html_static("window.onerror = asecur_error_handler;\n");
      html_static("if (window.top.frames.length < 2)\n");
      html_static("{\n");
      //html_vt("   setTimeout(\"top.location = '%s';\", 1000);\n", home_url);
      html_static("}\n");
      eJAVASCRIPT
   }
   if (whichPage != NULL)
   {
      if (strcmp(whichPage, isBannerPageCGIVal) == 0)
      {
      }
   }
   return(true);
}


/* --------------               aIEngine.org                   ------------- */
int   modul_myheader_size          = __LINE__;                               //
/* -------------------------------- EOF ------------------------------------ */

