/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : daten.c                                                     */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_daten_version   = "1.0.0";                                       //
char *modul_daten           = "aieRegister";                                 //
char *modul_daten_date      = __DATE__;                                      //
char *modul_daten_time      = __TIME__;                                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                   1                            //
#define AIENGINE_USE_CLIENT_LIB                 1                            //
#define AIENGINE_USE_DB_LIB                     1                            //
#define AIENGINE_USE_SQL_WRAP_LIB               1                            //
#define AIENGINE_USE_CGI_LIB                    1                            //
#define AIENGINE_USE_LOG_LIB                    1                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_anmeldung.h"                                      //
#include "aie_cgi_register_banner.h"                                         //
#include "aie_cgi_register_bodys.h"                                          //
#include "aie_cgi_register_header.h"                                         //
#include "aie_cgi_register_cgival.h"                                         //
#include "aie_cgi_register_cgivar.h"                                         //
#include "aie_cgi_register_define.h"                                         //
#include "aie_cgi_register_frames.h"                                         //
#include "aie_cgi_register_register.h"                                       //
#include "aie_cgi_register_user.h"                                           //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// siehe unten                                                               //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

bool UserhasUserRecord = false;

AIE_STRUCT_KNOWN_FRAMES =
{
   { AIENGINE_FRAME_ISTOPOFWINDOW           },
   { AIENGINE_FRAME_TOP_INTRO               }
};
AIE_INT_VAR_SIZE_KNOWN_FRAMES;


AIE_STRUCT_PAGE_REC =
{
   { 0, isPageNotFoundCGIVal,             pic_bg_square,   "",        page_not_found },
   { 0,  isRegistrierungPageCGIVal,       pic_bg_square,  "",         registrierungs_page },
   { 0,  is_aie_UserAnmeldungPageCGIVal,       pic_bg_square,  "",    anmeldung_page },
   { 0,  is_aie_UserAbmeldungPageCGIVal,       pic_bg_square,  "",    abmeldung_page },
   { 0,  isNeuerBenutzerPageCGIVal,       pic_bg_square,  "",    neuer_benutzer_page },
   { 0,  isChangeBenutzerPageCGIVal,       pic_bg_square,  "",    change_benutzer_page }
};
AIE_INT_VAR_SIZE_PAGE_REC;

AIE_STRUCT_BASIC_REC =
{
   { 0, isTopUtilPageCGIVal,                  "",                        "show()",   body_top_util_page    },
};
AIE_INT_VAR_SIZE_BASIC_REC;
//AIENGINE_EMPTY_KNOWN_MENUES;
#if 0
struct aiengine_menue_cell aiengine_std_menue_cell =
{
   "top.jpg", "toph.jpg", "menrow.jpg", "menrowh.jpg", false, "220", "190", 
   "rbgl.jpg", "menbrow.jpg" 
};

struct known_menues known_menues[] =
{
   {  isIntroMenPageCGIVal,  
   	   appl_menue_intro,
  	   "Wer, Wie, Was?",   
   	   FrameNameWork, 
	   isIntroWorkPageCGIVal,          
	   true, 
	   false,
	   isMenueCGIVar,
	   pic_menue_intro,    
      	   &aiengine_std_menue_cell,
	   NULL,  
	   NULL
   },
   {  isComputerkunstMenPageCGIVal,
	   appl_menue_computerkunst, 
	   "Surreales",     
	   FrameNameWork,   
	   isCPUArtWorkPageCGIVal,         
	   false,
	   false,
	   isMenueCGIVar,
	   pic_menue_computerkunst,
	   &aiengine_std_menue_cell,
	   NULL, 
	   NULL 
   },
   {  isDownloadMenPageCGIVal,      
	   appl_menue_download, 
      	   "Kostenlose Software", 
      	   FrameNameWork,  
	   isDownloadWorkPageCGIVal,       
	   false,
	   false,
	   isMenueCGIVar,
	   pic_menue_download,  
       	   &aiengine_std_menue_cell,
	   NULL,  
	   NULL 
   },
   {  isLinkMenPageCGIVal,    
    	   appl_menue_link,   
    	   "Sprungbrett ins Internet",
	   FrameNameWork, 
	   isLinkWorkPageCGIVal,           
	   false,
	   false,
	   isMenueCGIVar, 
	   pic_menue_link,  
   	   &aiengine_std_menue_cell, 
	   NULL, 
	   NULL 
   }
};
int size_known_menues = sizeof(known_menues)/sizeof(struct known_menues);
#endif
//AIENGINE_EMPTY_APPL_STANDARD_IMP;
#if 0
struct standard_imp appl_standard_imp[] =
{
   { isBodyImpIntroPageCGIVal,      IMP_AIENGINE_INTRO          },
   { isBodyImpCPUArtPageCGIVal,     IMP_AIENGINE_CPUART         },
   { isBodyImpDownloadPageCGIVal,   IMP_AIENGINE_DOWNLOAD       },
   { isBodyImpLinkPageCGIVal,       IMP_AIENGINE_LINK           }
};

int size_appl_standard_imp = sizeof(appl_standard_imp) / sizeof(struct standard_imp);

struct imp_body_links appl_ibl[] =
{
    { IMP_AIENGINE_INTRO, FrameSetIntroIndex,         FrameNameTopOfWindow,  isIntroIndexPageCGIVal,          pic_imp_intro_s,           pic_imp_intro_b,         "Intro",          sAdKategorieNewart4u },
    { IMP_AIENGINE_INTRO, FrameSetComputerkunstIndex, FrameNameTopOfWindow,  isComputerkunstIndexPageCGIVal,  pic_imp_computerkunst_a,   pic_imp_computerkunst_b, "Computerkunst",  sAdKategorieNewart4u },
    { IMP_AIENGINE_INTRO, FrameSetDownloadIndex,      FrameNameTopOfWindow,  isDownloadIndexPageCGIVal,       pic_imp_download_a,        pic_imp_download_b,      "Downloads",      sAdKategorieNewart4u },
    { IMP_AIENGINE_INTRO, FrameSetLinkIndex,          FrameNameTopOfWindow,  isLinkIndexPageCGIVal,           pic_imp_link_a,            pic_imp_link_b,          "Links",          sAdKategorieNewart4u },

    { IMP_AIENGINE_CPUART, FrameSetIntroIndex,         FrameNameTopOfWindow,  isIntroIndexPageCGIVal,          pic_imp_intro_a,           pic_imp_intro_b,         "Intro",          sAdKategorieNewart4u },
    { IMP_AIENGINE_CPUART, FrameSetComputerkunstIndex, FrameNameTopOfWindow,  isComputerkunstIndexPageCGIVal,  pic_imp_computerkunst_s,   pic_imp_computerkunst_b, "Computerkunst",  sAdKategorieNewart4u },
    { IMP_AIENGINE_CPUART, FrameSetDownloadIndex,      FrameNameTopOfWindow,  isDownloadIndexPageCGIVal,       pic_imp_download_a,        pic_imp_download_b,      "Downloads",      sAdKategorieNewart4u },
    { IMP_AIENGINE_CPUART, FrameSetLinkIndex,          FrameNameTopOfWindow,  isLinkIndexPageCGIVal,           pic_imp_link_a,            pic_imp_link_b,          "Links",          sAdKategorieNewart4u },

    { IMP_AIENGINE_DOWNLOAD, FrameSetIntroIndex,         FrameNameTopOfWindow,  isIntroIndexPageCGIVal,          pic_imp_intro_a,           pic_imp_intro_b,         "Intro",          sAdKategorieNewart4u },
    { IMP_AIENGINE_DOWNLOAD, FrameSetComputerkunstIndex, FrameNameTopOfWindow,  isComputerkunstIndexPageCGIVal,  pic_imp_computerkunst_a,   pic_imp_computerkunst_b, "Computerkunst",  sAdKategorieNewart4u },
    { IMP_AIENGINE_DOWNLOAD, FrameSetDownloadIndex,      FrameNameTopOfWindow,  isDownloadIndexPageCGIVal,       pic_imp_download_s,        pic_imp_download_b,      "Downloads",      sAdKategorieNewart4u },
    { IMP_AIENGINE_DOWNLOAD, FrameSetLinkIndex,          FrameNameTopOfWindow,  isLinkIndexPageCGIVal,           pic_imp_link_a,            pic_imp_link_b,          "Links",          sAdKategorieNewart4u },

    { IMP_AIENGINE_LINK, FrameSetIntroIndex,         FrameNameTopOfWindow,  isIntroIndexPageCGIVal,          pic_imp_intro_a,           pic_imp_intro_b,         "Intro",          sAdKategorieNewart4u },
    { IMP_AIENGINE_LINK, FrameSetComputerkunstIndex, FrameNameTopOfWindow,  isComputerkunstIndexPageCGIVal,  pic_imp_computerkunst_a,   pic_imp_computerkunst_b, "Computerkunst",  sAdKategorieNewart4u },
    { IMP_AIENGINE_LINK, FrameSetDownloadIndex,      FrameNameTopOfWindow,  isDownloadIndexPageCGIVal,       pic_imp_download_a,        pic_imp_download_b,      "Downloads",      sAdKategorieNewart4u },
    { IMP_AIENGINE_LINK, FrameSetLinkIndex,          FrameNameTopOfWindow,  isLinkIndexPageCGIVal,           pic_imp_link_s,            pic_imp_link_b,          "Links",          sAdKategorieNewart4u }
};
int size_appl_imp_body_links = sizeof(appl_ibl) / sizeof(struct imp_body_links);

struct page_javascript page_javascript[] =
{
   { isTopUtilPageCGIVal,          "intro.js",       NULL,               
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isIntroMenPageCGIVal,         "ghosthead.js",   space_z_index,      
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isCPUArtWorkPageCGIVal,       "spacehead.js",   space_z_index,      
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isIntroMenPageCGIVal,         "alex.js",        alex_menue,         
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isIntroMenPageCGIVal,         "ghost.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isCPUArtWorkPageCGIVal,       "spaceship.js",   NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isComputerkunstMenPageCGIVal, "bush.js",        bush_speak,         
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isDownloadMenPageCGIVal,      "alice.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isLinkMenPageCGIVal,          "ma__.js",        NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isIntroWorkPageCGIVal,        "key.js",         NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isCPUArtWorkPageCGIVal,       "klee.js",        NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isDownloadWorkPageCGIVal,     "sh.js",          NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isLinkWorkPageCGIVal,         "space.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isLinkWorkPageCGIVal,         "eagle.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
//   { isIntroWorkPageCGIVal,        NULL,             intro_util_doc_ptr,  
//   AIENGINE_JAVASCRIPT_HEAD,    false },
   { isIntroWorkPageCGIVal,        "clock.js",       intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isIntroWorkPageCGIVal,        "somevars.js",    NULL,               
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isIntroWorkPageCGIVal,        "startclock.js",  NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isIntroWorkPageCGIVal,        "smile.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isTopUtilPageCGIVal,          "visitinit.js",   NULL,               
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isTopUtilPageCGIVal,          NULL,             init_banner_pic_array,   
      AIENGINE_JAVASCRIPT_HEAD,   false },
   { isCPUArtWorkPageCGIVal,       "clock.js",       intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isCPUArtWorkPageCGIVal,       "startclock.js",  NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isDownloadWorkPageCGIVal,     "clock.js",       intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isDownloadWorkPageCGIVal,     "startclock.js",  NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isBodyImpIntroPageCGIVal,     "biker.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isBodyImpIntroPageCGIVal,     "somebatch.js",   intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isLinkWorkPageCGIVal,         "clock.js",       intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isLinkWorkPageCGIVal,         "startclock.js",  NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isBannerPageCGIVal,           "week.js",        NULL,               
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isBannerPageCGIVal,           "smile.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isLinkMenPageCGIVal,          "spacehead.js",   space_z_index,      
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isLinkMenPageCGIVal,          "spaceship.js",   NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isDownloadMenPageCGIVal,      "smile.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isBodyImpLinkPageCGIVal,      "smile.js",       NULL,               
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isWorkPageCGIVal,             NULL,             intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        true },
   { isWorkPageCGIVal,             NULL,             winpopuptxt,        
      AIENGINE_JAVASCRIPT_HEAD,        true },
   { isWorkPageCGIVal,             NULL,             banner_pic_target,  
      AIENGINE_JAVASCRIPT_HEAD,        true },
   { isIntroMenPageCGIVal,         NULL,             intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isBannerPageCGIVal,           NULL,             intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isBannerPageCGIVal,           NULL,             do_banner_pic_array,   
      AIENGINE_JAVASCRIPT_HEAD,     false },
   { isBannerPageCGIVal,           NULL,             banner_pic_start,   
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isBottomInfoPageCGIVal,       NULL,             intro_util_doc_ptr, 
      AIENGINE_JAVASCRIPT_HEAD,        false },
   { isBottomInfoPageCGIVal,       NULL,             winpopupfkt,        
      AIENGINE_JAVASCRIPT_BODY_END,    false },
   { isBannerPageCGIVal,           NULL,             win_systemcheck,    
      AIENGINE_JAVASCRIPT_BODY_END,        false },
   { isIntroMenPageCGIVal,         NULL,             win_syschkexec,     
      AIENGINE_JAVASCRIPT_BODY_END,        false }
//   { isIntroMenPageCGIVal,         NULL,             win_systemcheck,    
//   AIENGINE_JAVASCRIPT_HEAD,        false }

};
int size_page_javascript = sizeof(page_javascript)/sizeof(struct page_javascript);
#endif

AIENGINE_EMPTY_PAGE_JAVASCRIPT
AIENGINE_EMPTY_FOLLOW_CGI_VARS
//AIENGINE_EMPTY_CGI_VAR_REMOTE_2_LOCAL                                        //
//AIENGINE_EMPTY_AD_FILES
#if 0
struct ad_files ad_files[] =
{
   { sAdKategorieNewart4u,        appl_banner_aiengine,          false }
};
int size_ad_files = sizeof(ad_files)/sizeof(struct ad_files);
#endif
//AIENGINE_EMPTY_SUB_MEN_PATHS
//AIENGINE_EMPTY_CGI_VERSION_INFO

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int  modul_daten_size       = __LINE__;                                      //
/* -------------------------------- EOF ------------------------------------ */

