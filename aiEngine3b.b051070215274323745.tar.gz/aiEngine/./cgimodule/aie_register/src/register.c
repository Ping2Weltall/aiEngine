/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : register.c                                                  */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 30.12.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_register_version      = "2.0.1";                                 //
char *modul_register              = "Register";                              //
char *modul_register_date         = __DATE__;                                //
char *modul_register_time         = __TIME__;                                //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIE_INSIDE_REGISTER_CGI
#define AIENGINE_USE_BASE_LIB                   1                            //
#define AIENGINE_USE_CLIENT_LIB                 1                            //
#define AIENGINE_USE_DB_LIB                     1                            //
#define AIENGINE_USE_SQL_WRAP_LIB               1                            //
#define AIENGINE_USE_CGI_LIB                    1                            //
#define AIENGINE_USE_LOG_LIB                    1                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
                                                                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_user.h"
#include "aie_cgi_register_util.h"
#include "aie_cgi_register_init.h"
#include "aie_cgi_register_register.h"                                       //
#include "aie_cgi_register_cgivar.h"                                         //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *cgiRequestUri;                                                  //
extern char *cgiRemoteAddr;
extern char *cgiUserAgent;
extern struct aie_sql_meta_db aiengine_sql_meta_db;
extern struct aie_wingui_screen_feld_var aie_registrierung_feld_2_var[];
extern unsigned int aie_size_registrierung_feld_2_var;
extern bool UserhasUserRecord;
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
static bool hasRegistration = false;
static bool SerialhasPoolEntry = false;
static char *SerialValidUntil = NULL;
static char *SerialPoolFreigabe = NULL;
static char *DBUserPasswort = NULL;
static char *UserValidUntil = NULL;
static long AktInstallCount = 0;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/

struct callback_data
{
   FILE *fptr_list;
   FILE *fptr_cleanup;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool do_register(AIE_CGI_STANDARD_FKT_PARAMETER,                      //
                               struct aie_wingui_screen_feld_var             //
			                                  *aie_feld_2_var,   //
                               unsigned int aie_size_feld_2_var);            //
static bool check_user_name_availible(const char *Username,                  //
                                      const char *Passwort,                  //
                               struct aie_sql_data *aie_sql_data);           //
static bool insert_registration_records(const char *Seriennummer,            //
                                        const char *ModulName,               //
					const char *Username,                //
					const char *Passwort,                //
                               struct aie_wingui_screen_feld_var             //
			                                  *aie_feld_2_var,   //
                               unsigned int aie_size_feld_2_var,             //
                                        struct aie_sql_data *aie_sql_data);  //
static bool insert_modul_registration(const char *Seriennummer,              //
                                      const char *Username,                  //
				      const char *timestamp,                 //
                                      struct aie_sql_data *aie_sql_data);    //
static int aie_user_record_callback(void *pArg, int nArg,                    //
                                           char **azArg, char **azCol);      //
static int aie_register_callback(void *pArg, int nArg, char **azArg,         //
		                                       char **azCol);        //
static int aie_serial_pool_check_callback(void *pArg, int nArg,              //
                                           char **azArg, char **azCol);      //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void registrierungs_page(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   bool hasError = false;
   char *result;
   register unsigned int i;
   static char crc_control[25];
   registrierung_header(AIE_CGI_STANDARD_PARAMETER);
   for (i = 0;i < aie_size_registrierung_feld_2_var; i++)
   {

      if (*aie_registrierung_feld_2_var[i].CGIVar != '.')
      {
            if ((result = 
		     aie_CGIValuePtr(aie_registrierung_feld_2_var[i].CGIVar))
		                                                    != NULL)
            {
               char *Feldname = aie_wingui_GetScreenCGIVar2FeldName(
				      aie_registrierung_feld_2_var[i].CGIVar,
	                              aie_registrierung_feld_2_var,
	                              aie_size_registrierung_feld_2_var);
               if (Feldname == NULL)
               {
	          html_vt("Fehler: Interner Progammfehler! Var[%s]\n", 
				      aie_registrierung_feld_2_var[i].CGIVar);
	          hasError = true;
               }
               else
	       {
	          html_vt(">\t\t%-*s \t%s\n", (30 - strlen(Feldname)),
				      Feldname,
		                              result);
	          aie_registrierung_feld_2_var[i].Value = aie_strdup(result);
	       }
            }
            else
            {
	       if (aie_registrierung_feld_2_var[i].required)
	       {
	          html_vt("!\t\t%s \t%s\n", 
				      aie_registrierung_feld_2_var[i].Feld,
		     result);
	          hasError = true;
	      }
           }
      }
   }
   if (hasError)
   {
      html_vt("Fehler: Es wurden nicht alle notwendigen Felder ausgef�llt!");
   }
   else
   {
      char *FreigabeCRC = 
	 aie_wingui_GetScreenValueFromCGIVar(isFreigabeCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
      char *Seriennummer = 
	 aie_wingui_GetScreenValueFromCGIVar(isSeriennummerCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
     if ((Seriennummer == NULL) || (FreigabeCRC == NULL))
     {
	html_vt("Fehler: %s(%d): Interner Fehler oder ungueltiger Aufruf [%p]:[%p]!", 
              __FILE__, __LINE__,
	      Seriennummer, FreigabeCRC);
     }
     else
     {
         memset(crc_control, '\0', sizeof(crc_control));
         sprintf(crc_control, "%.8lX", 
	                       aie_crc32(0x666, Seriennummer, 
				            strlen(Seriennummer))); 
           if ((strcmp(crc_control, FreigabeCRC) != 0))
	   {
	      html_vt("Fehler: Die Pruefsumme ist inkorrekt!");
   	   }
	   else
           {
	      if ((do_register(AIE_CGI_STANDARD_PARAMETER, aie_registrierung_feld_2_var,
                                         aie_size_registrierung_feld_2_var)))
	      {
	         html_vt(">>Freigabe=%s ", crc_control);
	         html_static(">> Modul wurde freigegeben!\n");
	      }
	      else
	      {
	         html_static(" - Das Modul wurde nicht registriert!");
	      }
	   }
       }  
   }
   registrierung_footer();
}
/*---------------------------------------------------------------------------*/
static bool do_register(AIE_CGI_STANDARD_FKT_PARAMETER,                      //
                               struct aie_wingui_screen_feld_var             //
			                                  *aie_feld_2_var,   //
                               unsigned int aie_size_feld_2_var)             //
{
   bool rc = false;
   struct aie_sql_data *aie_sql_data = NULL; 
   if ((aie_sql_data = InitBackgroundDB()) != NULL)
   {
       aie_CGIValueVar(Seriennummer, isSeriennummerCGIVar);
       if (check_is_registert(Seriennummer, aie_sql_data))
       {
          html_vt("Fehler: Das Modul wurde bereits woanders unter dieser Seriennummer registriert!");
       }
       else
       {
          aie_CGIValueVar(Freigabe, isFreigabeCGIVar);
	  if (check_serial_in_pool_ok(Seriennummer, Freigabe, aie_sql_data))
	  {
             aie_CGIValueVar(ModulName, isModulNameCGIVar);
             aie_CGIValueVar(Username, isUserIdCGIVar);
             aie_CGIValueVar(Passwort, isPasswortCGIVar);
             aie_sql_meta_start_transaction(&aiengine_sql_meta_db);
	     if (check_user_name_availible(Username, Passwort, aie_sql_data) &&
	         ((rc = insert_registration_records(Seriennummer,
						    ModulName, 
						    Username, Passwort, 
			                            aie_feld_2_var,
                                                    aie_size_feld_2_var,
						       aie_sql_data)) == true))
	     {
                 aie_sql_meta_commit(&aiengine_sql_meta_db);
	     }
	     else
	     {
                 aie_sql_meta_rollback(&aiengine_sql_meta_db);
	     }
	  }
      }
      ExitBackgroundDB();
   }
   else
   {
      html_static("Fehler: Problem beim initialisieren der Regestrierungsdatenbank. Bitte versuchen Sie es sp�ter erneut.");
   }
   return(rc);
}

bool check_serial_in_pool_ok(const char *Seriennummer, const char *Freigabe, 
	                       struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "check_serial_in_pool" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR,    "Out of Memory?" },
      { AIE_LOG_SECURITY_INFO, "Versuch unbekannte Seriennummer %s "
	                       "zu registrieren!" }
   };
   bool rc = false;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((Seriennummer != NULL), true))
   {
      struct callback_data callback_data;
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      callback_data.fptr_list = NULL;
      callback_data.fptr_cleanup = NULL;
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_serial_pool_check_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = (void *)&callback_data;

         sprintf(sql_cmd, "SELECT %s, %s, %s FROM %s WHERE %s='%s'", 
	                                         is_aie_FreigabeSqlFld,
					is_aie_SerialCurrentInstallCountSqlFld, 
			                         is_aie_ValidUntilDateSqlFld,
						 AIE_DB_TABLE_SERIAL_POOL,
	                                         is_aie_SeriennummerSqlFld,
						 Seriennummer);
         //sys_log("%s(%d): SQL[%s]", __FILE__, __LINE__, sql_cmd); 
         if (!aie_sql_run(aie_sql_data))
         {
	    // TODO: sqlite3 ref entfernen
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
      if(!SerialhasPoolEntry)
      {
         // Versuch unbekannte Seriennummer %s registrieren!
         aie_sys_log(3, Seriennummer);
         html_vt("Fehler: Die Seriennummer ist im System nicht bekannt! Moeglicherweise haben Sie sich verschrieben.");
      }
      else
      {
         if ((Freigabe != NULL) && 
	  (SerialPoolFreigabe != NULL) &&
	  (SerialValidUntil != NULL) &&
	  (strcmp(Freigabe, SerialPoolFreigabe)== 0))
         {
            char *timestamp = aie_get_time_stamp();
	    if (strncmp(timestamp, SerialValidUntil, 8) < 0)
	    {
	       html_static("Fehler: Die Gueltigkeitsdauer der von Ihnen eingegebenen Seriennummer ist abgelaufen. Wenden Sie sich bitte an Ihren Provider um eine neue Seriennummer zu erhalten!");
	    }
	    else
	    {
	       rc = true;
	    }
         }
         else
         {
            html_vt("Fehler: Pruefsummenfehler oder ungueltiger Datenbankwert! [%p:%p:%p]", Freigabe, SerialPoolFreigabe, SerialValidUntil);
         }
         if (SerialValidUntil != NULL)
         {
	    aie_free(SerialValidUntil);
         }
         if (SerialPoolFreigabe != NULL)
         {
	    aie_free(SerialPoolFreigabe);
         }
      }
   }
   return(rc);
}

static int aie_user_record_callback(void *pArg, int nArg,
                                           char **azArg, char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_user_record_callback" },
      { AIE_LOG_ERROR, "Keine Callback Daten!" },
      { AIE_LOG_DB_ERROR, "Unbekannte Spalte[%s]" }
   };
   struct aie_sql_data *callback_aie_sql_data = (struct aie_sql_data *)pArg;
   struct callback_data *callback_data = 
                          (struct callback_data *)callback_aie_sql_data->data;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   UserhasUserRecord = true;

   if (__builtin_expect((callback_data == NULL), false))
   {
     // Keine Callback Daten!
     aie_sys_log(1);
   }
   else
   {
      for(int i=0; i<nArg; i++)
      {
	 if (strcmp(azCol[i], is_aie_UserPasswortSqlFld) == 0)
	 {
            DBUserPasswort = aie_strdup(azArg[i]);
	 }
	 else if (strcmp(azCol[i], is_aie_ValidUntilDateSqlFld) == 0)
	 {
	    UserValidUntil = aie_strdup(azArg[i]);
	 }
	 else
	 {
	    // Unbekannte Spalte[%s]
            aie_sys_log(2, azCol[i]);
	 }
      }
   }
   return(0);
}

static bool check_user_name_availible(const char *Username, 
                                      const char *Passwort,
                               struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "check_user_name_available" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" },
   };
   bool rc = false;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if ((Username != NULL) && (Passwort != NULL))
   {
      struct callback_data callback_data;
      char *sql_cmd = (char *)aie_malloc(1024);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_user_record_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = (void *)&callback_data;

         sprintf(sql_cmd, "SELECT %s, %s FROM %s WHERE %s='%s'", 
	                                         is_aie_UserPasswortSqlFld, 
			                         is_aie_ValidUntilDateSqlFld,
						 AIE_DB_TABLE_USER,
	                                         is_aie_UserIdSqlFld,
						 Username);
         if (!aie_sql_run(aie_sql_data))
         {
	    // TODO: sqlite3 ref entfernen
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
      if(!UserhasUserRecord)
      {
	 rc = true;
      }
      else
      {
	 if ((DBUserPasswort != NULL) &&
	       (strcmp(DBUserPasswort, Passwort) == 0))
	 {
	    rc = true;
	 }
	 else
	 {
            html_vt("Fehler: Der Benutzername %s ist leider schon vergeben. Aendern Sie bitte Ihren Wunsch Benutzernamen oder wenn es Ihr bisheriger Benutzername ist geben Sie Ihr aktuelles Passwort ein.", Username);
	 }
         if (DBUserPasswort != NULL)
         {
	    aie_free(DBUserPasswort);
         }
         if (UserValidUntil)
	 {
            aie_free(UserValidUntil);
	 }
      }
   }
   return(rc);
}

static bool insert_registration_records(const char *Seriennummer,
                                        const char *ModulName, 
					const char *Username,
					const char *Passwort,
                               struct aie_wingui_screen_feld_var             //
			                                  *aie_feld_2_var,   //
                               unsigned int aie_size_feld_2_var,             //
                                        struct aie_sql_data *aie_sql_data)   //
{
   char *timestamp = aie_get_time_stamp();
   bool rc = false;
   if (insert_modul_registration(Seriennummer, Username, timestamp, 
	                                                  aie_sql_data) &&
       (UserhasUserRecord ||
	   insert_user_record(Seriennummer, Username, Passwort,
	                                      timestamp, aie_feld_2_var, 
					      aie_size_feld_2_var, 
					                   aie_sql_data)) &&
       update_serial_information(Seriennummer, ModulName, timestamp,
	                                                     aie_sql_data))
   {
      rc = true;
   }
   return(rc);
}

bool update_serial_information(const char *Seriennummer, 
                               const char *ModulName,
                               char *timestamp,
                               struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "check_user_name_available" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" },
   };
   bool rc = false;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((Seriennummer != NULL), true))
   {
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
	 char NewInstallCount[8];
	 sprintf(NewInstallCount, "%ld", (AktInstallCount + 1));
         *sql_cmd = '\0';
         aie_sql_data->callback = NULL; //aie_user_record_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = NULL;

         sprintf(sql_cmd, "UPDATE %s SET %s='%s', "
	                                "%s='%s', "
				        "%s='%s' "
				        "WHERE %s='%s'",
	                                         AIE_DB_TABLE_SERIAL_POOL,
						 is_aie_ModulNameSqlFld,
						 ModulName,
						 is_aie_InstallDateSqlFld,
                                                 timestamp,
	                              is_aie_SerialCurrentInstallCountSqlFld,
				      NewInstallCount,
			                         is_aie_SeriennummerSqlFld,
						 Seriennummer);
         //sys_log("%s(%d): SQL[%s]", __FILE__, __LINE__, sql_cmd);
         if (!aie_sql_run(aie_sql_data))
         {
	    // TODO: sqlite3 ref entfernen
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
         }
	 else
	 {
	    rc = true;
	 }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
   }
   return(rc);
}

static bool insert_modul_registration(const char *Seriennummer,
                                      const char *Username, 
				      const char *timestamp,
                                      struct aie_sql_data *aie_sql_data)
{
   bool rc = false;
   char *isFirma =
	 aie_wingui_GetScreenValueFromCGIVar(isFirmaCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isVorname =
	 aie_wingui_GetScreenValueFromCGIVar(isVornameCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isNachname =
	 aie_wingui_GetScreenValueFromCGIVar(isNachnameCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isStrasse =
	 aie_wingui_GetScreenValueFromCGIVar(isStrasseCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isPostleitzahl =
	 aie_wingui_GetScreenValueFromCGIVar(isPostleitzahlCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isOrt =
	 aie_wingui_GetScreenValueFromCGIVar(isOrtCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isEmail =
	 aie_wingui_GetScreenValueFromCGIVar(isEmailCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isModulName =
	 aie_wingui_GetScreenValueFromCGIVar(isModulNameCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   char *isFreigabe =
	 aie_wingui_GetScreenValueFromCGIVar(isFreigabeCGIVar,
	                                   aie_registrierung_feld_2_var,
					   aie_size_registrierung_feld_2_var);
   struct aie_sql_meta_insert sql_meta_insert =
   {
      AIE_DB_TABLE_ID_MODUL_REGISTER,
      true,
      NULL, 0,
      false,
      &aiengine_sql_meta_db
   };
   struct aie_sql_meta_feld_value_list sql_meta_feld_value_list[] =
   {
      { is_aie_SeriennummerSqlFld, 		Seriennummer },
      { is_aie_ModulNameSqlFld, 		isModulName },
      { is_aie_FreigabeSqlFld, 			isFreigabe },
      { is_aie_UserIdSqlFld, 			Username },
      { is_aie_FirmaSqlFld, 			isFirma },
      { is_aie_VornameSqlFld, 			isVorname },
      { is_aie_NachnameSqlFld, 			isNachname },
      { is_aie_StrasseSqlFld, 			isStrasse },
      { is_aie_PostleitzahlSqlFld, 		isPostleitzahl },
      { is_aie_OrtSqlFld, 			isOrt },
      { is_aie_EmailSqlFld, 			isEmail },
      { is_aie_InstallDateSqlFld, 		timestamp },
      { is_aie_LastRunSqlFld, 			timestamp },
      { is_aie_LastUpdateSqlFld, 		timestamp },
      { is_aie_RunCountSqlFld, 			"0" },
      { is_aie_SerialMaxInstallCountSqlFld, 	"1" },
      { is_aie_SerialCurrentInstallCountSqlFld, "1" },
      { is_aie_ValidUntilDateSqlFld, 		"20050601" }
   };
   sql_meta_insert.sql_meta_feld_value_list = sql_meta_feld_value_list;
   sql_meta_insert.size_sql_meta_feld_value_list =
                                           sizeof(sql_meta_feld_value_list) /
                                 sizeof(struct aie_sql_meta_feld_value_list);
   if (aie_sql_meta_table_insert(&sql_meta_insert))
   {
      rc = true;
      html_vt("Info: Neue Registrierung\n");
   }
   else
   {
      char db_error[256];
      sprintf(db_error, "Fehler: Datenbank Fehler \"%s\": %s\n",
      AIE_DB_AIENGINE,
      sqlite3_errmsg(aie_sql_data->sql_db_data->db));
      if (strstr(db_error, "not an error") == NULL)
      {
         html_vt("%s", db_error);
      }
   }
   return(rc);
}

bool check_is_registert(const char *Seriennummer, 
                        struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "check_is_registriert" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" },
      { AIE_LOG_SECURITY_INFO, "Versuch Seriennummer[%s] "
	                       "erneut zu registrieren!" }
   };
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif

   if (Seriennummer != NULL)
   {
      struct callback_data callback_data;
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      callback_data.fptr_list = NULL;
      callback_data.fptr_cleanup = NULL;
      if (__builtin_expect((sql_cmd != NULL), true))
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_register_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = (void *)&callback_data;

         sprintf(sql_cmd, "SELECT %s, %s, %s FROM %s WHERE %s='%s'",
	                                         is_aie_FreigabeSqlFld,
			                         is_aie_VornameSqlFld,
			                         is_aie_NachnameSqlFld,
						 AIE_DB_TABLE_MODUL_REGISTER,
	                                         is_aie_SeriennummerSqlFld,
						 Seriennummer);
         if (!aie_sql_run(aie_sql_data))
         {
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }

   }
   if (hasRegistration)
   {
      // Versuch Seriennummer[%s] erneut zu registrieren!
      aie_sys_log(3, Seriennummer);
   }
   return(hasRegistration);
}

static int aie_serial_pool_check_callback(void *pArg, int nArg, char **azArg,
		                                       char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_serial_pool_check_callback" },
      { AIE_LOG_ERROR, "Keine Callback Daten!" },
      { AIE_LOG_DB_ERROR, "Unbekannte Spalte[%s]" }
   };
   struct aie_sql_data *callback_aie_sql_data = (struct aie_sql_data *)pArg;
   struct callback_data *callback_data =
                          (struct callback_data *)callback_aie_sql_data->data;
   SerialhasPoolEntry = true;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif

   if (callback_data == NULL)
   {
     // Keine Callback Daten!
     aie_sys_log(1);
   }
   else
   {
      for(int i=0; i<nArg; i++)
      {
	 if (strcmp(azCol[i], is_aie_FreigabeSqlFld) == 0)
	 {
	    SerialPoolFreigabe = aie_strdup(azArg[i]);
	 }
	 else if (strcmp(azCol[i], is_aie_ValidUntilDateSqlFld) == 0)
	 {
	    SerialValidUntil = aie_strdup(azArg[i]);
	 }
	 else if (strcmp(azCol[i], is_aie_SerialCurrentInstallCountSqlFld) == 0)
	 {
	    AktInstallCount = atol(azArg[i]);
	 }
	 else
	 {
	    // Unbekannte Spalte[%s]
            aie_sys_log(2, azCol[i]);
	 }
      }
   }
   return(0);
}

static int aie_register_callback(void *pArg, int nArg, char **azArg,
		                                       char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_register_callback" },
      { AIE_LOG_ERROR, "Keine Callback Daten!" },
      { AIE_LOG_DB_ERROR, "Unbekannte Spalte[%s]" }
   };
   char jahr[5];
   char monat[3];
   char tag[3];
   char stunde[3];
   char minute[3];
   char sekunde[3];
   char *vorname = NULL;
   char *nachname = NULL;
   char *timestamp = NULL;
   char *freigabe = NULL;
   struct aie_sql_data *callback_aie_sql_data = (struct aie_sql_data *)pArg;
   struct callback_data *callback_data =
                          (struct callback_data *)callback_aie_sql_data->data;
   hasRegistration = true;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if(callback_data == NULL)
   {
     // Keine Callback Daten!
     aie_sys_log(1);
   }
   else
   {
      memset(jahr, '\0', sizeof(jahr));
      memset(monat, '\0', sizeof(monat));
      memset(tag, '\0', sizeof(tag));
      memset(stunde, '\0', sizeof(stunde));
      memset(minute, '\0', sizeof(minute));
      memset(sekunde, '\0', sizeof(sekunde));
      for(int i=0; i<nArg; i++)
      {
	 if (strcmp(azCol[i], is_aie_FreigabeSqlFld) == 0)
	 {
	    freigabe = azArg[i];
	 }
	 else if (strcmp(azCol[i], is_aie_VornameSqlFld) == 0)
	 {
	    vorname = azArg[i];
	 }
	 else if (strcmp(azCol[i], is_aie_NachnameSqlFld) == 0)
	 {
	    nachname = azArg[i];
	 }
	 else
	 {
	    if (strcmp(azCol[i], is_aie_TimestampSqlFld) == 0)
	    {
	       timestamp = azArg[i];
	       if (strlen(timestamp) == 14)
	       {
                  strncpy(jahr, timestamp, 4);
                  strncpy(monat, timestamp + 4, 2);
                  strncpy(tag, timestamp + 6, 2);
                  strncpy(stunde, timestamp + 8, 2);
                  strncpy(minute, timestamp + 10, 2);
                  strncpy(sekunde, timestamp + 12, 2);
	       }
	    }
	    else
	    {
	       // Unbekannte Spalte[%s]
               aie_sys_log(2, azCol[i]);
	    }
	 }
      }
   }
   return(0);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_register_size         = __LINE__;                                //
/* -------------------------------- EOF ------------------------------------ */

