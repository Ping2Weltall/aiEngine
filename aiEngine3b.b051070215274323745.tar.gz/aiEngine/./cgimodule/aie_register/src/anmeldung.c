/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : anmeldung.c                                                 */
/* CGI         : aie_register.cgi                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/* Verwendet das @Secur(tm) Internet Engine & HTML Generator                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
char *modul_anmeldung_version     = "2.0.1";                                 //
char *modul_anmeldung             = "Register";                              //
char *modul_anmeldung_date        = __DATE__;                                //
char *modul_anmeldung_time        = __TIME__;                                //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIE_INSIDE_REGISTER_CGI
#define AIENGINE_USE_BASE_LIB                   1                            //
#define AIENGINE_USE_CLIENT_LIB                 1                            //
#define AIENGINE_USE_DB_LIB                     1                            //
#define AIENGINE_USE_SQL_WRAP_LIB               1                            //
#define AIENGINE_USE_CGI_LIB                    1                            //
#define AIENGINE_USE_LOG_LIB                    1                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <unistd.h>                                                         //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
//#include "aie_crc32.h"
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aie_cgi_register_register.h"                                       //
#include "aie_cgi_register_cgivar.h"                                         //
#include "aie_cgi_register_anmeldung.h"                                      //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *cgiRequestUri;                                                  //
extern char *cgiRemoteAddr;
extern char *cgiUserAgent;
extern struct aie_sql_meta_db aiengine_sql_meta_db;
extern struct aie_wingui_screen_feld_var aie_Anmeldung_screen_feld_var[];
extern unsigned int aie_Anmeldung_size_screen_feld_var;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
static bool UserhasUserRecord = false;
static char *DBUserPasswort = NULL;
static char *UserValidUntil = NULL;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct callback_data
{
   FILE *fptr_list;
   FILE *fptr_cleanup;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool check_user_ok(const char *Username, const char *Passwort,        //
                               struct aie_sql_data *aie_sql_data);           //
static struct aie_sql_data *InitBackgroundDB(void);                          //
static bool ExitBackgroundDB(void);                                          //
static int aie_user_record_callback(void *pArg, int nArg,                    //
                                           char **azArg, char **azCol);      //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void abmeldung_page(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "abmeldung_page" },
      { AIE_LOG_ERROR, "Session PTR == NULL UserId %s?!" },
      { AIE_LOG_TRACE_FKT, "Abmeldung Session [%s] User: [%s]" }
   };
      aie_CGIValueVar(Session, isSessionCGIVar);
      aie_CGIValueVar(UserID, isUserIdCGIVar);
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
     if ((Session == NULL))
     {
	// Session PTR == NULL UserId %s?!
        aie_sys_log(1, UserID);
     }
     else
     {
        #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
	// Abmeldung Session [%s] User: [%s]
        aie_sys_log(2, Session, UserID);
        #endif
	aie_delete_session(Session);
     }
     html_vt(">>OK\n");
}

void anmeldung_page(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "anmeldung_page" },
      { AIE_LOG_SECURITY, "Anmeldeversuch Benutzer [%s] - Abgelehnt! Passwort?" },
      { AIE_LOG_ERROR,    "Fehler: Problem beim initialisieren der "
	                  "Benutzerdatenbank. Bitte versuchen Sie es sp�ter "
			  "erneut." }

   };
      aie_CGIValueVar(UserID, isUserIdCGIVar);
      aie_CGIValueVar(Passwort, isPasswortCGIVar);
   aie_sys_log(0);
     if ((Passwort == NULL) || (UserID == NULL))
     {
        html_vt("Fehler: Es wurden nicht alle notwendigen Felder ausgef�llt!");
     }
     else
     {
        struct aie_sql_data *aie_sql_data = NULL; 
        if ((aie_sql_data = InitBackgroundDB()) != NULL)
        {
           if (!check_user_ok(UserID, Passwort, aie_sql_data))
	   {
	      //sys_log("%s(%d): Anmeldeversuch Benutzer [%s] mit Passwort: [%s] - Abgelehnt!", __FILE__, __LINE__, UserID, Passwort);
	      // Anmeldeversuch Benutzer [%s] - Abgelehnt! Passwort?
               aie_sys_log(1, UserID);
	   }
           ExitBackgroundDB();
        }
        else
        {
           // Fehler: Problem beim initialisieren der Benutzerdatenbank. Bitte versuchen Sie es sp�ter erneut.
           html_static(aie_log_msg_select(2));
           aie_sys_log(2);
        }
     }
}
/*---------------------------------------------------------------------------*/

static int aie_user_record_callback(void *pArg, int nArg,
                                           char **azArg, char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_user_record_callback" },
      { AIE_LOG_ERROR, "Keine Callback Daten" },
      { AIE_LOG_ERROR, "Unbekannte Spalte[%s]" }
   };
   struct aie_sql_data *callback_aie_sql_data = (struct aie_sql_data *)pArg;
   struct callback_data *callback_data = 
                          (struct callback_data *)callback_aie_sql_data->data;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   UserhasUserRecord = true;

   if(callback_data == NULL)
   {
     // Keine Callback Daten
     aie_sys_log(1);
   }
   else
   {
      for(int i=0; i<nArg; i++)
      {
	 if (strcmp(azCol[i], is_aie_UserPasswortSqlFld) == 0)
	 {
            DBUserPasswort = aie_strdup(azArg[i]);
	 }
	 else if (strcmp(azCol[i], is_aie_ValidUntilDateSqlFld) == 0)
	 {
	    UserValidUntil = aie_strdup(azArg[i]);
	 }
	 else
	 {
	    // Unbekannte Spalte[%s]
            aie_sys_log(2, azCol[i]);
	 }
      }
   }
   return(0);
}

static bool check_user_ok(const char *Username, const char *Passwort,
                               struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "check_user_ok" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" }
   };
   bool hasError = false;
   bool rc = false;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if ((Username != NULL) && (Passwort != NULL))
   {
      struct callback_data callback_data;
      char *sql_cmd = (char *)aie_malloc(1024);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_user_record_callback;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = (void *)&callback_data;

         sprintf(sql_cmd, "SELECT %s, %s FROM %s WHERE %s='%s'", 
	                                         is_aie_UserPasswortSqlFld, 
			                         is_aie_ValidUntilDateSqlFld,
						 AIE_DB_TABLE_USER,
	                                         is_aie_UserIdSqlFld,
						 Username);
         if (!aie_sql_run(aie_sql_data))
         {
            // TODO: sqlite3 ref entfernen 
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
            html_vt("Fehler: %s(%d): DB %s", __FILE__, __LINE__, 
                                 sqlite3_errmsg(aie_sql_data->sql_db_data->db));
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
	 html_vt("Fehler: Der Server hatte nicht genug Hauptspeicher um die Anmeldung durchzuf�hren!");
      }
      if(UserhasUserRecord)
      {
	 if ((DBUserPasswort != NULL) &&
	       (strcmp(DBUserPasswort, Passwort) == 0))
	 {
	    aie_check_user_has_session(Username);
	    {
	       char *Session = aie_make_session_nr(Username);
	       if (Session != NULL)
	       {
	          html_vt(">> Systemanmeldung OK  Session %s\n", Session);
	          rc = true;
	       }
	       else
	       {
		  html_vt("Es konnte keine Session erzeugt werden!\nEs sind ggf. zu viele Benutzer online!");
	       }
	    }
	 }
	 else
	 {
	    hasError = true;
	 }
         if (DBUserPasswort != NULL)
         {
	    aie_free(DBUserPasswort);
         }
         if (UserValidUntil)
	 {
            aie_free(UserValidUntil);
	 }
      }
      else
      {
	 hasError = true;
      }
   }
   if (hasError)
   {
       html_static("Fehler: Der Benutzer ist unbekannt oder Sie haben sich beim Passwort verschrieben!");
   }
   return(rc);
}

static struct aie_sql_data *InitBackgroundDB(void)
{
   return(aie_sql_meta_attach_db(AIE_DB_ID_AIENGINE, &aiengine_sql_meta_db));
}

static bool ExitBackgroundDB(void)
{
   return(aie_sql_meta_release_db(&aiengine_sql_meta_db));
}

/* --------------               aIEngine.de                    ------------- */
int   modul_anmeldung_size        = __LINE__;                                //
/* -------------------------------- EOF ------------------------------------ */

