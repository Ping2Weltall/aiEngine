/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_cgi_register_frames.h                                   */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_CGI_REGISTER_FRAMES_H
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_CGI_REGISTER_FRAMES_H
// 1 - 9   Reserviert fuer @Secur Core
#define SFrameSetIntroIndex         	"10"
#define SFrameSetIntroMain              "11"
#define SFrameSetIntroWork              "12"
#define FrameSetIntroIndex              10
#define FrameSetIntroMain               11
#define FrameSetIntroWork               12


#define SFrameSetComputerkunstIndex     "20"
#define SFrameSetComputerkunstMain      "21"
#define SFrameSetComputerkunstWork      "22"
#define FrameSetComputerkunstIndex      20
#define FrameSetComputerkunstMain       21
#define FrameSetComputerkunstWork       22


#define SFrameSetDownloadIndex          "30"
#define SFrameSetDownloadMain           "31"
#define SFrameSetDownloadWork           "32"
#define FrameSetDownloadIndex           30
#define FrameSetDownloadMain            31
#define FrameSetDownloadWork            32


#define SFrameSetLinkIndex              "40"
#define SFrameSetLinkMain               "41"
#define SFrameSetLinkWork               "42"
#define FrameSetLinkIndex               40
#define FrameSetLinkMain                41
#define FrameSetLinkWork                42


#define SFrameSetTopIntro               "50"
#define SFrameSetTopCPUArt              "51"
#define SFrameSetTopDownload            "53"
#define SFrameSetTopLink                "54"
#define FrameSetTopIntro                50
#define FrameSetTopCPUArt               51
#define FrameSetTopDownload             53
#define FrameSetTopLink                 54

#define FrameNameWork                   "work"
#define FrameNameTop                    "Top"
#define FrameNameMain                   "Main"
#define FrameNameMenue                  "Men"
#define FrameNameCenter                 "Center"
#define FrameNameImp                    "Imp"
#define FrameNameBanner                 "Ad"


#define frame_head_col_0                "cols=\"*,0px\""
//#define frame_head_col_0                "cols=\"10px,*\""
#define frame_head_col_s                "cols=\"880px,*\""
#define frame_men_nscroll_col_s         "cols=\"220px,*\""
#define frame_men_col_s                 "cols=\"220px,*\""
#define frame_men_col_w                 "cols=\"300px,*\""
#define frame_imp_row                   "rows=\"*,20px\""
#define frame_top_row                   "rows=\"90px,*\""
#define frame_scroll_auto               "auto"
#define frame_scroll_no                 "no"


#define AIENGINE_FRAME_ISTOPOFWINDOW                                                                                  \
   FrameSetIsTopOfWindow,  frame_head_col_0,                                                                          \
         frame_scroll_auto, FrameSetIntroIndex,         isIndexPageCGIVal,                      FrameNameTopOfWindow, \
         frame_scroll_no, 0,                            isTopUtilPageCGIVal,                    FrameNameUtilFrame

#define AIENGINE_FRAME_TOP_INTRO                                                                                            \
   FrameSetTopIntro,            frame_head_col_s,                                                                          \
         frame_scroll_no, 0,                            isBodyImpIntroPageCGIVal,            FrameNameTop,   \
         frame_scroll_no, 0,                            isBannerPageCGIVal,                     FrameNameBanner

#define AIENGINE_FRAME_TOP_CPUART                                                                                            \
   FrameSetTopCPUArt,            frame_head_col_s,                                                                          \
         frame_scroll_no, 0,                            isBodyImpCPUArtPageCGIVal,            FrameNameTop,   \
         frame_scroll_no, 0,                            isBannerPageCGIVal,                     FrameNameBanner

#define AIENGINE_FRAME_TOP_DOWNLOAD                                                                                            \
   FrameSetTopDownload,            frame_head_col_s,                                                                          \
         frame_scroll_no, 0,                            isBodyImpDownloadPageCGIVal,            FrameNameTop,   \
         frame_scroll_no, 0,                            isBannerPageCGIVal,                     FrameNameBanner

#define AIENGINE_FRAME_TOP_LINK                                                                                            \
   FrameSetTopLink,            frame_head_col_s,                                                                          \
         frame_scroll_no, 0,                            isBodyImpLinkPageCGIVal,            FrameNameTop,   \
         frame_scroll_no, 0,                            isBannerPageCGIVal,                     FrameNameBanner

#define AIENGINE_FRAME_INTRO_INDEX                                                                                          \
   FrameSetIntroIndex,             frame_top_row,                                                                     \
        frame_scroll_no, FrameSetTopIntro,              isTopBannerPageCGIVal,                  FrameNameTop,          \
        frame_scroll_no, FrameSetIntroMain,            isMainPageCGIVal,                       FrameNameMain

#define AIENGINE_FRAME_INTRO_WORK                                                                                           \
   FrameSetIntroWork,                  frame_men_nscroll_col_s,                                                               \
        frame_scroll_no, 0,                          isIntroMenPageCGIVal,                   FrameNameMenue,        \
        frame_scroll_auto, 0,                          isIntroWorkPageCGIVal,                  FrameNameWork

#define AIENGINE_FRAME_INTRO_MAIN                                                                                           \
   FrameSetIntroMain,          frame_imp_row,                                                                         \
        frame_scroll_auto, FrameSetIntroWork,          isWorkPageCGIVal,                       FrameNameCenter,       \
        frame_scroll_no, 0,                            isBottomInfoPageCGIVal,            FrameNameImp

#define AIENGINE_FRAME_COMPUTERKUNST_INDEX                                                                                      \
   FrameSetComputerkunstIndex,  frame_top_row,                                                                            \
        frame_scroll_no, FrameSetTopCPUArt,                  isTopBannerPageCGIVal,                  FrameNameTop,        \
        frame_scroll_no, FrameSetComputerkunstMain,     isMainPageCGIVal,                 FrameNameMain

#define AIENGINE_FRAME_COMPUTERKUNST_MAIN                                                                                       \
   FrameSetComputerkunstMain,        frame_imp_row,                                                                       \
        frame_scroll_auto, FrameSetComputerkunstWork,        isWorkPageCGIVal,                       FrameNameCenter,     \
        frame_scroll_no, 0,                            isBottomInfoPageCGIVal,             FrameNameImp

#define AIENGINE_FRAME_COMPUTERKUNST_WORK                                                                                       \
   FrameSetComputerkunstWork,        frame_men_nscroll_col_s,                                                             \
        frame_scroll_no, 0,                            isComputerkunstMenPageCGIVal,                 FrameNameMenue,      \
        frame_scroll_auto, 0,                          isCPUArtWorkPageCGIVal,                FrameNameWork

#define AIENGINE_FRAME_DOWNLOAD_INDEX                                                                                                         \
   FrameSetDownloadIndex,  frame_top_row,                                                                                               \
         frame_scroll_no, FrameSetTopDownload,                  isTopBannerPageCGIVal,                  FrameNameTop,    \
         frame_scroll_no, FrameSetDownloadMain,         isMainPageCGIVal,                       FrameNameMain

#define AIENGINE_FRAME_DOWNLOAD_MAIN                                                                                                              \
   FrameSetDownloadMain,           frame_imp_row,                                                                                           \
         frame_scroll_auto, FrameSetDownloadWork,       isWorkPageCGIVal,                       FrameNameCenter,     \
         frame_scroll_no, 0,                            isBottomInfoPageCGIVal,            FrameNameImp

#define AIENGINE_FRAME_DOWNLOAD_WORK                                                                                                               \
   FrameSetDownloadWork,           frame_men_nscroll_col_s,                                                                                          \
         frame_scroll_no, 0,                          isDownloadMenPageCGIVal,                FrameNameMenue ,      \
         frame_scroll_auto, 0,                          isDownloadWorkPageCGIVal,               FrameNameWork

#define AIENGINE_FRAME_LINKS_INDEX                                                                             \
   FrameSetLinkIndex,   frame_top_row,                                                                  \
         frame_scroll_no, FrameSetTopLink,                  isTopBannerPageCGIVal,                  FrameNameTop,   \
         frame_scroll_no, FrameSetLinkMain,            isMainPageCGIVal,                       FrameNameMain

#define AIENGINE_FRAME_LINKS_MAIN                                                                                \
   FrameSetLinkMain,    frame_imp_row,                                                                    \
         frame_scroll_auto, FrameSetLinkWork,          isWorkPageCGIVal,                       FrameNameCenter,  \
         frame_scroll_no, 0,                            isBottomInfoPageCGIVal,        FrameNameImp

#define AIENGINE_FRAME_LINKS_WORK                                                                                         \
   FrameSetLinkWork,    frame_men_nscroll_col_s,                                                                           \
         frame_scroll_no, 0,                          isLinkMenPageCGIVal,            FrameNameMenue,            \
         frame_scroll_auto, 0,                          isLinkWorkPageCGIVal,           FrameNameWork


/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/

/* -------------   @Secur Internet Engine & HTML Generator  ---------------- */
#endif
/* -------------------------------- EOF ------------------------------------ */
