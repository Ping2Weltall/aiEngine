/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Server Watchdog                                      */
/* Modul       : watchdog.c                                                  */
/* Server      : aIEngineWatchDog                                            */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 16.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Server fuer @Secur(tm) Internet Engine & HTML Generator                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 14.02.2005  : ALH           : Anpassungen an Cygwin                       */
/*             :               : User und Gruppen ID nicht pruefen           */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_watchdog_version      = "1.7.2";                           //
const char *modul_watchdog              = "WatchDog";                        //
const char *modul_watchdog_date         = __DATE__;                          //
const char *modul_watchdog_time         = __TIME__;                          //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                   1

#define TYP_INT			0
#define TYP_STRING		1

#ifndef __CYGWIN__
#if AIENGINE_ROOT_ONLY
#define MY_NEEDED_GID		0
#define MY_NEEDED_UID		0
#else
#define MY_NEEDED_GID		AIENGINE_GROUP_ID
#define MY_NEEDED_UID		AIENGINE_USER_ID
#endif
#endif

#define SERVER_START_OK		0
#define SERVER_START_WARNUNG	1
#define SERVER_START_FEHLER	2

/*---------------------------------------------------------------------------*/
/* System Header Dateien                                                     */
/*...........................................................................*/
#include <unistd.h>                                                          //
#include <errno.h>                                                           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern const char *aIEngine_Start_Prog;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct sys_proc_info 
{
   unsigned int Pid;
   unsigned int PPid;
   char *State;
   int VmSize;
   int VmLck;
   int VmRSS;
   int VmData;
   int VmStk;
   int VmExe;
   int VmLib;
   struct sys_proc_info *next;
};

struct system_progs 
{
   const char *name;
   bool online;
   struct sys_proc_info *proc_info;
   const char *start_up;
};

struct watchdog_progs 
{
   const char *name;
   unsigned int Pid;
   unsigned int PPid;
   char *State;
   int VmSize;
   int VmLck;
   int VmRSS;
   int VmData;
   int VmStk;
   int VmExe;
   int VmLib;
   bool online;
};

struct proc_info_move 
{
   const char *feld;
   void *ziel;
   int typ;
   unsigned int len;
}; 
     
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static void show_procinfo(void);
static void show_systemprocinfo(void);
static bool system_server_startup(void);
static void start_system_prog(const char *prog, const char *start_up);
static bool server_startup(void);
static void show_loadinfo(void);
static void show_upinfo(void);
static void show_meminfo(void);
static void show_dfinfo(void);
static void show_swap_info(void);
static int  read_procinfo(void);                                             //
static void check_prog(const char *pid);                                     //
static bool get_proc_info(char *proc, struct aie_file_text *txt_ptr);
static void get_system_proc_info(char *proc, struct aie_file_text *txt_ptr);
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
struct system_progs system_progs[] =
{
    { "httpd", false, NULL, "/aIEngine/apache2/bin/apachectl start" },
    // Hier koennen sweitere Systemdemonen eingefuegt werden z.b.
#if 0
    { "crond", false, NULL, NULL },
    { "syslogd", false, NULL, NULL },
    { "atd", false, NULL, NULL },
    { "bash", false, NULL, NULL },
    { "sh", false, NULL, NULL },
    { "su", false, NULL, NULL }
#endif
};
const unsigned int size_system_progs = sizeof(system_progs) /
                                         sizeof(struct system_progs);

struct watchdog_progs watchdog_progs[] =
{
    { "aIEngineLogD",      0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, false },
    { "aIEnginePrioD",     0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, false },
    { "aIEngineMenuD",     0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, false },
    { "aIEngineKeyD",      0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, false },
    { "aIEnginePlzD",      0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, false },
    { "aIEngineSitemapD",  0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, false }
    // Hier koennen weitere Anwendungsspezifische Server eingefuegt 
    // werden.
};
const unsigned int size_watchdog_progs = sizeof(watchdog_progs) /
                                         sizeof(struct watchdog_progs);

#ifndef AIENGINE_BASE_SERVER_DIR
const char *server_path   = "/aIEngine/server/";
#warning Serverpath not defined!
#else
const char *server_path   = AIENGINE_BASE_SERVER_DIR"/";
#endif
#ifndef AIENGINE_BASE_TEMP_DIR
const char *tmp_file_path = "/aIEngine/temp/";
#warning Temp directory not defined!
#else
const char *tmp_file_path = AIENGINE_BASE_TEMP_DIR"/";
#endif
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : int  (== 0 = Erfolgreich)                                 */
/*...........................................................................*/
int main(void)
{
   int tasks = 0;
   aIEngine_Start_Prog = modul_watchdog;
    aie_star_line(79, '#');
    printf("# %s Version %s\n# Build : %s %s\n", modul_watchdog,
	                                         modul_watchdog_version, 
						 modul_watchdog_date, 
						 modul_watchdog_time);
    //printf("# Author: Alexander J. Herrmann\n");
    printf("# (C) 1995-2004, Alexander Joerg Herrmann\n");
    //printf("#");
    //aie_star_line(78, '-');
    //printf("# Running as Pid %d\n", getpid());
    printf("#");
    aie_star_line(78, '-');
    show_upinfo();
    show_loadinfo();
    printf("#");
    aie_star_line(78, '-');
    if ((tasks = read_procinfo()) > 0)
    {
       if (server_startup())
       {
          printf("#");
          aie_star_line(78, '-');
       }
       if (system_server_startup())
       {
          printf("#");
          aie_star_line(78, '-');
       }
    }
    show_procinfo();
    printf("#");
    aie_star_line(78, '-');
    show_systemprocinfo();
    printf("#");
    aie_star_line(78, '-');
    show_meminfo();
    printf("#");
    aie_star_line(78, '-');
    show_dfinfo();
    printf("#");
    aie_star_line(78, '-');
    show_swap_info();
    printf("#");
    aie_star_line(78, '-');
    printf("# Anzahl derzeit geladene Tasks: %d\n", tasks);
    printf("#");
    aie_star_line(78, '-');
    printf("# %s - Version: %s\n", AIENGINE_LANGNAME, AIENGINE_VERSION);
    aie_star_line(79, '#');
    return(0);
}
/*---------------------------------------------------------------------------*/
static void show_procinfo(void)
{
    printf("# Server                Pid VmSize  VmRSS VmData  VmStk  VmExe  VmLib  Status\n"); 
    for (register unsigned int z = 0;z < size_watchdog_progs; z++)
    {
       printf("# %-20s ", watchdog_progs[z].name);
       if (!watchdog_progs[z].online) 
       {
	  printf(" *** OFFLINE! ***\n");
       }
       else
       {
          printf("%5d", watchdog_progs[z].Pid);
//PPid;
          //printf("%5s ", watchdog_progs[z].State);
          printf(" %5d ", watchdog_progs[z].VmSize);
          //printf("%5d ", watchdog_progs[z].VmLck);
          printf(" %5d ", watchdog_progs[z].VmRSS);
          printf(" %5d ", watchdog_progs[z].VmData);
          printf(" %5d ", watchdog_progs[z].VmStk);
          printf(" %5d ", watchdog_progs[z].VmExe);
          printf(" %5d ", watchdog_progs[z].VmLib);
	  printf(" Online\n");
       }
    }
}

static void show_systemprocinfo(void)
{
    printf("# System Demonen\n# bash, sh und su sollten OFFLINE sein ansonsten ggf. Eindringling im Stystem!\n");
    for (register unsigned int z = 0;z < size_system_progs; z++)
    {
       struct sys_proc_info *sys_proc_info_ptr;
       printf("# %-20s ", system_progs[z].name);
       if ((!system_progs[z].online) || 
	     ((sys_proc_info_ptr = system_progs[z].proc_info) == NULL)) 
       {
	  printf(" *** OFFLINE! ***\n");
       }
       else
       {
	  int y = 1;
	  printf(" -- Online\n");
          printf("# No.   Pid PPid VmSize VmLck  VmRSS VmData  VmStk  VmExe  VmLib  Status\n"); 
	  while (sys_proc_info_ptr != NULL)
	  {
	     printf("# %3d ", y);
             printf("%5d", sys_proc_info_ptr->Pid);
             printf("%5d", sys_proc_info_ptr->PPid);
//PPid;
             printf(" %5d ", sys_proc_info_ptr->VmSize);
             printf(" %5d ", sys_proc_info_ptr->VmLck);
             printf(" %5d ", sys_proc_info_ptr->VmRSS);
             printf(" %5d ", sys_proc_info_ptr->VmData);
             printf(" %5d ", sys_proc_info_ptr->VmStk);
             printf(" %5d ", sys_proc_info_ptr->VmExe);
             printf(" %5d ", sys_proc_info_ptr->VmLib);
             printf(" %s\n",  sys_proc_info_ptr->State);
	     y++;
	     sys_proc_info_ptr = sys_proc_info_ptr->next;
	  }
       }
    }
}

void start_system_prog(const char *prog, const char *start_up)
{
   char file_path[128];
   char tmp_error_file[128];
   int start_rc;
   bool start_fail = false;
   int startcode = -1;
   int start_errno = -1;

   errno = 0;
   sprintf(tmp_error_file, "%s%s%d.tmp", tmp_file_path, 
                                       prog,
                                       getpid());
   sprintf(file_path, "%s > %s 2>&1", start_up, 
						 tmp_error_file);
   printf("# Server %s wird gestartet!\n", prog);
   if ((start_rc = system(file_path)) == 0)
   {
       startcode = SERVER_START_OK;
   }
   else
   {
      startcode = SERVER_START_FEHLER;
      start_errno = errno;
      start_fail = true;
   }
   if (aie_file_exist(tmp_error_file))
   {
      struct aie_file_text *txt_base = NULL;
      struct aie_file_text *txt_ptr;
      if ((txt_ptr = aie_load_file_text(tmp_error_file, &txt_base)) != NULL)
      {
         while (txt_ptr != NULL)
         {
	    printf("# ->> %s\n", txt_ptr->txt);
	    if ((start_fail) || 
	       ((strstr(txt_ptr->txt, "Fehler")) != NULL) ||
	       ((strstr(txt_ptr->txt, "Warn")) != NULL) ||
	       ((strstr(txt_ptr->txt, "Error")) != NULL) ||
	       ((strstr(txt_ptr->txt, "warn")) != NULL) ||
	       ((strstr(txt_ptr->txt, "error")) != NULL))
	    {
	       if (startcode != SERVER_START_FEHLER)
	       {
	          startcode = SERVER_START_WARNUNG;
	       }
	    }
	    txt_ptr = txt_ptr->next;
	 }
	 aie_free_file_text(&txt_base);
      }
   }
   switch(startcode)
   {
       case SERVER_START_OK:
       {
          printf("#   --> Server wurde gestartet!  - ");
          printf("[Ok]\n");
       }
       break;
       case SERVER_START_WARNUNG:
       {
          printf("#   --> Server  - ");
          printf("[Warnung!] rc=%d errno=%d\n", start_rc, errno);
       }
       break;
       case SERVER_START_FEHLER:
       {
          printf("#   --> Server wurde NICHT gestartet!  - ");
          printf("[Fehler!] rc=%d errno=%d\n", start_rc, start_errno);
       }
       break;
       default:
       {
          printf("[Unbekannt!] rc=%d errno=%d\n", start_rc, errno);
       }
    }
    unlink(tmp_error_file);
}

static bool system_server_startup(void)
{
   bool did_start_server = false;

   for (register unsigned int z = 0;z < size_system_progs; z++)
   {
       if ((!system_progs[z].online) || 
	     (system_progs[z].proc_info == NULL)) 
       {
          if (system_progs[z].start_up != NULL)
	  {
             start_system_prog(system_progs[z].name, system_progs[z].start_up);
	     did_start_server = true;
	  }
       }
   }
   if (did_start_server)
   {
      read_procinfo();
   }
   return(did_start_server);
}

static bool server_startup(void)
{
   bool did_start_server = false;
   #ifndef __CYGWIN__ 
   gid_t my_gid = getgid();
   uid_t my_uid = getuid();
   #endif

   for (register unsigned int z = 0;z < size_watchdog_progs; z++)
   {
      if (watchdog_progs[z].online == false)
      {
	 char file_path[128];
	 char tmp_error_file[128];
	 int start_rc;
	 bool start_fail = false;
	 int startcode = -1;
	 int start_errno = -1;
	 errno = 0;

	 sprintf(tmp_error_file, "%s%s%d.tmp", tmp_file_path, 
	                                       watchdog_progs[z].name, 
	                                       getpid());
	 sprintf(file_path, "%s%s -s > %s 2>&1", server_path,
                                                 watchdog_progs[z].name,
						 tmp_error_file);
         printf("# %s Achtung!!! Server ist Offline!\n", 
                                        watchdog_progs[z].name); 
         #ifndef __CYGWIN__
	 if (((my_gid != MY_NEEDED_GID) || (my_uid != MY_NEEDED_UID)) &&
	    ((my_gid != 0) || (my_uid != 0)))
	 {
            #if AIENGINE_ROOT_ONLY
            printf("#  --> Nicht genuegend Rechte um %s zu starten!\n", 
                                        watchdog_progs[z].name); 
            #else
            printf("#  --> Falscher Benutzer um %s zu starten!\n", 
                                        watchdog_progs[z].name); 
            #endif
	 }
	 else
         #endif
	 {
	    if ((start_rc = system(file_path)) == 0)
	    {
	       startcode = SERVER_START_OK;
	    }
	    else
	    {
	       startcode = SERVER_START_FEHLER;
	       start_errno = errno;
	       start_fail = true;
	    }
            if (aie_file_exist(tmp_error_file))
            {
              struct aie_file_text *txt_base = NULL;
              struct aie_file_text *txt_ptr;
              if ((txt_ptr = aie_load_file_text(tmp_error_file, &txt_base)) != NULL)
              {
	         while (txt_ptr != NULL)
                 {
		    char *msg_ptr = txt_ptr->txt;
		    if ((start_fail) || 
		       ((msg_ptr = strstr(txt_ptr->txt, "Fehler")) != NULL))
		    {
	               printf("#    - %s\n", msg_ptr);
		       if (startcode != SERVER_START_FEHLER)
		       {
		          startcode = SERVER_START_WARNUNG;
		       }
		    }
		    txt_ptr = txt_ptr->next;
	         }
	         aie_free_file_text(&txt_base);
	       }
	    }
	    switch(startcode)
	    {
	       case SERVER_START_OK:
	       {
	          printf("#   --> Server wurde gestartet!  - ");
	          printf("[Ok]\n");
	       }
	       break;
	       case SERVER_START_WARNUNG:
	       {
	          printf("#   --> Server fehlerhaft gestartet!  - ");
	          printf("[Warnung!] rc=%d errno=%d\n", start_rc, errno);
	       }
	       break;
	       case SERVER_START_FEHLER:
	       {
	          printf("#   --> Server wurde NICHT gestartet!  - ");
	          printf("[Fehler!] rc=%d errno=%d\n", start_rc, start_errno);
	       }
	       break;
	       default:
	       {
	          printf("[Unbekannt!] rc=%d errno=%d\n", start_rc, errno);
	       }
	    }
	    unlink(tmp_error_file);
	    did_start_server = true;
         //const char *server_path = "/aIEngine/server/";
         }
      }
   }
   if (did_start_server)
   {
      read_procinfo();
   }
   return(did_start_server);
}

static void show_upinfo(void)
{
   const char *up_info = "/proc/uptime";
   if (aie_file_exist(up_info))
   {
      struct aie_file_text *txt_base = NULL;
      struct aie_file_text *txt_ptr;
      if ((txt_ptr = aie_load_file_text(up_info, &txt_base)) != NULL)
      {
	 if (txt_ptr != NULL)
         {
	    char *sptr;
	    long is_uptime;
	    if ((sptr = strchr(txt_ptr->txt, ' ')) != NULL)
	    {
	       *sptr = '\0';
	    }
            printf("# Systemstart vor : %s Sekunden", txt_ptr->txt);
	    if ((is_uptime = atol(txt_ptr->txt)) > 0)
	    {
	       char *sptr2;
               time_t t;

               time(&t);
	       t -= is_uptime;
	       sptr = asctime(localtime(&t));
	       if ((sptr2 = strchr(sptr, '\n')) != NULL)
	       {
		  *sptr2 = '\0';
	       }
	       printf(" - am %s -", sptr);
	    }
	    printf("\n");
	    txt_ptr = txt_ptr->next;
	 }
	 aie_free_file_text(&txt_base);
      }
      else
      {
         printf("# Fehler uptime Info  lesen!! [%s]\n", up_info);
      }
   }
   else
   {
      printf("# Keine Informationsdatei [%s]!\n", up_info);
   }
}

static void show_loadinfo(void)
{
   const char *load_info = "/proc/loadavg";
   if (aie_file_exist(load_info))
   {
      struct aie_file_text *txt_base = NULL;
      struct aie_file_text *txt_ptr;
      if ((txt_ptr = aie_load_file_text(load_info, &txt_base)) != NULL)
      {
	 while(txt_ptr != NULL)
         {
            printf("# Systemauslastung: %s\n", txt_ptr->txt);
	    txt_ptr = txt_ptr->next;
	 }
	 aie_free_file_text(&txt_base);
      }
      else
      {
         printf("# Fehler loadavg Info  lesen!! [%s]\n", load_info);
      }
   }
   else
   {
      printf("# Keine Informationsdatei [%s]!\n", load_info);
   }
}

static void show_meminfo(void)
{
   const char *mem_info = "/proc/meminfo";
   int z = 0;
   printf("# Hauptspeicher Information\n");
   if (aie_file_exist(mem_info))
   {
      struct aie_file_text *txt_base = NULL;
      struct aie_file_text *txt_ptr;
      if ((txt_ptr = aie_load_file_text(mem_info, &txt_base)) != NULL)
      {
	 while(txt_ptr != NULL)
         {
            printf("# %s\n", txt_ptr->txt);
	    if (z++ > 1)
	    {
	       break;
	    }
	    txt_ptr = txt_ptr->next;
	 }
	 aie_free_file_text(&txt_base);
      }
      else
      {
         printf("# Fehler Memory Info  lesen!! [%s]\n", mem_info);
      }
   }
   else
   {
      printf("# Keine Informationsdatei [%s]!\n", mem_info);
   }
}

static void show_dfinfo(void)
{
   const char *df_command = "(df -mH /aIEngine && df -miH /aIEngine) "
                           "| grep -v \"/dev/\""; 
   char tmp_df_file[128];
   char file_path[128];
   int start_rc;
   char *line_ptr[4] = { NULL, NULL, NULL, NULL };

   sprintf(tmp_df_file, "%s%s%d.tmp", tmp_file_path, "aie_df", 
	                                       getpid());
   sprintf(file_path, "%s > %s 2>&1", df_command, tmp_df_file);
   printf("# Festplatten Speicherplatz Information\n");
   if ((start_rc = system(file_path)) == 0)
   {
      if (aie_file_exist(tmp_df_file))
      {
         struct aie_file_text *txt_base = NULL;
         struct aie_file_text *txt_ptr;
	 int z = 0;
         if ((txt_ptr = aie_load_file_text(tmp_df_file, &txt_base)) != NULL)
         {
	    while(txt_ptr != NULL)
            {
	       line_ptr[z] = txt_ptr->txt + 20;
	       if (z < 2)
	       {
	          if (strlen(line_ptr[z]) > 27)
		  {
		     *(line_ptr[z] + 27) = '\0';
		  }
	       }
	       z++;
	       if (z > 3)
	       {
		  break;
	       }
	       txt_ptr = txt_ptr->next;
	    }
	    aie_free_file_text(&txt_base);
            printf("# %s%s\n# %s%s\n", line_ptr[0], line_ptr[2], line_ptr[1], 
		                   line_ptr[3]);
         }
         else
         {
            printf("# Fehler Memory Info  lesen!! [%s]\n", tmp_df_file);
         }
	 unlink(tmp_df_file);
      }
      else
      {
         printf("# Keine Informationsdatei [%s]!\n", tmp_df_file);
      }
   }
   else
   {
      printf("# Befehl konnte nicht ausgefuehrt werden error[%d]!!\n", 
	                                                            start_rc);
   }
}

static void show_swap_info(void)
{
   const char *swap_info_file = "/proc/swaps";
   if (aie_file_exist(swap_info_file))
   {
      struct aie_file_text *txt_base = NULL;
      struct aie_file_text *txt_ptr;
      if ((txt_ptr = aie_load_file_text(swap_info_file, &txt_base)) != NULL)
      {
	  printf("# Swap Information\n");
	  while(txt_ptr != NULL)
          {
	     printf("# %s\n", txt_ptr->txt);
	     txt_ptr = txt_ptr->next;
	  }
          aie_free_file_text(&txt_base);
      }
      else
      {
         printf("# Swap Information konnte nicht gelesen werden!\n");
      }
   }
   else
   {
      printf("# Keine Swap Information verfuegbar!\n");
   }
}
/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : int  (== 0 = Erfolgreich)                                 */
/*...........................................................................*/
static int read_procinfo(void)
{
   struct aie_file_liste *file_liste_base = NULL;
   struct aie_file_liste *file_liste_ptr;
   int tasks = 0;

   if ((file_liste_ptr = 
	    file_liste_ptr = aie_read_file_liste("/proc/", &file_liste_base)) 
	                                                              != NULL)
   {
      while(file_liste_ptr != NULL)
      {
	 if (atoi(file_liste_ptr->file) > 0)
         {
	    tasks++;
	    check_prog(file_liste_ptr->file);
	 }
	 file_liste_ptr = file_liste_ptr->next;
      }
      aie_free_file_liste(&file_liste_base);
   }
   else
   {
      printf("# Kein /proc Dateisystem?!\n");
   }
   return(tasks);
}
/*---------------------------------------------------------------------------*/
static void check_prog(const char *pid)
{
   char file_path[128] = "/proc/";
   const char *test_name = "Name:";
   const unsigned int len_test_name = strlen(test_name);
   strcat(file_path, pid);
   strcat(file_path, "/status");
   if (aie_file_exist(file_path))
   {
      struct aie_file_text *txt_base = NULL;
      struct aie_file_text *txt_ptr;
      if ((txt_ptr = aie_load_file_text(file_path, &txt_base)) != NULL)
      {
	 while(txt_ptr != NULL)
         {
            if (strncmp(txt_ptr->txt, test_name, len_test_name) == 0)
            {
	       char *sptr = txt_ptr->txt + len_test_name + 1;
	       while ((*sptr == ' ') && (*sptr != '\0'))
	       {
	          sptr++;
	       }	
               //if (!get_proc_info(txt_ptr->txt + len_test_name + 1, 
               if (*sptr != '\0')
	       {
                  if (!get_proc_info(sptr, txt_ptr->next))
	          {
                    get_system_proc_info(txt_ptr->txt + len_test_name + 1, 
		     txt_ptr->next);
	          }
	       }
	       break;
            }
	    txt_ptr = txt_ptr->next;
	 }
	 aie_free_file_text(&txt_base);
      }
      else
      {
         printf("# %s - Fehler Status lesen!! [%s]\n", pid, file_path);
      }
   }
   else
   {
      printf("# %s - Keine Informationsdatei [%s]!\n", pid, file_path);
   }
}

static bool get_proc_info(char *proc, struct aie_file_text *txt_ptr)
{
   bool found = false;

   for (register unsigned int z = 0;z < size_watchdog_progs; z++)
   {
      unsigned int len = strlen(watchdog_progs[z].name);
      if (len > 15)
      {
	 len = 15;
      }
      //if (strncmp(proc, watchdog_progs[z].name, len) == 0)
      if ((!watchdog_progs[z].online) &&
         (strncmp(proc, watchdog_progs[z].name, len) == 0))
      {
         struct proc_info_move proc_info_move[] =
         {
            { "Pid",     &watchdog_progs[z].Pid,    TYP_INT,    3 },
            //{ "PPid",    &watchdog_progs->PPid,   TYP_INT,    4 },
            { "VmSize",  &watchdog_progs[z].VmSize, TYP_INT,    6 }, 
            //{ "VmLck",   &watchdog_progs->VmLck,  TYP_INT,    5 },
            { "VmRSS",   &watchdog_progs[z].VmRSS,  TYP_INT,    5 }, 
            { "VmData",  &watchdog_progs[z].VmData, TYP_INT,    6 }, 
            { "VmStk",   &watchdog_progs[z].VmStk,  TYP_INT,    5 }, 
            { "VmExe",   &watchdog_progs[z].VmExe,  TYP_INT,    5 }, 
            { "VmLib",   &watchdog_progs[z].VmLib,  TYP_INT,    5 },
            { "State",   &watchdog_progs[z].State,  TYP_STRING, 5 }
         };
	 const unsigned int size_proc_info_move = sizeof(proc_info_move) /
	                                          sizeof(struct proc_info_move);
	 while(txt_ptr != NULL)
	 {
            for (register unsigned int y = 0;y < size_proc_info_move; y++)
	    {
	       if (strncmp(proc_info_move[y].feld, txt_ptr->txt, 
	                   proc_info_move[y].len) == 0)
	       {
		  if (__builtin_expect(proc_info_move[y].typ == TYP_INT, true))
		  {
		     *(int *)proc_info_move[y].ziel = atoi(txt_ptr->txt +
			                            proc_info_move[y].len + 2);
		  }
		  else
		  {
		     *(&proc_info_move[y].ziel) = strdup(txt_ptr->txt +
  			                            proc_info_move[y].len + 2);
		     //printf("%s Here[%s][%s]!\n", proc, 
		     //*(&proc_info_move[y].ziel), (char *)(txt_ptr->txt +
  			//                  proc_info_move[y].len + 2));
		  }
	       }
	    } 
	    txt_ptr = txt_ptr->next;
	 }
	 watchdog_progs[z].online = true;
	 found = true;
	 break;
      }
   }
   return(found);
}

static void get_system_proc_info(char *proc, struct aie_file_text *txt_ptr)
{
   //static bool first = true;

   for (register unsigned int z = 0;z < size_system_progs; z++)
   {
      unsigned int len = strlen(system_progs[z].name);
      if (len > 15)
      {
	 len = 15;
      }
      //if (strncmp(proc, watchdog_progs[z].name, len) == 0)
      if (strncmp(proc, system_progs[z].name, len) == 0)
      {
	 struct sys_proc_info *sys_proc_info = 
	                       (struct sys_proc_info *)
			       aie_malloc(sizeof(struct sys_proc_info));
	 if (sys_proc_info != NULL)
	 {
            struct proc_info_move proc_info_move[] =
            {
               { "Pid",     &sys_proc_info->Pid,    TYP_INT,    3 },
               { "PPid",    &sys_proc_info->PPid,   TYP_INT,    4 },
               { "VmSize",  &sys_proc_info->VmSize, TYP_INT,    6 }, 
               { "VmLck",   &sys_proc_info->VmLck,  TYP_INT,    5 },
               { "VmRSS",   &sys_proc_info->VmRSS,  TYP_INT,    5 }, 
               { "VmData",  &sys_proc_info->VmData, TYP_INT,    6 }, 
               { "VmStk",   &sys_proc_info->VmStk,  TYP_INT,    5 }, 
               { "VmExe",   &sys_proc_info->VmExe,  TYP_INT,    5 }, 
               { "VmLib",   &sys_proc_info->VmLib,  TYP_INT,    5 },
               { "State",   &sys_proc_info->State,  TYP_STRING, 5 }
            };
	    const unsigned int size_proc_info_move = sizeof(proc_info_move) /
	                                          sizeof(struct proc_info_move);

	    sys_proc_info->next = system_progs[z].proc_info;
	    system_progs[z].proc_info = sys_proc_info;
	    
	    while(txt_ptr != NULL)
	    {
               for (register unsigned int y = 0;y < size_proc_info_move; y++)
	       {
	          if (strncmp(proc_info_move[y].feld, txt_ptr->txt, 
	                   proc_info_move[y].len) == 0)
	          {
		     if (__builtin_expect(proc_info_move[y].typ == TYP_INT, 
			                                                true))
		     {
		        *(int *)proc_info_move[y].ziel = atoi(txt_ptr->txt +
			                            proc_info_move[y].len + 2);
		     }
		     else
		     {
		        //proc_info_move[y].ziel = strdup(txt_ptr->txt +
		        sys_proc_info->State = strdup(txt_ptr->txt +
  			                            proc_info_move[y].len + 2);
		     //printf("%s Here[%s][%s]!\n", proc, 
		     //*(&proc_info_move[y].ziel), (char *)(txt_ptr->txt +
  			//                  proc_info_move[y].len + 2));
		     }
	          }
	       } 
	       txt_ptr = txt_ptr->next;
	    }
	    system_progs[z].online = true;
	 }
	 break;
      }
   }
}
/* --------------              aIEngine Binutil                ------------- */
const int   modul_watchdog_size               = __LINE__;                    //
/* -------------------------------- EOF ------------------------------------ */

