/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : aie_genserial.c                                             */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 31.12.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Erstellt eine Datenbank mit Inseraten fuer den Bereich Intern             */
/* Verwendet das @Secur Engine & HTML Generator                              */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aie_genserial_version     = "1.0.0";                       //
const char *modul_aie_genserial             = "aieGenSerial";                //
const char *modul_aie_genserial_date        = __DATE__;                      //
const char *modul_aie_genserial_time        = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB                   1
#define AIENGINE_USE_SQL_WRAP_LIB               1
#define AIENGINE_USE_DB_LIB    		        1

                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <sys/time.h>                                                        //
#include <sys/resource.h>                                                    //
#include <sys/timeb.h>                                                       //
#include <sys/types.h>
#include <zlib.h>

/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#include AIENGINE_CRYPTO_INCLUDE
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sql_meta_db;                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static long do_gen_serial(struct aie_sql_data *aie_sql_data);                //
static bool insert_registration_serial(char *serial, char *is_crc,           //
                                       struct aie_sql_data *aie_sql_data);   //
static struct aie_sql_data *InitBackgroundDB(void);                          //
static bool ExitBackgroundDB(void);                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     :                                                           */
/* Rueckgabewert : int ( Immer 0 = OK)                                       */
/*...........................................................................*/
int main(void)
{
   const char *tmp_dir1 = AIE_DB_PATH;
   const char *tmp_dir_txt = 
  "# Pruefen ob Verzeichniss existiert ggf. erstellen\n#   --> %s\n";
   struct timeb t1;
   struct timeb t2;
   int millitm;
   long timetm;
   long anzahl = 0L;
   struct aie_sql_data *aie_sql_data;
      
   ftime(&t1);

   aie_star_line(79, '#');
   printf("# %-7s Version %s\n# Build : %s %s\n", modul_aie_genserial, 
	                                          modul_aie_genserial_version, 
						  modul_aie_genserial_date, 
						  modul_aie_genserial_time);
   printf("# (C) 2004-2006 @Secur Internet Engine & HTML Generator\n");
   printf("# Author: Alexander J. Herrmann\n");
   printf("#");
   aie_star_line(78, '-');
   printf(tmp_dir_txt, tmp_dir1);
   aie_check_create_dir(tmp_dir1, true);
   printf("#");
   aie_star_line(78, '-');
   if ((aie_sql_data = InitBackgroundDB()) != NULL)
   {
      anzahl = do_gen_serial(aie_sql_data);
      ExitBackgroundDB();
   }
   else
   {
      printf("# Fehler beim initialisieren der Pool Datenbank!\n");
   }
   printf("#");
   aie_star_line(78, '-');
   ftime(&t2);
   if ((millitm = t2.millitm - t1.millitm) < 0)
   {
        millitm += 1000;
        t2.time--;
   }
   timetm = t2.time - t1.time;
   printf(
       "# %5ld Seriennummern in %ld.%.3d Sekunden erstellt\n",
       	                                              anzahl, timetm, millitm);
   printf("#");
   aie_star_line(78, '-');
   printf("# %s - Version: %s\n", AIENGINE_LANGNAME, AIENGINE_VERSION);
   aie_star_line(79, '#');
   return(0);
}

static long do_gen_serial(struct aie_sql_data *aie_sql_data)
{
   char *sptr;
   int anzahl = 0;
   char serial[50];
   char dayval[] = "ABCDEFGHIJKLMN!PQRSTU123456789@";
   char monval[] = "#PQRSTUVWXYZ";

   time_t t = time(NULL);
   struct tm *tblock = localtime(&t);

   srand((unsigned)((tblock->tm_mday * tblock->tm_mon) + tblock->tm_sec));
       
   
   while (anzahl <= 10)
   {
      memset(serial, '\0', sizeof(serial));
      sptr = serial;
      *sptr = 'A';
      sptr++;
      *sptr = dayval[tblock->tm_mday - 1];
      sptr++;
      *sptr = monval[tblock->tm_mon];
      sptr++;
      *sptr = 'F';
      sptr++;
      *sptr = '-';
      sptr++;
      for(unsigned int z = 0; z < 4;z++)
      {
          if ((*sptr = (rand() % 26) + 'A') == 'O')
	  {
             *sptr = '@';
	  }
	  sptr++;
      }
      *sptr = '-';
      sptr++;
      for(unsigned int z = 0; z < 4;z++)
      {
          if ((rand() % 2))
	  {
             if ((*sptr = (rand() % 10) + '0') == '0')
	     {
		*sptr = '!';
	     }
	  }
	  else
	  {
             if ((*sptr = (rand() % 26) + 'A') == 'O')
	     {
                *sptr = '<';
	     }
	  }
	  sptr++;
      }
      *sptr = '-';
      sptr++;
      for(unsigned int z = 0; z < 4;z++)
      {
          if ((rand() % 2))
	  {
             if ((*sptr = (rand() % 10) + '0') == '0')
	     {
		*sptr = '*';
	     }
	  }
	  else
	  {
             if ((*sptr = (rand() % 26) + 'A') == 'O')
	     {
                *sptr = '>';
	     }
	  }
	  sptr++;
      }
      //*sptr = '-';
      //sptr++;
      //for (int u = 0;u < 10;u++)
      {
	 char is_crc[9];
         sprintf(is_crc, "%.8lX", 
	                       aie_crc32(0x666, (char *)serial, strlen(serial)));
         aie_sql_meta_start_transaction(&aiengine_sql_meta_db);
	 if (insert_registration_serial(serial, is_crc, aie_sql_data))
	 {
             aie_sql_meta_commit(&aiengine_sql_meta_db);
             printf(" %s   - %s\n", serial, is_crc);
	     anzahl++;
	  }
	  else
	  {
             aie_sql_meta_rollback(&aiengine_sql_meta_db);
          }
      }
   }
   return(anzahl);
}

static bool insert_registration_serial(char *serial, char *is_crc, 
                                       struct aie_sql_data *aie_sql_data)
{
   char *timestamp = aie_get_time_stamp();
   bool rc = false;
   struct aie_sql_meta_insert sql_meta_insert =
   {
      AIE_DB_TABLE_ID_SERIAL_POOL,
      true,
      NULL, 0,
      false, 
      &aiengine_sql_meta_db
   };
   struct aie_sql_meta_feld_value_list sql_meta_feld_value_list[] =
   {
      { is_aie_SeriennummerSqlFld, serial },
      { is_aie_ModulNameSqlFld, "" },
      { is_aie_FreigabeSqlFld, is_crc },
      { is_aie_InstallDateSqlFld, "" },
      { is_aie_SerialGenerateDateSqlFld, timestamp },
      { is_aie_SerialMaxInstallCountSqlFld, "1" },
      { is_aie_SerialCurrentInstallCountSqlFld, "0" },
      { is_aie_ValidUntilDateSqlFld, "01012006" }
   };
   sql_meta_insert.sql_meta_feld_value_list = sql_meta_feld_value_list;
   sql_meta_insert.size_sql_meta_feld_value_list =
                                           sizeof(sql_meta_feld_value_list) /
                                 sizeof(struct aie_sql_meta_feld_value_list);
   if (aie_sql_meta_table_insert(&sql_meta_insert))
   {
      printf("# OK -> ");
      rc = true;
   }
   else
   {
      char db_error[256];
      sprintf(db_error, "Fehler: Datenbank Fehler \"%s\": %s\n",
      AIE_DB_AIENGINE,
      sqlite3_errmsg(aie_sql_data->sql_db_data->db));
      if (strstr(db_error, "not an error") == NULL)
      {
         printf("# %s", db_error);
      }
      else
      {
	 printf("# Doppelt!? %s\n", serial);
      }
   }
   return(rc);
}


static struct aie_sql_data *InitBackgroundDB(void)
{
   return(aie_sql_meta_attach_db(AIE_DB_ID_AIENGINE, &aiengine_sql_meta_db));
}

static bool ExitBackgroundDB(void)
{
   return(aie_sql_meta_release_db(&aiengine_sql_meta_db));
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_aie_genserial_size   = __LINE__;                           //
/* -------------------------------- EOF ------------------------------------ */
