/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : aie_dbckeck.c                                               */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 30.12.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Erstellt eine Datenbank mit Inseraten fuer den Bereich Intern             */
/* Verwendet das @Secur Engine & HTML Generator                              */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aie_dbcheck_version     = "1.0.0";                         //
const char *modul_aie_dbcheck             = "aieDBCheck";                    //
const char *modul_aie_dbcheck_date        = __DATE__;                        //
const char *modul_aie_dbcheck_time        = __TIME__;                        //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_DB_LIB			1
#define AIENGINE_USE_SQL_WRAP_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include Dateien                                                    */
/*...........................................................................*/
#include <sys/time.h>                                                        //
#include <sys/resource.h>                                                    //
#include <sys/timeb.h>                                                       //
#include <sys/types.h>
#include <sys/stat.h>

/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen den Server                                      */
/*...........................................................................*/
//extern struct aie_sql_meta_db aiengine_sql_meta_db;                          //
extern struct aie_sql_meta_db aiengine_sitemap_sql_meta_db;                  //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer den Server                                  */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static long do_DB_run(struct aie_sql_meta_db *aie_sql_meta_db);
static long do_tables_run(struct aie_sql_meta_db *aie_sql_meta_db,
                          struct aie_sql_data *aie_sql_data, 
                          struct aie_sql_tables *tables, 
                          unsigned int size_tables, 
			  struct aie_sql_index *tbl_index, 
			  unsigned int size_index,
			  unsigned long *ges_index);
static long do_index_run(struct aie_sql_meta_db *aie_sql_meta_db,
                         struct aie_sql_data *aie_sql_data, const char *table,  
                         int tableid, struct aie_sql_index *tbl_index, 
                         unsigned int size_index);
static struct aie_sql_data *InitDB(int dbid, struct aie_sql_meta_db
                                                    *aie_sql_meta_db);
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
//static long AnzahlFiles = 0L;                                                //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : main                                                      */
/* Parameter     :                                                           */
/* Rueckgabewert : int ( Immer 0 = OK)                                       */
/*...........................................................................*/
int main(void)
{
   const char *tmp_dir1 = AIE_DB_PATH;
   const char *tmp_dir_txt = 
  "# Pruefen ob Verzeichniss existiert ggf. erstellen\n#   --> %s\n";
   struct timeb t1;
   struct timeb t2;
   int millitm;
   long timetm;
   long anzahl = 0L;
      
   ftime(&t1);

   aie_star_line(79, '#');
   printf("# %-7s Version %s\n# Build : %s %s\n", modul_aie_dbcheck, 
	                                          modul_aie_dbcheck_version, 
						  modul_aie_dbcheck_date, 
						  modul_aie_dbcheck_time);
   printf("# (C) 2004-2006 @Secur Internet Engine & HTML Generator\n");
   printf("# Author: Alexander J. Herrmann\n");
   printf("#");
   aie_star_line(78, '-');
   printf(tmp_dir_txt, tmp_dir1);
   aie_check_create_dir(tmp_dir1, true);
   printf("#");
   aie_star_line(78, '-');
   anzahl = do_DB_run(&aiengine_sitemap_sql_meta_db);
   //anzahl = do_DB_run(&aiengine_sql_meta_db);
   printf("#");
   aie_star_line(78, '-');
   ftime(&t2);
   if ((millitm = t2.millitm - t1.millitm) < 0)
   {
        millitm += 1000;
        t2.time--;
   }
   timetm = t2.time - t1.time;
   printf(
       "# %5ld SQL Datenbanken verarbeitet in %ld.%.3d Sekunden verarbeitet\n",
       	                                              anzahl, timetm, millitm);
   printf("#");
   aie_star_line(78, '-');
   printf("# %s - Version: %s\n", AIENGINE_LANGNAME, AIENGINE_VERSION);
   aie_star_line(79, '#');
   return(0);
}

static long do_tables_run(struct aie_sql_meta_db *aie_sql_meta_db,
                          struct aie_sql_data *aie_sql_data, 
                          struct aie_sql_tables *tables, 
                          unsigned int size_tables, 
			  struct aie_sql_index *tbl_index, 
			  unsigned int size_index,
			  unsigned long *ges_index)
{
   int anzahl = 0;
   for (unsigned int y = 0; y < size_tables; y++)
   {
      struct aie_sql_table_def *aie_sql_table_def = tables->table_def;
      const char *table = 
	    aie_sql_meta_get_table_name_from_id(tables->tableid, aie_sql_meta_db);
	                                           //   &aiengine_sql_meta_db);
      printf("#   --> Tabelle %s\n", table);
      if (aie_sql_table_def != NULL)
      {
	 char *dump_name;
	 dump_name = aie_sql_util_dump_table(tables->tableid, aie_sql_meta_db);
	                                     //&aiengine_sql_meta_db);
	 if (dump_name != NULL)
	 {
            printf("#             -[%s] Dump OK\n", table);
	    aie_sql_meta_drop_table(tables->tableid, aie_sql_meta_db);
		                    //&aiengine_sql_meta_db);
            if (!aie_sql_meta_create_table(tables->tableid, aie_sql_meta_db))
		                           //&aiengine_sql_meta_db))
            {
                printf("# Datenbank Fehler\n#  --> \"%s\": %s\n",
                                           table,
	                   sqlite3_errmsg(aie_sql_data->sql_db_data->db));
            }
	    if (!aie_sql_util_reload_table(tables->tableid, dump_name, 
                                               aie_sql_meta_db))
		                           //&aiengine_sql_meta_db))
	    {
              printf("# Datenbank Fehler\n#  --> Reload Table[%s]\n", table);
	      aie_delete_file(dump_name);
	    }
	    else
	    {
              printf("#             -[%s] Reload OK\n", table);
	    }
            if (tbl_index != NULL)
            {
               *ges_index = do_index_run(aie_sql_meta_db, aie_sql_data, table, 
		                                    tables->tableid, 
						    tbl_index, size_index);
            }
	 }
	 else
	 {
            printf("# Datenbank Fehler\n#  --> Dump Table[%s]\n", table);
            printf("#  --> Create Table[%s]\n", table);
            if (!aie_sql_meta_create_table(tables->tableid, aie_sql_meta_db))
		                           //&aiengine_sql_meta_db))
            {
                printf("# Datenbank Fehler\n#  --> \"%s\": %s\n",
                                           table,
	                   sqlite3_errmsg(aie_sql_data->sql_db_data->db));
            }
	    else
	    {
               if (tbl_index != NULL)
               {
                  *ges_index = do_index_run(aie_sql_meta_db, 
                                            aie_sql_data, table, 
		                                    tables->tableid, 
						    tbl_index, size_index);
               }
	    }
	 }
         if (*ges_index == 0)
         {
            printf("#    --> Keine Indizies definiert!\n");
         }
      }
      else
      {
         printf("#    --> Leere Tabellendefinition\n");
      }
      tables++;
      anzahl++;
   }
   return(anzahl);
}

static long do_index_run(struct aie_sql_meta_db *aie_sql_meta_db,
                         struct aie_sql_data *aie_sql_data, const char *table,  
                         int tableid, struct aie_sql_index *tbl_index, 
                         unsigned int size_index)
{
   int anzahl = 0;
   aie_sql_data = aie_sql_data;
   for (unsigned int y = 0; y < size_index; y++)
   {
      if (tableid == tbl_index->tableid)
      {
         const char *index_name = 
	       aie_sql_meta_get_index_name_from_id(tbl_index->indexid, 
                                                   aie_sql_meta_db);
		                                   //&aiengine_sql_meta_db);
         printf("#     --> Index %s\n", index_name);
         if (aie_sql_meta_create_index(tbl_index->indexid, aie_sql_meta_db))
		                       //&aiengine_sql_meta_db))
	 {
            anzahl++;
	 }
	 else
	 {
                printf("# Datenbank Fehler\n#  --> \"%s\": %s\n",
                                           table,
	                   sqlite3_errmsg(aie_sql_data->sql_db_data->db));
	 }
      }
      tbl_index++;
   }
   return(anzahl);
}

static long do_DB_run(struct aie_sql_meta_db *aie_sql_meta_db)
{   
   long anzahl = 0;
   unsigned long ges_tables = 0;
   unsigned long ges_index = 0;
   struct aie_sql_db *aie_sql_db = aie_sql_meta_db->sql_db;
   unsigned int size_sql_db = aie_sql_meta_db->size_sql_db;
   for (unsigned int z = 0; z < size_sql_db; z++)
   {
      struct aie_sql_tables *tables;
      struct aie_sql_index *tbl_index;
      struct aie_sql_data *aie_sql_data;
      aie_sql_data = InitDB(aie_sql_db->dbid, aie_sql_meta_db);
      if (aie_sql_data != NULL)
      {
         if ((tables = aie_sql_db->tables) != NULL)
         {
            unsigned long anzahl_index = 0;
            unsigned int size_tables = aie_sql_db->size_tables;
            unsigned int size_index = aie_sql_db->size_index;
            tbl_index = aie_sql_db->index;
            ges_tables += do_tables_run(aie_sql_meta_db, aie_sql_data, 
		                           tables, size_tables, 
		                           tbl_index, size_index, 
					   &anzahl_index);
           ges_index += anzahl_index;
         }
         else
         {
             printf("#    --> Keine Tabellen definiert!\n");
         }
         aie_sql_meta_release_db(aie_sql_meta_db);
      }
      else
      {
         const char *database = 
	       aie_sql_meta_get_db_name_from_id(aie_sql_db->dbid, 
                                                aie_sql_meta_db);
		                                //&aiengine_sql_meta_db); 
          printf("# Fehler beim oeffnen der Datenbank id[%d:%s]\n", 
		                                      aie_sql_db->dbid,
		                                      database);
       }
      aie_sql_db++;
      anzahl++;
   }
   printf("#");
   aie_star_line(78, '-');
   printf("# %5ld Tabellen\n", ges_tables);
   printf("# %5ld Indizies\n", ges_index);
   return(anzahl);
}

/*---------------------------------------------------------------------------*/
static struct aie_sql_data *InitDB(int dbid, struct aie_sql_meta_db
                                                    *aie_sql_meta_db)
{
   struct aie_sql_data *aie_sql_data = NULL;
   const char *database = aie_sql_meta_get_db_name_from_id(dbid,
                                                           aie_sql_meta_db);
   if (database != NULL)
   {
      char *db_name;
      printf("# Datenbank [%s]\n", database);

      if ((db_name = (char *)aie_malloc(AIENGINE_MAX_PATH_LENGTH)) != NULL)
      {
         sprintf(db_name, "%s/%s", AIE_DB_PATH, database);
         chown(AIE_DB_PATH, AIE_USERID, AIE_GROUPID);
         chmod(AIE_DB_PATH, 0777);
         aie_sql_data = aie_sql_meta_attach_db(dbid, aie_sql_meta_db);
         if (__builtin_expect((aie_sql_data == NULL),false))
         {
           printf("# Datenbank Fehler beim Oeffnen\n#  --> \"%s\"\n",
                 db_name);
         }
         else
         {
            chown(db_name, AIE_USERID, AIE_GROUPID);
            chmod(db_name, 0666);
            aie_sql_data->callback = NULL;
	    aie_sql_data->data = NULL;
	    aie_sql_data->sql_rc = 0;
         }
      }
      else
      {
         printf("# malloc %s(%d) - Out of Memory?\n", __FILE__, __LINE__);
      }
   }
   else
   {
      printf("# %s(%d) - Datenbank Id[%d] nicht gefunden!\n", __FILE__, 
	                                                      __LINE__,
							      dbid);
   }
   return(aie_sql_data);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_aie_dbcheck_size   = __LINE__;                             //
/* -------------------------------- EOF ------------------------------------ */

