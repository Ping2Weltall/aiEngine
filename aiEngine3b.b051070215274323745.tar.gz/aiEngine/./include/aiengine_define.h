/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aiengine_define.h                                           */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003 - Globales remake @Secur nach Datenverlust in Canada   */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_DEFINE_H 

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_DEFINE_H

#define AIENGINE_ALL_OK                 	0
#define AIENGINE_UNKNON_RUN_MODE        	0xF0
#define AIENGINE_INIT_FAILED            	0xF1
#define AIENGINE_CGI_RUN_FAILED         	0xF2

#define AIENGINE_RUN_AS_CGI             	1
#define AIENGINE_RUN_AS_SERVER          	2


#define aie_SizeOfStruct(a, b)	(sizeof(struct b) > 0 ? \
                                           (sizeof(a) / sizeof(struct b)) : 0)
#define aie_IntSizeOfStruct(a, b, c)	int a = aie_SizeOfStruct(b, c)

#ifdef true
   #error "true bereits definiert!"
#endif
#ifdef false
   #error "false bereits definiert!"
#endif

#ifndef bool
    #ifndef __WIN32__
       //typedef unsigned short int       bool;
          #define bool                      int
    #else
       //typedef long                     bool;
       #ifndef __cplusplus
          #define bool                     long
       #endif
    #endif
#endif

#ifndef __cplusplus
   #ifndef true
      #define true		(bool)(+1)
   #endif
   #ifndef false
      #define false		(bool)(+0)
   #endif
#endif

#ifndef UINT64_TYPE
# if defined(__WIN32__) || defined(__BORLANDC__)
#   define UINT64_TYPE unsigned __int64
# else
#   define UINT64_TYPE unsigned long long int
# endif
#endif
typedef UINT64_TYPE u64;

#ifdef __CYGWIN__
#define id_t	pid_t
// Fuer Sockets
#define MSG_WAITALL		0x0
#endif
#define AIE_GET_PROG_NAME(VariableName) \
      static char VariableName[AIE_STD_PROG_LEN + 1]; \
      { \
         const char *aie_tmp_var = \
                aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CGI_MYSELF); \
         memset(VariableName, '\0', AIE_STD_PROG_LEN + 1); \
         if (aie_tmp_var != NULL) \
            strncpy(VariableName, aie_tmp_var, AIE_STD_PROG_LEN); \
        else \
            strncpy(VariableName, "*Unbekannt*", AIE_STD_PROG_LEN); \
      }

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __CYGWIN__
// Fuer fdopen und strdup
extern FILE *fdopen(int fd, char *modes);
extern char *strdup(char *s);
#endif
// Moved to aiengine_client.h ALH 29.10.2005
//extern __inline bool is_AIE_AGENT_AIENGINE(void);
//extern __inline bool is_AIE_AGENT_AIENGINE(void)
//{
//   const char *UserAgent = aie_get_aIEngine_env(AIENGINE_ENV_HTTP_USER_AGENT);
//   return(UserAgent != NULL ? (strncmp(UserAgent, "@Secur(tm)", 10) == 0) : 0); 
//}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

