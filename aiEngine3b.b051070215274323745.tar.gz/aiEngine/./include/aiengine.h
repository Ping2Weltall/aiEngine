/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Include     : aiengine.h                                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003 - Globales remake @Secur nach Datenverlust in Canada   */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Globales Include fur das @Secur Engine - bindet alle anderen Header ein   */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 30.12.2004  : ALH           : Datenbankdefinitionen fuer Core Engine      */
/*.............+...............+.............................................*/
/* 18.01.2005  : ALH           : Benutzerberechtigungen                      */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIENGINE_H                                                           //
                                                                             //
#ifdef _MUDFLAP
#include "/usr/local/include/mf-runtime.h"
#endif
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIENGINE_H                                                           //
#define AIENGINE_VERSION     			"3.0.0"
#define AIENGINE_LANGNAME    \
                          "(R) @Secur (tm) Internet Engine &amp; HTML Generator"

#define aIEngine_GlobalEngineName    "@Secur&trade; Internet Engine"
#define aIEngine_ServerVersion       AIENGINE_VERSION
#define aIEngine_Copyright_1         \
	"&copy; 1998-2005, @Secur - Alexander J. Herrmann\0"
#define aIEngine_Copyright_2         "&reg;  1998-2005 @Secur&trade; Patent\0"
#define aIEngine_Copyright_txt       "Alle generierten Seiten: "
#define aIEngine_Generator           \
			  "@Secur&trade; Internet Engine &amp; HTML Generator"

// Wir lassen das mal global bis 4.0 :)
extern int aie_loglevel;

/*---------------------------------------------------------------------------*/
/* Systemheaderdateien                                                       */
/*...........................................................................*/
#include <stdlib.h>                                                          //
#include <stdio.h>                                                           //
#include <string.h>                                                          //
#include <stdarg.h>
#ifndef __WIN32__
#include <syslog.h>                                                          //
#endif
#ifdef __CYGWIN__
#include <sys/socket.h>
#endif
/*---------------------------------------------------------------------------*/
/* Headerdateien des (R)@Secur(tm) Internet Engine & HTML Generators         */
/*...........................................................................*/
#include "aiengine_config.h"
#include "aiengine_status.h"
#include "aiengine_define.h"

//   #include "aie_version.h"
//   #include "aie_wingui_session.h"
//   #include "aie_wingui_util.h"
//   #include "aie_client_define.h"
#ifdef AIENGINE_USE_BASE_LIB
   #if AIENGINE_USE_BASE_LIB
      #include "aiengine_base.h"
   #endif
#endif
#ifdef AIENGINE_USE_SERVER_LIB
   #if AIENGINE_USE_SERVER_LIB
      #include "aiengine_server.h"
   #endif
#endif
#ifdef AIENGINE_USE_CLIENT_LIB
   #if AIENGINE_USE_CLIENT_LIB
      #include "aiengine_client.h"
   #endif
#endif
#ifdef AIENGINE_USE_CGI_LIB
   #if AIENGINE_USE_CGI_LIB
      #include "aiengine_cgi.h"
   #endif
#endif
#ifdef AIENGINE_USE_CGI_CLIENT_LIB
   #if AIENGINE_USE_CGI_CLIENT_LIB
      #include "aiengine_cgi_client.h"
   #endif
#endif
#ifdef AIENGINE_USE_DB_LIB
   #if AIENGINE_USE_DB_LIB
      #include "aiengine_db.h"
   #endif
#endif
#ifdef AIENGINE_USE_SQL_WRAP_LIB
   #if AIENGINE_USE_SQL_WRAP_LIB
      #include "aiengine_sql_wrap.h"
      #ifndef AIE_SMALLBUILD
         #include AIENGINE_SQL_INCLUDE
      #endif
   #endif
#endif
#ifdef AIENGINE_USE_WIN_CGI_LIB
   #if AIENGINE_USE_WIN_CGI_LIB
      #include "aiengine_win_cgi.h"
   #endif
#endif
#ifdef AIENGINE_USE_SOCKETS
   #if AIENGINE_USE_SOCKETS
      #include "aiengine_sockets.h"
   #endif
#endif
#if !AIENGINE_LOG_NO_LOG
   #ifdef AIENGINE_USE_LOG_LIB
      #if AIENGINE_USE_LOG_LIB
         #include "aiengine_log.h"
      #endif
   #endif
#endif

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
//struct cfg_vars
//{
//   const char *var;
//   char **val;
//};

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Deprecated types                                                          */
/*...........................................................................*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

