/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Include     : aiengine_config.h                                           */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 20.12.2006                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Taken out of aiengine.h to have all configuration in one central file     */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 - see COPYING.                     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIENGINE_CONFIG_H                                                    //
                                                                             //
#ifdef _MUDFLAP
#include "/usr/local/include/mf-runtime.h"
#endif
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIENGINE_CONFIG_H                                                    //

#define AIENGINE_OPTIMIZE_SIZE			     	0
#define AIENGINE_OPTIMIZE_SPEED			     	0

#define AIE_GENERATE_SITEMAPS				1

#ifdef __WIN32__
#ifndef __CYGWIN__
#define AIE_TARGET_NOT_LINUX       		__WIN32__
#define AIE_NO_SETUID
#define AIE_NO_SETGID
#else
#define AIE_TARGET_IS_LINUX        			1
#endif
#else
#define AIE_TARGET_IS_LINUX        			1
#endif


#ifdef AIE_TARGET_IS_LINUX
#ifndef aie_do_use_keys
#define aie_do_use_keys					0
#endif
#define aie_do_uri_zip					1
#endif

#define AIE_LOG_QUEUE_NO_WAIT				0
// TODO: Future use
// For fine tuning look in aiengine_log.h
#ifdef __GNUC__
#define AIENGINE_LOG_NO_LOG				0
#else
#define AIENGINE_LOG_NO_LOG				0
#endif


#define AIENGINE_USE_DEPRECATED				1


#define AIENGINE_INLINE_FKT			        0 && \
                                            !AIENGINE_OPTIMIZE_SIZE
#define AIE_HAS_VERSION_INFO			        0 && \
			                          !AIENGINE_OPTIMIZE_SIZE



#define AIE_DEBUG_WRITE_HTML_STATIC			0

#ifdef __WIN32__
   #define NOT_LINUX __WIN32__
   #define __builtin_expect(a,b)			(a)
#else
   #ifdef _MUDFLAP
      #define __builtin_expect(a,b)			(a)
   #endif

   #ifdef AIENGINE_USER_ID
      #define AIE_USERID			AIENGINE_USER_ID
      #define AIE_SERVER_USERID    		AIENGINE_USER_ID
   #else
      #define AIE_USERID			2000
      #define AIE_SERVER_USERID 		2000
   #endif

   #ifdef AIENGINE_GROUP_ID
      #define AIE_GROUPID			AIENGINE_GROUP_ID
      #define AIE_SERVER_GROUPID		AIENGINE_GROUP_ID
   #else
      #define AIE_GROUPID			2000
      #define AIE_SERVER_GROUPID   		1600
   #endif

#endif


#ifdef __WIN32__
// Some fixed paths for windoze
#define AIENGINE_ROOT_DATA_DIR			"/aIEngine"
#define AIENGINE_SUB_DATA_DIR			"data"
#define AIENGINE_ROOT_HTDOCS_DIR		"/aIEngine"
#define AIENGINE_SUB_HTDOCS_DIR			"htdocs"

#define AIENGINE_DATABASE_DIR			"/aIEngine/data/aiengine/db"
#define AIENGINE_DATABASE_TEMP_DIR	        "/aIEngine/data/aiengine/temp"
#define AIENGINE_DATABASE			"aIEngine.db"
#define AIE_DB_AIENGINE				AIENGINE_DATABASE

#define AIENGINE_BASE_LOG_DIR                   "/aIEngine/data/logs"
#define AIENGINE_LOGFILE                        "aIEngine_Error.log"

// #define AIENGINE_SQL_INCLUDE                    "sqlite3.h"
#define AIENGINE_SQL_INCLUDE   "/data/data/com.termux/files/home/project/include/sqlite3.h"
#else

// Neu ALH 27.06.19
//
#define AIENGINE_SYSTEM_ROOT	"/storage/6664-3230/aiEngine"
#define AIENGINE_RUNTIME_ROOT	"/data/data/com.termux/files/aieRuntime"
#define AIENGINE_ROOT_DATA_DIR	AIENGINE_RUNTIME_ROOT"/data"
#define AIENGINE_CGI_DATA_ROOT	AIENGINE_RUNTIME_ROOT"/cgi"
#define AIENGINE_CGI_DATA_DIR             "data"
#define AIENGINE_SUB_DATA_DIR	AIENGINE_CGI_DATA_DIR"/sub"

#define AIENGINE_ROOT_HTDOCS_DIR	AIENGINE_RUNTIME_ROOT"/htdocs"
#define AIENGINE_CGI_HTDOCS_ROOT        AIENGINE_ROOT_HTDOCS_DIR
#define AIENGINE_CGI_HTDOCS_DIR           "htdocs"

// #define AIENGINE_BASE_LOG_DIR	AIENGINE_DATA_DIR"/logs"

// #define aIEngine_Error_Log	AIENGINE_BASE_LOG_DIR"/logs/aIEngine_Error.log"
#define AIENGINE_BASE_SOCKET_DIR	AIENGINE_SYSTEM_ROOT"/ipc"
#endif

#define login_error_file        		"login_error"
#define server_error_file       		"server_error"
#define performance_file        		"performance"

#ifndef AIENGINE_ROOT_DATA_DIR
#define AIENGINE_CGI_DATA_ROOT            "/aIEngine"
#warning Data base directory not defined!
#else
//#define AIENGINE_CGI_DATA_ROOT            "/"AIENGINE_ROOT_DATA_DIR
#endif
#ifndef AIENGINE_SUB_DATA_DIR
#define AIENGINE_CGI_DATA_DIR             "data"
#warning Data sub directrory not defined!
#else
//#define AIENGINE_CGI_DATA_DIR             AIENGINE_SUB_DATA_DIR
#endif

#ifndef AIENGINE_ROOT_HTDOCS_DIR
#define AIENGINE_CGI_HTDOCS_ROOT          "/aIEngine"
#warning htdocs base directory not definied!
#else
//#define AIENGINE_CGI_HTDOCS_ROOT          "/"AIENGINE_ROOT_HTDOCS_DIR
#endif
//#ifndef AIENGINE_SUB_HTDOCS_DIR
//#define AIENGINE_CGI_HTDOCS_DIR           "htdocs"
//#warning htdocs sub directory not defined!
//#else
//#define AIENGINE_CGI_HTDOCS_DIR           AIENGINE_SUB_HTDOCS_DIR
//#endif

#define AIENGINE_SQL_INCLUDE	"/data/data/com.termux/files/home/project/include/sqlite3.h"
#define AIENGINE_DATABASE_DIR	AIENGINE_RUNTIME_ROOT"/db"
#define AIE_DB_PATH   				AIENGINE_DATABASE_DIR
#define AIENGINE_DATABASE_TEMP_DIR AIENGINE_RUNTIME_ROOT"/tmp"
#define AIE_DB_TEMP_PATH			AIENGINE_DATABASE_TEMP_DIR
#define AIENGINE_DATABASE	"aiEngine.db"
// #define AIE_DB_AIENGINE				AIENGINE_DATABASE
#define AIE_DB_KEYS    				"aie_keys.db"
#define AIE_DB_SITEMAPS				"aie_sitemaps.db"


#define AIENGINE_BASE_LOG_DIR  AIENGINE_SYSTEM_ROOT"/log"
#define aIEngine_Error_Log     AIENGINE_BASE_LOG_DIR"/aIEngine_Error.log"
//#ifndef AIENGINE_BASE_LOG_DIR
//   #define aIEngine_Error_Log	"/aIEngine/data/logs/aIEngine_Error.log"
//   #warning No location for the Logfile was defined!
//#else
//   #ifndef AIENGINE_LOGFILE
//      #define aIEngine_Error_Log     AIENGINE_BASE_LOG_DIR"/aIEngine_Error.log"
//      #warning No logfile name was defined!
//   #else
//      #define aIEngine_Error_Log       AIENGINE_BASE_LOG_DIR"/"AIENGINE_LOGFILE
//   #endif
//#endif

#define         common_prog_data_divider        ':'



/*---------------------------------------------------------------------------*/
/* Systemheaderdateien                                                       */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Headerdateien des (R)@Secur(tm) Internet Engine & HTML Generators         */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Deprecated types                                                          */
/*...........................................................................*/
// Keine                                                                     //

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

