/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : mysocket.c                                                  */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.05.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : char * als const char * deklarieren         */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_mysocket_version         = "1.0.0";                        //
const char *modul_mysocket                 = "mySocket";                     //
const char *modul_mysocket_date            = __DATE__;                       //
const char *modul_mysocket_time            = __TIME__;                       //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_LOG_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>

/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aiengine.h"
#include "mysocket.h"
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
/*****************************************************************************/

void close_socket(int s)
{
   //shutdown(s, 2);
   //if (shutdown(s, 2) == 0)
   {
      close(s);
   }
}


bool warten_auf_daten(int fd, int timeout)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "warten_+auf_daten" },
      { AIE_LOG_ERROR, "select: %s" },
      { AIE_LOG_WARN, "Keine Datein innerhalb von [%d] Sekunden" }

   };
   bool rc = true;
   fd_set rfds;
   struct timeval tv;
   int retval;
   FD_ZERO(&rfds);
   FD_SET(fd, &rfds);
   tv.tv_sec = timeout;
   tv.tv_usec = 0;
    
   #if AIENGINE_LOG_TRACE_SOCKET_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(
	    ((retval = select(fd + 1, &rfds, NULL, NULL, &tv)) < 0),false))
   {
      // select: %s
      aie_sys_log(1, strerror(errno));
      rc = false;
   }
   else
   {
      if (__builtin_expect((retval),true))
      {
      }
      /* FD_ISSET(0, &rfds) muBte jetzt true sein. */
      else
      {
         // Keine Datein innerhalb von [%d] Sekunden
         aie_sys_log(2, timeout);
         rc = false;
      }
   }
   return(rc);
}

bool do_socket_server(const char *address, bool(*fkt)(int msgid, void *buf), 
                      void *buf, unsigned int buflen, const char *file)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "do_socket_server" },
      { AIE_LOG_ERROR, "%s: init_send_socket :%s" },
      { AIE_LOG_ERROR, "%s:Out of memory? :%s" }

   };
   bool rc = false;
   int socket_id;
   unsigned int len = sizeof(struct sockaddr) + strlen(address);
   struct sockaddr *saun = (struct sockaddr *)aie_malloc(len + 1);
    
   #if AIENGINE_LOG_TRACE_SOCKET_TRACE
   aie_sys_log(0);
   #endif

    if (__builtin_expect((saun != NULL),true))
    {
       saun->sa_family = PF_UNIX;
       // printf("Len: %d : %d\n", len, strlen(address));
       strcpy(saun->sa_data, address);
	    
       if (__builtin_expect(
	      ((socket_id = init_send_socket(address, saun, len)) < 0),false))
       {
          // %s: init_send_socket :%s
          aie_sys_log(1, file, strerror(errno));
          rc = true;
       }
       else
       {
          rc = do_socket_server_loop(socket_id, len, fkt, buf, buflen, file);
       }
       close_socket(socket_id);
       aie_free(saun);
    }
    else
    {
       // %s:Out of memory? :%s
          aie_sys_log(2, file, strerror(errno));
       rc = true;
    }
    return(rc);
}

bool do_socket_server_loop(int socket_id, unsigned int len, 
                           bool(*fkt)(int msgid, void *buf), 
			   void *buf, unsigned int buflen, const char *file)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "do_socket_server_loop" },
      { AIE_LOG_ERROR, "%s: Out of memory? :%s" },
      { AIE_LOG_ERROR, "%s: Fehler beim Oeffnen %s" },
      { AIE_LOG_WARN, "%s: Pipe moeglicherweise keine Daten ..  %s" }
   };
   int msgid;
   bool me_exit = false;
   struct sockaddr *fsaun = (struct sockaddr *)aie_malloc(len + 1);
   socklen_t fromlen = len;

    
   #if AIENGINE_LOG_TRACE_SOCKET_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((fsaun == NULL),false))
   {
       // %s: Out of memory? :%s
       aie_sys_log(1, file, strerror(errno));
       me_exit = true;
   }
   else
   {
       do
       { 
          if (__builtin_expect(((msgid = 
			 open_send_socket(socket_id, fsaun, &fromlen)) < 0), 
		                                                        false))
          {
	     // %s: Fehler beim Oeffnen %s
             aie_sys_log(2, file, strerror(errno));
	     me_exit = true;
	     sleep(1);
          }
          else
          {
             if (__builtin_expect((!warten_auf_daten(msgid, 5)),false))
	     {
	        // %s: Pipe moeglicherweise keine Daten ..  %s", 
                aie_sys_log(3, file, strerror(errno));
	        //me_exit = true;
	     }
	     else
	     {
		me_exit = socket_server_rcv(msgid, buf, buflen, fkt, file);
             }
	     close_socket(msgid);
          }
       } while(!me_exit);
       aie_free(fsaun);
   }
   return(true);
}

bool socket_server_rcv(int msgid, void *buf, unsigned int len, 
                           bool (*fkt)(int msgid, void *buf), const char *file)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "socket_server_rcv" },
      { AIE_LOG_ERROR, "%s: Fehler bei Recv beendet .. %s" },
      { AIE_LOG_ERROR, "%s: Leere Botschaft maybe eof(): %s" }
   };
   int size;
   bool me_exit = false;

    
   #if AIENGINE_LOG_TRACE_SOCKET_TRACE
   aie_sys_log(0);
   #endif
   errno = 0;
   if (__builtin_expect(
	    ((size = recv(msgid, buf, len, MSG_WAITALL)) < 0),false))
   {
      // %s: Fehler bei Recv beendet .. %s
       aie_sys_log(1, file, strerror(errno));
	 me_exit = true;
   }
   else
   {
      if (__builtin_expect((size == 0),false))
      {
         // %s: Leere Botschaft maybe eof(): %s
         aie_sys_log(2, file, strerror(errno));
	 me_exit = true;
      }
      else
      {
         me_exit = fkt(msgid, buf);
      }
   }
   return(me_exit);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_mysocket_size            = __LINE__;                       //
/* -------------------------------- EOF ------------------------------------ */
