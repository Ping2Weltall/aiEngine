/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : mysocket.h                                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.05.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklariert             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef MYSOCKET_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define MYSOCKET_H

#ifndef AIENGINE_BASE_SOCKET_DIR
#define SOCKET_MENUE_ADDRESS_BASE       "/aIEngine/sockets/Menue"
#define SOCKET_KEYS_ADDRESS_BASE        "/aIEngine/sockets/Keys"
#define SOCKET_PLZ_ADDRESS_BASE         "/aIEngine/sockets/Postleitzahlen"
#warning The file sockets directory is not definied!
#else
#define SOCKET_MENUE_ADDRESS_BASE       AIENGINE_BASE_SOCKET_DIR"/Menue"
#define SOCKET_KEYS_ADDRESS_BASE        AIENGINE_BASE_SOCKET_DIR"/Keys"
#define SOCKET_PLZ_ADDRESS_BASE         AIENGINE_BASE_SOCKET_DIR"/Postleitzahlen"
#endif

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#include <sys/types.h>
#include <sys/socket.h>
//#include <sys/un.h>
#include <unistd.h>
#include <stdio.h>
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
char *make_pid_socket_adress(pid_t pid);

int init_send_socket(const char *address, struct sockaddr *saun, 
                                                            unsigned int len);
bool send_on_socket(int s, void *packet, unsigned int len);
bool send_on_stream(FILE *stream, void *packet, unsigned int len);
void close_socket(int s);

int open_send_socket(int s, struct sockaddr *fsaun, socklen_t *fromlen);
//int open_rcv_socket(const char *address);
void *read_from_socket(void *buf, unsigned int len, int socket_id);

bool warten_auf_daten(int fd, int timeout);

bool do_socket_server(const char *address, bool(*fkt)(int msgid, void *buf), 
                      void *buf, unsigned int buflen, const char *file);
bool do_socket_server_loop(const int socket_id, unsigned int len, 
                           bool(*fkt)(int msgid, void *buf), 
			   void *buf, unsigned int buflen, const char *file);
bool socket_server_rcv(const int msgid, void *buf, unsigned int len, 
                       bool (*fkt)(int msgid, void *buf), const char *file);


/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

