/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_sparten.c                                               */
/* Library     : aiengine-cgi_client-3.nn.nn.so                              */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 03.04.2004  : ALH           : MouseOver fuer Spartenmenue mit Bild        */
/*                               Pointer auf Array anstatt Array             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sparten_version      = "1.1.4";                            //
const char *modul_sparten              = "Sparten";                          //
const char *modul_sparten_date         = __DATE__;                           //
const char *modul_sparten_time         = __TIME__;                           //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define SPARTEN_IMAGE_NAME	"sparten"                                    //
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *ht_table_dashed_frame;                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void do_sparten_menue(bool width, struct sparten_menue *sparten_menue, 
		             int sparten_size, 
			     struct aie_cgi_parameter *cgi_parameter)
{
   // TODO: Werte sollten aus der cgi_parametern kommen
  const char *appl_pic_menue_titel = AIE_MK_MENUE_IMAGE("titel.jpg");
  const char *ProgMe = 
                  aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CGI_MYSELF);

  int col = 0;
  register int z = 0;
  if (__builtin_expect((width == true),true))
  {
     bTABLEwvbg("400", ht_table_dashed_frame, appl_pic_menue_titel);
  }
  else
  {
     // bTABLEwvbg("500", ht_table_dashed_frame, appl_pic_menue_titel);
     bTABLEwv("520", ht_table_dashed_frame);
  }
  for (z = 0; z < sparten_size;z++)
  {
     char page[80];
     char frame[5];
     char adKategorie[5];
     struct aie_link_vars link_vars[] =
     {
          { isNameCGIVar, page },
          { isFrameCGIVar, frame },
          { isAdKategorieCGIVar, adKategorie }
     };
     struct aie_prog_link prog_link =
     {
         ProgMe,
         NULL, // FrameNameTopOfWindow },
         false,
	 link_vars, 
         sizeof(link_vars)/sizeof(struct aie_link_vars),
         cgi_parameter,
         NULL,
         NULL,
         { { NULL, NULL, NULL, NULL, NULL, 0 },
           { NULL, NULL, NULL, NULL, NULL, 0 } }
     };
     memset(page, '\0', sizeof(page));
     memset(frame, '\0', sizeof(frame));
     strncpy(page, sparten_menue->page, sizeof(page) - 1);
     strncpy(frame, sparten_menue->frame, sizeof(frame) - 1);

     strncpy(adKategorie, sparten_menue->ad_kategorie, sizeof(adKategorie) - 1);
     if (col == 0)
     {
        bTR
     }
     if (__builtin_expect(
	      ((sparten_menue->pic != NULL) && 
	       (*sparten_menue->pic != '\0')),true))
     {
           html_static("<td width=\"250\" height=\"75\" valign=\"left\" align=\"top\">");
           //bTDwhmbg("250", "75", MK_BUTTON_IMAGE("btnbgs.png"));
	   if (*page == '@')
           {
	      html_vt("<a href=\"http://%s\">", (page + 1));
           }
	   else
	   {
              aie_html_link(prog_link);
	   }
           html_static("<div id=\"picdiv\" style=\"z-index:2\"");
	   html_vt(" onMouseOver=\"mcp(1,'%.2d');\" ", z);
	   html_vt(" onMouseOut=\"mcp(0,'%.2d');\" ", z);
	   html_static(">");
           html_image(AIE_MK_BUTTON_IMAGE(sparten_menue->pic), 
		      SPARTEN_IMAGE_NAME, sparten_menue->titel, z);
           html_static("</div>");
	   eA
     }
     else
     {
        if (width)
        {
           bTDwhmbg("400", "75", AIE_MK_BUTTON_IMAGE("btnbg.jpg"));
           bFONTs("+2");
        }
        else
        {
           bTDwhmbg("250", "75", AIE_MK_BUTTON_IMAGE("btnbgs.png"));
           bFONTs("+1");
        }
        bCENTER
        bB
        aie_html_link(prog_link);
        html_static("<div id=\"txtdiv\" style=\"z-index:2\">");
        html_t(sparten_menue->titel);
        html_static("</div>");
        eA
        eB
        eCENTER
        eFONT
     }
     eTD
     if (width)
     {
        eTR
     }
     else
     {
        if (col == 1)
        {
           eTR
           col = 0;
           TBL_STD_ROW_COL_START
           NBSP
           TBL_STD_COL_CHANGE
           NBSP
           TBL_STD_COL_ROW_END
        }
        else
        {
          TBL_STD_COL_CHANGE
          NBSP
          eTD
          col = 1;
        }
     }
     sparten_menue++;
  }
  eTABLE
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void sparten_ini_javascript(struct sparten_menue *sparten_menue, 
		             int sparten_size)
{
  const char *mcp_script = "function mcp(fkt,nr)\n"
	            "{ var pic_cmd;\n"
		       "var pic_cmd='document.'+sp_base+nr+'.src';\n"
		       "if (document.images)\n"
		       "{\n" 
		          "if (fkt == 0)\n"
		          "{\n"
		             "pic_src='sp_img['+nr+'].src';\n"
		          "}\n"
		          "else\n"
		          "{\n"
			     "pic_src='sp_img_a['+nr+'].src';\n"
		          "}\n"
		          "eval(pic_cmd+'='+pic_src);\n" 
		       "}\n"
	            "}\n\n"; 
  register int z = 0;
  bJAVASCRIPT
  html_vt("var sp_base = '%s';\n", SPARTEN_IMAGE_NAME);
  html_static("var sp_img = new Array();\n");
  html_static("var sp_img_a = new Array();\n");
  for (z = 0; z < sparten_size;z++)
  {
     html_vt("sp_img[%.2d] = new Image;\nsp_img_a[%.2d] = new Image;\n", z, z);
     html_vt(" sp_img[%.2d].src = '%s';\n", z, 
	                              AIE_MK_BUTTON_IMAGE(sparten_menue->pic));
     html_vt(" sp_img_a[%.2d].src = '%s';\n", z, 
	                            AIE_MK_BUTTON_IMAGE(sparten_menue->pic_a));
    sparten_menue++; 
  }
  html_static(mcp_script);
  eJAVASCRIPT
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_sparten_size         = __LINE__;                                 //
/* -------------------------------- EOF ------------------------------------ */

