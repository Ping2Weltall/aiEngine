/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : menue.c                                                     */
/* Library     : aiengine-cgi_client-3.nn.nn.so                              */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Alle Logmeldungen Anpassen auf WinGui Client*/
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpasung  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 01.05.2004  : ALH           : Auslagern der Funktion s.u. in menuepath.cpp*/
/*                             : make_sub_men_file_path                      */
/*                             : GetMenueFileName                            */
/*                             : Auslagern der Funktion s.u. in menuetxt.cpp */
/*                             : menue_text                                  */
/*                             : page_menue_text                             */
/*.............+...............+.............................................*/
/* 27.03.2004  : ALH           : Auslagern einiger Funktionen in menueutil   */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_menue_version       = "2.2.9";                             //
const char *modul_menue               = "Menue";                             //
const char *modul_menue_date          = __DATE__;                            //
const char *modul_menue_time          = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *ht_table_b0;                                                    //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_menue_data *aie_get_menue_std_data(const char *seite, 
                                               struct aie_cgi_parameter 
					              *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_menue_std_data Seite[%s]" },         
      { AIE_LOG_ERROR, "Seite == NULL Ptr" }
   };
   struct aie_menue_data *menue_data = NULL;

   aie_sys_log(0);
    if (__builtin_expect((seite == NULL),false))
    {
       // Seite == NULL Ptr
       aie_sys_log(1);
    }
    else
    {
       unsigned int size_known_menues;
       struct aie_known_menues *known_menues;
       if (__builtin_expect(((known_menues = 
		       getRegistered_known_menues(&size_known_menues)) 
		                                          != NULL),true))
       {
          register unsigned int n = 0;
          for (n = 0; n < size_known_menues; n++)
          {
             if (__builtin_expect(
		      (strcmp(known_menues->page, seite) == 0),false))
             {
                const char *menue;
                menue = aie_GetMenueFileName(seite);

                if (__builtin_expect(
			 ((menue_data = (struct aie_menue_data *)
			       aie_malloc(sizeof(struct aie_menue_data)))
		                                                != NULL),true))
                {
                   // TODO: einige Werte sollten aus der cgi_parametern kommen
                   struct aie_menue_cell *menue_cell = 
		                                      known_menues->menue_cell;
                   menue_data->headimage = 
		                       AIE_MK_MENUE_IMAGE(known_menues->image);
                   menue_data->headtitel = known_menues->titel;
                   menue_data->top_image = 
		                     AIE_MK_MENUE_IMAGE(menue_cell->top_image);
                   menue_data->top_h_image = 
		                   AIE_MK_MENUE_IMAGE(menue_cell->top_h_image);
                   menue_data->row_image = 
		                     AIE_MK_MENUE_IMAGE(menue_cell->row_image);
                   menue_data->row_h_image = 
		                   AIE_MK_MENUE_IMAGE(menue_cell->row_h_image);
                   menue_data->menfile = menue;
                   menue_data->target_frame = known_menues->target_frame;
                   menue_data->target_page = known_menues->target_page;
                   menue_data->has_sub_content = known_menues->has_sub_content;
                   menue_data->does = known_menues->does;
                   menue_data->has_checkbox = known_menues->has_checkbox;
                   menue_data->is_width = menue_cell->is_width;
                   menue_data->table_width = menue_cell->table_width;
                   menue_data->cell_width = menue_cell->cell_width;
                   menue_data->bg_cell_1 = 
		                     AIE_MK_MENUE_IMAGE(menue_cell->bg_cell_1);
                   menue_data->bg_cell_2 = 
		                     AIE_MK_MENUE_IMAGE(menue_cell->bg_cell_2);
                   menue_data->cgi_parameter = cgi_parameter;
                }
                break;
             }
             known_menues++;
          }
       }
    }
    return(menue_data);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
void aie_standard_menue_fkt(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_standard_menue_fkt" },
      { AIE_LOG_ERROR, "Kein Menue Data fuer Seite %s" }
   };
   char *seite = aie_GetCharCGIValue(cgi_parameter, isNameCGIVar);
   struct aie_menue_data *menue_data;
   aie_sys_log(0);

   if (__builtin_expect(
	     ((menue_data = aie_get_menue_std_data(seite, cgi_parameter)) 
	                                                       == NULL),false))
   {
      // Kein Menue Data fuer Seite %s
      aie_sys_log(1, seite);
   }
   else
   {
      if (aie_is_main_menue(menue_data))
      {
      }
      else
      {
          //aIEngine_Cache_Off();
      }
      aie_free(menue_data);
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_is_main_menue(struct aie_menue_data *menue_data)
{
   bool rc = true;
   struct aie_is_menue *menue_base = NULL;
   const char *menfile = menue_data->menfile;

   if (__builtin_expect(
       (aie_load_menue(menfile, AIENGINE_MENUE_BASIS, &menue_base) == NULL), 
                                                                        false))
   {
       html_vt("Inhalt<br><small>%s</small>", menfile);
       rc = false;
   }
   else
   {
      rc = aie_show_main_menue(menue_data, menue_base);
      aie_free_menue(&menue_base);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_show_main_menue(struct aie_menue_data *menue_data, 
                         struct aie_is_menue *menue_base)
{
   const char *ProgMe = 
                  aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CGI_MYSELF);
   int i = 0;
   bool rc = true;
   struct aie_is_menue *menue_ptr;

   const char *m_table_width = menue_data->table_width;
   const char *m_men_cell_width = menue_data->cell_width;

   const char *bg_cell_1 = menue_data->bg_cell_1;
   const char *bg_cell_2 = menue_data->bg_cell_2;
   bool has_sub_content = menue_data->has_sub_content;
   bool has_checkbox = menue_data->has_checkbox;
   const char *does = menue_data->does;
   const char *target_frame = menue_data->target_frame;
   const char *target_page = menue_data->target_page;
   const char *menfile = menue_data->menfile;
   struct aie_cgi_parameter *cgi_parameter = menue_data->cgi_parameter;
   const char *menue_headimage = menue_data->headimage;
   const char *menue_headtitel = menue_data->headtitel;
   const char *menue_top_image = menue_data->top_image;
   const char *menue_top_h_image = menue_data->top_h_image;
   const char *menue_row_image = menue_data->row_image;
   const char *menue_row_h_image = menue_data->row_h_image;
   bool is_width = menue_data->is_width;

   if (__builtin_expect(((menue_ptr = menue_base) == NULL),false))
   {
       html_vt("Inhalt<br><small>%s</small>", menfile);
       rc = false;
   }
   else
   {
      bTABLEwv(m_table_width, ht_table_b0);
      bTR
      if (__builtin_expect(
	       (has_sub_content || has_checkbox || is_width),false))
      {
         bTDc4
      }
      else
      {
         bTDc3
      }
      html_image(menue_headimage, menue_headtitel, NULL, 0);
      TBL_STD_COL_ROW_TABLE_END
      while(menue_ptr != NULL)
      {
         struct aie_link_vars link_vars[] =
         {
             { isNameCGIVar,    target_page },
             { does,            menue_ptr->funktion }
         };
         struct aie_prog_link prog_link =
         {
            ProgMe,
            target_frame,
            false,
	    link_vars, 
            sizeof(link_vars)/sizeof(struct aie_link_vars),
            cgi_parameter,
            NULL,
            MousePictureJava,
            { { "Over", "top", menue_top_h_image, "row", menue_row_h_image, i },
              { "Out",  "top", menue_top_image,   "row", menue_row_image,   i } }
         };
         bTABLEwv(m_table_width, ht_table_b0);
         bTR
         if (__builtin_expect(
		  (has_sub_content || has_checkbox || is_width),false))
         {
            bTDc4
         }
         else
         {
            bTDc3
         }
         html_image(menue_top_image, "top", NULL, i);
         TBL_STD_COL_ROW_END
         bTR
         bTDwt("10");
         html_image(menue_row_image, "row", NULL, i);
         eTD
         // TODO: Wert sollte aus menue_data kommen
         bTDwmbg("20", AIE_MK_MENUE_IMAGE("rbgs.jpg"));
         html_pic_big_point();
         eTD
         bTDwmbg(m_men_cell_width, bg_cell_1);
	 html_static("<p class=aie_menue>");
         //bB
         aie_html_link(prog_link);
         html_t(menue_ptr->entry);
         eA
	 html_static("</p>");
         //eB
         //eFONT
         eTD
         if (__builtin_expect((has_checkbox == true),false))
         {
            bTDwmbg("10", bg_cell_2);
            html_b_checkbox_wfkt(isSuchenInCGIVar,  menue_ptr->funktion);
            //html_static(" checked ");
            MousePictureJava("Over", "top", menue_top_h_image, "row", 
		             menue_row_h_image, i);
            MousePictureJava("Out", "top", menue_top_image, "row", 
		             menue_row_image, i);
            html_e_checkbox_wfkt();
            eTD
         }
	 else
	 {
            if (__builtin_expect((is_width == true),false))
            {
               //bTD
               bTDwmbg("10", bg_cell_2);
               if (has_sub_content)
               {
                  //html_link(prog_link, link_vars);
                  // Adjust for Submen ToDo
                  // html_vt("&lt;%d&gt;", list_inserat(menue_ptr->funktion, NULL, false, cgi_vars_base));
                  // eA
               }
	       NBSP
               eTD
	    }
	 }

         eTR
         eTABLE
         i++;
         menue_ptr = menue_ptr->next;
      }
      bTABLEwv(m_table_width, ht_table_b0);
      bTR
      if (__builtin_expect((has_sub_content || has_checkbox),false))
      {
         bTDc4
      }
      else
      {
         bTDc3
      }
      html_image(menue_top_image, "top", NULL, i);
      TBL_STD_COL_ROW_TABLE_END
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_menue_size          = __LINE__;                                  //
/* -------------------------------- EOF ------------------------------------ */

