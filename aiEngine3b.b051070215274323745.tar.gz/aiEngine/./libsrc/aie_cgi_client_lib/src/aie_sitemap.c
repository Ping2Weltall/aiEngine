/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_sitemap.c                                               */
/* Library     : aiengine-cgi_client-3.nn.nn.so                              */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 11.06.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sitemap_version      = "1.0.0";                            //
const char *modul_sitemap              = "Sitemap";                          //
const char *modul_sitemap_date         = __DATE__;                           //
const char *modul_sitemap_time         = __TIME__;                           //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
#define AIENGINE_USE_SOCKETS		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
									     //
#ifndef __WIN32__
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <syslog.h>
#else
#include <dos.h>
#endif
// #include <sys/timeb.h>                                                       //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// We need this to prevent redundance - maybe it should be defined 
// somewhere more global
#include "../../../server/aie_sitemap/include/sitemap_define.h"
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *aIEngine_CGI_Prog;                                              //
extern char *aIEngine_Start_Prog;                                            //
extern char *content;                                                        //
extern char *is_hash;                                                        //
extern char *aIEngine_myExtension;                                           //
extern char *aIEngine_ApplTitle;
extern char *aIEngine_Content_language;
extern char *aIEngine_Support_Email;
extern char *aIEngine_Author;
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
#ifndef __WIN32__
static bool aie_start_sitemap_server(void);                                  //
static bool aie_sitemap_server_anfrage(struct sitemap_server_msgbuf 
                                                       *request_buf);
static void aie_sitemap_company_tag(void);                                   //
static void include_sitemap_schema_url(void);
#endif
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
#if AIE_GENERATE_SITEMAPS
#ifndef __WIN32__
static struct aIEngine_sockets *sitemap_server_socket = NULL;                //
#endif
#endif
                                                                             //
/*****************************************************************************/

#if AIE_GENERATE_SITEMAPS
#ifndef __WIN32__
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_send_sitemap_save_msg(const char *url, const char *path, 
                               const char *modul, 
                               int frame, const char *page,
                               const char *run_time, u64 size)
{
   bool rc = false;
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_send_sitemap_save_msg url[%s] modul[%s]" },         
      { AIE_LOG_ERROR, "Fehler beim speichern der Sitemap Info! "
	               "Url[%s] Modul[%s]" },
      { AIE_LOG_ERROR, "Sitemap Save konnte nicht gesendet werden! "
	               "Url[%s] Modul[%s]" }
   };
   aie_sys_log(0, url, modul);
   if (__builtin_expect((sitemap_server_socket == NULL),true))
   {
      aie_start_sitemap_server();
   }
   if (__builtin_expect((sitemap_server_socket != NULL),true))
   {
      struct sitemap_server_msgbuf *request_buf = 
	        (struct sitemap_server_msgbuf *)sitemap_server_socket->buf;
      struct ipc_sitemap_server_save_msg *ipc_sitemap_server_save_msg =
	        &request_buf->m.ipc_sitemap_server_save_msg;
      memset(request_buf, '\0', sizeof(sitemap_server_socket->len));
      request_buf->mtype = MSG_SITEMAP_SERVER_URL_SPEICHERN;
      sprintf(ipc_sitemap_server_save_msg->size, "%Ld", size);
      strncpy(ipc_sitemap_server_save_msg->url, url, AIE_SITEMAP_URL_LEN);
      strncpy(ipc_sitemap_server_save_msg->path, path, AIE_SITEMAP_PATH_LEN);
      strncpy(ipc_sitemap_server_save_msg->modul, modul, AIE_SITEMAP_MODUL_LEN);
      ipc_sitemap_server_save_msg->frame = frame;
      strncpy(ipc_sitemap_server_save_msg->page, page, AIE_SITEMAP_PAGE_LEN);
      strncpy(ipc_sitemap_server_save_msg->run_time, run_time, 
                                                  AIE_SITEMAP_RUN_TIME_LEN);
      if (__builtin_expect((aie_sitemap_server_anfrage(request_buf)), true))
      {
         rc = true;
      }
      else
      {
	  // Fehler beim speichern der Sitemap Info! Url[%s] Modul[%s]
          aie_sys_log(1, url, modul);
      }
   }
   else
   {
      // Sitemap Save konnte nicht gesendet werden! Url[%s] Modul[%s]
      aie_sys_log(2, url, modul);
   }
   return(rc);
   
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool aie_start_sitemap_server(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_start_sitemap_server" },         
      { AIE_LOG_ERROR, "Fehler Sitemap Server Startup" }
   };
   bool rc = true;
   aie_sys_log(0);
   if (__builtin_expect(((sitemap_server_socket = 
	    aIEngine_StartSocketServer(SOCKET_SITEMAP_ADDRESS_BASE, 
	                               MSG_SITEMAP_SERVER_START, 
				       MSG_SITEMAP_SERVER_STOP, 
				       sizeof(struct sitemap_server_msgbuf)))
	 == NULL),false))
   {
      // Fehler Sitemap Server Startup
      aie_sys_log(1);
      rc = false;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool aie_sitemap_server_anfrage(struct sitemap_server_msgbuf 
                                                       *request_buf)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sitemap_server_anfrage" },
      { AIE_LOG_ERROR, "client: sitemap_server_send: %s" },
      { AIE_LOG_ERROR, "Received Empty Line?!" },
      { AIE_LOG_ERROR, "Sitemap Speichern Fehler - URL[%s] Status[%d]" },
      { AIE_LOG_ERROR, "client: Nicht Initialisiert?: %s" }
   };
   bool rc = true;
   //AIE_GET_PROG_NAME(ProgMe)
   if (__builtin_expect((sitemap_server_socket != NULL),true))
   {
      struct sitemap_server_msgbuf *answer_buf = 
	     (struct sitemap_server_msgbuf *)sitemap_server_socket->buf;
   
      if (__builtin_expect(
	       ((sitemap_server_socket->fp != NULL) && 
		(sitemap_server_socket->client_socket >= 0)),true))
      {
         if (__builtin_expect(
		  (send(sitemap_server_socket->client_socket, request_buf, 
		                    sitemap_server_socket->len, 0) < 0),false))
         {
             // client: sitemap_server_send: %s
             aie_sys_log(1, strerror(errno));
             rc = false;
         }
         else
         {
            if (request_buf->mtype != MSG_SITEMAP_SERVER_URL_SPEICHERN)
	    {
               const char *cgiServerName = 
		           aie_get_aIEngine_env(AIENGINE_ENV_SERVER_NAME);
	       FILE *fptr;
	       char *sptr = answer_buf->m.ipc_sitemap_server_answer_msg.line;
               sleep(0);
	       // TODO: Der Pfad sollte keine konstante sein!
	       fptr = fopen("/aIEngine/temp/sitemaps.tmp", "a+");
	       do 
	       {
                  fread(answer_buf, sitemap_server_socket->len, 1, 
		                                    sitemap_server_socket->fp);
	          if (__builtin_expect(
			  ( (strcmp(sptr, SITEMAP_FOOTER) == 0) &&
		      (strcmp(cgiServerName, "generator.aiengine.org") == 0)),
			                                               false))
	          {
	             include_sitemap_schema_url();
	          }
	          html_vt("%s", sptr);
	          if (*sptr == '\0')
	          {
	             // Received Empty Line?!
                     aie_sys_log(2);
	          }
	          else
	          {
	             fprintf(fptr, "%s", sptr);
	          }
	       } while ((!answer_buf->m.ipc_sitemap_server_answer_msg.eot) &&
	   	        (*sptr != '\0'));
	       fclose(fptr);
	    }
	    else
	    {
               fread(answer_buf, sitemap_server_socket->len, 1, 
		                                    sitemap_server_socket->fp);
	       if (answer_buf->m.ipc_sitemap_server_save_reply_msg.status !=
	          AIE_STATUS_SITEMAP_SPEICHERN_OK)
	       {
                     // Sitemap Speichern Fehler - URL[%s] Status[%d]
                     aie_sys_log(3, 
		     answer_buf->m.ipc_sitemap_server_save_reply_msg.url,
		     answer_buf->m.ipc_sitemap_server_save_reply_msg.status);
	       }
	    }
         }
      }
      else
      {
         // client: Nicht Initialisiert?  %s
         aie_sys_log(4, strerror(errno));
         rc = false;
      }
   }
   else
   {
      // client: Nicht Initialisiert?: %s
      aie_sys_log(4, strerror(errno));
      rc = false;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_generate_sitemap(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_generate_sitemap" },
      { AIE_LOG_ERROR, "Server Offline? - Generating Temporaery Sitemap!" }
   };
   // TODO: Agent pruefen und Google spezifische anpassungen bei der Ausgabe
   const char *cgiRequestUri = 
                           aie_get_aIEngine_env(AIENGINE_ENV_REQUEST_URI);
   bool rc = false;
   int typ = -1;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (cgiRequestUri != NULL)
   {
      if (strcmp(cgiRequestUri, AIE_SITEMAP_NAME) == 0) 
      {
         typ = MSG_SITEMAP_SERVER_MAP_REQUEST;
      }
      else if (strcmp(cgiRequestUri, AIE_SITEMAPINDEX_NAME) == 0)
      {
         typ = MSG_SITEMAP_SERVER_INDEX_REQUEST;
      }
   }
   if (typ > 0)
   {
      const char *channel = 
	              aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CHANNEL);
      const char *classification = 
	      aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CLASSIFICATION);
      const char *language = 
	     aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CONTENT_LANGUAGE);
      const char *publisher = 
	            aie_GetStandardAsecurVariableValue(AIENGINE_VAR_PUBLISHER);
      const char *author = 
	            aie_GetStandardAsecurVariableValue(AIENGINE_VAR_AUTHOR);
      const char *email = 
	        aie_GetStandardAsecurVariableValue(AIENGINE_VAR_SUPPORT_EMAIL);
      const char *title = 
	                aie_GetStandardAsecurVariableValue(AIENGINE_VAR_TITLE);
      const char *description = 
	          aie_GetStandardAsecurVariableValue(AIENGINE_VAR_DESCRIPTION);
      const char *keywords = 
	         aie_GetStandardAsecurVariableValue(AIENGINE_VAR_KEYWORDS);
      const char *info = 
	             aie_GetStandardAsecurVariableValue(AIENGINE_VAR_SITEINFO);
      const char *audience = 
	             aie_GetStandardAsecurVariableValue(AIENGINE_VAR_AUDIENCE);
      const char *robots = 
	             aie_GetStandardAsecurVariableValue(AIENGINE_VAR_ROBOTS);
      const char *resource_typ = 
	         aie_GetStandardAsecurVariableValue(AIENGINE_VAR_RESOURCE_TYP);
      const char *revisit_after = 
	        aie_GetStandardAsecurVariableValue(AIENGINE_VAR_REVISIT_AFTER);
      const char *cgiServerSoftware = 
	                    aie_get_aIEngine_env(AIENGINE_ENV_SERVER_SOFTWARE);
      const char *cgiUserAgent = 
	                    aie_get_aIEngine_env(AIENGINE_ENV_HTTP_USER_AGENT);
      const char *cgiServerName = 
	                        aie_get_aIEngine_env(AIENGINE_ENV_SERVER_NAME);
      const char *cgiRemoteAddr =
	                        aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_ADDR);
      const char *cgiRemotePort =
	                        aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_PORT);
      html_vt("Content-Type: text/xml%c%c", 10, 10);
      if (__builtin_expect((sitemap_server_socket == NULL),true))
      {
         aie_start_sitemap_server();
      }
      if (__builtin_expect((sitemap_server_socket != NULL),true))
      {

         struct sitemap_server_msgbuf *request_buf = 
	        (struct sitemap_server_msgbuf *)sitemap_server_socket->buf;
         struct ipc_sitemap_server_msg *ipc_sitemap_server_msg = 
	                             (struct ipc_sitemap_server_msg *)
		                     &request_buf->m.ipc_sitemap_server_msg;
         struct aie_sitemap_environment *sitemap_environment = 
	                    (struct aie_sitemap_environment *)
		            &ipc_sitemap_server_msg->sitemap_environment;
         struct aie_sitemap_webmaster *sitemap_webmaster = 
	                    (struct aie_sitemap_webmaster *)
		            &sitemap_environment->sitemap_webmaster;
         struct aie_sitemap_robot *sitemap_robot = 
	                    (struct aie_sitemap_robot *)
		            &sitemap_environment->sitemap_robot;
         memset(request_buf, '\0', sizeof(sitemap_server_socket->len));
         request_buf->mtype = typ;
	 if (__builtin_expect((cgiServerSoftware != NULL),true))
	 {
            strncpy(sitemap_environment->server_software, 
		                              cgiServerSoftware, 
	                                      AIE_SITEMAP_SERVER_SOFTWARE_LEN);
	 }
	 if (__builtin_expect((cgiUserAgent != NULL),true))
	 {
            strncpy(ipc_sitemap_server_msg->agent, cgiUserAgent, 
	                                          AIE_SITEMAP_AGENT_LEN);
	 }
	 if (__builtin_expect((cgiServerName != NULL),true))
	 {
            strncpy(ipc_sitemap_server_msg->url, cgiServerName, 
	                 			  AIE_SITEMAP_URL_LEN);
	 }
	 if (__builtin_expect((cgiRemoteAddr != NULL),true))
	 {
            strncpy(ipc_sitemap_server_msg->ip, cgiRemoteAddr, 
	                                          AIE_SITEMAP_IP_LEN);
	 }
	 if (__builtin_expect((cgiRemotePort != NULL),true))
	 {
            strncpy(ipc_sitemap_server_msg->port, cgiRemotePort, 
	                                          AIE_SITEMAP_PORT_LEN);
	 }
	 if (__builtin_expect((cgiRequestUri != NULL),true))
	 {
            strncpy(ipc_sitemap_server_msg->result, cgiRequestUri, 
	                                          AIE_SITEMAP_RESULT_LEN);
	 }
         if (__builtin_expect((language != NULL),true))
	 {
            strncpy(sitemap_environment->language, language,
	                   AIE_SITEMAP_LANGUAGE_LEN);
	 }
         if (__builtin_expect((email != NULL),true))
	 {
            strncpy(sitemap_webmaster->email, email, AIE_SITEMAP_EMAIL_LEN);
	 }
         if (__builtin_expect((channel != NULL),true))
	 {
            strncpy(sitemap_robot->channel, channel,
	                    AIE_SITEMAP_CHANNEL_LEN);
	 }
         if (__builtin_expect((classification != NULL),true))
	 {
            strncpy(sitemap_robot->classification, classification,
	                   AIE_SITEMAP_CLASSIFICATION_LEN);
	 }
         if (__builtin_expect((publisher != NULL),true))
	 {
            strncpy(sitemap_robot->publisher, publisher,
	                   AIE_SITEMAP_PUBLISHER_LEN);
	 }
         if (__builtin_expect((author != NULL),true))
	 {
            strncpy(sitemap_robot->author, author, AIE_SITEMAP_AUTHOR_LEN);
	 }
         if (__builtin_expect((title != NULL),true))
	 {
            strncpy(sitemap_robot->title, title, AIE_SITEMAP_TITLE_LEN);
	 }
         if (__builtin_expect((description != NULL),true))
	 {
            strncpy(sitemap_robot->description, description,
	                   AIE_SITEMAP_DESCRIPTION_LEN);
	 }
         if (__builtin_expect((keywords != NULL),true))
	 {
            strncpy(sitemap_robot->keywords, keywords,
	                   AIE_SITEMAP_KEYWORDS_LEN);
	 }
         if (__builtin_expect((info != NULL),true))
	 {
            strncpy(sitemap_robot->info, info, AIE_SITEMAP_INFO_LEN);
	 }
         if (__builtin_expect((audience != NULL),true))
	 {
            strncpy(sitemap_robot->audience, audience,
	                   AIE_SITEMAP_AUDIENCE_LEN);
	 }
         if (__builtin_expect((robots != NULL),true))
	 {
            strncpy(sitemap_robot->robots, robots, AIE_SITEMAP_ROBOTS_LEN);
	 }
         if (__builtin_expect((resource_typ != NULL),true))
	 {
            strncpy(sitemap_robot->resource_typ, resource_typ,
	                   AIE_SITEMAP_RESOURCE_TYP_LEN);
	 }
         if (__builtin_expect((revisit_after != NULL),true))
	 {
            strncpy(sitemap_robot->revisit_after, revisit_after,
	                   AIE_SITEMAP_REVISIT_AFTER_LEN);
	 }
         rc = aie_sitemap_server_anfrage(request_buf);
      }
      if (__builtin_expect((rc == false),false))
      {
         char *ts = aie_get_time_stamp();
         char year[5];
         char month[3];
         char day[3];
         AIE_GET_PROG_NAME(ProgMe);

         // Server Offline? - Generating Temporaery Sitemap!
         aie_sys_log(1);
         memset(year, '\0', sizeof(year));
         memset(month, '\0', sizeof(month));
         memset(day, '\0', sizeof(day));
         strncpy(year, ts, 4);
         strncpy(month, ts+4, 2);
         strncpy(day, ts+6, 2);
         html_vt("%s", XML_HEADER);
         html_vt("%s", XML_COMMENT_START);
         html_vt("%s - ", AIENGINE_LANGNAME);
         html_vt("%s", AIENGINE_VERSION"\n");
         html_vt("%s", aIEngine_Copyright_1);
         html_vt("\nCGI: %s\n", ProgMe);
         html_static("Homepage: http://www.aIEngine.org\n");
         html_static("Author: Alexander J. Herrmann\n");
         html_static("Email: Alexander@aIEngine.org\n");
         html_static("XML Tag Description: http://generator.aIEngine.orgi/schemas/sitemap/index.html\n");
         html_static("\nGenerating: Sitemap");
         switch (typ)
         {
            case MSG_SITEMAP_SERVER_INDEX_REQUEST:
	    {
               html_static(" - Index\n");
	    }
	    break;
            case MSG_SITEMAP_SERVER_MAP_REQUEST:
	    {
               html_static("\n");
	    }
	    break;
         }
         html_vt("Processing: %s\n",  cgiServerName);
         html_vt("Output: %s\n",  cgiRequestUri);
         html_vt("Generated for: %s\n",  cgiUserAgent);
         html_vt("Feeding to: %s:%s\n\n",  cgiRemoteAddr, cgiRemotePort);
         html_vt("Timestamp: %s\n", ts);
         html_vt("%s", XML_COMMENT_END);
         if (typ == MSG_SITEMAP_SERVER_MAP_REQUEST)
         {
            html_static(SITEMAP_HEADER);
            html_static("<url>\n<loc>");
            html_vt("http://%s/", cgiServerName);
            html_static("</loc>\n");
            html_vt("<lastmod>%s-%s-%sT00:00:00+01:00</lastmod>\n", year, 
		                                                    month, 
								    day);
            html_static("<changefreq>monthly</changefreq>\n");
            html_static("<priority>1.0</priority>\n");
            html_static("</url>");
	    if (strcmp(cgiServerName, "generator.aiengine.org") == 0)
	    {
	       include_sitemap_schema_url();
	    }
            html_static(SITEMAP_FOOTER);
         }
         else if (typ == MSG_SITEMAP_SERVER_INDEX_REQUEST)
         {
            html_static(SITEINDEX_HEADER);
	    html_static("<environment>\n");
	    html_vt("<generator>%s - %s</generator>\n", AIENGINE_LANGNAME, 
	                                           AIENGINE_VERSION); 
	    html_vt("<server>%s</server>\n", cgiServerSoftware);
	    html_static("<ossystem>686-pc-linux-gnu</ossystem>\n"); 
	    aie_sitemap_company_tag();
	    html_static("<webmaster>\n");
	    html_static("<name>Alexander J. Herrmann</name>\n");
	    html_static("<email>Alexander@aiengine.org</email>\n");
	    html_static("</webmaster>\n");
	    html_static("<language>\n");
	    html_static("de, ch, deutsch");
	    html_static("</language>\n");
	    html_static("</environment>\n");
	    html_static("<sitemap>\n");
            html_vt("<loc>http://%s%s</loc>\n", cgiServerName, AIE_SITEMAP_NAME);
            html_vt("<lastmod>%s-%s-%sT00:00:00+01:00</lastmod>\n", year, 
		                                                    month, 
								    day);
	    html_static("<environment>\n");
	    if (__builtin_expect(
		            (language != NULL), true))
	    {
	       html_vt("<language>%s</language>\n", 
		                            language);
	    }
	    html_static("<webmaster>\n");
	    if (__builtin_expect(
		              (author != NULL), true))
	    {
	       html_vt("<name>%s</name>\n", author);
	    }
	    if (__builtin_expect(
		               (email != NULL), true))
	    {
	       html_vt("<email>%s</email>\n", email);
	    }
	    html_static("</webmaster>\n");
	    html_vt("<robot>\n");
	    if (__builtin_expect((title != NULL), true))
	    {
               html_vt("<title>%s</title>\n", title);
	    }
	    if (__builtin_expect(
		          (description != NULL), true))
	    {
               html_vt("<description>%s</description>\n", 
		                          description);
	    }
	    if (__builtin_expect(
		            (publisher != NULL), true))
	    {
	       html_vt("<publisher>%s</publisher>\n", 
		                            publisher);
	    }
	    if (__builtin_expect(
		               (robots != NULL), true))
	    {
	       html_vt("<scope>%s</scope>\n", robots);
	    }
	    if (__builtin_expect(
		             (channel != NULL), true))
	    {
	       html_vt("<channel>%s</channel>\n", 
		                             channel);
	    }
	    if (__builtin_expect(
		      (classification != NULL), true))
	    {
	       html_vt("<classification>%s</classification>\n", 
		                      classification);
	    }
	    if (__builtin_expect(
		            (audience != NULL), true))
	    {
	       html_vt("<audience>%s</audience>\n", 
		                            audience);
	    }
	    if (__builtin_expect((info != NULL), true))
	    {
	       html_vt("<info>%s</info>\n", info);
	    }
	    if (__builtin_expect(
		         (resource_typ != NULL), true))
	    {
	       html_vt("<resource>%s</resource>\n", 
		                         resource_typ);
	    }
	    if (__builtin_expect(
		        (revisit_after != NULL), true))
	    {
	       html_vt("<revisit>%s</revisit>\n", 
		                        revisit_after);
	    }
	    html_vt("</robot>\n");
	    html_static("</environment>\n");
	    html_static("</sitemap>\n");
            html_static(SITEINDEX_FOOTER);
         }
         rc = true;
      }
   }
   return(rc);
}

static void include_sitemap_schema_url(void)
{
   const char *cgiServerName = aie_get_aIEngine_env(AIENGINE_ENV_SERVER_NAME);
   html_static("<url>\n<loc>");
   html_vt("http://%s/", cgiServerName);
   html_static("schemas/sitemap/");
   html_static("</loc>\n");
   html_static("<lastmod>2005-06-16T00:00:00+01:00</lastmod>\n");
   html_static("<changefreq>monthly</changefreq>\n");
   html_static("<priority>0.95</priority>\n");
   html_static("</url>");
}
/*---------------------------------------------------------------------------*/
static void aie_sitemap_company_tag(void)
{
   html_static("<company>\n");
   html_static("<name>");
   html_static("aIEngine.org");
   html_static("</name>\n");
   html_static("<department>\n");
   html_static("<name>");
   html_static("Hosting");
   html_static("</name>\n");
   html_static("<contact>\n");
   html_static("<email>info@aiengine.org</email>\n");
   html_static("<street>129/110 Soi Kantang 7</street>\n");
   html_static("<zip>92000</zip>\n");
   html_static("<town>Trang</town>\n");
   html_static("<province>Ampue Muang</province>\n");
   html_static("<country>Thailand</country>\n");
   html_static("<phone>06-2701801</phone>\n");
   html_static("<fax>n.a.</fax>\n");
   html_static("</contact>\n");
   html_static("</department>\n");
   html_static("</company>\n");
}
#endif
#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_sitemap_size         = __LINE__;                                 //
/* -------------------------------- EOF ------------------------------------ */

