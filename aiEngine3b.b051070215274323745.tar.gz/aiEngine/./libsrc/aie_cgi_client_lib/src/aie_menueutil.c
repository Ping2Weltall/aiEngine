/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_menueutil.c                                             */
/* Library     : aiengine-cgi_client-3.nn.nn.so                              */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 27.03.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Alle Logmeldungen Anpassen auf WinGui Client*/
/*.............+...............+.............................................*/
/* 02.01.2005  : ALH           : Neu load_menue_subset fuer Suche innerhalb  */
/*             :               : des Menue's                                 */
/*             :               : Speicher zum empfangen eines Menuetextes    */
/*             :               : nun statisch.                               */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_menueutil_version       = "1.0.0";                         //
const char *modul_menueutil              = "MenueUtil";                      //
const char *modul_menueutil_date          = __DATE__;                        //
const char *modul_menueutil_time          = __TIME__;                        //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
#define AIENGINE_USE_SOCKETS		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Header Dateien                                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
//#include "aiengine_sockets.h"                                                //
//#include "aiengine_msg.h"                                                    //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static struct aie_is_menue *aie_do_load_menue_from_server(                   //
                                                  const char *menue_file,    // 
                                                  const char *subset,        //
                                                  int typ,                   // 
		                                  struct aie_is_menue        //
						         **menue);           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_is_menue *aie_load_menue(const char *menue_file, int typ, 
                                                 struct aie_is_menue **menue)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_load_menue" },
      { AIE_LOG_WARN,  "menue ptr != NULL" },
      { AIE_LOG_INFO,  "Menue [%s] laden" }
   };
   struct aie_is_menue *menue_base = *menue;
   aie_sys_log(0);
   if (__builtin_expect((menue_base != NULL),false))
   {
      // menue ptr != NULL
      aie_sys_log(1);
   }
   else
   {
      // Menue [%s] laden
      aie_sys_log(2, menue_file);
      #if AIE_TARGET_IS_LINUX
      menue_base = aie_do_load_menue_from_server(menue_file, NULL, typ, 
	                                                      &menue_base);
      #else
      menue_base = aie_load_menue_from_file(menue_file, typ, &menue_base);
      #endif
   }
   *menue = menue_base;
   return(menue_base);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_is_menue *aie_load_menue_subset(const char *menue_file, 
                                   const char *subset, int typ, 
                                   struct aie_is_menue **menue)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_load_menue_subset" },
      { AIE_LOG_WARN,  "menue ptr != NULL" }
   };
   struct aie_is_menue *menue_base = *menue;
   aie_sys_log(0);
#if AIE_TARGET_IS_LINUX
   if (__builtin_expect((menue_base != NULL),false))
   {
      // menue ptr != NULL
      aie_sys_log(1);
   }
   else
   {
      menue_base = aie_do_load_menue_from_server(menue_file, subset, typ, 
                                                                   menue);
      *menue = menue_base;
   }
   return(menue_base);
#else
      *menue = NULL;
   return(NULL);      
#endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
void aie_free_menue(struct aie_is_menue **menue)
{
   struct aie_is_menue *menue_base = *menue;
   struct aie_is_menue *menue_ptr;

   if (__builtin_expect(
	    ((menue_ptr = menue_base) != NULL),true))
   {
      while(menue_ptr != NULL)
      {
         menue_base = menue_ptr->next;
         if (__builtin_expect((menue_ptr->entry != NULL),true))
         {
            aie_free(menue_ptr->entry);
         }
         if (__builtin_expect((menue_ptr->funktion != NULL),true))
         {
            aie_free(menue_ptr->funktion);
         }
         if (__builtin_expect((menue_ptr->subkat != NULL),true))
         {
            aie_free(menue_ptr->subkat);
         }
         aie_free(menue_ptr);
         menue_ptr = menue_base;
      }
   }
   *menue = NULL;
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_is_menue *aie_load_menue_from_file(const char *menue_file, int typ, 
		                      struct aie_is_menue **menue)
{
   struct aie_is_menue *menue_base = *menue;
   struct aie_is_menue *menue_ptr = NULL;
   FILE *fptr;

   if (__builtin_expect((!aie_file_exist(menue_file)),false))
   {
   }
   else
   {
      char *buf = (char *)aie_malloc(AIENGINE_STD_BUF_SIZE);
      char *entry = NULL;
      char *funktion = NULL;
      char *subkat = NULL;
      if (__builtin_expect(
	       ((fptr = aie_open_read_text_file(menue_file)) != NULL),true))
      {
         char *sptr;
         char *sptr2;
         while(!feof(fptr))
         {
            if (__builtin_expect(
		     (fgets(buf, AIENGINE_STD_BUF_SIZE - 1, fptr) 
		                                              != NULL),true))
            {
	       if (__builtin_expect((*buf != '#'),true))
	       {
                  funktion = buf;
                  if ((sptr2 = strchr(buf, '\n')) != NULL)
                  {
                     *sptr2 = '\0'; // Maybe 2 be changed
                  }
                  sptr2 = NULL;
                  if ((sptr = strchr(buf, ':')) != NULL)
                  {
                     *sptr = '\0';
                     sptr++;
		     entry = sptr;
                     if (typ == AIENGINE_MENUE_ERWEITERT)
                     {
                        if ((sptr2 = strchr(sptr, ':')) != NULL)
                        {
                           *sptr2 = '\0';
                           sptr2++;
			   subkat = sptr2;
                        }
                     }
		     menue_base = aie_add_menue_entry(&menue_base, &menue_ptr,
				                  entry, 
						  funktion, 
						  subkat);
                  }
	       }
            }
         }
         aie_close_file(fptr);
      }
      aie_free(buf);
   }
   return(menue_base);
}
/*---------------------------------------------------------------------------*/
#ifndef __WIN32__
static struct aie_is_menue *aie_do_load_menue_from_server(
                                                  const char *menue_file, 
                                                  const char *subset,
                                                  int typ, 
		                                  struct aie_is_menue **menue)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_do_load_menue_from_server" },
      { AIE_LOG_ERROR, "memory malloc - socket adresse == NULL: %s" },
      { AIE_LOG_ERROR, "client: socket: %s" },
      { AIE_LOG_ERROR, "client: connect: %s" },
      { AIE_LOG_ERROR, "client: send: %s" },
      { AIE_LOG_INFO,  "Menue empfangen  %s %s" }
   };
   FILE *fp;
   register int s;
   const char *address = SOCKET_MENUE_ADDRESS_BASE;
   unsigned int len = sizeof(struct sockaddr)+strlen(address);
   struct sockaddr *saun = (struct sockaddr *)aie_malloc(len + 1);
   struct aie_is_menue *menue_base = *menue;
   struct aie_is_menue *menue_ptr = NULL;

   aie_sys_log(0);

   if (__builtin_expect((saun == NULL),false))
   {
      // memory malloc - socket adresse == NULL: %s
      aie_sys_log(1, strerror(errno));
      menue_base = aie_load_menue_from_file(menue_file, typ, menue);
   }
   else
   {
      if (__builtin_expect(
	       ((s = socket(AF_UNIX, SOCK_STREAM, 0)) < 0), false))
      {
          // client: socket: %s
          aie_sys_log(2, strerror(errno));
          menue_base = aie_load_menue_from_file(menue_file, typ, menue);
      }
      else
      {
         saun->sa_family = AF_UNIX;
         strcpy(saun->sa_data, address);

         //len = sizeof(saun.sa_family) + strlen(saun.sa_data);

         if (__builtin_expect((connect(s, saun, len) < 0), false))
         {
             // client: connect: %s
             aie_sys_log(3, strerror(errno));
             menue_base = aie_load_menue_from_file(menue_file, typ, menue);
         }
         else
         {
            struct menue_read_msgbuf request_buf;
            fp = fdopen(s, "r");
            memset(&request_buf, '\0', sizeof(request_buf));
	    if (subset == NULL)
	    {
               request_buf.mtype = MSG_MENUE_READ;
	    }
	    else
	    {
               request_buf.mtype = MSG_MENUE_SUBSET_READ;
               strncpy(request_buf.m.ipc_menue_read_msg.subset, 
		                                 subset, AIE_LEN_MENUE_SUBSET);
	    }
            strncpy(request_buf.m.ipc_menue_read_msg.menue, 
	                                   menue_file, AIE_LEN_MENUEFILE_NAME);
            request_buf.m.ipc_menue_read_msg.typ = typ;
            request_buf.m.ipc_menue_read_msg.pid = getpid();
            if (__builtin_expect(
	           (send(s, &request_buf, sizeof(request_buf), 0) < 0),false))
	    {
                // client: send: %s
                aie_sys_log(4, strerror(errno));
                menue_base = aie_load_menue_from_file(menue_file, typ, menue);
	    }
	    else
	    {
	       sleep(0);
               while(1)
               {
                  struct menue_send_msgbuf answer_buf;
                  fread(&answer_buf, sizeof(answer_buf), 1, fp);
                  if (__builtin_expect((!feof(fp)),true))
                  {
                     char *entry = answer_buf.m.ipc_menue_send_msg.entry;
                     char *funktion = answer_buf.m.ipc_menue_send_msg.funktion;
                     char *subkat = answer_buf.m.ipc_menue_send_msg.subkat;
		     // Menue empfangen  %s %s
                     aie_sys_log(5, entry, funktion);
                     menue_base = aie_add_menue_entry(&menue_base, &menue_ptr,
				                  entry, 
						  funktion, 
						  subkat);
                     if (__builtin_expect(
                          (answer_buf.m.ipc_menue_send_msg.eot == true),false))
                     {
	                break;
                     }
                  }
                  else
                  {
	             break;
                  }
               }
	    }
         }
         close(s);
      }
      aie_free(saun);
   }
   *menue = menue_base;
   return(menue_base);
}
#endif

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_is_menue *aie_add_menue_entry(struct aie_is_menue **menue, 
		                        struct aie_is_menue **ptr, 
					const char *entry,
					const char *funktion,
					const char *subkat)
{
   struct aie_is_menue *menue_base = *menue;
   struct aie_is_menue *menue_ptr = *ptr;


   if (__builtin_expect((menue_base == NULL),false))
   {
      menue_base = (struct aie_is_menue *)
	                               aie_malloc(sizeof(struct aie_is_menue));
      menue_ptr = menue_base;
   }
   else
   {
      menue_ptr->next = (struct aie_is_menue *)
	                               aie_malloc(sizeof(struct aie_is_menue));
      menue_ptr = menue_ptr->next;
   }
   menue_ptr->entry = aie_strdup(entry);
   menue_ptr->funktion= aie_strdup(funktion);
   if ((subkat != NULL) && (*subkat != '\0'))
   {
      menue_ptr->subkat= aie_strdup(subkat);
   }
   else
   {
      menue_ptr->subkat = NULL;
   }
   menue_ptr->next = NULL;
   *menue = menue_base;
   *ptr = menue_ptr;
   return(menue_base);
}
/*---------------------------------------------------------------------------*/
#ifndef __WIN32__
char *aie_load_menue_text_from_server(const char *menue_file, int typ,
	                                const char *funktion)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_do_load_menue_text_from_server" },
      { AIE_LOG_ERROR, "memory malloc - socket adresse == NULL: %s" },
      { AIE_LOG_ERROR, "client: socket: %s" },
      { AIE_LOG_ERROR, "client: connect: %s" },
      { AIE_LOG_ERROR, "client: send: %s" },
      { AIE_LOG_INFO,  "Menue Item empfangen [%s]" },
      { AIE_LOG_ERROR, "Kein Menue Item %s" }
   };
   char *rc_ptr = NULL;

   aie_sys_log(0);
   if (menue_file != NULL)
   {
      FILE *fp;
      register int s;
      const char *address = SOCKET_MENUE_ADDRESS_BASE;
      unsigned int len = sizeof(struct sockaddr)+strlen(address);
      struct sockaddr *saun = (struct sockaddr *)aie_malloc(len + 1);

      if (__builtin_expect((saun == NULL),false))
      {
         // memory malloc - socket adresse == NULL: %s
         aie_sys_log(1, strerror(errno));
      }
      else
      {
         if (__builtin_expect(
	          ((s = socket(AF_UNIX, SOCK_STREAM, 0)) < 0), false))
         {
            // client: socket: %s
            aie_sys_log(2, strerror(errno));
         }
         else
         {
            saun->sa_family = AF_UNIX;
            strcpy(saun->sa_data, address);
            if (__builtin_expect((connect(s, saun, len) < 0), false))
            {
              // client: connect: %s
              aie_sys_log(3, strerror(errno));
            }
            else
            {
               struct menue_read_msgbuf request_buf;
               fp = fdopen(s, "r");
               memset(&request_buf, '\0', sizeof(request_buf));
               request_buf.mtype = MSG_MENUE_TEXT_READ;
               strncpy(request_buf.m.ipc_menue_read_item_msg.menue, 
		                               menue_file, 
					       AIE_LEN_MENUEFILE_NAME);
               strncpy(request_buf.m.ipc_menue_read_item_msg.funktion, 
	                                         funktion, 
						 AIE_LEN_MENUE_FUNKTION);
               request_buf.m.ipc_menue_read_item_msg.typ = typ;
               //request_buf.m.ipc_menue_read_item_msg.pid = getpid();
               if (__builtin_expect(
	              (send(s, &request_buf, sizeof(request_buf), 0) < 0),
		                                                        false))
	       {
                  // client: send: %s
                  aie_sys_log(4, strerror(errno));
	       }
	       else
	       {
                  static struct menue_send_msgbuf answer_buf;
	          sleep(0);
                  fread(&answer_buf, sizeof(answer_buf), 1, fp);
                  if (__builtin_expect((!feof(fp)),true))
                  {
                     char *entry = answer_buf.m.ipc_menue_send_msg.entry;
	             if (*entry != '\0')
		     {
		        rc_ptr = entry;
		        //Menue Item empfangen [%s]
                        aie_sys_log(5, entry);
		     }
		     else
		     {
		        // Kein Menue Item %s
                        aie_sys_log(6, funktion);
		     }
                  }
	       }
            }
            close(s);
         }
         aie_free(saun);
      }
   }
   return(rc_ptr);
}
#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_menueutil_size          = __LINE__;                              //
/* -------------------------------- EOF ------------------------------------ */

