/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_http.h                                                  */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003 - Globales remake @Secur nach Datenverlust in Canada   */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*                             : Laengen fuer Strukturen in aie_len.h        */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklariert             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_HTTP_H  

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_HTTP_H  

#define HTMLb _html_b
#define HTMLe _html_e

#define HT_SELECT               html_select
#define HT_SELECT_n             html_select_n
#define HT_s_eSELECT            html_s_e_select

#define HT_INPUT                html_input

#define HT_TABLE                html_table
#define HT_TABLE_v              html_v_table
#define HT_TABLE_w_v            html_w_v_table
#define HT_TABLE_w_v_bg         html_w_v_bg_table
#define HT_s_eTABLE             html_s_e_table
#define HT_TR                   html_tr
#define HT_s_TR                 html_s_tr
#define HT_s_eTR                html_s_e_tr
#define HT_s_TD                 html_s_td
#define HT_TD                   html_td
//#define HT_v_TD                 html_v_td
#define HT_cs_TD                html_cs_td
#define HT_cslt_TD              html_cslt_td
#define HT_rs_TD                html_rs_td
#define HT_wlt_TD               html_wlt_td
#define HT_wrt_TD               html_wrt_td
#define HT_wt_TD                html_wt_td
#define HT_wh_TD                html_wh_td

#define HT_al_TD                 html_al_td
#define HT_ac_TD                 html_ac_td
#define HT_ar_TD                 html_ar_td
#define HT_alvt_TD               html_alvt_td
#define HT_amvt_TD               html_amvt_td
#define HT_arvt_TD               html_arvt_td

#define HT_vt_TD                html_vt_td
#define HT_vm_TD                html_vm_td
#define HT_bg_TD                html_bg_td
#define HT_wmbg_TD              html_wmbg_td
#define HT_whbg_TD              html_whbg_td
#define HT_acbg_TD              html_acbg_td
#define HT_wacbg_TD             html_wacbg_td
#define HT_whmbg_TD             html_whmbg_td
#define HT_csacbg_TD            html_csacbg_td
#define HT_csacvt_TD            html_csacvt_td
#define HT_csacvm_TD            html_csacvm_td
#define HT_cscmbg_TD            html_cscmbg_td
#define HT_cscbbg_TD            html_cscbbg_td
#define HT_cshbg_TD             html_cshbg_td
#define HT_cshacbg_TD           html_cshacbg_td
#define HT_cswacbg_TD           html_cswacbg_td
#define HT_s_eTD                html_s_e_td

#define HT_A                    html_a
#define HT_s_eA                 html_s_e_a
#define HT_B                    html_b
#define HT_s_bB                 html_s_b_b
#define HT_s_eB                 html_s_e_b
//#define HT_BR                   html_br
//#define HT_HR                   html_hr
//#define HT_NBSP                 html_nbsp
#define HT_s_BR                 html_s_br
#define HT_s_BR2                html_s_br2
#define HT_s_HR                 html_s_hr
#define HT_s_NBSP               html_s_nbsp

#define HT_FORM                 html_form
#define HT_s_eFORM              html_s_e_form
#define HT_CENTER               html_center
#define HT_s_eCENTER            html_s_e_center
#define HT_FONT                 html_font
#define HT_s_eFONT              html_s_e_font
#define HT_FONT_s               html_font_s
#define HT_FONT_c               html_font_c
#define HT_FONT_sc              html_font_sc

#define HT_SMALL                html_small
#define HT_s_bSMALL             html_s_b_small
#define HT_s_eSMALL             html_s_e_small
#define HT_BODY                 html_body
#define HT_s_eBODY              html_s_e_body
#define HT_HTML                 html_html
#define HT_s_eHTML              html_s_e_html
#define HT_HEAD                 html_head
#define HT_s_eHEAD              html_s_e_head
#define HT_TITLE                html_title
#define HT_s_eTITLE             html_s_e_title
#define HT_FRAMESET             html_frameset
#define HT_s_eFRAMESET          html_s_e_frameset
#define HT_NOSCRIPT             html_noscript
#define HT_s_eNOSCRIPT          html_s_e_noscript

#define START_JS                html_start_js
#define END_JS                  html_end_js

#define TBL_STD_TABLE_ROW_COL_START     write_static_html(html_tags_tbl_std_tbl_row_col_start);
#define TBL_STD_COL_ROW_TABLE_END       write_static_html(html_tags_tbl_std_col_row_tbl_end);FlushOut = true;

#define TBL_STD_ROW_COL_START           write_static_html(html_tags_tbl_std_row_col_start);
#define TBL_STD_COL_ROW_CHANGE          write_static_html(html_tags_tbl_std_col_row_change);
#define TBL_STD_ROW_CHANGE              write_static_html(html_tags_tbl_std_row_change);
#define TBL_STD_COL_CHANGE              write_static_html(html_tags_tbl_std_col_change);
#define TBL_STD_COL_ROW_END             write_static_html(html_tags_tbl_std_col_row_end);
#define is_HTML_static_t        0
#define is_HTML_t               1
#define is_HTML_b               2
#define is_HTML_e               3

#define html_static(a)          write_static_html(a)
#define html_t(a)               write_html(is_HTML_t, a)
#define head_html_t(a)          head_html_vt(a, NULL)

#define bA                      write_html(is_HTML_b, HT_A);
//#define eA                      write_html(is_HTML_e, HT_A);
#define eA                      write_static_html(HT_s_eA);

#define bB                      write_static_html(HT_s_bB);
//#define bB                      write_html(is_HTML_b, HT_B);
//#define eB                      write_html(is_HTML_e, HT_B);
#define eB                      write_static_html(HT_s_eB);

#define bSMALL                  write_static_html(HT_s_bSMALL);
//#define bSMALL                  write_html(is_HTML_b, HT_SMALL);
//#define eSMALL                  write_html(is_HTML_e, HT_SMALL);
#define eSMALL                  write_static_html(HT_s_eSMALL);

#define bSELECT(a)              write_v_html(is_HTML_b, HT_SELECT, HT_SELECT_n, a);
//#define eSELECT                 write_html(is_HTML_e, HT_SELECT);
#define eSELECT                 write_static_html(HT_s_eSELECT);

#define bTABLE                  write_html(is_HTML_b, HT_TABLE);
#define bTABLEv(a)              write_v_html(is_HTML_b, HT_TABLE_v, HT_TABLE, a);
#define bTABLEwv(a, b)          write_v_html(is_HTML_b, HT_TABLE_w_v, HT_TABLE, a, b);
#define bTABLEwvbg(a, b, c)     write_v_html(is_HTML_b, HT_TABLE_w_v_bg, HT_TABLE, a, b, c);
//#define eTABLE                  write_html(is_HTML_e, HT_TABLE);
#define eTABLE                  write_static_html(HT_s_eTABLE);FlushOut = true;

//#define bTR                     write_html(is_HTML_b, HT_TR);
#define bTR                     write_static_html(HT_s_TR);
//#define eTR                     write_html(is_HTML_e, HT_TR);
#define eTR                     write_static_html(HT_s_eTR);

//#define bTD                     write_html(is_HTML_b, HT_TD);
#define bTD                     write_static_html(HT_s_TD);
#define bTDvt                   write_v_html(is_HTML_b, HT_vt_TD, HT_TD);
#define bTDvm                   write_v_html(is_HTML_b, HT_vm_TD, HT_TD);
#define bTDwlt(a)               write_v_html(is_HTML_b, HT_wlt_TD, HT_TD, a);
#define bTDwrt(a)               write_v_html(is_HTML_b, HT_wrt_TD, HT_TD, a);
#define bTDwt(a)                write_v_html(is_HTML_b, HT_wt_TD, HT_TD, a);
#define bTDwh(a, b)             write_v_html(is_HTML_b, HT_wh_TD, HT_TD, a, b);
#define bvTD(a)                 write_v_html(is_HTML_b, HT_v_TD, HT_TD, a);
#define bTDbg(a)                write_v_html(is_HTML_b, HT_bg_TD, HT_TD, a);
#define bTDacbg(a)              write_v_html(is_HTML_b, HT_acbg_TD, HT_TD, a);
#define bTDwacbg(a, b)          write_v_html(is_HTML_b, HT_wacbg_TD, HT_TD, a, b);
#define bTDwmbg(a, b)           write_v_html(is_HTML_b, HT_wmbg_TD, HT_TD, a, b);
#define bTDwhbg(a, b, c)        write_v_html(is_HTML_b, HT_whbg_TD, HT_TD, a, b, c);
#define bTDwhmbg(a, b, c)       write_v_html(is_HTML_b, HT_whmbg_TD, HT_TD, a, b, c);
#define bTDcsacbg(a, b)         write_v_html(is_HTML_b, HT_csacbg_TD, HT_TD, a, b);
#define bTDcsacvm(a)            write_v_html(is_HTML_b, HT_csacvm_TD, HT_TD, a);
#define bTDcsacvt(a)            write_v_html(is_HTML_b, HT_csacvt_TD, HT_TD, a);
#define bTDcscmbg(a, b)         write_v_html(is_HTML_b, HT_cscmbg_TD, HT_TD, a, b);
#define bTDcscbbg(a, b)         write_v_html(is_HTML_b, HT_cscbbg_TD, HT_TD, a, b);
#define bTDcshbg(a, b, c)       write_v_html(is_HTML_b, HT_cshbg_TD, HT_TD, a, b, c);
#define bTDcshacbg(a, b, c)     write_v_html(is_HTML_b, HT_cshacbg_TD, HT_TD, a, b, c);
#define bTDcswacbg(a, b, c)     write_v_html(is_HTML_b, HT_cswacbg_TD, HT_TD, a, b, c);
#define bTDcs(a)                write_v_html(is_HTML_b, HT_cs_TD, HT_TD, a);
#define bTDcslt(a)              write_v_html(is_HTML_b, HT_cslt_TD, HT_TD, a);
#define bTDrs(a)                write_v_html(is_HTML_b, HT_rs_TD, HT_TD, a);

#define bTDc2                   bTDcs("2")
#define bTDc3                   bTDcs("3")
#define bTDc4                   bTDcs("4")
#define bTDc5                   bTDcs("5")

#define bTDal                   write_v_html(is_HTML_b, HT_al_TD, HT_TD);
#define bTDac                   write_v_html(is_HTML_b, HT_ac_TD, HT_TD);
#define bTDar                   write_v_html(is_HTML_b, HT_ar_TD, HT_TD);
#define bTDalvt                 write_v_html(is_HTML_b, HT_alvt_TD, HT_TD);
#define bTDamvt                 write_v_html(is_HTML_b, HT_amvt_TD, HT_TD);
#define bTDarvt                 write_v_html(is_HTML_b, HT_arvt_TD, HT_TD);
#define bTDamvc                 write_v_html(is_HTML_b, HT_amvc_TD, HT_TD);

//#define eTD                     write_html(is_HTML_e, HT_TD);
#define eTD                     write_static_html(HT_s_eTD);

//#define BR                      write_html(is_HTML_b, HT_BR);
//#define HR                      write_html(is_HTML_b, HT_HR);

#define BR                      write_static_html(HT_s_BR);
#define BR2                     write_static_html(HT_s_BR2);
#define HR                      write_static_html(HT_s_HR);

#define NBSP                    write_static_html(HT_s_NBSP);

#define bFONT                   write_html(is_HTML_b, HT_FONT);
#define bFONT_s1                write_v_html(is_HTML_b, HT_FONT_s, HT_FONT, "+1");
#define bFONTs(a)               write_v_html(is_HTML_b, HT_FONT_s, HT_FONT, a);
#define bFONTc(a)               write_v_html(is_HTML_b, HT_FONT_c, HT_FONT, a);
#define bFONTsc(a, b)           write_v_html(is_HTML_b, HT_FONT_sc, HT_FONT, a, b);
//#define eFONT                   write_html(is_HTML_e, HT_FONT);
#define eFONT                   write_static_html(HT_s_eFONT);

#define bFORM                   write_html(is_HTML_b, HT_FORM);
//#define eFORM                   write_html(is_HTML_e, HT_FORM);
#define eFORM                   write_static_html(HT_s_eFORM);

#define bCENTER                 write_html(is_HTML_b, HT_CENTER);
//#define eCENTER                 write_html(is_HTML_e, HT_CENTER);
#define eCENTER                 write_static_html(HT_s_eCENTER);

#define bBODY                   write_html(is_HTML_b, HT_BODY);
//#define eBODY                   write_html(is_HTML_e, HT_BODY);
#define eBODY                   write_static_html(HT_s_eBODY);

#define bHTML                   write_html(is_HTML_b, HT_HTML);
//#define eHTML                   write_html(is_HTML_e, HT_HTML);
#define eHTML                   write_static_html(HT_s_eHTML);

#define bHEAD                   write_html(is_HTML_b, HT_HEAD);
//#define eHEAD                   write_html(is_HTML_e, HT_HEAD);
#define eHEAD                   write_static_html(HT_s_eHEAD);

#define bTITLE                  write_html(is_HTML_b, HT_TITLE);
//#define eTITLE                  write_html(is_HTML_e, HT_TITLE);
#define eTITLE                  write_static_html(HT_s_eTITLE);

#define bFRAMESET               write_html(is_HTML_b, HT_FRAMESET);
//#define eFRAMESET               write_html(is_HTML_e, HT_FRAMESET);
#define eFRAMESET               write_static_html(HT_s_eFRAMESET);

#define bNOSCRIPT               write_html(is_HTML_b, HT_NOSCRIPT);
//#define eNOSCRIPT               write_html(is_HTML_e, HT_NOSCRIPT);
#define eNOSCRIPT               write_static_html(HT_s_eNOSCRIPT);

#define bJAVASCRIPT             write_html(is_HTML_t, START_JS);
//#define eJAVASCRIPT             write_html(is_HTML_t, END_JS);
#define eJAVASCRIPT             write_static_html(END_JS);

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#include <stdarg.h>                                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
                                                                             //
struct aie_aIEngine_body_tag                                                 //
{                                                                            //
   char var[AIE_AIENGINE_BODY_TAG_VAL_LEN+1];                                //
   char val[AIE_AIENGINE_BODY_TAG_VAL_LEN+1];                                //
   //const char *var;                                                        //
   //const char *val;                                                        //
};                                                                           //
#define AIENGINE_EMPTY_BODY_TAG             \
struct aie_aIEngine_body_tag body_tag[] =   \
{                                           \
   { "", "" }                               \
};                                          \
int aie_size_body_tag = 0;

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
//bool html_focus_error_field(const char *FormName);
//void html_focus_field(const char *FormName, const char *nam);
//void aie_mask_error_field_fkt(void);
void http_textbuf_add(int typ, char *t);                                     //
void html_pic_point(void);                                                   //
void html_pic_big_point(void);                                               //
//void html_select_auswahl(const char *bereich, const char *file,              //
//                         const char *selected,                               //
//                         const char *var);                                   //
//void html_input_nvs(const char *nam, const char *val, const char *size);     //
//void html_input_nvsm(const char *nam, const char *val,                       //
//                     const char *size, const char *max);                     //
//void html_input_password_ns(const char *nam, const char *size);              //
//void html_input_password_nvsm(const char *nam, const char *val,              //
//                              const char *size, const char *max);            //
//void html_submit(const char *t);                                             //
//void html_submit_name(const char *nam, const char *val);                     //
//void html_checkbox(const char *nam, const char *val);                        //
//void html_checkbox_var(const char *nam, const char *val, const char *t);     //
//void html_hidden_inp(const char *nam, const char *val);                      //
//void html_file(const char *nam, const char *val);                            //
//void html_option(const char *val, const char *t, bool selected);             //
//void html_radio(const char *nam, const char *val, bool checked);             //
//void html_b_checkbox_wfkt(const char *nam, const char *val);                 //
//void html_e_checkbox_wfkt(void);                                             //
//void head_html_vt(const char *t, ...);                                       //
//void html_input_textarea(const char *nam, const char *val,                   //
//                         const char *rows, const char *cols);                //
//void html_body_tag(char *background, char *funktion);                      //
bool html_body_tag(const char *background, const char *funktion,             //
                   struct aie_cgi_parameter *cgi_parameter);                 //
void html_vt(const char *t, ...);                                            //
void html_argptr_vt(const char *t, va_list argptr);                          //
#if AIE_DEBUG_WRITE_HTML_STATIC
void _write_static_html(const char *t, const char *file, int line);          //
#else
void write_static_html(const char *t);                                       //
#endif
void write_v_html(int typ, const char *t, ...);                              //
void write_html(int typ, const char *t);                                     //
void html_image(const char *image, const char *name, const char *alt,        //
                int count);                                                  //
void MousePictureJava(const char *MouseFkt,                                  //
                      const char *name1, const char *image1,                 //
                      const char *name2, const char *image2, int index_nr);  //
bool write_free_http_textbuf(struct aie_cgi_parameter *cgi_parameter);       //
#ifdef __cplusplus
}
#endif
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

