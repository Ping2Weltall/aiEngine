/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_cgi_data.h                                              */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003 - Globales remake @Secur nach Datenverlust in Canada   */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_CGI_DATA_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_CGI_DATA_H

#define AIE_AGENT_AIENGINE		is_AIE_AGENT_AIENGINE()


#define HTTP_HEAD_KEYWORD_STD             1

#define HTEQUIV                           0
#define HTNAME                            1

#define SFrameSetNone                     "0"
#define SFrameSetIsTopOfWindow            "1"

#define FrameSetNone                      0
#define FrameSetIsTopOfWindow             1
#define SFrameSetTop                      "-1" // "80"
#define FrameSetTop                       -1  // 80

#define aIEngine_FrameName                "aIEngine"
#define FrameNameTopOfWindow              aIEngine_FrameName
#define FrameNameUtilFrame                "Utils0815"

#define aIEngine_cfg_var_appl_title             "title"
#define aIEngine_cfg_var_audience               "audience"
#define aIEngine_cfg_var_author                 "author"
#define aIEngine_cfg_var_channel                "channel"
#define aIEngine_cfg_var_classification         "classification"
#define aIEngine_cfg_var_copyright              "copyright"
#define aIEngine_cfg_var_created                "created"
#define aIEngine_cfg_var_content_language       "content-language"
#define aIEngine_cfg_var_content_style_type     "content-style-type"
#define aIEngine_cfg_var_content_type           "content-type"
#define aIEngine_cfg_var_date                   "date"
#define aIEngine_cfg_var_expires                "expires"
#define aIEngine_cfg_var_home_url               "siteinfo"
#define aIEngine_cfg_var_email                  "email"
#define aIEngine_cfg_var_generator              "generator"
#define aIEngine_cfg_var_keywords               "keywords"
#define aIEngine_cfg_var_description            "description"
#define aIEngine_cfg_var_language               "language"
#define aIEngine_cfg_var_page_type              "page-type"
#define aIEngine_cfg_var_page_topic             "page-topic"
#define aIEngine_cfg_var_proxy_keep_alive       "proxy-keep-alive"
#define aIEngine_cfg_var_publisher              "publisher"
#define aIEngine_cfg_var_robots                 "robots"
#define aIEngine_cfg_var_resource_type          "resource-type"
#define aIEngine_cfg_var_reply_to               "reply to"
#define IEngine_cfg_var_server_version          "server_version"
#define aIEngine_cfg_var_siteinfo               "siteinfo"
#define aIEngine_cfg_var_revisit_after          "revisit-after"
#define aIEngine_cfg_var_linked_from            "Linked-From"
#define aIEngine_cfg_var_made_4_ip              "Made-4-IP"

#define aIEngine_ini_val_appl_title             AIENGINE_VAR_TITLE
#define aIEngine_ini_val_channel                AIENGINE_VAR_CHANNEL
#define aIEngine_ini_val_classification         AIENGINE_VAR_CLASSIFICATION
#define aIEngine_ini_val_copyright              AIENGINE_VAR_COPYRIGHT
#define aIEngine_ini_val_server_version         AIENGINE_VAR_SERVER_VERSION
#define aIEngine_ini_val_home_url               AIENGINE_VAR_HOME_URL
#define aIEngine_ini_val_author                 AIENGINE_VAR_AUTHOR
#define aIEngine_ini_val_generator              AIENGINE_VAR_GENERATOR
#define aIEngine_ini_val_description            AIENGINE_VAR_DESCRIPTION
#define aIEngine_ini_val_keywords               AIENGINE_VAR_KEYWORDS
#define aIEngine_ini_val_language               AIENGINE_VAR_LANGUAGE
#define aIEngine_ini_val_audience               AIENGINE_VAR_AUDIENCE
#define aIEngine_ini_val_proxy_keep_alive       AIENGINE_VAR_PROXY
#define aIEngine_ini_val_publisher              AIENGINE_VAR_PUBLISHER
#define aIEngine_ini_val_siteinfo               AIENGINE_VAR_SITEINFO
#define aIEngine_ini_val_robots                 AIENGINE_VAR_ROBOTS
#define aIEngine_ini_val_reply_to               AIENGINE_VAR_REPLY_TO
#define aIEngine_ini_val_resource_type          AIENGINE_VAR_RESOURCE_TYP
#define aIEngine_ini_val_page_type              AIENGINE_VAR_PAGE_TYP
#define aIEngine_ini_val_page_topic             AIENGINE_VAR_PAGE_TOPIC
#define aIEngine_ini_val_revisit_after          AIENGINE_VAR_REVISIT_AFTER
#define aIEngine_ini_val_expires                AIENGINE_VAR_EXPIRES
#define aIEngine_ini_val_created                AIENGINE_VAR_CREATED
#define aIEngine_ini_val_content_style_type     AIENGINE_VAR_CONTENT_STYLE
#define aIEngine_ini_val_content_type           AIENGINE_VAR_CONTENT_TYP
#define aIEngine_ini_val_content_language       AIENGINE_VAR_CONTENT_LANGUAGE
#define aIEngine_ini_val_email                  AIENGINE_VAR_EMAIL
#define aIEngine_ini_val_date                   AIENGINE_VAR_DOCDATE

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/

#ifndef BACKGROUND_MODUL

extern const char *html_tags_tbl_std_tbl_row_col_start;
extern const char *html_tags_tbl_std_row_col_start;
extern const char *html_tags_tbl_std_col_row_change;
extern const char *html_tags_tbl_std_row_change;
extern const char *html_tags_tbl_std_col_change;
extern const char *html_tags_tbl_std_col_row_end;
extern const char *html_tags_tbl_std_col_row_tbl_end;

extern const char *_html_b;
extern const char *_html_e;

extern const char *html_select;
extern const char *html_select_n;
extern const char *html_s_e_select;

extern const char *html_table;
extern const char *html_v_table;
extern const char *html_w_v_table;
extern const char *html_w_v_bg_table;
extern const char *html_s_e_table;
extern const char *html_s_tr;
extern const char *html_tr;
extern const char *html_s_e_tr;
// TD
extern const char *html_td;
extern const char *html_s_td;
//extern const char *html_v_td;
extern const char *html_vm_td;
extern const char *html_wlt_td;
extern const char *html_wrt_td;
extern const char *html_wh_td;
extern const char *html_wt_td;
extern const char *html_t_td;
extern const char *html_rt_td;
extern const char *html_ct_td;
extern const char *html_cs_td;
extern const char *html_cslt_td;
extern const char *html_rs_td;

extern const char *html_bg_td;
extern const char *html_whbg_td;
extern const char *html_whmbg_td;
extern const char *html_wmbg_td;
extern const char *html_wacbg_td;
extern const char *html_acbg_td;
extern const char *html_csacbg_td;
extern const char *html_csacvm_td;
extern const char *html_csacvt_td;
extern const char *html_cscmbg_td;
extern const char *html_cscbbg_td;
extern const char *html_cshbg_td;
extern const char *html_cshacbg_td;
extern const char *html_cswacbg_td;

extern const char *html_al_td;
extern const char *html_ac_td;
extern const char *html_ar_td;
extern const char *html_vt_td;
extern const char *html_alvt_td;
extern const char *html_arvt_td;
extern const char *html_amvc_td;
extern const char *html_amvt_td;
extern const char *html_s_e_td;

extern const char *html_input;

extern const char *html_a;
extern const char *html_s_e_a;
//extern const char *html_b;
extern const char *html_s_b_b;
extern const char *html_s_e_b;
//extern const char *html_br;
//extern const char *html_hr;
//extern const char *html_nbsp;
extern const char *html_s_br;
extern const char *html_s_br2;
extern const char *html_s_hr;
extern const char *html_s_nbsp;

extern const char *html_font;
extern const char *html_font_s;
extern const char *html_font_c;
extern const char *html_font_sc;
extern const char *html_s_e_font;

extern const char *html_form;
extern const char *html_s_e_form;
extern const char *html_center;
extern const char *html_s_e_center;
extern const char *html_frameset;
extern const char *html_s_e_frameset;
extern const char *html_html;
extern const char *html_s_e_html;
//extern const char *html_small;
extern const char *html_s_b_small;
extern const char *html_s_e_small;
extern const char *html_head;
extern const char *html_s_e_head;
extern const char *html_title;
extern const char *html_s_e_title;
extern const char *html_body;
extern const char *html_s_e_body;
extern const char *html_noscript;
extern const char *html_s_e_noscript;
extern const char *html_start_js;
extern const char *html_end_js;

//extern const char *ht_table_100p;
//extern const char *ht_table_b0;
//extern const char *ht_table_b1;
//extern const char *ht_table_dashed_frame;
#endif

extern bool FlushOut;

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

