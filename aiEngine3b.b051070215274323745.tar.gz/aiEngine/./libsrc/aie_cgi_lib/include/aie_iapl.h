/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_iapl.h                                                  */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Neue CGI Variablen fuer den WinGui Client   */
/*             :               : Interne Namen starten nun mit is_aie_       */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklariert             */
/*.............+...............+.............................................*/
/* 04.05.2004  : ALH           : Anpassungen einiger Variablen               */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_IAPL_H                                                           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_IAPL_H                                                           //

#define AIENGINE_EMPTY_CGI_VAR_REMOTE_2_LOCAL                   \
struct aie_cgi_var_remote_2_local cgi_var_remote_2_local[] =    \
{                                                               \
   { "",      /* char *remote */                                \
     "",   }  /* char *local  */                                \
};                                                              \
unsigned int aie_size_cgi_var_remote_2_local = 0;                            //
                                                                             //
// Globale CGI Variablen fuer alle Anwendungen                               //
// beginnend mit '.', '#' und 'z'                                            //
                                                                             //
// ------------- Reservierte Variablen -------------                         //
#define isFunctionCGIVar                        ".-0"                        //
#define isSubFunctionCGIVar                     ".-s"                        //
#define isNameCGIVar                            ".-1"                        //
#define isMenueCGIVar                           ".-2"                        //
#define isFileCGIVar                            ".-3"                        //
#define isFrameCGIVar                           ".-4"                        //
#define isParentPageCGIVar                      ".-5"                        //
#define isParentFrameCGIVar                     ".-6"                        //
#define isNoJavaScriptCGIVar                    ".-9"                        //
#define isFormularNameCGIVar                    ".fn"                        //
                                                                             //
#define isPopUpCGIVar                           ".pa"                        //
#define isPopUpSequenzNummerCGIVar              ".pn"                        //
#define isPageCheatCGIVar                       ".c1"                        //
                                                                             //
#define isBrowserCGIVar                         "._a"                        //
#define isBrowserVersionCGIVar                  "._b"                        //
                                                                             //
#define isAdCGIVar                              ".$$"                        //
#define isAdKategorieCGIVar                     ".$k"                        //
#define isAdTypCGIVar                           ".$t"                        //
#define isAdMaxCGIVar                           ".$m"                        //
                                                                             //
                                                                             //
#define isGruppeCGIVar                          ".>0"                        //
#define isSessionCGIVar                         ".>1"                        //
#define isIPCGIVar                              ".>2"                        //
#define isUserCGIVar                            ".>3"                        //
#define isPasswdCGIVar                          ".>4"                        //
#define isNeedPasswdCGIVar                      ".>5"                        //

#define is_aie_NameCGIVar                       ".-1"                        //
#define is_aie_GruppeCGIVar                     ".>0"                        //
#define is_aie_SessionCGIVar                    ".>1"                        //
#define is_aie_IPCGIVar                         ".>2"                        //
#define is_aie_NeedPasswdCGIVar                 ".>5"                        //
#define is_aie_UserCGIVar                       isUserCGIVar
#define is_aie_PasswordCGIVar                   isPasswdCGIVar
                                                                             //
#define isLoginTryCGIVar                        ".<0"                        //
#define isLoginTxtCGIVar                        ".<1"                        //
                                                                             //
#define isMultiPartDataFileCGIVar		".--"                        //
#define isMultiPartDataSizeCGIVar               ".-a"                        //
#define isMultiPartDataNameCGIVar               ".-b"                        //
#define isMultiPartDataTypeCGIVar               ".-c"                        //

#define is_aie_SeriennummerCGIVar               "@Reg"
								             //
                                                                             //
#define isaIEngineInfoPageCGIVal                "#-#"                        //
#define isFromCGIVar                            "###"                        //
#define isCodedCGIVar                           "**"                         //
#define isMagicCGIVar                           "#^#"                        //
#define isLifeCGIVar                            "#$#"                        //
#define isErrorCGIVar                           ".Er"                        //
                                                                             //
// Die folgenden Werte muessen zu gueltigen JavaScript Variablen umgeformt   //
// werden koennen d.h. der Anfangsbuchstabe muss in alpha zeichen sein       //
#define isSucheCGIVar                           "zx0"                        //
#define isSuchenInCGIVar                        "zx1"                        //
#define isSucheAlleCGIVar                       "zx2"                        //
#define isSucheBtnCGIVar                        "zx3"                        //
                                                                             //
// Reservierte Werte                                                         //
// ------------------ Index ------------------------                         //
#define isIndexPageCGIVal                       ".@*"                        //
#define isSubFramePageCGIVal                    ".@-"                        //
#define isPopUpPageCGIVal                       ".@#"                        //
// ------------------ Frame ------------------------                         //
#define isMainPageCGIVal                        ".@0"                        //
#define isWorkPageCGIVal                        ".@1"                        //
#define isVersionPageCGIVal                     ".@2"                        //
                                                                             //
// ------------------ System -----------------------                         //
#define isBannerPageCGIVal                      ".ad"                        //
#define isPageNotFoundCGIVal                    ".zx"                        //
#define isPageRelocateCGIVal                    ".zy"                        //
                                                                             //
#define isPageCheatPopUpCGIVal                  ".@c"                        //

#define is_aie_UserAnmeldungPageCGIVal          ".@<"                        //
#define is_aie_UserAbmeldungPageCGIVal          ".@>"                        //
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Strukturen jetzt in aie_struct.h                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifndef AIE_SMALLBUILD
#ifdef __cplusplus
extern "C" {
#endif

time_t aie_GetCGIValueDateTime(AIE_CGI_STANDARD_FKT_PARAMETER, const char *var);
double aie_GetCGIValueDouble(AIE_CGI_STANDARD_FKT_PARAMETER, const char *var);
float aie_GetCGIValueFloat(AIE_CGI_STANDARD_FKT_PARAMETER, const char *var);
int aie_unescapechar(char *url);                                             //
struct aie_cgi_variables *aie_LoadCGIVariables(struct aie_cgi_parameter      //
                                                  *cgi_parameter);           //
struct aie_cgi_variables *aie_LoadCGIVariablesFromString(
                                                     const char *clientinput,//
                                                     struct aie_cgi_parameter//
						            *cgi_parameter); //
//#if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
//void _aie_doCleanUpCGIVars(const char *file, int line, struct aie_cgi_parameter *cgi_parameter);
//#else
void aie_CleanUpCGIVars(struct aie_cgi_parameter *cgi_parameter);            //
//#endif

//#if !AIENGINE_INLINE_FKT
int aie_GetIntCGIValue(struct aie_cgi_parameter *cgi_parameter,              //
                       const char *name);
char *aie_GetCharCGIValue(struct aie_cgi_parameter *cgi_parameter,           //
                      const char *name);
//#endif
                                                                             //
struct aie_cgi_variables *aie_SetCharCGIValue(struct aie_cgi_parameter       //
                                                 *cgi_parameter,             //
						 char *name, char *value);   //
struct aie_cgi_variables *aie_SetCGIVarsFromProgLink(const struct
                                                            aie_link_vars    //
                                                        *link_vars,          //
                                                 int size,                   //
                                                 struct aie_cgi_parameter    //
					                *cgi_parameter);     //
struct aie_cgi_variables *aie_GetCharListCGIValue(struct aie_cgi_parameter   //
                                                     *cgi_parameter,         //
                                     const char *name,                       //
                                     struct aie_cgi_variables                //
				                          **vars_base);      //
void aie_CleanCharListCGIValue(struct aie_cgi_variables **vars_base);        //
//char aie_EvalFrameSet(struct aie_cgi_parameter *cgi_parameter);              //
//char *aie_isPageName(struct aie_cgi_parameter *cgi_parameter);               //
const char *aie_get_upload_image_path(void);                                 //
#ifdef __cplusplus
}
#endif
#endif                                                                             //
#if AIENGINE_INLINE_FKT
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
#define aie_GetIntCGIValue(cgi_parameter, name) \
{ \
   const char *ptr; \
   (__builtin_expect( \
	    ((ptr = aie_GetCharCGIValue(cgi_parameter, name)) != NULL),true)) \
   ? atoi(ptr) : 0; \
} 

#define aie_GetCharCGIValue(cgi_parameter, name) \
{ \
   char *ptr = NULL; \
   if (__builtin_expect((cgi_parameter != NULL), true)) \
   { \
      struct aie_cgi_variables *cgi_vars_ptr = cgi_parameter->cgi_variables;\
      while(cgi_vars_ptr != NULL)\
      {\
         if (__builtin_expect((strcmp(cgi_vars_ptr->nam, name) == 0),false))\
         {\
            ptr = cgi_vars_ptr->val;\
            break; \
         } \
         cgi_vars_ptr = cgi_vars_ptr->next; \
      } \
   } \
   ptr; \
} 
#error hier
#endif
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

