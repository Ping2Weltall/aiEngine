/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_cgi_define.h                                            */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 12.12.2006 (Split clientlib und cgi_lib)                    */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_CGI_DEFINE_H 

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_CGI_DEFINE_H

// Globale Stringliste fuer Eingabemasken fehler
#define	AIE_HTML_MASK_FLD_STRL	      "aie_html_masken_felder_stringliste"
#define AIE_HTML_MASK_FLD(a, b)	      \
               AIE_STRL_PUSH_VAR(AIE_HTML_MASK_FLD_STRL, \
		                               aie_StrEmpty(a) ? "*" : a, \
					       aie_StrEmpty(b) ? "*" : b)
#define	AIE_HTML_MASK_STRL	      "aie_html_masken_stringliste"
#define AIE_HTML_MASKE_FEHLER(a)      \
                                   aie_stringlist_add(AIE_HTML_MASK_STRL,#a, a)
#define AIE_HTML_MASKE_HAS_FEHLER(a)  aie_stringlist_has_value(AIE_HTML_MASK_STRL, a)

#define AIE_STRL_PUSH_VAR(id, var1, var2)    aie_stringlist_add(id, var1, var2)
#define AIE_STRL_SET_VAR(id, var1, var2)    aie_stringlist_replace_add(id, var1, var2)
   
#define AIE_STRL_PUSH(id, var)	 AIE_STRL_PUSH(id, #var, var)

// Trace
//#define aie_CleanUpCGIVars(a) _aie_doCleanUpCGIVars(__FILE__, __LINE__, a)

#define AIE_STANDARD_CGI_MAIN(cgi_runinfo)                              \
int main(void)                                                          \
{                                                                       \
   int rc;                                                              \
   struct aie_aIEngine_parameter aIEngineParameter;                     \
   aIEngineParameter.aIEngineMode = AIENGINE_RUN_AS_CGI;                \
   aIEngineParameter.Name = cgi_runinfo.cgiModul;                       \
   aIEngineParameter.Titel = cgi_runinfo.cgiTitel;                      \
   aIEngineParameter.StartFrameCGIVal = cgi_runinfo.StartFrame;         \
   aIEngineParameter.StartPageCGIVal = cgi_runinfo.StartPage;           \
   aIEngineParameter.cgi_parameter = NULL;                              \
   aIEngineParameter.dyn_cgi_parameter = false;                         \
   aIEngineParameter.cgi_hooks = &cgi_runinfo.cgi_hooks;                \
   aIEngineParameter.TraceMemory = true;                                \
   if (__builtin_expect((aie_Init_aIEngineClient(&aIEngineParameter)),  \
	                                                         true)) \
   {                                                                    \
      rc = aIEngineClient(&aIEngineParameter);                          \
      aie_Exit_aIEngineClient(&aIEngineParameter);                      \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      rc = AIENGINE_INIT_FAILED;                                        \
   }                                                                    \
   return(rc);                                                          \
}

#if 0
#define AIE_STATUS_SITEMAP_SPEICHERN_OK			0
#define AIE_STATUS_SITEMAP_SPEICHERN_FAIL		1
#endif

#define AIE_CGI_STANDARD_PARAMETER	cgi_parameter
#ifdef __GNUC__
#define AIE_CGI_STANDARD_FKT_PARAMETER	struct aie_cgi_parameter \
			                       *AIE_CGI_STANDARD_PARAMETER \
					       __attribute__ ((unused))
#else
#define AIE_CGI_STANDARD_FKT_PARAMETER	struct aie_cgi_parameter \
			                       *AIE_CGI_STANDARD_PARAMETER
#endif
#define aie_SetCGIValueCharPtr(a, b)		\
                             aie_SetCharCGIValue(AIE_CGI_STANDARD_PARAMETER, \
				         (a != NULL ? aie_strdup(a) : NULL), \
				         (b != NULL ? aie_strdup(b) : NULL))
#define aie_SetCGIValueInt(a, b)		\
                              aie_SetCharCGIValue(AIE_CGI_STANDARD_PARAMETER, a, aie_IntToStr(b))
#define aie_SetCGIValueBool(a, b)	aie_SetCGIValueInt(a, b ? 1 : 0)
#define aie_SetCGIValue(a, b)		aie_SetCGIValueCharPtr(a, b)

#define aie_CGIValueCharPtr(a)		aie_GetCGIValueCharPtr(a)
					
#define aie_GetCGIValueCharPtr(a)		\
                             aie_GetCharCGIValue(AIE_CGI_STANDARD_PARAMETER, a)
#define aie_GetCGIValueInt(a)		\
                              aie_GetIntCGIValue(AIE_CGI_STANDARD_PARAMETER, a)

#define aie_CGIValueCharVar(a, b)	const char *a = \
                                                      aie_GetCGIValueCharPtr(b)
#define aie_CGIValueStrStr(a, b)        (aie_CGIValueEmpty(a) || \
                                         aie_StrEmpty(b) ? NULL : \
                                                   (strstr(aie_CGIValue(a), b))
#define aie_CGIValueEmpty(a)		aie_StrEmpty(aie_GetCGIValueCharPtr(a))
#define aie_CGIValuePtr(a)		aie_GetCGIValueCharPtr(a)
#define aie_CGIValueVar(a, b)		aie_CGIValueCharVar(a, b)
#define aie_CGIValueIntVar(a, b)	int  a = aie_GetCGIValueInt(b)
#define aie_CGIValueInt(a)		aie_GetCGIValueInt(a)
#define aie_CGIValueBoolVar(a, b)	bool  a = aie_GetCGIValueInt(b)
#define aie_CGIValueBool(a)	        (bool) \
                                        (aie_CGIValueEmpty(a) \
					? false : \
                                          ((aie_GetCGIValueInt(a) != 0) || \
					   (strstr(aie_CGIValuePtr(a), "true") \
					                              != NULL) \
					   ? true : false ))
//				   (aie_CGIValueStrStr(a, "true") != NULL) 
#define aie_CGIValueBoolCmp(a, b)	(bool)((aie_CGIValuePtr(a) != NULL) &&\
                                        (*aie_CGIValuePtr(a) == b))
#define aie_CGIValueDateTimeVar(a, b)	time_t  a = aie_GetCGIValueDateTime(AIE_CGI_STANDARD_PARAMETER, b)
#define aie_CGIValueDateTime(a)         aie_GetCGIValueDateTime(AIE_CGI_STANDARD_PARAMETER, a)
#define aie_CGIValueDouble(a)	        aie_GetCGIValueDouble(AIE_CGI_STANDARD_PARAMETER, a)
#define aie_CGIValueFloat(a)	        aie_GetCGIValueFloat(AIE_CGI_STANDARD_PARAMETER, a)
#if 0
#define aie_CGIValueDateTime(a)		{ \
                                          const char *tmp_aie_CGIPtr = \
                                          aie_CGIValue(a) != NULL ?  \
					  aie_StrToDateTime(tmp_aie_CGIPtr) \
					  : 0 \
                                        }
#define aie_CGIValueDouble(a)	\
                    {const char *tmp_aie_CGIPtr = aie_CGIValue(a) != NULL \
                                        ? atof(tmp_aie_CGIPtr) : 0.0 }
#endif
#define aie_CGIValueDoubleVar(a, b)	const double a = aie_CGIValueDouble(b)
#define aie_CGIValue(a)			aie_GetCGIValueCharPtr(a)
#define AIE_GET_STD_VAR			aie_GetStandardAsecurVariableValue
#define AIE_GET_ENV_VAR			aie_get_aIEngine_env
#define AIE_GET_CHAR_CGI_VAR_PTR	aie_GetCGIValueCharPtr

#define aie_CGIPageNamePtr		aie_GetCGIValueCharPtr(isNameCGIVar)
#define aie_CGIPageNameCharPtr		aie_CGIValueCharPtr(isNameCGIVar)
#define aie_CGIPageNameCharVar(a)	aie_CGIValueCharVar(a, isNameCGIVar)
#define aie_CGIFrameSetCharPtr		aie_CGIValueCharPtr(isFrameCGIVar)
#define aie_CGIFrameSetCharVar(a)	aie_CGIValueCharVar(a, isFrameCGIVar)
#define aie_CGIFrameSetInt		aie_CGIValueInt(isFrameCGIVar)
#define aie_CGIFrameSetIntVar(a)	aie_CGIValueIntVar(a, isFrameCGIVar)
#define aie_CGIMenueItemCharPtr		aie_CGIValueCharPtr(isMenueCGIVar)
#define aie_CGIFunctionCharPtr	        aie_CGIValueCharPtr(isFunctionCGIVar)

#define aie_CGIFunctionInt	 	aie_CGIValueInt(isFunctionCGIVar)
#define aie_CGIFrameSet			aie_CGIFrameSetCharPtr
#define aie_CGIPageName			aie_CGIPageNameCharPtr
#define aie_CGISession			aie_CGIValueCharPtr(isSessionCGIVar)
#define aie_CGIUser			aie_CGIValueCharPtr(isUserCGIVar)
#define aie_CGIGruppe			aie_CGIValueCharPtr(isGruppeCGIVar)
#define aie_CGIPasswd			aie_CGIValueCharPtr(isPasswdCGIVar)
#define aie_CGIIPClient			aie_CGIValueCharPtr(isIPCGIVar)
#define aie_CGIMenueItem		aie_CGIMenueItemCharPtr
#define aie_CGIFunction			aie_CGIFunctionCharPtr

#define aie_CGIMenueItemCharVar(a)	aie_CGIValueCharVar(a, isMenueCGIVar)
#define aie_CGIMenueItemIntVar(a)	aie_CGIValueIntVar(a, isMenueCGIVar)
#define aie_CGIFunctionCharVar(a)	aie_CGIValueCharVar(a, isFunctionCGIVar)
#define aie_CGIFunctionIntVar(a)	aie_CGIValueIntVar(a, isFunctionCGIVar)
#define aie_CGIFrameSetVar(a)		aie_CGIFrameSetCharVar(a)
#define aie_CGIPageNameVar(a)		aie_CGIPageNameCharVar(a)
#define aie_CGISessionVar(a)		aie_CGIValueCharVar(a, isSessionCGIVar)
#define aie_CGIUserVar(a)		aie_CGIValueCharVar(a, isUserCGIVar)
#define aie_CGIGruppeVar(a)		aie_CGIValueCharVar(a, isGruppeCGIVar)
#define aie_CGIPasswdVar(a)		aie_CGIValueCharVar(a, isPasswdCGIVar)
#define aie_CGIIPClientVar(a)		aie_CGIValueCharVar(a, isIPCGIVar)
#define aie_CGIMenueItemVar(a)		aie_CGIMenueItemCharVar(a)
#define aie_CGIFunctionVar(a)		aie_CGIFunctionCharVar(a)

#define aie_CGIRemoteAddrVar(a)		aie_VariableVar(a, AIE_GET_ENV_VAR, \
                                                      AIENGINE_ENV_REMOTE_ADDR)
#define aie_CGIRemotePortVar(a)		aie_VariableVar(a, AIE_GET_ENV_VAR, \
                                                      AIENGINE_ENV_REMOTE_PORT)
#define aie_CGIUserAgentVar(a)		aie_VariableVar(a, AIE_GET_ENV_VAR, \
                                                AIENGINE_ENV_HTTP_USER_AGENT)
#define aie_CGIRefererVar(a)		aie_VariableVar(a, AIE_GET_ENV_VAR, \
                                                AIENGINE_ENV_HTTP_REFERER)
#define aie_VariableVar(a, b, c)	const char *a = b(c)
#define aie_VariableDup(a, b, c)	char *a = (c != NULL) ? \
                                        aie_StrdupDynMemory(b(c)) : NULL

#define aie_CGIhasJavascript		\
		                        (__builtin_expect( \
		(aie_GetCGIValueCharPtr(isNoJavaScriptCGIVar) == NULL),\
		                                                       true))

#define AIE_FKT_NAME_REGISTER(a, b, c)	aIEngine_Register(a, b, c)

#define AIE_STRUCT_PAGE_CGI_DISPATCH		const struct aie_page_cgi_dispatch \
                                                     page_cgi_dispatch[]

#define AIE_SIZE_PAGE_CGI_DISPATCH	aie_SizeOfStruct(page_cgi_dispatch, \
                                                    aie_page_cgi_dispatch);

#define AIE_INT_VAR_SIZE_PAGE_CGI_DISPATCH	unsigned int aie_size_page_cgi_dispatch = \
                                            AIE_SIZE_PAGE_CGI_DISPATCH

#define AIE_EXTERN_PAGE_CGI_DISPATCH	extern AIE_STRUCT_PAGE_CGI_DISPATCH; \
					extern unsigned int aie_size_page_cgi_dispatch;
					
#define AIE_FKT_REGISTER_PAGE_CGI_DISPATCH	\
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_PAGE_CGI_DISPATCH, \
				      (void *)&page_cgi_dispatch, \
				      aie_size_page_cgi_dispatch)

#define AIE_STRUCT_FRAME_CGI_DISPATCH	const struct aie_frame_cgi_dispatch \
                                                     frame_cgi_dispatch[]

#define AIE_SIZE_FRAME_CGI_DISPATCH	aie_SizeOfStruct(frame_cgi_dispatch, \
                                                    aie_frame_cgi_dispatch);

#define AIE_INT_VAR_SIZE_FRAME_CGI_DISPATCH unsigned int aie_size_frame_cgi_dispatch = \
                                            AIE_SIZE_FRAME_CGI_DISPATCH


#define AIE_EXTERN_FRAME_CGI_DISPATCH	extern AIE_STRUCT_FRAME_CGI_DISPATCH; \
					extern unsigned int aie_size_frame_cgi_dispatch;

#define AIE_FKT_REGISTER_FRAME_CGI_DISPATCH	\
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_FRAME_CGI_DISPATCH, \
				      (void *)&frame_cgi_dispatch, \
				      aie_size_frame_cgi_dispatch)

// KEYWORDS MACROS
#define AIE_VAR_STRUCT_HTML_KEYWORDS	html_keywords
#define AIE_VAR_SIZE_HTML_KEYWORDS	aie_size_html_keywords
						     
#define AIE_STRUCT_HTML_KEYWORDS	const struct aie_html_keywords \
					        AIE_VAR_STRUCT_HTML_KEYWORDS[]

#define AIE_INT_VAR_SIZE_HTML_KEYWORDS	unsigned int AIE_VAR_SIZE_HTML_KEYWORDS = \
				          aie_SizeOfStruct( \
						AIE_VAR_STRUCT_HTML_KEYWORDS, \
                                                       aie_html_keywords)

#define AIE_EXTERN_HTML_KEYWORDS	extern AIE_STRUCT_HTML_KEYWORDS; \
					extern unsigned int AIE_VAR_SIZE_HTML_KEYWORDS;

#define AIE_FKT_REGISTER_HTML_KEYWORDS \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_KEYWORDS, \
				      (void *)&AIE_VAR_STRUCT_HTML_KEYWORDS, \
				      AIE_VAR_SIZE_HTML_KEYWORDS)


// STATIC VARIABLES MACROS
#define AIE_VAR_STRUCT_STATIC_VARIABLES	aie_static_variablen
#define AIE_VAR_SIZE_STATIC_VARIABLES	aie_size_static_variablen
						     
#define AIE_STRUCT_CGI_STATIC_VARIABLES	struct aie_static_variables \
				        AIE_VAR_STRUCT_STATIC_VARIABLES[]

#define AIE_INT_VAR_SIZE_CGI_STATIC_VARIABLES	unsigned int \
					AIE_VAR_SIZE_STATIC_VARIABLES = \
				          aie_SizeOfStruct( \
					AIE_VAR_STRUCT_STATIC_VARIABLES, \
                                                       aie_static_variables)

#define AIE_EXTERN_STATIC_VARIABLES	extern AIE_STRUCT_CGI_STATIC_VARIABLES; \
					extern unsigned int AIE_VAR_SIZE_STATIC_VARIABLES;

// META_HEAD_INFO MACROS
#define AIE_VAR_STRUCT_META_HEAD_INFO	html_meta_head_info
#define AIE_VAR_SIZE_META_HEAD_INFO	aie_size_meta_head_info
						     
#define AIE_STRUCT_META_HEAD_INFO		const struct aie_meta_head_info \
					        AIE_VAR_STRUCT_META_HEAD_INFO[]

#define AIE_INT_VAR_SIZE_META_HEAD_INFO	unsigned int AIE_VAR_SIZE_META_HEAD_INFO = \
				          aie_SizeOfStruct( \
						AIE_VAR_STRUCT_META_HEAD_INFO, \
                                                       aie_meta_head_info)

#define AIE_EXTERN_META_HEAD_INFO	extern AIE_STRUCT_META_HEAD_INFO; \
					extern unsigned int AIE_VAR_SIZE_META_HEAD_INFO;

#define AIE_FKT_REGISTER_META_HEAD_INFO \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_META_HEAD_INFO, \
				      (void *)&AIE_VAR_STRUCT_META_HEAD_INFO,\
				      AIE_VAR_SIZE_META_HEAD_INFO)


// ------------
#define AIE_STRUCT_CGI_GLOBALE_VARIABLEN	\
			          struct \
				  aie_aIEngine_cgi_globale_variablen \
				  aIEngine_cgi_globale_variablen[]
#define AIE_VAR_SIZE_CGI_GLOBALE_VARIABLEN \
				  aie_size_aIEngine_cgi_globale_variablen

#define AIE_INT_VAR_SIZE_CGI_GLOBALE_VARIABLEN \
        			unsigned int AIE_VAR_SIZE_CGI_GLOBALE_VARIABLEN = \
				aie_SizeOfStruct( \
				      aIEngine_cgi_globale_variablen, \
				      aie_aIEngine_cgi_globale_variablen) 

#define AIE_EXTERN_CGI_GLOBALE_VARIABLEN \
				  extern AIE_STRUCT_CGI_GLOBALE_VARIABLEN; \
			  extern unsigned int AIE_VAR_SIZE_CGI_GLOBALE_VARIABLEN;

#define AIE_FKT_INIT_CGI_GLOBALE_VARIABLEN                               \
				  aie_Init_aIEngine_cgi_variablen(       \
				  aIEngine_cgi_globale_variablen,        \
				  AIE_VAR_SIZE_CGI_GLOBALE_VARIABLEN)

// KNOWN FRAMES Macros
#define AIE_STRUCT_VAR_KNOWN_FRAMES	known_frames
#define AIE_VAR_SIZE_KNOWN_FRAMES	aie_size_known_frames
#define AIE_STRUCT_KNOWN_FRAMES	  const struct aie_known_frames \
				  AIE_STRUCT_VAR_KNOWN_FRAMES[]
#define AIE_SIZE_KNOWN_FRAMES	aie_SizeOfStruct(AIE_STRUCT_VAR_KNOWN_FRAMES, \
                                                      aie_known_frames)

#define AIE_INT_VAR_SIZE_KNOWN_FRAMES	unsigned int AIE_VAR_SIZE_KNOWN_FRAMES = \
                                            AIE_SIZE_KNOWN_FRAMES
#define AIE_EXTERN_KNOWN_FRAMES \
				  extern AIE_STRUCT_KNOWN_FRAMES; \
			  extern unsigned int AIE_VAR_SIZE_KNOWN_FRAMES;
#define AIE_FKT_REGISTER_KNOWN_FRAMES \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_KNOWN_FRAMES, \
				      (void *)&AIE_STRUCT_VAR_KNOWN_FRAMES,\
				      AIE_VAR_SIZE_KNOWN_FRAMES)

// PAGE_REC Macros
#define AIE_STRUCT_VAR_PAGE_REC	page_rec
#define AIE_VAR_SIZE_PAGE_REC	aie_size_page_rec
#define AIE_STRUCT_PAGE_REC	  const struct aie_page_rec \
				  AIE_STRUCT_VAR_PAGE_REC[]
#define AIE_SIZE_PAGE_REC	aie_SizeOfStruct(AIE_STRUCT_VAR_PAGE_REC, \
                                                      aie_page_rec)

#define AIE_INT_VAR_SIZE_PAGE_REC	unsigned int AIE_VAR_SIZE_PAGE_REC = \
                                            AIE_SIZE_PAGE_REC
#define AIE_EXTERN_PAGE_REC \
				  extern AIE_STRUCT_PAGE_REC; \
			  extern unsigned int AIE_VAR_SIZE_PAGE_REC;
#define AIE_FKT_REGISTER_PAGE_REC \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_PAGE_REC, \
				      (void *)&AIE_STRUCT_VAR_PAGE_REC,\
				      AIE_VAR_SIZE_PAGE_REC)
// BASIC REC Macros
#define AIE_STRUCT_VAR_BASIC_REC	basic_rec
#define AIE_VAR_SIZE_BASIC_REC	aie_size_basic_rec
#define AIE_STRUCT_BASIC_REC	  const struct aie_basic_rec \
				  AIE_STRUCT_VAR_BASIC_REC[]
#define AIE_SIZE_BASIC_REC	aie_SizeOfStruct(AIE_STRUCT_VAR_BASIC_REC, \
                                                      aie_basic_rec)

#define AIE_INT_VAR_SIZE_BASIC_REC	unsigned int AIE_VAR_SIZE_BASIC_REC = \
                                            AIE_SIZE_BASIC_REC
#define AIE_EXTERN_BASIC_REC \
				  extern AIE_STRUCT_BASIC_REC; \
			  extern unsigned int AIE_VAR_SIZE_BASIC_REC;
#define AIE_FKT_REGISTER_BASIC_REC \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_BASIC_REC, \
				      (void *)&AIE_STRUCT_VAR_BASIC_REC,\
				      AIE_VAR_SIZE_BASIC_REC)

// KNOWN_MENUES Macros
#define AIE_STRUCT_VAR_KNOWN_MENUES	known_menues
#define AIE_VAR_SIZE_KNOWN_MENUES	aie_size_known_menues
#define AIE_KNOWN_MENUES	  const struct aie_known_menues \
				  AIE_STRUCT_VAR_KNOWN_MENUES[]
#define AIE_SIZE_KNOWN_MENUES	aie_SizeOfStruct(AIE_STRUCT_VAR_KNOWN_MENUES, \
                                                      aie_known_menues)

#define AIE_INT_VAR_SIZE_KNOWN_MENUES	unsigned int AIE_VAR_SIZE_KNOWN_MENUES = \
                                            AIE_SIZE_KNOWN_MENUES
#define AIE_EXTERN_KNOWN_MENUES \
				  extern AIE_KNOWN_MENUES; \
			  extern unsigned int AIE_VAR_SIZE_KNOWN_MENUES;
#define AIE_FKT_REGISTER_KNOWN_MENUES \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_KNOWN_MENUES, \
				      (void *)&AIE_STRUCT_VAR_KNOWN_MENUES,\
				      AIE_VAR_SIZE_KNOWN_MENUES)

// STANDARD_IMP Macros
#define AIE_STRUCT_VAR_STANDARD_IMP	standard_imp
#define AIE_VAR_SIZE_STANDARD_IMP	aie_size_standard_imp
#define AIE_STANDARD_IMP	  const struct aie_standard_imp \
				  AIE_STRUCT_VAR_STANDARD_IMP[]
#define AIE_SIZE_STANDARD_IMP	aie_SizeOfStruct(AIE_STRUCT_VAR_STANDARD_IMP, \
                                                      aie_standard_imp)

#define AIE_INT_VAR_SIZE_STANDARD_IMP	unsigned int AIE_VAR_SIZE_STANDARD_IMP = \
                                            AIE_SIZE_STANDARD_IMP
#define AIE_EXTERN_STANDARD_IMP \
				  extern AIE_STANDARD_IMP; \
			  extern unsigned int AIE_VAR_SIZE_STANDARD_IMP;
#define AIE_FKT_REGISTER_STANDARD_IMP \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_STANDARD_IMP, \
				      (void *)&AIE_STRUCT_VAR_STANDARD_IMP,\
				      AIE_VAR_SIZE_STANDARD_IMP)

// PAGE_JAVASCRIPT Macros
#define AIE_STRUCT_VAR_PAGE_JAVASCRIPT		page_javascript
#define AIE_VAR_SIZE_PAGE_JAVASCRIPT	aie_size_page_javascript
#define AIE_STRUCT_PAGE_JAVASCRIPT	  const struct aie_page_javascript \
				  AIE_STRUCT_VAR_PAGE_JAVASCRIPT[]
#define AIE_SIZE_PAGE_JAVASCRIPT	aie_SizeOfStruct(AIE_STRUCT_VAR_PAGE_JAVASCRIPT, \
                                                      aie_page_javascript)

#define AIE_INT_VAR_SIZE_PAGE_JAVASCRIPT	unsigned int AIE_VAR_SIZE_PAGE_JAVASCRIPT = \
                                            AIE_SIZE_PAGE_JAVASCRIPT
#define AIE_EXTERN_PAGE_JAVASCRIPT \
				  extern AIE_STRUCT_PAGE_JAVASCRIPT; \
			  extern unsigned int AIE_VAR_SIZE_PAGE_JAVASCRIPT;
#define AIE_FKT_REGISTER_PAGE_JAVASCRIPT \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_PAGE_JAVASCRIPT, \
				      (void *)&AIE_STRUCT_VAR_PAGE_JAVASCRIPT,\
				      AIE_VAR_SIZE_PAGE_JAVASCRIPT)

// FOLLOW_CGI_VARS Macros
#define AIE_STRUCT_VAR_FOLLOW_CGI_VARS		follow_cgi_vars
#define AIE_VAR_SIZE_FOLLOW_CGI_VARS	aie_size_follow_cgi_vars
#define AIE_STRUCT_FOLLOW_CGI_VARS	  const struct aie_follow_cgi_vars \
				  AIE_STRUCT_VAR_FOLLOW_CGI_VARS[]
#define AIE_SIZE_FOLLOW_CGI_VARS	aie_SizeOfStruct(AIE_STRUCT_VAR_FOLLOW_CGI_VARS, \
                                                      aie_follow_cgi_vars)

#define AIE_INT_VAR_SIZE_FOLLOW_CGI_VARS	unsigned int AIE_VAR_SIZE_FOLLOW_CGI_VARS = \
                                            AIE_SIZE_FOLLOW_CGI_VARS
#define AIE_EXTERN_FOLLOW_CGI_VARS \
				  extern AIE_STRUCT_FOLLOW_CGI_VARS; \
			  extern unsigned int AIE_VAR_SIZE_FOLLOW_CGI_VARS;
#define AIE_FKT_REGISTER_FOLLOW_CGI_VARS \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_FOLLOW_CGI_VARS, \
				      (void *)&AIE_STRUCT_VAR_FOLLOW_CGI_VARS,\
				      AIE_VAR_SIZE_FOLLOW_CGI_VARS)

// CGI_VAR_REMOTE_2_LOCAL Macros
#define AIE_STRUCT_VAR_CGI_VAR_REMOTE_2_LOCAL	cgi_var_remote_2_local	
#define AIE_VAR_SIZE_CGI_VAR_REMOTE_2_LOCAL	aie_size_cgi_var_remote_2_local
#define AIE_CGI_VAR_REMOTE_2_LOCAL	  const struct aie_cgi_var_remote_2_local \
				  AIE_STRUCT_VAR_CGI_VAR_REMOTE_2_LOCAL[]
#define AIE_SIZE_CGI_VAR_REMOTE_2_LOCAL	aie_SizeOfStruct(AIE_STRUCT_VAR_CGI_VAR_REMOTE_2_LOCAL, \
                                                      aie_cgi_var_remote_2_local)

#define AIE_INT_VAR_SIZE_CGI_VAR_REMOTE_2_LOCAL	unsigned int AIE_VAR_SIZE_CGI_VAR_REMOTE_2_LOCAL = \
                                            AIE_SIZE_CGI_VAR_REMOTE_2_LOCAL
#define AIE_EXTERN_CGI_VAR_REMOTE_2_LOCAL \
				  extern AIE_CGI_VAR_REMOTE_2_LOCAL; \
			  extern unsigned int AIE_VAR_SIZE_CGI_VAR_REMOTE_2_LOCAL;
#define AIE_FKT_REGISTER_CGI_VAR_REMOTE_2_LOCAL \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_CGI_VAR_REMOTE_2_LOCAL, \
				      (void *)&AIE_STRUCT_VAR_CGI_VAR_REMOTE_2_LOCAL,\
				      AIE_VAR_SIZE_CGI_VAR_REMOTE_2_LOCAL)
// AD_FILES Macros
#define AIE_STRUCT_VAR_AD_FILES		ad_files
#define AIE_VAR_SIZE_AD_FILES	aie_size_ad_files
#define AIE_AD_FILES	  const struct aie_ad_files \
				  AIE_STRUCT_VAR_AD_FILES[]
#define AIE_SIZE_AD_FILES	aie_SizeOfStruct(AIE_STRUCT_VAR_AD_FILES, \
                                                      aie_ad_files)

#define AIE_INT_VAR_SIZE_AD_FILES	unsigned int AIE_VAR_SIZE_AD_FILES = \
                                            AIE_SIZE_AD_FILES
#define AIE_EXTERN_AD_FILES \
				  extern AIE_AD_FILES; \
			  extern unsigned int AIE_VAR_SIZE_AD_FILES;
#define AIE_FKT_REGISTER_AD_FILES \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_AD_FILES, \
				      (void *)&AIE_STRUCT_VAR_AD_FILES,\
				      AIE_VAR_SIZE_AD_FILES)

// SUB_MEN_PATH Macros
#define AIE_STRUCT_VAR_SUB_MEN_PATHS		sub_men_paths
#define AIE_VAR_SIZE_SUB_MEN_PATHS	aie_size_sub_men_paths
#define AIE_SUB_MEN_PATHS	  const struct aie_sub_men_paths \
				  AIE_STRUCT_VAR_SUB_MEN_PATHS[]
#define AIE_SIZE_SUB_MEN_PATHS	aie_SizeOfStruct(AIE_STRUCT_VAR_SUB_MEN_PATHS, \
                                                      aie_sub_men_paths)

#define AIE_INT_VAR_SIZE_SUB_MEN_PATHS	unsigned int AIE_VAR_SIZE_SUB_MEN_PATHS = \
                                            AIE_SIZE_SUB_MEN_PATHS
#define AIE_EXTERN_SUB_MEN_PATHS \
				  extern AIE_SUB_MEN_PATHS; \
			  extern unsigned int AIE_VAR_SIZE_SUB_MEN_PATHS;
#define AIE_FKT_REGISTER_SUB_MEN_PATHS \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_SUB_MEN_PATHS, \
				      (void *)&AIE_STRUCT_VAR_SUB_MEN_PATHS,\
				      AIE_VAR_SIZE_SUB_MEN_PATHS)

// CGI_VERSION_INFO Macros
#define AIE_STRUCT_VAR_CGI_VERSION_INFO		cgi_version_info
#define AIE_VAR_SIZE_CGI_VERSION_INFO	aie_size_cgi_version_info
#define AIE_CGI_VERSION_INFO	  const struct aie_version_info \
				  AIE_STRUCT_VAR_CGI_VERSION_INFO[]
#define AIE_SIZE_CGI_VERSION_INFO	aie_SizeOfStruct(AIE_STRUCT_VAR_CGI_VERSION_INFO, \
                                                      aie_cgi_version_info)

#define AIE_INT_VAR_SIZE_CGI_VERSION_INFO	unsigned int AIE_VAR_SIZE_CGI_VERSION_INFO = \
                                            AIE_SIZE_CGI_VERSION_INFO
#define AIE_EXTERN_CGI_VERSION_INFO \
				  extern AIE_CGI_VERSION_INFO; \
			  extern unsigned int AIE_VAR_SIZE_CGI_VERSION_INFO;
#define AIE_FKT_REGISTER_CGI_VERSION_INFO \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_CGI_VERSION_INFO, \
				      (void *)&AIE_STRUCT_VAR_CGI_VERSION_INFO,\
				      AIE_VAR_SIZE_CGI_VERSION_INFO)
// MODULE_2_CGIPROG Macros
#define AIE_VAR_SIZE_MODULE_2_CGI_PROG	aie_size_module_2_cgi_prog
#define AIE_STRUCT_VAR_MODULE_2_CGI_PROG	module_2_cgi_prog
#define AIE_STRUCT_MODULE_2_CGI_PROG		const struct aie_module_2_cgi_prog \
					AIE_STRUCT_VAR_MODULE_2_CGI_PROG[]

#define AIE_SIZE_MODULE_2_CGI_PROG	aie_SizeOfStruct(module_2_cgi_prog, \
                                                      aie_module_2_cgi_prog)

#define AIE_INT_VAR_SIZE_MODULE_2_CGI_PROG	unsigned int AIE_VAR_SIZE_MODULE_2_CGI_PROG = \
                                            AIE_SIZE_MODULE_2_CGI_PROG
#define AIE_EXTERN_MODULE_2_CGI_PROG \
				  extern AIE_STRUCT_MODULE_2_CGI_PROG; \
			  extern unsigned int AIE_VAR_SIZE_MODULE_2_CGI_PROG;

#define AIE_FKT_REGISTER_MODULE_2_CGI_PROG \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_MODULE_2_CGI_PROG, \
				      (void *)&AIE_STRUCT_VAR_MODULE_2_CGI_PROG,\
				      AIE_VAR_SIZE_MODULE_2_CGI_PROG)
// BODY_TAG Macros
#define AIE_VAR_SIZE_BODY_TAG	aie_size_body_tag
#define AIE_STRUCT_VAR_BODY_TAG	body_tag
#define AIE_STRUCT_BODY_TAG		const struct aie_aIEngine_body_tag \
					AIE_STRUCT_VAR_BODY_TAG[]

#define AIE_SIZE_BODY_TAG	aie_SizeOfStruct(body_tag, \
                                                      aie_aIEngine_body_tag)

#define AIE_INT_VAR_SIZE_BODY_TAG	unsigned int AIE_VAR_SIZE_BODY_TAG = \
                                            AIE_SIZE_BODY_TAG
#define AIE_EXTERN_BODY_TAG \
				  extern AIE_STRUCT_BODY_TAG; \
			  extern unsigned int AIE_VAR_SIZE_BODY_TAG;

#define AIE_FKT_REGISTER_BODY_TAG \
				AIE_FKT_NAME_REGISTER ( \
				      AIENGINE_REGISTER_BODY_TAG, \
				      (void *)&AIE_STRUCT_VAR_BODY_TAG,\
				      AIE_VAR_SIZE_BODY_TAG)

#define AIE_LINK_VARS			link_vars
#define AIE_STRUCT_LINK_VARS		const struct aie_link_vars \
				                                AIE_LINK_VARS[]
#define AIE_SIZE_LINK_VARS		aie_SizeOfStruct(AIE_LINK_VARS, \
                                                         aie_link_vars)
#define AIE_PROG_LINK			prog_link
#define AIE_STRUCT_PROG_LINK		const struct aie_prog_link \
                                                               AIE_PROG_LINK
#define AIE_STANDARD_HTML_LINK		aie_html_link(AIE_PROG_LINK)
#define AIE_HTML_LINK		        AIE_STANDARD_HTML_LINK
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
// Keine                                                                     //

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

