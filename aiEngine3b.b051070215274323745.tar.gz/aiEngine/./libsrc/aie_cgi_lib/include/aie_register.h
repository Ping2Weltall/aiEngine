/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_register.h                                              */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 02.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 13.12.2005  : ALH           : Anpassung an Version 3.0                    */
/*.............+...............+.............................................*/
/* 29.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_REGISTER_H                                                       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_REGISTER_H                                                       //

#define AIENGINE_REGISTER_KEYWORDS                      0x01
#define AIENGINE_REGISTER_META_HEAD_INFO                0x02
//#define AIENGINE_REGISTER_AD_FILES                      0x03
//#define AIENGINE_REGISTER_IMP_BODY_LINKS                0x04
//#define AIENGINE_REGISTER_STANDARD_IMP                  0x05
#define AIENGINE_REGISTER_PAGE_JAVASCRIPT               0x06
#define AIENGINE_REGISTER_CGI_VAR_REMOTE_2_LOCAL        0x07
//#define AIENGINE_REGISTER_KNOWN_MENUES                  0x08
#define AIENGINE_REGISTER_PAGE_REC                      0x09
//#define AIENGINE_REGISTER_BASIC_REC                     0x0a
#define AIENGINE_REGISTER_KNOWN_FRAMES                  0x0b
#define AIENGINE_REGISTER_MODULE_2_CGI_PROG             0x0c
#define AIENGINE_REGISTER_PAGE_CGI_DISPATCH             0x0d
#define AIENGINE_REGISTER_FRAME_CGI_DISPATCH            0x0e
#define AIENGINE_REGISTER_FOLLOW_CGI_VARS               0x0f
//#define AIENGINE_REGISTER_SUB_MEN_PATHS                 0x10
//#define AIENGINE_REGISTER_CGI_VERSION_INFO              0x11
#define AIENGINE_REGISTER_AIENGINE_ENV                  0x12
#define AIENGINE_REGISTER_BODY_TAG                      0x13
                                                                             //
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Strukturen jetzt in aie_struct.h                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
bool aIEngine_Register(int typ, const void *variable, unsigned int size);
struct aie_html_keywords *getRegistered_html_keywords(unsigned int *size);
struct aie_meta_head_info *getRegistered_meta_head_info(unsigned int *size);
//struct aie_ad_files *getRegistered_ad_files(unsigned int *size);
//struct aie_imp_body_links *getRegistered_imp_body_links(unsigned int *size);
//struct aie_standard_imp *getRegistered_standard_imp(unsigned int *size);
struct aie_page_javascript *getRegistered_page_javascript(unsigned int *size);
//struct aie_cgi_var_remote_2_local *getRegistered_cgi_var_remote_2_local(unsigned int *size);
//struct aie_known_menues *getRegistered_known_menues(unsigned int *size_known_menue);
struct aie_page_rec *getRegistered_page_rec(unsigned int *size);
//struct aie_basic_rec *getRegistered_basic_reg(unsigned int *size);
struct aie_known_frames *getRegistered_known_frames(unsigned int *size);
struct aie_module_2_cgi_prog *getRegistered_module_2_cgi_prog(unsigned int *size);
struct aie_page_cgi_dispatch *getRegistered_page_cgi_dispatch(unsigned int *size);
struct aie_frame_cgi_dispatch *getRegistered_frame_cgi_dispatch(unsigned int *size);
struct aie_follow_cgi_vars *getRegistered_follow_cgi_var(unsigned int *size);
//struct aie_sub_men_paths *getRegistered_sub_men_paths(unsigned int *size);
//struct aie_version_info *getRegistered_cgi_version_info(unsigned int *size);
struct aie_aIEngine_env *getRegistered_aIEngine_env(unsigned int *size);
struct aie_aIEngine_body_tag *getRegistered_aIEngine_body_tag(unsigned int *size);
#ifdef __cplusplus
}
#endif
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

