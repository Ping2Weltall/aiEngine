/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_dispatch.h                                              */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003 - Globales remake @Secur nach Datenverlust in Canada   */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 12.06.2004  : ALH           : Konstanten als const deklariert             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_DISPATCH_H                                                       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_DISPATCH_H                                                       //

#define AIENGINE_EMPTY_KNOWN_FRAMES      \
struct aie_known_frames known_frames[] = \
{                                        \
    { 0,     /*  int FrameSet     */     \
      "\0",  /*  char *Frame      */     \
      "\0",  /*  char *scroll_a   */     \
      0,     /*  int new_frame_a  */     \
      "\0",  /*  char *target_a   */     \
      "\0",  /*  char *name_a     */     \
      "\0",  /*  char *scroll_b   */     \
      0,     /*  int new_frame_b  */     \
      "\0",   /*  char *target_b   */    \
      "\0"   } /*  char *name_b     */   \
};                                       \
unsigned int aie_size_known_frames = 0;                                      //
                                                                             //
#define AIENGINE_EMPTY_PAGE_REC         \
struct aie_page_rec page_rec[] =        \
{                                       \
   { false,   /* bool canCache;  */     \
     "",      /* char *page;     */     \
     "",      /* char *bg;       */     \
     "",      /* char *body_fkt; */     \
     NULL  }  /* void (*fkt)     */     \
};                                      \
unsigned int aie_size_page_rec = 0;                                          //
                                                                             //
#define AIENGINE_EMPTY_BASIC_REC        \
struct aie_basic_rec basic_rec[] =      \
{                                       \
   { false,   /* bool canCache   */     \
     "",      /* char *page      */     \
     "",      /* char *bg        */     \
     "",      /* char *body_fkt  */     \
     NULL  }  /* void (*fkt)     */     \
};                                      \
unsigned int aie_size_basic_rec = 0;                                         //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/

struct aie_page_rec                                                          //
{                                                                            //
   /*const*/ bool canCache;                                                  //
   /*const*/ char page[AIE_PAGE_REC_PAGE_LEN+1];                             //
   /*const*/ char bg[AIE_PAGE_REC_BG_LEN+1];                                 //
   /*const*/ char body_fkt[AIE_PAGE_REC_BODY_FKT_LEN+1];                     //
   void (*fkt)(struct aie_cgi_parameter *cgi_parameter);                     //
};                                                                           //
                                                                             //
struct aie_basic_rec                                                         //
{                                                                            //
   bool canCache;                                                            //
   /*const*/ char page[AIE_BASIC_REC_PAGE_LEN+1];                            //
   /*const*/ char bg[AIE_BASIC_REC_BG_LEN];                                  //
   /*const*/ char body_fkt[AIE_BASIC_REC_BODY_FKT_LEN+1];                    //
   void (*fkt)(void);                                                        //
};                                                                           //


struct aie_known_frames                                                      //
{                                                                            //
   int FrameSet;                                                             //
   /*const*/ char *Frame;                                                    //
   /*const*/ char *scroll_a;                                                 //
   int new_frame_a;                                                          //
   /*const*/ char *target_a;                                                 //
   /*const*/ char *name_a;                                                   //
   /*const*/ char *scroll_b;                                                 //
   int new_frame_b;                                                          //
   /*const*/ char *target_b;                                                 //
   /*const*/ char *name_b;                                                   //
};                                                                           //
#if 0
struct known_frames                                                       //
{                                                                         //
   int FrameSet;                                                          //
   char Frame[AIE_KNOWN_FRAMES_FRAME_LEN+1];                              //
   char scroll_a[AIE_KNOWN_FRAMES_SCROLL_A_LEN+1];                        //
   int new_frame_a;                                                       //
   char target_a[AIE_KNOWN_FRAMES_TARGET_A_LEN+1];                        //
   char name_a[AIE_KNOWN_FRAMES_NAME_A_LEN+1];                            //
   char scroll_b[AIE_KNOWN_FRAMES_SCROLL_B_LEN+1];                        //
   int new_frame_b;                                                       //
   char target_b[AIE_KNOWN_FRAMES_TARGET_B_LEN+1];                        //
   char name_b[AIE_KNOWN_FRAMES_NAME_B_LEN+1];                            //
};                                                                           //
#endif

struct aie_page_cgi_dispatch                                                     //
{                                                                            //
   /*const*/ char page[AIE_PAGE_CGI_DISPATCH_PAGE_LEN+1];                    //
   /*const*/ int modul;                                                      //
};                                                                           //
                                                                             //
struct aie_frame_cgi_dispatch                                                    //
{                                                                            //
   /*const*/ char frame[AIE_FRAME_CGI_DISPATCH_FRAME_LEN+1];                 //
   /*const*/ int modul;                                                      //
};                                                                           //
                                                                            
struct aie_module_2_cgi_prog                                                     //
{                                                                            //
   /*const*/ int modul;                                                      //
   /*const*/ char cgi_prog[AIE_MODULE_2_CGI_PROG_CGI_PROG_LEN+2];            //
};                                                                           //
                                                                             //
#if 0
struct page_rec                                                              //
{                                                                            //
   const bool canCache;                                                      //
   const char *page;                                                         //
   const char *bg;                                                           //
   const char *body_fkt;                                                     //
   void (*fkt)(struct cgi_vars *cgi_vars_base);                              //
};                                                                           //
                                                                             //
struct basic_rec                                                             //
{                                                                            //
   const bool canCache;                                                      //
   const char *page;                                                         //
   const char *bg;                                                           //
   const char *body_fkt;                                                     //
   void (*fkt)(void);                                                        //
};                                                                           //
struct page_cgi_dispatch                                                     //
{                                                                            //
   const char *page;                                                         //
   const int modul;                                                          //
};                                                                           //
                                                                             //
struct frame_cgi_dispatch                                                    //
{                                                                            //
   const char *frame;                                                        //
   const int modul;                                                          //
};                                                                           //
#endif
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
struct aie_page_rec *aie_get_page_record(const char *whichPage);             //
//struct aie_basic_rec *aie_get_basic_record(const char *whichPage);           //
struct aie_known_frames *aie_SelectFrameSet(int whichFrameSet);              //
/*const*/ char *aie_get_page_2_cgi_prog(const char *whichPage);              //
/*const*/ char *aie_get_frame_2_cgi_prog(const char *whichFrame);            //
const char *aie_get_cgi_prog_from_cgi_vars(struct aie_cgi_parameter          //
                                                  *cgi_parameter);           //
#ifdef __cplusplus
}
#endif
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

