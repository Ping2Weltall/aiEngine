/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_header.c                                                */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 13.10.2005  : ALH           : Titel ueber Parameter      fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_header_version         = "1.0.0";                          //
const char *modul_header                 = "Header";                         //
const char *modul_header_date            = __DATE__;                         //
const char *modul_header_time            = __TIME__;                         //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Funktionsprototypen des CGI                               */
/*...........................................................................*/
extern char *doctype;                                                        //
extern char *doctype_trans;                                                  //
extern char *doctype_frame;                                                  //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
//extern char *aIEngine_HTML_Titel;                                            //
extern char *cfg_var_keywords;                                               //
extern char *tag_meta;                                                       //
                                                                             //
extern char *htequiv;                                                        //
extern char *htname;                                                         //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static void do_head_metatags(void);                                          //
static bool ShowHeadExtensions(const char *whichPage,                        //
                               struct aie_cgi_parameter *cgi_parameter);     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/
//#undef AIENGINE_LOG_NO_LOG
//#define AIENGINE_LOG_NO_LOG	1


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool aie_ShowHead(bool isFrameSet, const char *whichPage, 
                                       struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	                           "aie_ShowHead Frame[%d] Page[%s]" },
      { AIE_LOG_WARN,      "PageVariable == NULL Ptr Frame[%d]" },
      { AIE_LOG_WARN,      "Language == NULL Ptr Frame[%d] Page[%s]" },
      { AIE_LOG_TRACE_FKT,  	   "Frame[%d] Page[%s] Titel[%s]" },
      { AIE_LOG_WARN,      "Titel == NULL Ptr" },
      { AIE_LOG_TRACE, "aIEngine_ShowHead .. done rc=%d" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	                           "aie_ShowHead Frame[%d] Page[%s] "
				      "Language[%s]" },
   };
   #endif
   //char *appl_title = GetStandardAsecurVariableValue(AIENGINE_VAR_TITLE);
   bool rc = true;
   const char *language = 
                     aie_GetStandardAsecurVariableValue(AIENGINE_VAR_LANGUAGE);
   //char *whichPage = aie_isPageName(cgi_parameter);
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, isFrameSet, whichPage);
   if (__builtin_expect((whichPage == NULL), false))
   {
      aie_sys_log(1, isFrameSet);
   }
   #endif
   if (!AIE_AGENT_AIENGINE)
   {
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, isFrameSet, whichPage);
      #endif
      if (__builtin_expect((isFrameSet == true),false))
      {
         head_html_vt(doctype, doctype_frame);
      }
      else
      {
         head_html_vt(doctype, doctype_trans);
      }
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, isFrameSet, whichPage);
      #endif
      aie_do_page_prev_html_javascript(whichPage, cgi_parameter);
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, isFrameSet, whichPage);
      #endif
      if (__builtin_expect((language != NULL),true))
      {
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(6, isFrameSet, whichPage, language);
         #endif
         head_html_vt("<%s lang=\"%s\">\n", HT_HTML, language);
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(0, isFrameSet, whichPage);
         #endif
      }
      else
      {
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(0, isFrameSet, whichPage);
         #endif
         bHTML
      }
      bHEAD
      bTITLE
      {
         //head_html_vt("%s", aIEngine_HTML_Titel);
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(0, isFrameSet, whichPage);
         #endif
	 if (__builtin_expect((cgi_parameter != NULL) &&
		               (cgi_parameter->Titel != NULL), true))
	 {
            #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
            aie_sys_log(3, isFrameSet, whichPage, cgi_parameter->Titel);
            #endif
            head_html_vt("%s", cgi_parameter->Titel);
	 }
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
	 else
	 {
            aie_sys_log(4, isFrameSet, whichPage);
	 }
         #endif
      }
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, isFrameSet, whichPage);
      #endif
      eTITLE
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, isFrameSet, whichPage);
      #endif
      do_head_metatags();
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, isFrameSet, whichPage);
      #endif
      rc = ShowHeadExtensions(whichPage, cgi_parameter);
      eHEAD
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(5, rc);
   #endif
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static bool ShowHeadExtensions(const char *whichPage, struct aie_cgi_parameter 
                                                       *cgi_parameter)
{
   bool rc = true;
   char *whichFrame = aie_GetCharCGIValue(cgi_parameter, isFrameCGIVar);
   if (__builtin_expect((whichPage == NULL),false))
   {
   }
   else
   {
      if (whichFrame == NULL)
      {
         #if 0
         bJAVASCRIPT
         html_static("function asecur_error_handler(a)\n");
         html_static("{\n");
         html_static("   var error_url = '/cgi-bin/ff.cgi&error=' + a;");
         html_static("window.open(error_url,"
                             "\"TheWindow\","
                             "\"toolbar=no,"
                              "width=100,height=500"
                              "directories=no,"
                              "status=no,"
                              "scrollbars=yes,"
                              "resize=yes,"
                              "menubar=no\");");
         html_static("}\n\n");
         eJAVASCRIPT
         #endif
      }
      aie_do_page_head_javascript(whichPage, cgi_parameter);
   }
   if (__builtin_expect(
	    ((cgi_parameter != NULL) && 
	     (cgi_parameter->cgi_hooks != NULL) &&
	     (cgi_parameter->cgi_hooks->extern_cgi_header != NULL)), true))
   {
      rc = cgi_parameter->cgi_hooks->extern_cgi_header(whichFrame, 
	                                                     whichPage, 
	                                                     cgi_parameter);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : Ausgabe von Metatags innerhalb der HTML Head Section      */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void do_head_metatags(void)
{
   unsigned int size_meta_head_info;
   struct aie_meta_head_info *meta_head_info;
   unsigned int size_html_keywords;
   const struct aie_html_keywords *html_keywords;
  
   if (__builtin_expect(((html_keywords = 
	    getRegistered_html_keywords(&size_html_keywords)) != NULL),true))
   {
      register unsigned int i = 0;
      for (i = 0;i < size_html_keywords;i++)
      {
         if (__builtin_expect(
		  (html_keywords->typ == HTTP_HEAD_KEYWORD_STD),true))
         {
            head_html_vt(tag_meta, htname, aIEngine_cfg_var_keywords, 
		                                      html_keywords->keywords);
            //head_html_vt(tag_meta, html_keywords->keywords, htequiv, aIEngine_cfg_var_keywords);
         }
         html_keywords++;
      }
   }
   if (__builtin_expect(
	    ((meta_head_info = 
       getRegistered_meta_head_info(&size_meta_head_info)) != NULL),true))
   {
      register unsigned int i = 0;
      for (i = 0;i < size_meta_head_info;i++)
      {
         const char *sptr;
         const char *value;

         if (__builtin_expect(((meta_head_info->value != NULL) &&
            (*meta_head_info->value != '\0')), true))
         {
            switch(meta_head_info->typ)
            {
               case HTEQUIV:
               {
                  sptr = htequiv;
               }
               break;
               case HTNAME:
               {
                  sptr = htname;
               }
               break;
               default:
                  sptr = "";
            }
            if (__builtin_expect(
		 ((value = aie_do_variable_funktions(ASECUR_GLOBAL_VARIABLEN,
                                       meta_head_info->value)) != NULL),true))
            {
               if (__builtin_expect((*value != '\0'),true))
               {
                  head_html_vt(tag_meta, sptr, meta_head_info->name, value);
               }
            }
         }
         meta_head_info++;
      }
   }
}
/*---------------------------------------------------------------------------*/


/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_header_size            = __LINE__;                               //
/* -------------------------------- EOF ------------------------------------ */

