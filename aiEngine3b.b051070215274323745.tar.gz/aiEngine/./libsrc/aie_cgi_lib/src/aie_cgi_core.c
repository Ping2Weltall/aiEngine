/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_cgi_core.c                                              */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 19.10.2005  : ALH           : Split in aie_core, aie_core_init, aie_core  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 13.01.2005  : ALH           : KeyClient nur noch starten wenn nicht       */
/*             :               : WinClient AIE_AGENT_AIENGINE                */
/*.............+...............+.............................................*/
/* 12.01.2005  : ALH           : Optimierung fuer internen Zugriff durch     */
/*             :               : WinClient AIE_AGENT_AIENGINE                */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*                             : Win include fuer sleep                      */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : const char * als const * deklarieren        */
/*.............+...............+.............................................*/
/* 20.04.2004  : ALH           : Aenderungen wegen Auslagerung der Ver-      */
/*             :               : schluesselung in eigenen Server.            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_cgi_core_version     = "1.1.6";                            //
const char *modul_cgi_core             = "Core";                             //
const char *modul_cgi_core_date        = __DATE__;                           //
const char *modul_cgi_core_time        = __TIME__;                           //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Includes                                                           */
/*...........................................................................*/
#ifndef __WIN32__
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <syslog.h>
#else
#include <dos.h>
#endif
//#include <sys/timeb.h>                                                       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
									     //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool aIEngine_Run_as_CGI(struct aie_cgi_parameter *cgi_parameter);    //
static int aIEngine_as_CGI(struct aie_cgi_parameter *cgi_parameter);         //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
bool aie_cgi_did_Sitemap = false;                                            //
                                                                             //
bool AIENGINE_CONF_USE_PERFORMANCE =	false;
bool AIENGINE_CONF_USE_SITEMAPS =	false;
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool aIEngine_Run_as_CGI(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	                           "aIEngine_Run_as_CGI Frame[%d] Page[%s]" },
      { AIE_LOG_WARN,  "Problem CGI ShowFrameSet!" },
      { AIE_LOG_WARN,  "Problem CGI ShowBody!" },
      { AIE_LOG_TRACE, "aIEngine_Run_as_CGI .. done rc=%d" }
   };
   bool isFrameSet = false;
   bool rc = true;
   aie_CGIFrameSetIntVar(whichFrameSet);
   aie_CGIPageNameVar(whichPage);
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, whichFrameSet, whichPage);
   #endif
   if (!AIE_AGENT_AIENGINE)
   {
      char *sptr;
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, whichFrameSet, whichPage);
      #endif

      if ((sptr = aie_GetCharCGIValue(cgi_parameter, isFromCGIVar)) != NULL)
      {
         aie_SetAsecurVariable(ASECUR_GLOBAL_VARIABLEN,
                               AIENGINE_VAR_LINKED_FROM,
                               0,
                               sptr,
                               NULL);
         //strncpy(LinkedFrom, sptr, sizeof(LinkedFrom) - 1);
      }
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, whichFrameSet, whichPage);
      #endif
      if (__builtin_expect((whichFrameSet != 0),false))
      {
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(0, whichFrameSet, whichPage);
         #endif
         isFrameSet = true;
         #if AIE_TARGET_IS_LINUX
         if (!AIE_AGENT_AIENGINE)
         {
	    aie_send_prio_message(cgi_parameter->Name, getpid(), 
		                                AIENGINE_PRIO_FRAME_CGI, true);
	 }
         #endif
      }
      else
      {
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(0, whichFrameSet, whichPage);
         #endif
         #if AIE_TARGET_IS_LINUX
         if (!AIE_AGENT_AIENGINE)
         {
            aie_send_prio_message("httpd", getppid(), AIENGINE_PRIO_FAST_PARENT,
		                                                       false);
	    aie_send_prio_message(cgi_parameter->Name, getpid(), AIENGINE_PRIO_CGI, true);
	 }
         #endif
      }
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, whichFrameSet, whichPage);
      #endif
      aie_ShowHead(isFrameSet, whichPage, cgi_parameter);
      sleep(0);
     if (__builtin_expect((isFrameSet == true),false))
      {
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(0, whichFrameSet, whichPage);
         #endif
         rc = aie_ShowFrameSet(whichFrameSet, cgi_parameter);
         if (!rc)
         {
            bBODY
            isFrameSet = false;
	    // Problem CGI ShowFrameSet!
            aie_sys_log(1);
         }
      }
      else
      {
         #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
         aie_sys_log(0, whichFrameSet, whichPage);
         #endif
         if (__builtin_expect(
		  //(!(rc = aie_ShowBody(aie_isPageName(cgi_parameter), 
		  (!(rc = aie_ShowBody(whichPage, cgi_parameter))),
	       false))
	 {
	    // Problem CGI ShowBody!
            aie_sys_log(2);
	 }
      }
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, whichFrameSet, whichPage);
      #endif
      aie_ShowFoot(isFrameSet);
   }
   else
   {
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, whichFrameSet, whichPage);
      #endif
      if (__builtin_expect(
	       //(!(rc = aie_ShowBody(aie_isPageName(cgi_parameter), 
	       (!(rc = aie_ShowBody(whichPage, cgi_parameter))),
	                                                               false))
      {
	  // Problem CGI ShowBody!
          aie_sys_log(2);
      }
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(3, rc);
   #endif
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : int                                                       */
/*...........................................................................*/
int aIEngineClient(struct aie_aIEngine_parameter *aIEngine_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aIEngineStartup" },
      { AIE_LOG_ERROR, "Engine kann nicht mit NULL Pointer gestartet werden!"}
   };
   int rc = AIENGINE_UNKNON_RUN_MODE;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((aIEngine_parameter != NULL) &&
          (aIEngine_parameter->cgi_parameter != NULL), true))
   {
      if (__builtin_expect((aIEngine_parameter->cgi_parameter->Mode == 
		                                   AIENGINE_RUN_AS_CGI), true))
      {
         rc = aIEngine_as_CGI(aIEngine_parameter->cgi_parameter);
      }
   }
   else
   {
      // Engine kann nicht mit NULL Pointer gestartet werden!
      aie_sys_log(1);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : int                                                       */
/*...........................................................................*/
int aIEngine_as_CGI(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aIEngine_as_CGI" },
      { AIE_LOG_INFO,  "aIEngine_as_CGI Returncode is: %x" },
      { AIE_LOG_PERFORMANCE, "Run: %5ld.%.3d Frame[%3d] Page[%2s] Job: %s" },
      { AIE_LOG_PERFORMANCE, "rc=%d Save Msg Time [%s] Size %Ld Frame[%d] "
	                     "Page[%s] url[%s]" },
      { AIE_LOG_WARN, "Sitemap write error: [%s] Size %Ld Frame[%d] "
	                     "Page[%s] url[%s]" },
      { AIE_LOG_SECURITY,    "Sitemap not saved Url[%s]" },
      { AIE_LOG_ERROR,        "aIEngine_as_CGI Parameter = NULL Ptr" }
   };
   int rc = AIENGINE_ALL_OK;
   // ALH 30.06.2019  b051
#if 0
   // struct timeb t1;
   // struct timeb t2;
   int millitm;
   long timetm;
#endif
   #if AIE_TARGET_IS_LINUX
   pid_t parent_pid = getppid();
   #endif

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif

   // ALH 30.06.2019 b051
   // ftime(&t1);
   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      #if AIE_TARGET_IS_LINUX
      aie_send_prio_message(cgi_parameter->Name, getpid(), 
	                                              AIENGINE_PRIO_FAST_CGI, 
	                                                                true);
      #endif
      if (__builtin_expect((aie_Init_aIEngine_as_CGI(cgi_parameter) == true), 
	                                                                 true))
      {
         if (__builtin_expect((!aie_cgi_did_Sitemap), false))
         {
            if (__builtin_expect((!aIEngine_Run_as_CGI(cgi_parameter)),
	                                                                false))
            {
               if (!AIE_AGENT_AIENGINE)
               {
                  rc = AIENGINE_CGI_RUN_FAILED;
	       }
            }
	    //else
	    //{
            //   rc = AIENGINE_CGI_RUN_FAILED;
	    //}
         }
      }
      else
      {
         rc = AIENGINE_INIT_FAILED;
      }
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      // Returncode is: %x
      aie_sys_log(1, rc);
      #endif
      #if AIE_TARGET_IS_LINUX
      if (!AIE_AGENT_AIENGINE)
      {
         aie_send_prio_message(cgi_parameter->Name, getpid(), 
	                                                 AIENGINE_PRIO_LOW_CGI, 
	                                                                 true);
         sleep(0);
         aie_send_prio_message("httpd", parent_pid, AIENGINE_PRIO_NORMAL_PARENT, 
	                                                              false);
         sleep(0);
      }
      #endif
      if (__builtin_expect((!aie_cgi_did_Sitemap),false))
      {
         const char *cgiRequestMethod = 
	                     aie_get_aIEngine_env(AIENGINE_ENV_REQUEST_METHOD);
         if (__builtin_expect((cgiRequestMethod != NULL),true))
         {
            const char *cgiRequestUri = 
	                        aie_get_aIEngine_env(AIENGINE_ENV_REQUEST_URI);
            char *uri = NULL;
            char *sptr;
            aie_CGIFrameSetIntVar(hasFrameSet);
            aie_CGIPageNameVar(hasPageName);
	    if (__builtin_expect((uri != NULL), true))
	    {
	       uri = aie_strdup(cgiRequestUri);
	    }
	    else
	    {
	       uri = aie_strdup("Unbekannt");
	    }
            if ((sptr = strchr(uri, '?')) != NULL)
            {
	       *sptr = '\0';
            }
            sptr = uri + strlen(uri);
            while ((sptr != uri) && (*sptr !='/')) 
            {
                sptr--;
            }
            #if 0
            if (strlen(cgiRequestUri) > 512)
            {
               *(cgiRequestUri + 500) = '\0';
               strcat(cgiRequestUri, "..");
            }
            #endif
            //if (((sptr = isPageName(*cgi_vars_base)) != NULL) &&
            if (__builtin_expect((((hasPageName) != NULL) &&
                 (strcmp(hasPageName, isPageNotFoundCGIVal) != 0) &&
                 (rc == AIENGINE_ALL_OK)), true))
            {
	       const char *sptr2;
	       if (((sptr2 = cgi_parameter->Name) != NULL) && (*sptr2 != '\0'))
	       {
	          sptr2 += strlen(sptr2) - 1;
	          while(sptr2 != cgi_parameter->Name)
	          {
	             if (*sptr2 == '/')
	             {
		        sptr2++;
		        break;
	             }
	             sptr2--;
	          }
	       }
	       // ALH 30.06.2019 b051
#if 0
               ftime(&t2);
               if ((millitm = t2.millitm - t1.millitm) < 0)
               {
                   millitm += 1000;
                   t2.time--;
               }
               timetm = t2.time - t1.time;
               if (AIENGINE_CONF_USE_PERFORMANCE)
	       {
                  aie_do_log(performance_file,
                      "Run: %5ld.%.3d Frame[%3d] Page[%2s] Job: %s", 
		                             timetm, millitm,
                                             hasFrameSet,
                                             hasPageName,
					     sptr2);
                  // "Run: %5ld.%.3d Frame[%3d] Page[%2s] Job: %s", 
                  aie_sys_log(2, timetm, millitm, hasFrameSet,
                                             hasPageName,
					     sptr2);
	       }
#endif
	       // ALH 30.06.2019
#if 0
               if (__builtin_expect((AIENGINE_CONF_USE_SITEMAPS) &&
                                    (!AIE_AGENT_AIENGINE) &&
                         ((cgi_parameter != NULL) && 
	                  (cgi_parameter->cgi_hooks != NULL) &&
	                  (cgi_parameter->cgi_hooks->extern_cgi_sitemap_write 
                                                              != NULL)), true))
	       {
		  aie_CGISessionVar(session);
		  aie_CGIUserVar(user);
		  aie_CGIPasswdVar(passwort);
	          if (__builtin_expect(((session == NULL) && 
			             (user == NULL) && 
				     (passwort == NULL) &&
                                     (strcmp(hasPageName, 
					     isPageRelocateCGIVal) != 0)
				     ) ,true))
	          {
                     const char *cgiServerName = 
	                    aie_get_aIEngine_env(AIENGINE_ENV_SERVER_NAME);
		     // ALH 30.06.2019 b051
#if 0
	             char run_time[AIE_SITEMAP_RUN_TIME_LEN + 1];
	             sprintf(run_time, "%ld%.3d", timetm, millitm); 
	                // rc=%d Save Msg Time [%s] Size %Ld Frame[%d] Page[%s] 
		        // url[%s]"
                     aie_sys_log(3, rc, run_time, 
			            cgi_parameter->BytesWritten, 
			            hasFrameSet, hasPageName, cgiRequestUri);
#endif
                     #if 0
                     aie_send_sitemap_save_msg(cgiServerName, cgiRequestUri, 
			                       sptr2,
                                               hasFrameSet, hasPageName,
                                               run_time, 
					       cgi_parameter->BytesWritten);
                     #endif
                     if(!cgi_parameter->cgi_hooks->extern_cgi_sitemap_write(
                                               cgiServerName, cgiRequestUri, 
			                       sptr2,
                                               hasFrameSet, hasPageName,
                                               run_time, 
					       cgi_parameter->BytesWritten))
                     {
                        aie_sys_log(4, run_time, 
			            cgi_parameter->BytesWritten, 
			            hasFrameSet, hasPageName, cgiRequestUri);
                     }
	          }
	          else
	          {
	                // Not saved[%s]
                        aie_sys_log(5, cgiRequestUri);
	          }
               }
#endif
	    }
            aie_free(uri);
         }
      }
      aie_Cleanup_aIEngine_CGI(cgi_parameter);
   }
   else
   {
      aie_sys_log(6);
   }
   return(AIENGINE_ALL_OK);
   //return(rc);
}
/*---------------------------------------------------------------------------*/
//#if AIE_USE_MUDFLAP
bool is_AIE_AGENT_AIENGINE(void)  
{
   const char *UserAgent = aie_get_aIEngine_env(AIENGINE_ENV_HTTP_USER_AGENT);
   return(UserAgent != NULL ? (strncmp(UserAgent, "@Secur(tm)", 10) == 0) : 0); 
}
//#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_cgi_core_size        = __LINE__;                                 //
/* -------------------------------- EOF ------------------------------------ */

