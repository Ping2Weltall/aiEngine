/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_links.c                                                 */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 27.12.2003                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Erstellen von HTML Links (Tag oder Referenz) incl. Verschluesselung       */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 05.08.2005  : ALH           : html link gekapselt um variblen ueber       */
/*                             : verschiedene frames zu uebernehmen ohne     */
/*                             : diese als follow vars zu deklarieren.       */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 05.05.2004  : ALH           : Entfernen der Cache Funkitionalitaet        */
/*.............+...............+.............................................*/
/* 03.01.2004  : ALH           : Funktion cgiVarFollow von modul iapl in     */
/* dieses Modul verlagert. Selbige  Funktion CPU optimiert.                  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_links_version      = "1.0.1";                              //
const char *modul_links              = "Links";                              //
const char *modul_links_date         = __DATE__;                             //
const char *modul_links_time         = __TIME__;                             //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define MAX_SIZE_FOLLOW_VARS_STRING     128                                  //
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1

/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *is_href;                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static void is_html_link(bool vars_follow,                                   //
                         const struct aie_prog_link prog_link);              //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : html_link                                                 */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     : struct prog_link prog_link - Struktur auf Link Parameter  */
/* Parameter     : struct link_vars link_vars[] - Struktur auf Variablen     */
/*                                                fuer aufzurufendes CGI     */
/* Rueckgabewert : ohne                                                      */
/* Bemerkung     :                                                           */
/*.............+...............+.............................................*/
/* 27.12.2003  : ALH           : Verarbeitung Dispatch Tabelle fuer CGI Prog */
/*                               Verwendet nun SetCGIVarsFromProgLink        */
/*.............+...............+.............................................*/
/* 05.05.2004  : ALH           : Parameter nun * anstatt [] link_vars        */
/*                             : Entfernen der Cache Funktionen (No_cache)   */
/*...........................................................................*/
void aie_html_vars_follow_link(const struct aie_prog_link prog_link)
{
   is_html_link(true, prog_link);
}

void aie_html_link(const struct aie_prog_link prog_link)
{
   is_html_link(false, prog_link);
}

static void is_html_link(bool vars_follow, const struct aie_prog_link prog_link)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "is_html_link [%d]" },         
      { AIE_LOG_WARN,  "Link: Kein CGI Program - Link nicht gesetzt" }, 
      { AIE_LOG_WARN,  "Link: Orginal verwendet: %s Page:[%s] Frame[%s]" },
      { AIE_LOG_ERROR, "Link Parameter == NULL!!" },
      { AIE_LOG_INFO,  "Link Tag[%s]" },
      { AIE_LOG_ERROR, "Kein Memory - Link nicht gesetzt" },
      { AIE_LOG_TRACE_FKT,  "is_html_link Trace Info %s=[%s]" },
      { AIE_LOG_WARN, "Link Variablen == NULL!!" }
   };
   #if AIENGINE_LOG_TRACE_LINK
   aie_sys_log(0, vars_follow);
   #endif 
   if (__builtin_expect((prog_link.prog == NULL), false))
   {
       // Link Warnung - Kein CGI Program - Link nicht gesetzt
       aie_sys_log(1);
   }
   else
   {
      //bool RefOnly = prog_link.RefOnly;
      //t size = prog_link.size_link_vars;
      char *link_tag = (char *)aie_malloc(AIE_LINK_TAG_BUF_LEN);
      //struct link_vars *link_vars = prog_link.link_vars; 
      struct aie_cgi_parameter *link_cgi_parameter = 
	                          (struct aie_cgi_parameter *)
		                  aie_malloc(sizeof(struct aie_cgi_parameter));
   #if AIENGINE_LOG_TRACE_LINK
      aie_sys_log(6, "Prog", prog_link.prog);
   #endif 
      if (__builtin_expect(((link_tag != NULL) &&
		            (link_cgi_parameter != NULL)), true))
      {
         char *VarFollow = NULL;
         struct aie_cgi_variables *link_cgi_vars_base;
         const char *cgi_prog;
         const char *link_parameter;
	 if (__builtin_expect(
		  ((prog_link.cgi_parameter != NULL) &&
		   (prog_link.cgi_parameter->cgi_variables != NULL)), true))
	 {
            VarFollow = 
	            aie_cgiVarFollow(prog_link.cgi_parameter->cgi_variables);
	 }
         #if AIENGINE_LOG_TRACE_LINK
         aie_sys_log(6, "VarFollow", VarFollow);
         #endif 

	 link_cgi_parameter->cgi_variables = NULL;

         memset(link_tag, '\0', sizeof(AIE_LINK_TAG_BUF_LEN));
   
         if (__builtin_expect(((link_cgi_vars_base = 
                aie_SetCGIVarsFromProgLink(prog_link.link_vars, 
		                           prog_link.size_link_vars, 
		                       link_cgi_parameter)) == NULL), false))
	 {
            aie_sys_log(7);
	 }
         cgi_prog = aie_get_cgi_prog_from_cgi_vars(link_cgi_parameter);
         #if AIENGINE_LOG_TRACE_LINK
         aie_sys_log(6, "cgi_prog", cgi_prog);
         #endif
         if (__builtin_expect((vars_follow == true), false))
         {
            struct aie_cgi_variables *cgi_vars_ptr = NULL;
            if (__builtin_expect(((prog_link.cgi_parameter != NULL) &&
		  ((cgi_vars_ptr = prog_link.cgi_parameter->cgi_variables) 
		                                              != NULL)), true))
            {
	       while (cgi_vars_ptr != NULL)
	       {
#if 0
		     sys_log("%s(%d): test %s[%s]", __FILE__, __LINE__,
			          cgi_vars_ptr->nam,
			          cgi_vars_ptr->val);
#endif
	          if (__builtin_expect((cgi_vars_ptr->nam != NULL) &&
		                       (aie_GetCharCGIValue(link_cgi_parameter, 
			                cgi_vars_ptr->nam) == NULL), true))
	          {
	             if (__builtin_expect((
			   (strcmp(cgi_vars_ptr->nam, isCodedCGIVar) != 0) &&
			   (strcmp(cgi_vars_ptr->nam, isFrameCGIVar) != 0) &&
			   (strcmp(cgi_vars_ptr->nam, isNameCGIVar) != 0))
			                                              , false))
	             {
		        aie_SetCharCGIValue(link_cgi_parameter, 
			                aie_strdup(cgi_vars_ptr->nam),
			                aie_strdup(cgi_vars_ptr->val));
		     }
	          }
	          cgi_vars_ptr = cgi_vars_ptr->next;
	       }
	    }
         }
         if (__builtin_expect((!prog_link.RefOnly),true))
         {
            strcpy(link_tag, "<");
            strcat(link_tag, is_href);
         }
         if (__builtin_expect((cgi_prog != NULL),true))
         {
            strcat(link_tag, cgi_prog);
         }
         else
         {
            char *page = aie_GetCharCGIValue(link_cgi_parameter, 
		                             isNameCGIVar);
            char *frame = aie_GetCharCGIValue(link_cgi_parameter, 
		                              isFrameCGIVar);
            // Link Warnung orginal verwendet: %s Page:[%s] Frame[%s]
            aie_sys_log(2, prog_link.prog, page, frame);
            strcat(link_tag, prog_link.prog);
         }
         #if aie_do_use_keys
         strcat(link_tag, "?");
         strcat(link_tag, isCodedCGIVar);
         strcat(link_tag, "=");
         #else
         strcat(link_tag, "?");
         #endif
         if (__builtin_expect(((link_parameter = 
	       aie_get_html_link_parameter(link_cgi_parameter->cgi_variables, 
		                       true, /*
					(prog_link.cgi_parameter != NULL), */
				       VarFollow)) != NULL),true))
         {
            strcat(link_tag, link_parameter);
            #if AIENGINE_LOG_TRACE_LINK
            aie_sys_log(6, "link_parameter", link_parameter);
            #endif
         }
         else
         {
            // Link Parameter == NULL!!
            aie_sys_log(3);
            strcat(link_tag, aie_log_msg[3].msg);
         }
         if (__builtin_expect((!prog_link.RefOnly),true))
         {
            strcat(link_tag, "\"");
            if (prog_link.target != NULL)
            {
               strcat(link_tag, " target=\"");
               strcat(link_tag, prog_link.target);
               strcat(link_tag, "\"");
            }
         }
         html_t(link_tag);
	 // Link Tag[%s]
         #if AIENGINE_LOG_TRACE_LINK
         aie_sys_log(4, link_tag);
         #endif 
         #if 0
               if (vars_follow)
               {
                  sys_log("%s(%d): %s", __FILE__, __LINE__, link_tag);
               }
         #endif
         aie_free(link_tag);

         aie_CleanUpCGIVars(link_cgi_parameter);
         if (__builtin_expect((!prog_link.RefOnly),true))
         {
            if (prog_link.Mouse != NULL)
            {
               prog_link.Mouse(prog_link.MouseParameter[0].MouseFkt,
                       prog_link.MouseParameter[0].name1,
                       prog_link.MouseParameter[0].image1,
                       prog_link.MouseParameter[0].name2,
                       prog_link.MouseParameter[0].image2,
                       prog_link.MouseParameter[0].index_nr);
               prog_link.Mouse(prog_link.MouseParameter[1].MouseFkt,
                       prog_link.MouseParameter[1].name1,
                       prog_link.MouseParameter[1].image1,
                       prog_link.MouseParameter[1].name2,
                       prog_link.MouseParameter[1].image2,
                       prog_link.MouseParameter[1].index_nr);
            }
            html_static(">");
         }
      }
      else
      {
         // Kein Memory - Link nicht gesetzt
         aie_sys_log(5);
         if (__builtin_expect((link_tag != NULL), true))
         {
            aie_free(link_tag);
         }
         if (__builtin_expect((link_cgi_parameter != NULL), true))
         {
            aie_free(link_cgi_parameter);
         }
      }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*.............+...............+.............................................*/
/* 05.05.2004  : ALH           : Entfernen der Cache Funktionen (No_cache)   */
/*...........................................................................*/
const char *aie_get_html_link_parameter(struct aie_cgi_variables 
                                           *link_cgi_vars_base, 
                                    //struct cgi_vars *cgi_vars_base, 
				    bool append_follow,
			            const char *VarFollow)
{
   //static char link_dyn[AIE_LINK_TAG_BUF_LEN];
   static char *link_dyn = NULL;
   struct aie_cgi_variables *link_cgi_vars_ptr;
   const char *sptr = NULL;
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_html_link_parameter" },
      { AIE_LOG_ERROR, "Out of Memory?! Link erstellen" },
      { AIE_LOG_INFO,  "This is the link[%s]" },
      { AIE_LOG_TRACE_FKT, "aie_get_html_link_parameter Trace %s=[%s]" },
      { AIE_LOG_WARN, 	"Keine Link Variablen?!" }
   };
   #if AIENGINE_LOG_TRACE_LINK
   aie_sys_log(0);
   #endif 

   if (link_dyn == NULL)
   {
     if (__builtin_expect(
	  ((link_dyn = aie_CharDynMemory(MAX_SIZE_FOLLOW_VARS_STRING)) == NULL),
	                                                                 false))
     {
        // Out of Memory?! Link erstellen
        aie_sys_log(1);
     }
   }
   if (__builtin_expect((link_dyn != NULL), true))
   {
      sptr = link_dyn;
      //memset(link_dyn, '\0', sizeof(link_dyn));
      memset(link_dyn, '\0', MAX_SIZE_FOLLOW_VARS_STRING);

      if (__builtin_expect(
	    ((link_cgi_vars_ptr = link_cgi_vars_base) != NULL),true))
      {
         while(link_cgi_vars_ptr != NULL)
         {
            if (__builtin_expect((link_cgi_vars_ptr->val != NULL),true))
            {
               #if AIENGINE_LOG_TRACE_LINK
               aie_sys_log(3, link_cgi_vars_ptr->nam,
                              link_cgi_vars_ptr->val);
               #endif 
               strcat(link_dyn, link_cgi_vars_ptr->nam);
               strcat(link_dyn, "=");
               strcat(link_dyn, link_cgi_vars_ptr->val);
               strcat(link_dyn, "&");
            }
            link_cgi_vars_ptr = link_cgi_vars_ptr->next;
         }
      }
      else
      {
         aie_sys_log(4);
      }
      //if (__builtin_expect((cgi_vars_base != NULL),true))
      if (__builtin_expect(((append_follow) && (VarFollow != NULL)),true))
      {
         #if AIENGINE_LOG_TRACE_LINK
         aie_sys_log(3, "VarFollow", VarFollow);
         #endif 
         strcat(link_dyn, VarFollow);
      }
      #if aie_do_use_keys
      strcat(link_dyn, "&");
      strcat(link_dyn, isMagicCGIVar);
      strcat(link_dyn, "=");
      strcat(link_dyn, aie_get_time_stamp());
      #if 0 
      // Dispatch over Networks off for now 
      if (__builtin_expect(
	       ((sptr = get_simple_life_instruction()) != NULL),true))
      {
         strcat(link_dyn, "&");
         strcat(link_dyn, isLifeCGIVar);
         strcat(link_dyn, "=");
         strcat(link_dyn, sptr);
      }
      #endif
      sptr = aie_do_code_string(link_dyn);
      //return(sptr);
      #else
      //return(link_dyn);
      sptr = link_dyn;
      #endif
      // This is the link[%s]
      #if AIENGINE_LOG_TRACE_LINK
      aie_sys_log(2, sptr);
      #endif 
   }
   return(sptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
char *aie_cgiVarFollow(struct aie_cgi_variables *cgi_vars_base)
{
   static char *follow = NULL;
   static struct aie_cgi_variables *cgi_vars_base_merker = NULL;

   if (follow == NULL || 
	 (cgi_vars_base != cgi_vars_base_merker))
   {
      struct aie_cgi_variables *cgi_vars_ptr;
      unsigned int size_follow_cgi_var;
      struct aie_follow_cgi_vars *follow_cgi_var_base;
      struct aie_follow_cgi_vars *follow_cgi_var;
      if (cgi_vars_base != cgi_vars_base_merker)
      {
         cgi_vars_base_merker = cgi_vars_base;
      }
      if (cgi_vars_base == NULL)
      {
         follow = NULL;
      }
      else
      {
         if (__builtin_expect(
		  ((follow = 
		    aie_CharDynMemory(MAX_SIZE_FOLLOW_VARS_STRING)) != NULL),
		                                                         true))
         {
            *follow = '\0';
            if (__builtin_expect(
		 ((follow_cgi_var_base = 
		     getRegistered_follow_cgi_var(&size_follow_cgi_var)) 
		                                                != NULL),true))
            {
               cgi_vars_ptr = cgi_vars_base;
  
               while(cgi_vars_ptr != NULL)
               {
		  unsigned int i = 0;
                  follow_cgi_var = follow_cgi_var_base;
   
                  for(i = 0; i < size_follow_cgi_var;i++)
                  {
                     if (__builtin_expect(
			  (strstr(cgi_vars_ptr->nam, follow_cgi_var->name) 
		                                         != NULL),false))
                     {
                        if (__builtin_expect(
				 (cgi_vars_ptr->val != NULL),true))
                        {
                           strcat(follow, "&");
                           strcat(follow, cgi_vars_ptr->nam);
                           strcat(follow, "=");
                           strcat(follow, cgi_vars_ptr->val);
//sys_log("%s(%d): Test [%s:%s]", __FILE__, __LINE__, cgi_vars_ptr->nam, follow_cgi_var->name);
                           break;
                        }
                     }
                     follow_cgi_var++;
                  }
                  cgi_vars_ptr = cgi_vars_ptr->next;
               }
            }
         }
      }
   }
   return(follow);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_links_size       = __LINE__;                                     //
/* -------------------------------- EOF ------------------------------------ */

