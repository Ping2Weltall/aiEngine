/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_javascript.c                                            */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_javascript_version         = "1.0.1";                      //
const char *modul_javascript                 = "JavaScript";                 //
const char *modul_javascript_date            = __DATE__;                     //
const char *modul_javascript_time            = __TIME__;                     //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Include                                                            */
/*...........................................................................*/
#include <unistd.h>
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static void do_page_javascript(int typ, const char *whichPage,               //
                               struct aie_cgi_parameter *cgi_parameter);     //
static void js_msg_var(const char *msg, struct aie_cgi_parameter             //
                                               *cgi_parameter);              //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/
//#undef AIENGINE_LOG_NO_LOG
//#define AIENGINE_LOG_NO_LOG	1

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_do_page_prev_html_javascript(const char *whichPage, 
                                  struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_prev_html_javascript Page[%s]" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_prev_html_javascript .. done" }
   };
   aie_sys_log(0, whichPage);
   #endif
   if (aie_CGIhasJavascript)
   {
      do_page_javascript(AIENGINE_JAVASCRIPT_PREV_HTML, whichPage, 
	                                                cgi_parameter);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1, whichPage);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_do_page_head_javascript(const char *whichPage, struct aie_cgi_parameter 
                                                           *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_head_javascript Page[%s]" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_head_javascript .. done" }
   };
   aie_sys_log(0, whichPage);
   #endif
   if (aie_CGIhasJavascript)
   {
      do_page_javascript(AIENGINE_JAVASCRIPT_HEAD, whichPage, cgi_parameter);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1, whichPage);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_do_page_body_start_javascript(const char *whichPage, 
                                   struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_body_start_javascript Page[%s]" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_body_start_javascript .. done" }
   };
   aie_sys_log(0, whichPage);
   #endif
   if (aie_CGIhasJavascript)
   {
      do_page_javascript(AIENGINE_JAVASCRIPT_BODY_START, whichPage, 
	                                                 cgi_parameter);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1, whichPage);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_do_page_body_end_javascript(const char *whichPage, 
                                 struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_body_end_javascript Page[%s]" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_body_end_javascript .. done" }
   };
   aie_sys_log(0, whichPage);
   #endif
   if (aie_CGIhasJavascript)
   {
      do_page_javascript(AIENGINE_JAVASCRIPT_BODY_END, whichPage, 
	                                               cgi_parameter);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1, whichPage);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void do_page_javascript(int typ, const char *whichPage,
                               struct aie_cgi_parameter *cgi_parameter)
{
#if 0
   typ = typ;
   whichPage = whichPage;
   cgi_parameter = cgi_parameter;
#endif
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_javascript Page[%s]" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_javascript Page[%s] "
	      "Keine Javascript Struct Registriert" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_javascript .. done" }
   };
   aie_sys_log(0, whichPage);
   #endif
   if (aie_CGIhasJavascript)
   {
      char *hasFrame = aie_GetCharCGIValue(cgi_parameter, isFrameCGIVar);
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(0, whichPage);
      #endif
      if (__builtin_expect((whichPage != NULL),true))
      {
         struct aie_page_javascript *page_javascript;
         unsigned int size_page_javascript;
         if (__builtin_expect(((page_javascript = 
		 getRegistered_page_javascript(&size_page_javascript)) 
		                                               != NULL),true))
         {
            register unsigned int i = 0;
            for (i = 0;i < size_page_javascript; i++)
            {
	       //sys_log("%s(%d): i=%d von %d %d", __FILE__, __LINE__, i, size_page_javascript, page_javascript->frame);
	       //sys_log("%s(%d): %s", __FILE__, __LINE__, getenv("MUDFLAP_OPTIONS"));
               if (__builtin_expect((page_javascript->typ == typ),false))
               {
                  if (((hasFrame != NULL) && page_javascript->frame) ||
                      (hasFrame == NULL && !page_javascript->frame))
                  {
                     if (__builtin_expect(
		  (strcmp(page_javascript->page, whichPage) == 0),false))
                     {
                        if (page_javascript->fkt != NULL)
                        {
                           page_javascript->fkt(cgi_parameter);
                        }
                        if (page_javascript->script != NULL)
                        {
                           html_vt("<SCRIPT LANGUAGE=\"JavaScript\""
				   " src=\"/js/%s\"></script>", 
				                     page_javascript->script);
                        }
                     }
                  }
               }
               page_javascript++;
            }
         }
	 else
	 {
            #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
            aie_sys_log(1, whichPage);
            #endif
	 }
      }
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(2, whichPage);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_javascript_exit_frames(struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_javascript_exit_frames" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_javascript_exit_frames .. done" }
   };
   aie_sys_log(0);
   #endif
   if (aie_CGIhasJavascript)
   {
      static const char *script = "if (parent.frames.length>=1) {\n"
	                    "window.top.location.href=window.top.location.href=self.location.href;\n}\n";
      char *hasFrame = aie_GetCharCGIValue(cgi_parameter, isFrameCGIVar);
      if (__builtin_expect(
	       ((hasFrame != NULL) && 
		(strcmp(hasFrame, SFrameSetIsTopOfWindow) == 0)), false))
      {
         aie_output_javascript(script, NULL);
      }
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_intro_frame_doc_ptr(struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_intro_frame_doc_ptr" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_intro_frame_doc_ptr .. done" }
   };
   aie_sys_log(0);
   #endif
   if (aie_CGIhasJavascript)
   {
      const char *home_url = 
	             aie_GetStandardAsecurVariableValue(AIENGINE_VAR_HOME_URL);

      const char *script = "var PageOk = (parent.frames['%s']) ? true : false;\n"
                  "if(!PageOk)\n"
                  "{\n"
                  "   //setTimeout(\"self.location = '%s';\", 1000);\n"
                  "}\n"
                  "else\n"
                  "{\n"
                  "   var p = window.parent;\n"
                  "   p.d = parent.frames['%s'].document;\n"
                  "}\n";

      aie_output_javascript(script, FrameNameTopOfWindow, home_url, 
	                FrameNameTopOfWindow);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_intro_util_doc_ptr(struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_intro_util_doc_ptr" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_intro_util_doc_ptr .. done" }
   };
   aie_sys_log(0);
   #endif
   if (aie_CGIhasJavascript)
   {
      const char *home_url = 
	             aie_GetStandardAsecurVariableValue(AIENGINE_VAR_HOME_URL);
      const char *script = "var PageOk = (window.top.frames['%s']) ? true : false;\n"
                  "if(!PageOk)\n"
                  "{\n"
                  "   setTimeout(\"top.location = '%s';\", 1000);\n"
                  "}\n"
                  "else\n"
                  "{\n"
                  "   var util = window.top.frames['%s'];\n"
                  "}\n";

      aie_output_javascript(script, FrameNameUtilFrame, 
	                home_url, FrameNameUtilFrame, 
			FrameNameUtilFrame);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_top_frame_doc_var(struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_top_frame_doc_var" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_top_frame_doc_var .. done" }
   };
   #endif
   const char *script = "var pic_ss_path='%s';\n";
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (aie_CGIhasJavascript)
   {
      aie_output_javascript(script, AIE_MK_SS_IMAGE(""));
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_js_msg_var_intro(struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_js_msg_var_intro" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_js_msg_var_intro } .. done" }
   };
   aie_sys_log(0);
   #endif
   js_msg_var("Startseite wird geladen!", cgi_parameter);
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_js_msg_var_menue(struct aie_cgi_parameter *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_js_msg_var_menue Page[%s]" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_js_msg_var_menue .. done" }
   };
   aie_sys_log(0);
   #endif
   js_msg_var("Men&uuml;daten werden geladen!", cgi_parameter);
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void js_msg_var(const char *msg, struct aie_cgi_parameter
                                               *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_prev_html_javascript msg[%s]" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_do_page_prev_html_javascript .. done" }
   };
   aie_sys_log(0, msg);
   #endif
   if (aie_CGIhasJavascript)
   {
      const char *long_line = "//----------------------------------------------"
	                      "-----------------------------------------------";
      const char *script = "%s\n"
                  "var asecur_publisher = '%s';\n"
                  "var asecur_copyright = '%s';\n"
                  "var asecur_home_url = '%s';\n"
                  "%s\n"
                  "var asecur_engine_name = '%s';\n"
                  "var asecur_version = '%s';\n"
                  "var asecur_generator = '%s';\n"
                  "var asecur_author = '%s';\n"
                  "var asecur_engine_copyright = '%s';\n"
                  "var asecur_js_msg = '%s';\n"
                  "%s\n";
      const char *global_engine_name = 
	   aie_GetStandardAsecurVariableValue(AIENGINE_VAR_GLOBAL_ENGINE_NAME);
      const char *server_version = 
	       aie_GetStandardAsecurVariableValue(AIENGINE_VAR_SERVER_VERSION);
      const char *generator =
	            aie_GetStandardAsecurVariableValue(AIENGINE_VAR_GENERATOR);
      const char *author = 
	               aie_GetStandardAsecurVariableValue(AIENGINE_VAR_AUTHOR);
      const char *publisher =
	            aie_GetStandardAsecurVariableValue(AIENGINE_VAR_PUBLISHER);
      const char *copyright_asecur_1 =
	   aie_GetStandardAsecurVariableValue(AIENGINE_VAR_COPYRIGHT_ENGINE_1);
      const char *copyright =
	            aie_GetStandardAsecurVariableValue(AIENGINE_VAR_COPYRIGHT);
      const char *home_url =
	             aie_GetStandardAsecurVariableValue(AIENGINE_VAR_HOME_URL);
      aie_output_javascript(script, long_line, publisher, copyright, home_url, 
	                long_line, global_engine_name, server_version, 
			generator, author, copyright_asecur_1, msg, long_line);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_output_javascript(const char *script, ...)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_output_javascript" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, 
	   "aie_output_javascript .. done" }
   };
   #endif
   va_list argptr;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   va_start(argptr, script);
   bJAVASCRIPT
   html_argptr_vt(script, argptr);
   eJAVASCRIPT
   va_end(argptr);
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(1);
   #endif
}
/*---------------------------------------------------------------------------*/
void aie_output_escape_js_file(char *myScript)
{
   pid_t mypid = getpid();
   if (aie_file_exist(myScript))
   {
      bool has_error = false;
      struct aie_file_text *isScript = NULL;
      struct aie_file_text *txt_ptr = aie_load_file_text(myScript, &isScript);
      char *esc_line;
      bJAVASCRIPT
      //html_static("linux_is_safer = '';");
      html_vt("fkt_id%d = '", mypid);
      while (txt_ptr != NULL)
      {
         if ((esc_line = aie_escape_line(txt_ptr->txt)) != NULL)
         {
            html_vt("%s", esc_line);
            //html_vt("linux_is_safer += '%s';", esc_line);
            //html_t(txt_ptr->txt);
         }
         else
         {
            has_error = true;
         }
         if ((txt_ptr = txt_ptr->next) == NULL)
         {
            aie_free_file_text(&isScript);
            html_static("';");
            if (!has_error)
            {
               html_vt("eval(unescape(fkt_id%d));", mypid);
               html_vt("fkt_id%d = true;");
            }
         }
      }
      eJAVASCRIPT
      //html_static("Did Make");
   }
   else
   {
      //html_static("Not Found!");
   }
}

void aie_js_qMessageBox(const char *sErr, const char *titel, int flags)
{
   titel = titel;
   if (sErr != NULL)
   {
      if (titel != NULL)
      {
         aie_stringlist_add("MessageBox", titel, sErr);
      }
      else
      {
         aie_stringlist_add("MessageBox", "MB", sErr);
      }
   }
   if ((flags & MB_SHOW) == MB_SHOW)
   {
      struct aie_string_liste *strl_ptr = aie_stringlist_read("MessageBox");
      if (strl_ptr != NULL)
      {
      bJAVASCRIPT
	 html_static("alert(");
	 while (strl_ptr != NULL)
	 {
	    if (strl_ptr->value != NULL)
	    {
	       static bool first = true;
	       if (first)
	       {
	          html_vt("'%s'", strl_ptr->value);
		  first = false;
	       }
	       else
	       {
	          html_vt(" + \n'\\n%s'", strl_ptr->value);
	       }
	       strl_ptr = strl_ptr->next;
	    }
	    else
	    {
	       html_static("'Keine Msg'");
	    }
	 }
	 html_static(");");
	 eJAVASCRIPT
      }
   }
}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_javascript_size            = __LINE__;                           //
/* -------------------------------- EOF ------------------------------------ */

