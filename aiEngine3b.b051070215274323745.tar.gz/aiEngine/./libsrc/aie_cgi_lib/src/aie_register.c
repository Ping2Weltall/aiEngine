/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_register.c                                              */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 02.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aie_register_version        = "0.5.3";                     //
const char *modul_aie_register                = "Register";                  //
const char *modul_aie_register_date           = __DATE__;                    //
const char *modul_aie_register_time           = __TIME__;                    //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static struct aie_html_keywords *reg_html_keywords = NULL;                   //
static unsigned int size_reg_html_keywords = 0;                              //
                                                                             //
static struct aie_meta_head_info *reg_meta_head_info = NULL;                 //
static unsigned int size_reg_meta_head_info;                                 //
                                                                             //
//static struct aie_ad_files *reg_ad_files = NULL;                             //
//static unsigned int size_reg_ad_files = 0;                                   //
                                                                             //
//static struct aie_imp_body_links *reg_imp_body_links = NULL;                 //
//static unsigned int size_reg_imp_body_links = 0;                             //
                                                                             //
//static struct aie_standard_imp *reg_standard_imp = NULL;                     //
//static unsigned int size_reg_standard_imp = 0;                               //
                                                                             //
static struct aie_page_javascript *reg_page_javascript = NULL;               //
static unsigned int size_reg_page_javascript = 0;                            //
                                                                             //
//static struct aie_cgi_var_remote_2_local *reg_cgi_var_remote_2_local = NULL; //
//static unsigned int size_reg_cgi_var_remote_2_local = 0;                     //
                                                                             //
//static struct aie_known_menues *reg_known_menues = NULL;                     //
//static unsigned int size_reg_known_menues = 0;                               //
                                                                             //
static struct aie_page_rec *reg_page_rec = NULL;                             //
static unsigned int size_reg_page_rec = 0;                                   //
                                                                             //
//static struct aie_basic_rec *reg_basic_rec = NULL;                           //
//static unsigned int size_reg_basic_rec = 0;                                  //
                                                                             //
static struct aie_known_frames *reg_known_frames = NULL;                     //
static unsigned int size_reg_known_frames = 0;                               //
                                                                             //
static struct aie_module_2_cgi_prog *reg_module_2_cgi_prog = NULL;           //
static unsigned int size_reg_module_2_cgi_prog = 0;                          //
                                                                             //
static struct aie_page_cgi_dispatch *reg_page_cgi_dispatch = NULL;           //
static unsigned int size_reg_page_cgi_dispatch = 0;                          //
                                                                             //
static struct aie_frame_cgi_dispatch *reg_frame_cgi_dispatch = NULL;         //
static unsigned int size_reg_frame_cgi_dispatch = 0;                         //
                                                                             //
static struct aie_follow_cgi_vars *reg_follow_cgi_vars = NULL;               //
static unsigned int size_reg_follow_cgi_vars = 0;                            //
                                                                             //
//static struct aie_sub_men_paths *reg_sub_men_paths = NULL;                   //
//static unsigned int size_reg_sub_men_paths = 0;                              //
                                                                             //
//static struct aie_version_info *reg_cgi_version_info = NULL;                 //
//static unsigned int size_reg_cgi_version_info = 0;                           //
                                                                             //
static struct aie_aIEngine_env *reg_aIEngine_env = NULL;                     //
static unsigned int size_reg_aIEngine_env = 0;                               //
                                                                             //
static struct aie_aIEngine_body_tag *reg_aIEngine_body_tag = NULL;           //
static unsigned int size_reg_aIEngine_body_tag = 0;                          //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool aIEngine_Register(int typ, const void *variable, unsigned int size)
{
   bool rc = true;
   if (__builtin_expect(((size > 0) && (variable != NULL)),true))
   {
      switch(typ)
      {
         case AIENGINE_REGISTER_KEYWORDS:
         {
            reg_html_keywords = (struct aie_html_keywords *)aie_malloc(
		  sizeof(struct aie_html_keywords) * size);
	    if (__builtin_expect((reg_html_keywords != NULL), true))
	    {
	       memcpy(reg_html_keywords, variable, sizeof(struct aie_html_keywords) * size);
               size_reg_html_keywords = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_META_HEAD_INFO:
         {
            reg_meta_head_info = (struct aie_meta_head_info *)aie_malloc(
		  sizeof(struct aie_meta_head_info) * size);
	    if (__builtin_expect((reg_meta_head_info != NULL), true))
	    {
	       memcpy(reg_meta_head_info, variable, sizeof(struct aie_meta_head_info) * size);
               size_reg_meta_head_info = size;
	    }
         }
         break;
         #if 0
         case AIENGINE_REGISTER_AD_FILES:
         {
            reg_ad_files = (struct aie_ad_files *)aie_malloc(
		  sizeof(struct aie_ad_files) * size);
	    if (__builtin_expect((reg_ad_files != NULL), true))
	    {
	       memcpy(reg_ad_files, variable, sizeof(struct aie_ad_files) * size);
               size_reg_ad_files = size;
	    }
         }
         #endif
         break;
#if 0
         case AIENGINE_REGISTER_IMP_BODY_LINKS:
         {
            reg_imp_body_links = (struct aie_imp_body_links *)aie_malloc(
		  sizeof(struct aie_imp_body_links) * size);
	    if (__builtin_expect((reg_imp_body_links != NULL), true))
	    {
	       memcpy(reg_imp_body_links, variable, sizeof(struct aie_imp_body_links) * size);
               size_reg_imp_body_links = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_STANDARD_IMP:
         {
            reg_standard_imp = (struct aie_standard_imp *)aie_malloc(
		  sizeof(struct aie_standard_imp) * size);
	    if (__builtin_expect((reg_standard_imp != NULL), true))
	    {
	       memcpy(reg_standard_imp, variable, sizeof(struct aie_standard_imp) * size);
               size_reg_standard_imp = size;
	    }
         }
         break;
#endif
         case AIENGINE_REGISTER_PAGE_JAVASCRIPT:
         {
            reg_page_javascript = (struct aie_page_javascript *)aie_malloc(
		  sizeof(struct aie_page_javascript) * size);
	    if (__builtin_expect((reg_page_javascript != NULL), true))
	    {
	       memcpy(reg_page_javascript, variable, sizeof(struct aie_page_javascript) * size);
               size_reg_page_javascript = size;
	    }
         }
         break;
#if 0
         case AIENGINE_REGISTER_CGI_VAR_REMOTE_2_LOCAL:
         {
            reg_cgi_var_remote_2_local = (struct aie_cgi_var_remote_2_local *)aie_malloc(
		  sizeof(struct aie_cgi_var_remote_2_local) * size);
	    if (__builtin_expect((reg_cgi_var_remote_2_local != NULL), true))
	    {
	       memcpy(reg_cgi_var_remote_2_local, variable, sizeof(struct aie_cgi_var_remote_2_local) * size);
               size_reg_cgi_var_remote_2_local = size;
	    }
         }
         break;
#endif
         #if 0
         case AIENGINE_REGISTER_KNOWN_MENUES:
         {
            reg_known_menues = (struct aie_known_menues *)aie_malloc(
		  sizeof(struct aie_known_menues) * size);
	    if (__builtin_expect((reg_known_menues != NULL), true))
	    {
	       memcpy(reg_known_menues, variable, sizeof(struct aie_known_menues) * size);
               size_reg_known_menues = size;
	    }
         }
         break;
         #endif
         case AIENGINE_REGISTER_PAGE_REC:
         {
            reg_page_rec = (struct aie_page_rec *)aie_malloc(
		  sizeof(struct aie_page_rec) * size);
	    if (__builtin_expect((reg_page_rec != NULL), true))
	    {
	       memcpy(reg_page_rec, variable, sizeof(struct aie_page_rec) * size);
               size_reg_page_rec = size;
	    }
         }
         break;
#if 0
         case AIENGINE_REGISTER_BASIC_REC:
         {
            reg_basic_rec = (struct aie_basic_rec *)aie_malloc(
		  sizeof(struct aie_basic_rec) * size);
	    if (__builtin_expect((reg_basic_rec != NULL), true))
	    {
	       memcpy(reg_basic_rec, variable, sizeof(struct aie_basic_rec) * size);
               size_reg_basic_rec = size;
	    }
         }
         break;
#endif
         case AIENGINE_REGISTER_KNOWN_FRAMES:
         {
            reg_known_frames = (struct aie_known_frames *)aie_malloc(
		  sizeof(struct aie_known_frames) * size);
	    if (__builtin_expect((reg_known_frames != NULL), true))
	    {
	       memcpy(reg_known_frames, variable, sizeof(struct aie_known_frames) * size);
               size_reg_known_frames = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_MODULE_2_CGI_PROG:
         {
            reg_module_2_cgi_prog = (struct aie_module_2_cgi_prog *)aie_malloc(
		  sizeof(struct aie_module_2_cgi_prog) * size);
	    if (__builtin_expect((reg_module_2_cgi_prog != NULL), true))
	    {
	       memcpy(reg_module_2_cgi_prog, variable, sizeof(struct aie_module_2_cgi_prog) * size);
               size_reg_module_2_cgi_prog = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_PAGE_CGI_DISPATCH:
         {
            reg_page_cgi_dispatch = (struct aie_page_cgi_dispatch *)aie_malloc(
		  sizeof(struct aie_page_cgi_dispatch) * size);
	    if (__builtin_expect((reg_page_cgi_dispatch != NULL), true))
	    {
	       memcpy(reg_page_cgi_dispatch, variable, sizeof(struct aie_page_cgi_dispatch) * size);
               size_reg_page_cgi_dispatch = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_FRAME_CGI_DISPATCH:
         {
            reg_frame_cgi_dispatch = (struct aie_frame_cgi_dispatch *)aie_malloc(
		  sizeof(struct aie_frame_cgi_dispatch) * size);
	    if (__builtin_expect((reg_frame_cgi_dispatch != NULL), true))
	    {
	       memcpy(reg_frame_cgi_dispatch, variable, sizeof(struct aie_frame_cgi_dispatch) * size);
               size_reg_frame_cgi_dispatch = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_FOLLOW_CGI_VARS:
         {
            reg_follow_cgi_vars = (struct aie_follow_cgi_vars *)aie_malloc(
		  sizeof(struct aie_follow_cgi_vars) * size);
	    if (__builtin_expect((reg_follow_cgi_vars != NULL), true))
	    {
	       memcpy(reg_follow_cgi_vars, variable, sizeof(struct aie_follow_cgi_vars) * size);
               size_reg_follow_cgi_vars = size;
	    }
         }
         break;
         #if 0
         case AIENGINE_REGISTER_SUB_MEN_PATHS:
         {
            reg_sub_men_paths = (struct aie_sub_men_paths *)aie_malloc(
		  sizeof(struct aie_sub_men_paths) * size);
	    if (__builtin_expect((reg_sub_men_paths != NULL), true))
	    {
	       memcpy(reg_sub_men_paths, variable, sizeof(struct aie_sub_men_paths) * size);
               size_reg_sub_men_paths = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_CGI_VERSION_INFO:
         {
            reg_cgi_version_info = (struct aie_version_info *)aie_malloc(
		  sizeof(struct aie_version_info) * size);
	    if (__builtin_expect((reg_cgi_version_info != NULL), true))
	    {
	       memcpy(reg_cgi_version_info, variable, sizeof(struct aie_version_info) * size);
               size_reg_cgi_version_info = size;
	    }
         }
         break;
         #endif
         case AIENGINE_REGISTER_AIENGINE_ENV:
         {
            reg_aIEngine_env = (struct aie_aIEngine_env *)aie_malloc(
		  sizeof(struct aie_aIEngine_env) * size);
	    if (__builtin_expect((reg_aIEngine_env != NULL), true))
	    {
	       memcpy(reg_aIEngine_env, variable, sizeof(struct aie_aIEngine_env) * size);
               size_reg_aIEngine_env = size;
	    }
         }
         break;
         case AIENGINE_REGISTER_BODY_TAG:
         {
            reg_aIEngine_body_tag = (struct aie_aIEngine_body_tag *)aie_malloc(
		  sizeof(struct aie_aIEngine_body_tag) * size);
	    if (__builtin_expect((reg_aIEngine_body_tag != NULL), true))
	    {
	       memcpy(reg_aIEngine_body_tag, variable, sizeof(struct aie_aIEngine_body_tag) * size);
               size_reg_aIEngine_body_tag = size;
	    }
         }
         break;
         default:
         {
            rc = false;
         }
      }
   }
   else
   {
      rc = false;
   }
   return(rc);
}

struct aie_html_keywords *getRegistered_html_keywords(unsigned int *size)
{
   *size = size_reg_html_keywords;
   return(reg_html_keywords);
}

struct aie_meta_head_info *getRegistered_meta_head_info(unsigned int *size)
{
   *size = size_reg_meta_head_info;
   return(reg_meta_head_info);
}
#if 0
struct aie_ad_files *getRegistered_ad_files(unsigned int *size)
{
   *size = size_reg_ad_files;
   return(reg_ad_files);
}

struct aie_imp_body_links *getRegistered_imp_body_links(unsigned int *size)
{
   *size = size_reg_imp_body_links;
   return(reg_imp_body_links);
}

struct aie_standard_imp *getRegistered_standard_imp(unsigned int *size)
{
   *size = size_reg_standard_imp;
   return(reg_standard_imp);
}
#endif
struct aie_page_javascript *getRegistered_page_javascript(unsigned int *size)
{
   *size = size_reg_page_javascript;
   return(reg_page_javascript);
}
#if 0
struct aie_cgi_var_remote_2_local *getRegistered_cgi_var_remote_2_local(unsigned int *size)
{
   *size = size_reg_cgi_var_remote_2_local;
   return(reg_cgi_var_remote_2_local);
}

struct aie_known_menues *getRegistered_known_menues(unsigned int *size)
{
   *size = size_reg_known_menues;
   return(reg_known_menues);
}
#endif
struct aie_page_rec *getRegistered_page_rec(unsigned int *size)
{
   *size = size_reg_page_rec;
   return(reg_page_rec);
}
#if 0
struct aie_basic_rec *getRegistered_basic_reg(unsigned int *size)
{
   *size = size_reg_basic_rec;
   return(reg_basic_rec);
}
#endif
struct aie_known_frames *getRegistered_known_frames(unsigned int *size)
{
   *size = size_reg_known_frames;
   return(reg_known_frames);
}

struct aie_module_2_cgi_prog *getRegistered_module_2_cgi_prog(unsigned int *size)
{
   *size = size_reg_module_2_cgi_prog;
   return(reg_module_2_cgi_prog);
}

struct aie_page_cgi_dispatch *getRegistered_page_cgi_dispatch(unsigned int *size)
{
   *size = size_reg_page_cgi_dispatch;
   return(reg_page_cgi_dispatch);
}

struct aie_frame_cgi_dispatch *getRegistered_frame_cgi_dispatch(unsigned int *size)
{
   *size = size_reg_frame_cgi_dispatch;
   return(reg_frame_cgi_dispatch);
}

struct aie_follow_cgi_vars *getRegistered_follow_cgi_var(unsigned int *size)
{
   *size = size_reg_follow_cgi_vars;
   return(reg_follow_cgi_vars);

}
#if 0
struct aie_sub_men_paths *getRegistered_sub_men_paths(unsigned int *size)
{
   *size = size_reg_sub_men_paths;
   return(reg_sub_men_paths);

}

struct aie_version_info *getRegistered_cgi_version_info(unsigned int *size)
{
   *size = size_reg_cgi_version_info;
   return(reg_cgi_version_info);

}
#endif
struct aie_aIEngine_env *getRegistered_aIEngine_env(unsigned int *size)
{
   *size = size_reg_aIEngine_env;
   return(reg_aIEngine_env);

}

struct aie_aIEngine_body_tag *getRegistered_aIEngine_body_tag(unsigned int *size)
{
   *size = size_reg_aIEngine_body_tag;
   return(reg_aIEngine_body_tag);

}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_aie_register_size        = __LINE__;                             //
/* -------------------------------- EOF ------------------------------------ */

