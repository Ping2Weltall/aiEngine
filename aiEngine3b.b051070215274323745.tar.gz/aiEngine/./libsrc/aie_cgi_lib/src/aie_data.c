/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_data.c                                                  */
/* Library     : Core aiengine-nn.nn.nn.a                                    */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : char * als const char * deklarieren         */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_data_version   = "1.1.5";                                  //
const char *modul_data           = "Appl_Data";                              //
const char *modul_data_date      = __DATE__;                                 //
const char *modul_data_time      = __TIME__;                                 //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#ifdef aie_do_use_keys                                                       //
#define MYCRYPT_CFG_H                                                        //
#endif                                                                       //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
#if __GNUC__
#define AIENGINE_DATA_SECTION	__attribute__ ((section ("aie_aIEngineData")))
#else
#define AIENGINE_DATA_SECTION
#endif

const char *aIEngine_Content	AIENGINE_DATA_SECTION
                                 = "Content-Type: text/html\10\10";
const char *aIEngine_myExtension	AIENGINE_DATA_SECTION
                                 = "-.html";

// Global httpd tags
const char *doctype	AIENGINE_DATA_SECTION
                                 = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.%s//DE\">\n";

const char *htequiv	AIENGINE_DATA_SECTION
                                 = "http-equiv";
const char *htname	AIENGINE_DATA_SECTION
                                 = "name";

const char *doctype_trans	AIENGINE_DATA_SECTION
                                 = "0 Transitional";
const char *doctype_frame	AIENGINE_DATA_SECTION
                                 = "01 Frameset";

const char *is_href	AIENGINE_DATA_SECTION
                                 = "a href=\"";

const char *image_tag_template	AIENGINE_DATA_SECTION
                                 = "img src=\"%s\" alt=\"%s\" name=\"%s%.2d\" border=\"0\"";
const char *MousePicJavaStr_i1_template	AIENGINE_DATA_SECTION
                                 = " onMouse%s=\"if(document.images){document.%s%.2d.src='%s';}\"";
const char *MousePicJavaStr_i2_template	AIENGINE_DATA_SECTION
                                 = " onMouse%s=\"if(document.images){document.%s%.2d.src='%s';document.%s%.2d.src='%s';}\"";

const char *html_tags_tbl_std_tbl_row_col_start	AIENGINE_DATA_SECTION
                                 = "<TABLE><TR><TD>";
const char *html_tags_tbl_std_row_col_start	AIENGINE_DATA_SECTION
                                = "<TR><TD>";
const char *html_tags_tbl_std_col_row_change	AIENGINE_DATA_SECTION
                                = "</TD></TR><TR><TD>";
const char *html_tags_tbl_std_row_change	AIENGINE_DATA_SECTION
                                = "</TR><TR>";
const char *html_tags_tbl_std_col_change	AIENGINE_DATA_SECTION
                                = "</TD><TD>";
const char *html_tags_tbl_std_col_row_end	AIENGINE_DATA_SECTION
                                = "</TD></TR>";
const char *html_tags_tbl_std_col_row_tbl_end	AIENGINE_DATA_SECTION
                                = "</TD></TR></TABLE>";

const char *html_select	AIENGINE_DATA_SECTION
                                = "SELECT";
const char *html_select_n	AIENGINE_DATA_SECTION
                                = "SELECT NAME=\"%s\"";
const char *html_s_e_select	AIENGINE_DATA_SECTION
                                = "</SELECT>";

const char *html_table	AIENGINE_DATA_SECTION
                                = "TABLE";
const char *html_v_table	AIENGINE_DATA_SECTION
                                = "%s %s";
const char *html_w_v_table	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" %s";
const char *html_w_v_bg_table	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" %s BACKGROUND=\"%s\"";
const char *html_s_e_table	AIENGINE_DATA_SECTION
                                = "</TABLE>\n";
const char *html_s_tr	AIENGINE_DATA_SECTION
                                = "<TR>";
const char *html_tr	AIENGINE_DATA_SECTION
                                = "TR";
const char *html_s_e_tr	AIENGINE_DATA_SECTION
                                = "</TR>";

const char *html_s_td	AIENGINE_DATA_SECTION
                                = "<TD>";
const char *html_td	AIENGINE_DATA_SECTION
                                = "TD";
const char *html_wlt_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" ALIGN=\"left\" VALIGN=\"top\"";
const char *html_wrt_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" ALIGN=\"right\" VALIGN=\"top\"";
const char *html_wacbg_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" ALIGN=\"center\" BACKGROUND=\"%s\"";
const char *html_wt_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" VALIGN=\"top\"";
const char *html_wmbg_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" VALIGN=\"middle\" BACKGROUND=\"%s\"";
const char *html_wh_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" HEIGHT=\"%s\"";
const char *html_whbg_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" HEIGHT=\"%s\" BACKGROUND=\"%s\"";
const char *html_whmbg_td	AIENGINE_DATA_SECTION
                                = "%s WIDTH=\"%s\" VALIGN=\"middle\" HEIGHT=\"%s\" BACKGROUND=\"%s\"";
//const char *html_whmbg_td	AIENGINE_DATA_SECTION
//                                 = "%s WIDTH=\"%s\" HEIGHT=\"%s\" VALIGN=\"middle\" BACKGROUND=\"%s\"";
const char *html_bg_td	AIENGINE_DATA_SECTION
                                = "%s BACKGROUND=\"%s\"";
const char *html_acbg_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"center\" BACKGROUND=\"%s\"";
const char *html_cs_td 	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\"";
const char *html_cslt_td 	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"left\" VALIGN=\"top\"";
const char *html_csacbg_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"center\" BACKGROUND=\"%s\"";
const char *html_csacvm_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"center\" VALIGN=\"middle\"";
const char *html_csacvt_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"center\" VALIGN=\"top\"";
const char *html_cscmbg_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"center\" VALIGN=\"middle\" BACKGROUND=\"%s\"";
const char *html_cscbbg_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"center\" VALIGN=\"bottom\" BACKGROUND=\"%s\"";
const char *html_cshacbg_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"center\" HEIGHT=\"%s\" BACKGROUND=\"%s\"";
const char *html_cswacbg_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" ALIGN=\"center\" WIDTH=\"%s\" BACKGROUND=\"%s\"";
const char *html_cshbg_td	AIENGINE_DATA_SECTION
                                = "%s COLSPAN=\"%s\" HEIGHT=\"%s\" BACKGROUND=\"%s\"";

const char *html_rs_td 	AIENGINE_DATA_SECTION
                                = "%s ROWSPAN=\"%s\"";

const char *html_vt_td	AIENGINE_DATA_SECTION
                                = "%s VALIGN=\"top\"";
const char *html_vm_td	AIENGINE_DATA_SECTION
                                = "%s VALIGN=\"middle\""; // vc -> vm

const char *html_al_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"left\"";
const char *html_ac_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"center\""; //am -> ac
const char *html_ar_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"right\"";

const char *html_alvt_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"left\" VALIGN=\"top\"";
const char *html_arvt_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"right\" VALIGN=\"top\"";
const char *html_amvt_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"middle\" VALIGN=\"top\"";
const char *html_amvc_td	AIENGINE_DATA_SECTION
                                = "%s ALIGN=\"middle\" VALIGN=\"center\"";

const char *html_s_e_td	AIENGINE_DATA_SECTION
                                = "</TD>";

const char *html_input	AIENGINE_DATA_SECTION
                                = "INPUT";

const char *html_a	AIENGINE_DATA_SECTION
                                = "A";
const char *html_s_e_a	AIENGINE_DATA_SECTION
                                = "</A>";
//char *html_b	AIENGINE_DATA_SECTION
//                                 = "B";
const char *html_s_b_b	AIENGINE_DATA_SECTION
                                = "<B>";
const char *html_s_e_b	AIENGINE_DATA_SECTION
                                = "</B>";
//char *html_br	AIENGINE_DATA_SECTION
//                                 = "BR";
//char *html_hr	AIENGINE_DATA_SECTION
//                                 = "HR";
//char *html_nbsp	AIENGINE_DATA_SECTION
//                                 = "&nbsp;";
const char *html_s_br	AIENGINE_DATA_SECTION
                                = "<BR>";
const char *html_s_br2	AIENGINE_DATA_SECTION
                                = "<BR><BR>";
const char *html_s_hr	AIENGINE_DATA_SECTION
                                = "<HR>";
const char *html_s_nbsp	AIENGINE_DATA_SECTION
                                = "&nbsp;";
const char *html_font	AIENGINE_DATA_SECTION
                                = "FONT";
const char *html_font_s	AIENGINE_DATA_SECTION
                                = "%s SIZE=\"%s\"";
const char *html_font_c	AIENGINE_DATA_SECTION
                                = "%s COLOR=\"%s\"";
const char *html_font_sc	AIENGINE_DATA_SECTION
                                = "%s SIZE=\"%s\" COLOR=\"%s\"";
const char *html_s_e_font	AIENGINE_DATA_SECTION
                                = "</FONT>";
const char *html_form	AIENGINE_DATA_SECTION
                                = "FORM";
const char *html_s_e_form	AIENGINE_DATA_SECTION
                                = "</FORM>";
const char *html_center	AIENGINE_DATA_SECTION
                                = "CENTER";
const char *html_s_e_center	AIENGINE_DATA_SECTION
                                = "</CENTER>";
const char *html_html	AIENGINE_DATA_SECTION
                                = "HTML";
const char *html_s_e_html	AIENGINE_DATA_SECTION
                                = "</HTML>";
const char *html_head	AIENGINE_DATA_SECTION
                                = "HEAD";
const char *html_s_e_head	AIENGINE_DATA_SECTION
                                = "</HEAD>\n";
const char *html_title	AIENGINE_DATA_SECTION
                                = "TITLE";
const char *html_s_e_title	AIENGINE_DATA_SECTION
                                = "</TITLE>\n";
const char *html_small	AIENGINE_DATA_SECTION
                                = "SMALL";
const char *html_s_b_small	AIENGINE_DATA_SECTION
                                = "<SMALL>";
const char *html_s_e_small	AIENGINE_DATA_SECTION
                                = "</SMALL>";
const char *html_body	AIENGINE_DATA_SECTION
                                = "BODY";
const char *html_s_e_body	AIENGINE_DATA_SECTION
                                = "</BODY>";
const char *html_frameset	AIENGINE_DATA_SECTION
                                = "FRAMESET";
const char *html_s_e_frameset	AIENGINE_DATA_SECTION
                                = "</FRAMESET>";
const char *html_noscript	AIENGINE_DATA_SECTION
                                = "NOSCRIPT";
const char *html_s_e_noscript	AIENGINE_DATA_SECTION
                                = "</NOSCRIPT>";
const char *html_start_js	AIENGINE_DATA_SECTION
                                = "<script language=\"javascript\" type=\"text/javascript\">\n<!--\n";
const char *html_end_js	AIENGINE_DATA_SECTION
                                = "//-->\n</script>\n";

const char *frame_options	AIENGINE_DATA_SECTION
                                = " name=\"%s\" scrolling=\"%s\" FRAMEBORDER=\"0\" NORESIZE MARGINHEIGHT=\"0\" MARGINWIDTH=\"0\">";
const char *frame_intro  	AIENGINE_DATA_SECTION
                                = "<frame src=";
const char *tag_frameset 	AIENGINE_DATA_SECTION
                                = "<frameset %s FRAMEBORDER=\"0\" BORDER=\"0\" FRAMESPACING=\"0\" FRAMEBORDER=\"0\">";

const char *unknown_html_body	AIENGINE_DATA_SECTION
                                = "<body><br>* Body nicht definiert * [%s] *<br>";

const char *ht_table_100p	AIENGINE_DATA_SECTION
                                = "100%";
const char *ht_table_b0	AIENGINE_DATA_SECTION
                                = "border=\"0\" cellpadding=\"0\" cellspacing=\"0\"";
const char *ht_table_b1	AIENGINE_DATA_SECTION
                                = "border=\"1\"";
const char *ht_table_dashed_frame	AIENGINE_DATA_SECTION
                                = "STYLE=\"BORDER-RIGHT: #12c6c4 1px dashed; BORDER-TOP: #12c6c4 1px dashed; BORDER-LEFT: #12c6c4 1px dashed; BORDER-BOTTOM: #12c6c4 1px dashed\" CELLSPACING=\"0\" CELLPADDING=\"0\" ALIGN=\"center\" BORDER=\"0\"";

const char *tag_form_get	AIENGINE_DATA_SECTION
                                = "<FORM name=\"%s\" action=%s method=\"get\" >";
const char *tag_form_post	AIENGINE_DATA_SECTION
                                = "<FORM name=\"%s\" action=%s method=\"post\" autocomplete=\"off\" >";
const char *tag_form_post_multipart	AIENGINE_DATA_SECTION
                                = "<FORM name=\"%s\" action=%s method=\"post\" autocomplete=\"off\" encType=\"multipart/form-data\" >";

const char *tag_meta	AIENGINE_DATA_SECTION
                                = "<meta %s=\"%s\" content=\"%s\">\n";

/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int  modul_data_size       = __LINE__;                                       //
/* -------------------------------- EOF ------------------------------------ */

