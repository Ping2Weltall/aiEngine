/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : dispmain.c                                                  */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : September 2003                                              */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2006  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : const char * als const * deklarieren        */
/*.............+...............+.............................................*/
/* 27.12.2003  : ALH           : Neue Funktionen -  get_page_2_cgi_prog      */
/*                                                  get_frame_2_cgi_prog     */
/*                                                  get_cgi_name             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_dispmain_version    = "1.0.0";                             //
const char *modul_dispmain            = "Dispmain";                          //
const char *modul_dispmain_date       = __DATE__;                            //
const char *modul_dispmain_time       = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static /*const*/ char *get_cgi_name(int modul);                              //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Erstellt      : ALH / 27.12.2003                                          */
/* Rueckgabewert : struct page_rec *                                         */
/*...........................................................................*/
struct aie_page_rec *aie_get_page_record(const char *whichPage)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_page_record Page[%s]" },
      { AIE_LOG_TRACE_FKT,  "Struktur page_rec nicht Registriert - "
	                                                   "Page[%s]" },
      { AIE_LOG_WARN, "aie_get_page_record Parameter == NULL Ptr" },
      { AIE_LOG_TRACE_FKT,  "Keine Zuordnung Page[%s] zu page_rec" }
   };
   struct aie_page_rec *ptr = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, whichPage);
   #endif
   //sys_log("%s(%d): Here", __FILE__, __LINE__);
   if (__builtin_expect((whichPage != NULL),true))
   {
      struct aie_page_rec *page_rec;
      //struct aie_page_rec page_rec[];
      unsigned int size_page_rec;

   //sys_log("%s(%d): Here", __FILE__, __LINE__);
      if (__builtin_expect(((page_rec = 
	       getRegistered_page_rec(&size_page_rec)) != NULL),true))
      {
         register unsigned int i = 0;
   //sys_log("%s(%d): Here", __FILE__, __LINE__);
         for (i = 0;i < size_page_rec;i++)
         {
   //sys_log("%s(%d): Here i=%d", __FILE__, __LINE__, i);
            if (__builtin_expect(
		     //(strcmp(whichPage, page_rec->page) == 0),false))
		     (strcmp(whichPage, page_rec[i].page) == 0),false))
            {
               ptr = &page_rec[i];
               break;
            }
            //page_rec++;
         }
      }
      else
      {
         aie_sys_log(1, whichPage);
      }
   }
   else
   {
      aie_sys_log(2);
   }
   if (__builtin_expect((ptr != NULL), true))
   {
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(3, whichPage);
      #endif
   }
   //sys_log("%s(%d): Here", __FILE__, __LINE__);
   return(ptr);
}
/*---------------------------------------------------------------------------*/

#if 0
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Erstellt      : ALH / 27.12.2003                                          */
/* Rueckgabewert : struct basic_rec *                                        */
/*...........................................................................*/
struct aie_basic_rec *aie_get_basic_record(const char *whichPage)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_basic_record Page[%s]" },
      { AIE_LOG_TRACE_FKT,  "Struktur basic_rec nicht Registriert - "
	                                                   "Page[%s]" },
      { AIE_LOG_WARN, "aie_get_basic_record Parameter == NULL Ptr" },
      { AIE_LOG_TRACE_FKT,  "Keine Zuordnung Page[%s] zu page_rec" }
   };
   struct aie_basic_rec *ptr = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, whichPage);
   #endif
   if (__builtin_expect((whichPage != NULL),true))
   {
      struct aie_basic_rec *basic_rec;
      unsigned int size_basic_rec;
      if (__builtin_expect(((basic_rec = 
                      getRegistered_basic_reg(&size_basic_rec)) != NULL),true))
      {
         register unsigned int i = 0;
         for (i = 0;i < size_basic_rec;i++)
         {
            if (__builtin_expect((
	                       strcmp(whichPage, basic_rec->page) == 0),false))
            {
               ptr = basic_rec;
               break;
            }
            basic_rec++;
         }
      }
      else
      {
         aie_sys_log(1, whichPage);
      }
   }
   else
   {
      aie_sys_log(2, whichPage);
   }
   if (__builtin_expect((ptr != NULL), true))
   {
      aie_sys_log(3, whichPage);
   }
   return(ptr);
}
/*---------------------------------------------------------------------------*/
#endif
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Erstellt      : ALH / 27.12.2003                                          */
/* Rueckgabewert : struct known_frames *                                     */
/*...........................................................................*/
struct aie_known_frames *aie_SelectFrameSet(int whichFrameSet)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_SelectFrameSet FrameSet[%d]" },
      { AIE_LOG_WARN,  "Struktur known_frames nicht Registriert - "
	                                                   "FrameSet[%d]" },
      { AIE_LOG_WARN,  "Keine Zuordnung FrameSet[%d] zu Frame" }
   };
   struct aie_known_frames *known_frames;
   unsigned int size_known_frames;
   struct aie_known_frames *ptr = NULL;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((
	    (known_frames = getRegistered_known_frames(&size_known_frames)) 
                                                          != NULL),true))
   {
      register unsigned int i = 0;
      for (i = 0; i < size_known_frames; i++)
      {
         if (__builtin_expect((known_frames->FrameSet == whichFrameSet),false))
         {
            ptr = known_frames;
         }
         known_frames++;
      }
   }
   else
   {
      aie_sys_log(1, whichFrameSet);
   }
   if (__builtin_expect((ptr == NULL), false))
   {
      aie_sys_log(2, whichFrameSet);
   }
   return(ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : get_page_2_cgi_prog                                       */
/*                 Ermittelt aus der Seitenvariable das CGI das die Seite    */
/*                 verarbeitet.                                              */
/* Erstellt      : ALH / 27.12.2003                                          */
/* Parameter     : char *   - Seite                                          */
/* Rueckgabewert : char *   - CGI Programmname                               */
/*                 NULL     - Parameter Seite == NULL                        */
/*                 NULL     - Falls Seite nicht gefunden wird                */
/*...........................................................................*/
/*const*/ char *aie_get_page_2_cgi_prog(const char *whichPage)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_page_2_cgi_prog Page[%s]" },         
      { AIE_LOG_WARN,  "Struktur page_cgi_dispatch nicht Registriert || "
	                                                   "NULL Page[%s]" },
      { AIE_LOG_WARN, "aie_get_page_2_cgi_prog Page Parameter NULL Ptr" },
      { AIE_LOG_WARN,  "Keine Zuordnung page[%s] zu cgi Programm" }
   };
   /*const*/ char *rc_ptr = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, whichPage);
   #endif
   {
      rc_ptr = NULL;
      if (__builtin_expect(((whichPage != NULL) && 
		            (*whichPage != '\0')),true))
      {
         struct aie_page_cgi_dispatch *page_cgi_dispatch;
         unsigned int size_page_cgi_dispatch;
         if (__builtin_expect(((page_cgi_dispatch = 
		  getRegistered_page_cgi_dispatch(&size_page_cgi_dispatch)) 
                                                                != NULL),true))
         {
            register unsigned int i = 0;
            for(i = 0; i < size_page_cgi_dispatch; i++)
            {
               if (__builtin_expect((
		       strcmp(page_cgi_dispatch->page, whichPage) == 0),false))
               {
                  rc_ptr = get_cgi_name(page_cgi_dispatch->modul);
                  break;
               }
               page_cgi_dispatch++;
            }
         }
         else
         {
            aie_sys_log(1, whichPage);
         }
      }
      else
      {
         aie_sys_log(2);
      }
   }
   if (__builtin_expect((rc_ptr == NULL), false))
   {
      aie_sys_log(3, whichPage);
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : get_frame_2_cgi_prog                                      */
/*                 Ermittelt aus der Framevariable das CGI das die Seite     */
/*                 verarbeitet.                                              */
/* Erstellt      : ALH / 27.12.2003                                          */
/* Parameter     : char *   - Frame                                          */
/* Rueckgabewert : char *   - CGI Programmname                               */
/*                 NULL     - Parameter Frame == NULL                        */
/*                 NULL     - Falls Frame nicht gefunden wird                */
/*...........................................................................*/
/*const*/ char *aie_get_frame_2_cgi_prog(const char *whichFrame)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_frame_2_cgi_prog Frame[%s]" },         
      { AIE_LOG_WARN,  "Struktur frame_cgi_dispatch nicht Registriert || "
	                                                   "NULL Frame[%s]" },
      { AIE_LOG_WARN, "aie_get_frame_2_cgi_prog Frame Parameter NULL Ptr" },
      { AIE_LOG_WARN,  "Keine Zuordnung Frame[%s] zu cgi Programm" }
   };
   /*const*/ char *rc_ptr = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, whichFrame);
   #endif
   if (__builtin_expect(((whichFrame != NULL) && 
	                 (*whichFrame != '\0')),true))
   {
      struct aie_frame_cgi_dispatch *frame_cgi_dispatch;
      unsigned int size_frame_cgi_dispatch;
      if (__builtin_expect(((frame_cgi_dispatch = 
	       getRegistered_frame_cgi_dispatch(&size_frame_cgi_dispatch))
	                                                         != NULL),true))
      {
         register unsigned int i = 0;
         for(i = 0; i < size_frame_cgi_dispatch; i++)
         {
            if (__builtin_expect((
		    strcmp(frame_cgi_dispatch->frame, whichFrame) == 0),false))
            {
               rc_ptr = get_cgi_name(frame_cgi_dispatch->modul);
               break;
            }
            frame_cgi_dispatch++;
         }
      }
      else
      {
         aie_sys_log(1, whichFrame);
      }
   }
   else
   {
      aie_sys_log(2, whichFrame);
   }
   if (__builtin_expect((rc_ptr == NULL), false))
   {
      aie_sys_log(3, whichFrame);
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : get_cgi_name                                              */
/* Parameter     : int                                                       */
/* Erstellt      : ALH / 28.12.2003                                          */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
static /*const*/ char *get_cgi_name(int modul)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_cgi_name Modul[%d]" },         
      { AIE_LOG_WARN,  "Struktur module_2_cgi_prog nicht Registriert || NULL" },
      { AIE_LOG_TRACE_FKT, "aie_get_cgi_name have cache Modul[%d]" },         
      { AIE_LOG_WARN,  "Keine Zuordnung Modul[%d] zu cgi Programm" }
   };
   static /*const*/ char *rc_ptr = NULL;
   static int modul_merker = -1;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, modul);
   #endif

   if (__builtin_expect((modul != modul_merker),false))
   {
      struct aie_module_2_cgi_prog *module_2_cgi_prog;
      unsigned int size_module_2_cgi_prog;
      rc_ptr = NULL;
      modul_merker = modul;
      if (__builtin_expect(((module_2_cgi_prog = 
	       getRegistered_module_2_cgi_prog(&size_module_2_cgi_prog)) 
	                                                        != NULL),true))
      {
         register unsigned int i = 0;
         for (i = 0; i < size_module_2_cgi_prog; i++)
         {
            if (__builtin_expect((module_2_cgi_prog->modul == modul),false))
            {
                rc_ptr = module_2_cgi_prog->cgi_prog;
                break;
            }
            module_2_cgi_prog++;
         }
      }
      else
      {
	 // Struktur module_2_cgi_prog nicht Registriert oder NULL
         aie_sys_log(1, modul);
      }
   }
   else
   {
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(2, modul);
      #endif
   }
   if (__builtin_expect((rc_ptr == NULL), false))
   {
      // Keine Zuordnung Modul[%d] zu cgi Programm
      aie_sys_log(3, modul);
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : get_cgi_prog_from_cgi_vars                                */
/* Parameter     : struct cgi_vars *                                         */
/* Erstellt      : ALH / 29.12.2003                                          */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
const char *aie_get_cgi_prog_from_cgi_vars(struct aie_cgi_parameter 
                                                  *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_get_cgi_prog_from_cgi_vars" },         
      { AIE_LOG_WARN,  "Kein dispatch Eintrag fuer Frame [%s]" },
      { AIE_LOG_INFO,  "Dispatch Frame[%s] fuer Page [%s] suchen" }, 
      { AIE_LOG_INFO,  "Moegliches neues Ziel %s" },
      { AIE_LOG_INFO,  "Switch CGI - [%s] [%s]->[%s]" }, 
      { AIE_LOG_WARN,  "Kein dispatch Eintrag fuer Seite [%s]" },
      { AIE_LOG_INFO,  "Kein Frame  - Verwende Seite %s als Ziel" },
      { AIE_LOG_ERROR, "Kein Frame und Keine Seite - Link Fehler" }
   };
   const char *rc_ptr = NULL;
   aie_CGIFrameSetVar(hasFrame);

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(aie_CharEmptyValue(hasFrame),true))
   {
      aie_CGIPageNameVar(hasPage);
      #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
      aie_sys_log(6, hasPage);
      #endif
      if (__builtin_expect((!aie_CharEmptyValue(hasPage)), false))
      {
          rc_ptr = aie_get_page_2_cgi_prog(hasPage);
      }
      else
      {
         aie_sys_log(7);
      }
   }
   else
   {
      const char *ProgMe = 
	          aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CGI_MYSELF);
      rc_ptr = aie_get_frame_2_cgi_prog(hasFrame);
      if (ProgMe != NULL)
      {
	 if (__builtin_expect((rc_ptr == NULL) ||
		              (strcmp(rc_ptr, ProgMe) == 0), true))
	 {
	    char *tmp;
            aie_CGIPageNameVar(hasPage);
	    if (__builtin_expect((rc_ptr == NULL), false))
	    {
	       // Kein dispatch Eintrag fuer Frame [%s]", 
               aie_sys_log(1, hasFrame);
	    }
            #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
	    // Dispatch Frame[%s] fuer Page [%s] suchen", 
            aie_sys_log(2, hasFrame, hasPage);
            #endif
            tmp = aie_get_page_2_cgi_prog(hasPage);
	    if (tmp != NULL)
	    {
               #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
	       // Moegliches neues Ziel %s
               aie_sys_log(3, tmp);
               #endif
	       if (__builtin_expect(
		      ((rc_ptr == NULL) || (strcmp(tmp, rc_ptr) != 0)),false))
	       {
                  #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
	          // Switch CGI - [%s] [%s]->[%s]", 
                  aie_sys_log(4, ProgMe, rc_ptr, tmp);
                  #endif
		  rc_ptr = tmp;
	       } 
	    }
	    else
	    {
	       // Kein dispatch Eintrag fuer Seite [%s]
               aie_sys_log(5, hasPage);
	    }
	 }
      }
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   // Verwende %s als Ziel
   aie_sys_log(6, rc_ptr);
   #endif
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_dispmain_size       = __LINE__;                                  //
/* -------------------------------- EOF ------------------------------------ */

