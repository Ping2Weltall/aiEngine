/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_iapl.c                                                  */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 08.10.2004  : ALH           : GetCharListCGIValue                         */
/*                 Aenderung der Reiehenfolge - nun Reverse weil neue Element*/
/*                 Elemente - siehe SetCharCGIValue am Anfang der Liste an-  */
/*                 gehaengt werden. Gleiches vorgehen jetzt in GetCharListCGI*/
/*                 Value wodurch sortierung wieder hergestellt wird und      */
/*                 performance sollte besser werden.                         */
/*.............+...............+.............................................*/
/* 07.10.2004  : ALH           : SetCharCGIValue so geandert das Variablen am*/
/*             :               : anfang der Liste angehaengt werden und nicht*/
/*             :               : mehr am Ende - wegen Link Optimierung sollte*/
/*             :               : auch performance verbessern.                */
/*             :               : Verusachte Fehler in FollowCgiVariablen.    */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 27.12.2003  : ALH           : Neue Funktion  - SetCGIVarsFromProgLink     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_iapl_version        = "1.0.1";                             //
const char *modul_iapl                = "IApl";                              //
const char *modul_iapl_date           = __DATE__;                            //
const char *modul_iapl_time           = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#ifdef __WIN32__                                                             //
#include <fcntl.h>                                                           //
#include <io.h>                                                              //
#endif                                                                       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static struct aie_cgi_variables 
          *aie_parse_multipart_data(struct aie_cgi_parameter *cgi_parameter);//
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

//#undef AIENGINE_LOG_TRACE_RUN_CGI_TRACE
//#define AIENGINE_LOG_TRACE_RUN_CGI_TRACE 1
#if 0
	  // Die Funktionen sind nun als Macro Inline
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
char aie_EvalFrameSet(struct aie_cgi_parameter *cgi_parameter)
{
  return((char)aie_GetIntCGIValue(cgi_parameter, isFrameCGIVar));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
char *aie_isPageName(struct aie_cgi_parameter *cgi_parameter)
{
  return(aie_GetCharCGIValue(cgi_parameter, isNameCGIVar));
}
/*---------------------------------------------------------------------------*/
#endif

#if 0
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
static const char *CgiRemote2LocalPictureVar(const char *RemotePicCGIVar)
{
   const char *rc_ptr = NULL;
   if (__builtin_expect((RemotePicCGIVar != NULL),true))
   {
       struct cgi_var_remote_2_local *cgi_var_remote_2_local;
       unsigned int size_cgi_var_remote_2_local;
       if (__builtin_expect(((cgi_var_remote_2_local = 
            getRegistered_cgi_var_remote_2_local(&size_cgi_var_remote_2_local)) 
	                                                       != NULL),true))
       {
          for(unsigned int z = 0; z < size_cgi_var_remote_2_local; z++)
          {
             if (strcmp(cgi_var_remote_2_local->remote, RemotePicCGIVar) == 0)
             {
                rc_ptr = cgi_var_remote_2_local->local;
                break;
             }
             cgi_var_remote_2_local++;
          }
       }
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/
#endif

/*---------------------------------------------------------------------------*/
time_t aie_GetCGIValueDateTime(AIE_CGI_STANDARD_FKT_PARAMETER, const char *var)
{
   aie_CGIValueVar(tmp_aie_CGIPtr, var);
   return(aie_StringEmpty(tmp_aie_CGIPtr) ? (time_t)0 : 
                                aie_StrToDateTime(tmp_aie_CGIPtr));
}

double aie_GetCGIValueDouble(AIE_CGI_STANDARD_FKT_PARAMETER, const char *var)
{
   aie_CGIValueVar(tmp_aie_CGIPtr, var);
   return(aie_StringEmpty(tmp_aie_CGIPtr) ? (double)0.0 : 
	                                                atof(tmp_aie_CGIPtr));
}

float aie_GetCGIValueFloat(AIE_CGI_STANDARD_FKT_PARAMETER, const char *var)
{
   aie_CGIValueVar(tmp_aie_CGIPtr, var);
   return(aie_StringEmpty(tmp_aie_CGIPtr) ? (double)0.0 : 
	                                                atof(tmp_aie_CGIPtr));
}
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
int aie_GetIntCGIValue(struct aie_cgi_parameter *cgi_parameter, const char *name) 
{
   #if AIENGINE_LOG_TRACE_CGI_VALUES
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_GetIntCGIValue [%s]" }
   };
   #endif
   char *ptr;
   int rc = 0;

   #if AIENGINE_LOG_TRACE_CGI_VALUES
   aie_sys_log(0, name);
   #endif
   if (__builtin_expect(
	    ((ptr = aie_GetCharCGIValue(cgi_parameter, name)) != NULL),true))
   {
      rc = atoi(ptr);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
char *aie_GetCharCGIValue(struct aie_cgi_parameter *cgi_parameter, 
                      const char *name) 
{
   #if AIENGINE_LOG_TRACE_CGI_VALUES
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_GetCharCGIValue Name[%s]" },
      { AIE_LOG_TRACE, "aie_GetCharCGIValue Neme[%s] == Name[%s]?" },
      { AIE_LOG_TRACE, "aie_GetCharCGIValue found Name[%s] Value[%s]" },
      { AIE_LOG_TRACE, "aie_GetCharCGIValue .. done Name[%s]" }
   };
   #endif
   char *ptr = NULL;

   #if AIENGINE_LOG_TRACE_CGI_VALUES
   aie_sys_log(0, name);
   #endif
   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      struct aie_cgi_variables *cgi_vars_ptr = cgi_parameter->cgi_variables;
      while(cgi_vars_ptr != NULL)
      {
         #if AIENGINE_LOG_TRACE_CGI_VALUES
         aie_sys_log(1, cgi_vars_ptr->nam, name);
         #endif
         if (__builtin_expect((strcmp(cgi_vars_ptr->nam, name) == 0),false))
         {
            #if AIENGINE_LOG_TRACE_CGI_VALUES
            aie_sys_log(2, name, cgi_vars_ptr->val, name);
            #endif
            ptr = cgi_vars_ptr->val;
            break;
         }
         cgi_vars_ptr = cgi_vars_ptr->next;
      }
   }
   #if AIENGINE_LOG_TRACE_CGI_VALUES
   aie_sys_log(3, name);
   #endif
   return(ptr);
}
/*---------------------------------------------------------------------------*/
//#endif

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     : Aenderung wegen Link Optimierung wenn Variable angefuegt  */
/*                 wird diese nun vorne angehaengt wodurch sich die Speicher-*/
/*                 adresse aendert.                                          */
/*...........................................................................*/
struct aie_cgi_variables *aie_SetCharCGIValue(struct aie_cgi_parameter 
                                             *cgi_parameter, 
                                      char *name, char *value)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_SetCharCGIValue name[%s] wert[%s]" },         
      { AIE_LOG_ERROR, "CGI Parameter == NULL" }
   };
   struct aie_cgi_variables *cgi_vars_ptr = NULL;

   #if AIENGINE_LOG_TRACE_CGI_VALUES
   aie_sys_log(0, name, value);
   #endif

   if (__builtin_expect((value != NULL), true))
   {
      if (__builtin_expect((cgi_parameter != NULL), true))
      {
         cgi_vars_ptr = (struct aie_cgi_variables *)
	                          aie_malloc(sizeof(struct aie_cgi_variables));
         if (__builtin_expect((cgi_vars_ptr != NULL),true))
         {
            cgi_vars_ptr->next = cgi_parameter->cgi_variables;
            cgi_vars_ptr->nam = name;
            cgi_vars_ptr->val = value;
            cgi_vars_ptr->len = strlen(value);
            cgi_parameter->cgi_variables = cgi_vars_ptr;
         }
      }
      else
      {
         // CGI Parameter == NULL
         aie_sys_log(1);
      }
   }
   return(cgi_vars_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : SetCGIVarsFromProgLink                                    */
/* Erstellt      : ALH / 27.12.2003                                          */
/* Aenderung     : ALH / 05.05.2004                                          */
/*               : Link vars anstatt [] nun *                                */
/* Parameter     : struct link_vars link_vars[]  - Variblen fuer html link   */
/*                 int size                 -Anzahl der Elemente in link_vars*/
/*                 struct cgi_vars *cgi_vars_base - Pointer auf Rueckgabe    */
/* Rueckgabewert : struct cgi_vars *                                         */
/* Bemerkung     : Die zurueckgegebene Verkettete Liste muss spaeter explizit*/
/*                 mit CleanUpCGIVars freigegeben werden.                    */
/*.............+...............+.............................................*/
/* 07.05.2004  : ALH           : Erlaubt jetzt auch '\0' Werte als value     */
/*...........................................................................*/
struct aie_cgi_variables *aie_SetCGIVarsFromProgLink(const struct 
                                                                 aie_link_vars 
                                                        *link_vars, 
                                                 int size,
                                                 struct aie_cgi_parameter 
					                *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_SetCGIVarsFromProgLink Size[%d]" },
      { AIE_LOG_TRACE_FKT, "VarsFromProgLink [%s]=[%s]" },
      { AIE_LOG_WARN, "aie_SetCGIVarsFromProgLink Parameter == NULL Ptr" }
   }; 
   register int i = 0;
   struct aie_cgi_variables *cgi_vars_ptr = NULL;
   #if AIENGINE_LOG_TRACE_LINK
   aie_sys_log(0, size);
   #endif
   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      cgi_vars_ptr = cgi_parameter->cgi_variables;
      for (i = 0;i < size;i++)
      {
           #if AIENGINE_LOG_TRACE_LINK
           aie_sys_log(1, link_vars->var, link_vars->val);
           #endif
         if (__builtin_expect((link_vars->val != NULL),true))
         {
            cgi_vars_ptr = aie_SetCharCGIValue(cgi_parameter, 
		                           aie_strdup(link_vars->var),
                                           aie_strdup(link_vars->val));
         }
         link_vars++;
      }
      cgi_parameter->cgi_variables = cgi_vars_ptr;
   }
   else
   {
      aie_sys_log(1);
   }
   return(cgi_vars_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     : Aenderung der Reiehenfolge - nun Reverse weil neue Element*/
/*                 Elemente - siehe SetCharCGIValue am Anfang der Liste an-  */
/*                 gehaengt werden. Gleiches vorgehen jetzt in GetCharListCGI*/
/*                 Value wodurch sortierung wieder hergestellt wird und      */
/*                 performance sollte besser werden.                         */
/*...........................................................................*/
struct aie_cgi_variables *aie_GetCharListCGIValue(struct aie_cgi_parameter 
                                                 *cgi_parameter, 
                                              const char *name, 
				              struct aie_cgi_variables 
					             **vars_base)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_GetCharListCGIValue name=[%s]" },         
      { AIE_LOG_WARN,  "CGI List PTR != NULL" },
      { AIE_LOG_ERROR, "Out of Memory?!" },
      { AIE_LOG_ERROR, "Keine Variablen vorhanden!?" }
   };
   struct aie_cgi_variables *var_list_base = NULL;
   struct aie_cgi_variables *var_list_ptr = NULL;
   struct aie_cgi_variables *cgi_vars_ptr = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0, name);
   #endif
   if (__builtin_expect(((cgi_parameter != NULL) && 
	  ((cgi_vars_ptr = cgi_parameter->cgi_variables) != NULL)), true))
   {
      if (__builtin_expect(((var_list_base = *vars_base) != NULL),false))
      {
         // CGI List PTR != NULL
         aie_sys_log(1);
      }
      else
      {
         //cgi_vars_ptr = cgi_vars_base;
         while(cgi_vars_ptr != NULL)
         {
            if (__builtin_expect((strstr(cgi_vars_ptr->nam, name) != NULL),false))
            {
                var_list_ptr = 
		        (struct aie_cgi_variables *)
			          aie_malloc(sizeof(struct aie_cgi_variables));
		if (__builtin_expect((var_list_ptr != NULL), true))
		{
                   if (__builtin_expect((var_list_base == NULL),false))
                   {
	              var_list_ptr->next = NULL;	
                   }
                   else
                   {
                      var_list_ptr->next = var_list_base;
                   }
                   var_list_ptr->nam = cgi_vars_ptr->nam;
                   var_list_ptr->val = cgi_vars_ptr->val;
                   var_list_base = var_list_ptr;
                   *vars_base = var_list_base;
		}
		else
		{
		   // Out of Memory?!
                   aie_sys_log(2);
		}
            }
            cgi_vars_ptr = cgi_vars_ptr->next;
         }
      }
   }
   else
   {
      // Keine Variablen vorhanden!?
      aie_sys_log(3);
   }
   return(var_list_base);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
void aie_CleanCharListCGIValue(struct aie_cgi_variables **vars_base)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_CleanCharListCGIValue" },         
      { AIE_LOG_ERROR, "CGI List PTR == NULL" }
   };
   static struct aie_cgi_variables *var_list_base;
   static struct aie_cgi_variables *var_list_ptr;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((var_list_base = *vars_base) == NULL),false))
   {
      // CGI List PTR == NULL
      aie_sys_log(1);
   }
   else
   {
      var_list_ptr = var_list_base;
      while(var_list_ptr != NULL)
      {
         var_list_base = var_list_ptr->next;
         aie_free(var_list_ptr);
         var_list_ptr = var_list_base;
      }
   }
   *vars_base = NULL;
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
#ifdef aie_CleanUpCGIVars
#undef aie_CleanUpCGIVars
#endif
//#if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
//void _aie_doCleanUpCGIVars(const char *file, int line, struct aie_cgi_parameter *cgi_parameter)
//#else
void aie_CleanUpCGIVars(struct aie_cgi_parameter *cgi_parameter)
//#endif
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_CleanUpCGIVars"}         
   };
   #endif
   struct aie_cgi_variables *cgi_vars_ptr;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      while ((cgi_vars_ptr = cgi_parameter->cgi_variables) != NULL)
      {
         cgi_parameter->cgi_variables = cgi_vars_ptr->next;
         if (__builtin_expect((cgi_vars_ptr->nam != NULL),true))
         {
            aie_free(cgi_vars_ptr->nam);
         }
         if (__builtin_expect((cgi_vars_ptr->val != NULL),true))
         {
            aie_free(cgi_vars_ptr->val);
         }
         aie_free(cgi_vars_ptr);
      }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
const char *aie_get_upload_image_path(void)
{
   static const char *inserate_img_p_l = NULL;
   if (__builtin_expect((inserate_img_p_l == NULL),true))
   {
      inserate_img_p_l = AIE_MK_IMAGE_UPLOAD_PATH("");
   }
   return(inserate_img_p_l);
}
/*---------------------------------------------------------------------------*/

#if 0
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
static char *save_cgi_image(char *extension, char *picture, int *restlen)
{
   static char imagename[30];
   //char *file_path = CharDynMemory(AIENGINE_MAX_PATH_LENGTH);
   char *file_path = (char *)aie_malloc(AIENGINE_MAX_PATH_LENGTH);
   bool done = false;
   char *sptr = picture;
   //int maxlen = *restlen;
   int z = 0;
   FILE *fptr;
   bool has_error = false;
   //FILE *test_fptr = fopen("ashjccasdf", "r");

   strcat(imagename, get_time_stamp());
   strcat(imagename, ".");
   strcat(imagename, extension);
   strcpy(file_path, get_upload_image_path());
   strcat(file_path, imagename);
   if (__builtin_expect(
	    ((fptr = open_write_binary_file(file_path)) != NULL),true))
   {
      while(!done)
      {
         if (__builtin_expect((fputc(*sptr, fptr) == EOF),false))
         {
             do_log(server_error_file, "Multipart Fehler Grafik = %s", imagename);
             has_error = true;
             done = true;
         }
         z++;
         sptr++;
         if (__builtin_expect((*(sptr + 2) == '-'),false))
         {
            if (__builtin_expect(
		     (strncmp((sptr + 2), "----------", 10) == 0),false))
            {
               done = true;
            }
         }
         if (z >= *restlen)
         {
            done = true;
         }
      }
      close_file(fptr);
      if (__builtin_expect((has_error == true),false))
      {
         delete_file(imagename);
      }
   }
   *restlen = z;
   aie_free(file_path);
   return(imagename);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
static char *do_multipart(char *input, unsigned int len)
{
   char *buf;
   char *sptr = input;
   if (__builtin_expect(((buf = (char *)aie_malloc(len + 1)) != NULL),true))
   {
      memset(buf, '\0', sizeof(buf));
      while ((sptr != NULL) && (sptr = strstr(sptr, "Content-Disposition:")) != NULL)
      {
          char *sptr2;
          if (__builtin_expect(
		   ((sptr2 = strstr(sptr, "name=\"")) == NULL),false))
          {
             do_log(server_error_file, "Multipart Fehler = %s", sptr);
             sptr = NULL;
          }
          else
          {
             char *sptr3;
             if (__builtin_expect(
		      ((sptr3 = strchr(sptr2 + 6, '\"')) == NULL),false))
             {
                do_log(server_error_file, "Multipart Fehler Name = %s", sptr2);
                sptr = NULL;
             }
             else
             {
                const char *pic_var = CgiRemote2LocalPictureVar(sptr2 + 6);

                *sptr3 = '\0';
                sptr3 += 5;
                if (__builtin_expect((pic_var != NULL),true))
                {
                   if ((pic_var != NULL) && 
			 ((sptr2 = strstr(sptr3 - 2, "filename=\"")) != NULL))
                   {
                      char *sptr4;
                      sptr2 += 11;
                      if ((sptr4 = strstr(sptr2 , "Content-Type: image/")) 
			                                               != NULL)
                      {
                         //if (*(sptr2 - 4) == '.')
                         {
                            char extension[5];
                            int restlen = len - ((sptr4 + 20) - input);
                            char *imagename = NULL;
                            memset(extension, '\0', sizeof(extension));
                            if (*(sptr4 + 23) == 'g')
                            {
                               strncpy(extension, sptr4 + 20, 4);
                               imagename = save_cgi_image(extension, sptr4 + 28, &restlen);
                            }
                            else
                            {
                               strncpy(extension, sptr4 + 20, 3);
                               imagename = save_cgi_image(extension, sptr4 + 27, &restlen);
                            }
                            if (__builtin_expect((imagename != NULL),true))
                            {
                               strcat(buf, pic_var);
                               strcat(buf, "=");
                               strcat(buf, imagename);
                               strcat(buf, "&");
                            }
                            sptr = sptr4 + (restlen + 27);
                         }
                      }
                      else
                      {
                         sptr = sptr2;
                      }
                   }
                   else
                   {
                       sptr = sptr3;
                   }
                }
                else
                {
                   char *is_var = sptr2 + 6;
                   //strcat(buf, sptr2 + 6);
                   //strcat(buf, "=");
                   if (__builtin_expect(
			    ((sptr2 = strchr(sptr3, 0x0d)) == NULL),false))
                   {
                      do_log(server_error_file, "Multipart Fehler Value = %s", sptr2);
                   }
                   else
                   {
                      *sptr2 = '\0';
                      // sptr2++;
                      if (__builtin_expect((*sptr3 != '\0'),true))
                      {
                         if (strcmp(is_var, isCodedCGIVar) != 0)
                         {
                            strcat(buf, is_var);
                            strcat(buf, "=");
                            strcat(buf, sptr3);
                         }
                         else
                         {
                            // New Decode
                             #if aie_do_use_keys
                                strcat(buf, do_decode_string(sptr3));
                             #endif
                         }
                         strcat(buf, "&");
                      }
                      sptr = sptr2 + 1;
                   }
                }
             }
          }
      }
   }
   sys_log("%s(%d): Multipart[%s]", __FILE__, __LINE__, buf);
   return(buf);
}
/*---------------------------------------------------------------------------*/
#endif

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
struct aie_cgi_variables *aie_LoadCGIVariables(struct aie_cgi_parameter 
                                                  *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,     "aie_LoadCGIVariables" },
      { AIE_LOG_ERROR,     "Multipart Input nicht erkannt !?" },
      { AIE_LOG_ERROR,     "cgi_parameter->environment == NULL" },
      { AIE_LOG_ERROR,     "cgi_parameter == NULL" },
      { AIE_LOG_TRACE_FKT, "REQUEST_METHOD=%s" },
      { AIE_LOG_TRACE_FKT, "ContentLength == 0 QueryString[%s]" },
      { AIE_LOG_WARN, 	   "QueryString == NULL" },
      { AIE_LOG_TRACE_FKT, "ClientInput == NULL" }
   };
   struct aie_cgi_variables *cgi_vars_base = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((cgi_parameter != NULL) &&
	                 (cgi_parameter->cgi_environment != NULL)), true))
   {
      struct aie_cgi_variables **cgi_vars = &cgi_parameter->cgi_variables;
      unsigned int cl = 0; 
      char *qs, *clientinput = NULL;
      char *content_type = cgi_parameter->cgi_environment->ContentType;

      cgi_vars_base = *cgi_vars;
      
      //content_type = getenv("CONTENT_TYPE");

      #ifdef __WIN32__
         setmode( fileno( stdin ), O_BINARY );
         setmode( fileno( stdout ), O_BINARY );
      #endif /* WIN32 */

       #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
       aie_sys_log(4, cgi_parameter->cgi_environment->RequestMethod);
       #endif
      if (__builtin_expect(
	 (!strcmp("POST", cgi_parameter->cgi_environment->RequestMethod)), 
	                                                                false))
      { /* POST */
        if ((content_type != NULL) && 
	     !strncmp(content_type, "multipart/form-data", 
	                            strlen("multipart/form-data"))) 
       {
          cgi_vars_base = aie_parse_multipart_data(cgi_parameter);   
       }
       else
       {
          if (__builtin_expect((cgi_parameter->cgi_environment->ContentLength
	                                                != NULL), true))
	  {
             cl = atoi(cgi_parameter->cgi_environment->ContentLength);
	  }
          if (__builtin_expect((cl != 0), false))
          {
             clientinput = (char*) aie_malloc(sizeof(char)*(cl+1));
             if (__builtin_expect((clientinput != NULL), true))
             {
                memset(clientinput, '\0', cl + 1);
                fread(clientinput, cl, 1, stdin); /* get the client input */
                if (__builtin_expect(
  	            (strstr(clientinput, "Content-Disposition:") != NULL),
	                                                                false))
                {
	           // Multipart Input nicht erkannt !?
                   aie_sys_log(1);
                }
             }
          }
       }
     }
     else
     { /* GET */
       //qs = cgiQueryString; // getenv("QUERY_STRING");
       //if (__builtin_expect((qs == NULL),false))
       if (__builtin_expect((
		   (qs = cgi_parameter->cgi_environment->QueryString) != NULL),
		                                                        true))
       {
          if (__builtin_expect(((cl = strlen(qs)) != 0), true))
	  {
             clientinput = (char*) aie_malloc(sizeof(char)*(cl+1));
             if (__builtin_expect((clientinput != NULL), true))
             {
                strcpy(clientinput, qs);
             }
	  }
          else
          {
             #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
             aie_sys_log(5, getenv("QUERY_STRING"));
             #endif
          }
       }
       else
       {
          aie_sys_log(6);
       }
     }
     if (__builtin_expect(
                  ((clientinput != NULL) && (*clientinput != '\0')),true))
     {
        cgi_vars_base = 
	           aie_LoadCGIVariablesFromString(clientinput, cgi_parameter);
     }
     else
     {
        #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
        aie_sys_log(7);
        #endif
     }
     if (clientinput != NULL)
     {
        aie_free(clientinput);
     }
     *cgi_vars = cgi_vars_base;
   }
   else
   {
      if (__builtin_expect((cgi_parameter != NULL), true))
      {
	 aie_sys_log(2);
      }
      else
      {
	 aie_sys_log(3);
      }
   }
   return(cgi_vars_base);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
struct aie_cgi_variables *aie_LoadCGIVariablesFromString(
                                                      const char *clientinput, 
                                                      struct aie_cgi_parameter 
						             *cgi_parameter)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_LoadCGIVariablesFromString" }         
   };
   #endif
   struct aie_cgi_variables **cgi_vars = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      char *token;
      unsigned int  l1, l2;
      // struct cgi_vars *cgi_vars_base = *cgi_vars;
      char *sptr = aie_strdup(clientinput);

      cgi_vars = &cgi_parameter->cgi_variables;

      token=strtok(sptr, "&");
      while (token!=NULL)
      {
         char *nam, *val;
         l1 = strlen(token);
         l2 = strcspn(token,"=");

         nam = (char *)aie_malloc(sizeof(char) * (l2+1));
         if (__builtin_expect((nam == NULL),false))
         {
            return(*cgi_vars);
         }
         strncpy(nam, token,l2);
         nam[l2] = '\0';
         aie_unescapechar(nam);
         if (__builtin_expect(((l1 != l2) && (*(token+l2+1) != '&')),true))
         {
            val = (char *)aie_malloc(sizeof(char) * (l1-l2));
            if(val == NULL)
            {
              return(*cgi_vars);
            }
            strcpy(val, token+l2+1);
            aie_unescapechar(val);
         }
         else /* special case of name=& */
         {
            val = NULL;
         }
         token=strtok(NULL, "&");
         if (__builtin_expect((val != NULL), true))
         {
            aie_SetCharCGIValue(cgi_parameter, nam, val);
         }
         else
         {
            aie_free(nam);
         }
      }
      aie_free(sptr);
   }
   return(*cgi_vars);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
int aie_unescapechar(char *url)
{
   int x,y;
   char hex[3]; /* contains xx of %xx */

   for(x=0,y=0;url[y];++x,++y)
   {
        if (__builtin_expect((url[y] == '+'),false))
          url[x] = ' ';       /* change '+' to ' ' */
        else if (__builtin_expect((url[y] == '%'),false))
        { /* change xx as char */
          hex[0] = url[y+1]; hex[1] = url[y+2]; hex[2] = '\0';
          url[x] = (char)strtol(hex, NULL, 16);
          y+=2;              /* three chars %xx as one char */
        }
        else
          url[x] = url[y];
    }
    url[x] = '\0';
   return(0);
}
/*---------------------------------------------------------------------------*/


/* For decode multipart/form-data */
static struct aie_cgi_variables 
                         *aie_parse_multipart_data(struct aie_cgi_parameter 
                                                               *cgi_parameter) 
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_parse_multipart_data" },         
      { AIE_LOG_ERROR, "The boundary string is too long. Stopping process." }, 
      { AIE_LOG_ERROR, "non-HTTP compliant message" },
      { AIE_LOG_ERROR, "String format invalid." },
      { AIE_LOG_ERROR, "Memory allocation fail." },
      { AIE_LOG_ERROR, "Broken stream at end of '%s'" }
   };
   struct aie_cgi_variables *cgi_vars_base = NULL;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      int  cnt;
      struct aie_cgi_variables **cgi_vars = &cgi_parameter->cgi_variables;
      

      char *name, *value, *filename, *contenttype;
      int  valuelen;

      char boundary[256], boundaryEOF[256];
      char rnboundaryrn[256], rnboundaryEOF[256];
      int  boundarylen, boundaryEOFlen;
      unsigned int maxboundarylen;

      char buf[1024];
      int  c, c_count;

      int  finish;

      cgi_vars_base = *cgi_vars;
      /* For parse multipart/form-data method */

      /* Force to check the boundary string length to defense overflow attack */
      maxboundarylen =  strlen("--");
      maxboundarylen += strlen(strstr(getenv("CONTENT_TYPE"), "boundary=") + 
	                strlen("boundary="));
      maxboundarylen += strlen("--");
      maxboundarylen += strlen("\r\n");
      if (__builtin_expect((maxboundarylen >= sizeof(boundary)), false))
      {
         // The boundary string is too long. Stopping process."
         aie_sys_log(1);
      }

      /* find boundary string */
      sprintf(boundary, "--%s", strstr(getenv("CONTENT_TYPE"), "boundary=") + 
	                        strlen("boundary="));
      /* This is not necessary but, I can not trust MS Explore */
      aie_RemoveSpace(boundary);

      sprintf(boundaryEOF, "%s--", boundary);

      sprintf(rnboundaryrn, "\r\n%s\r\n", boundary);
      sprintf(rnboundaryEOF, "\r\n%s", boundaryEOF);

      boundarylen    = strlen(boundary);
      boundaryEOFlen = strlen(boundaryEOF);

      /* check boundary */
      if (__builtin_expect((fgets(buf, sizeof(buf), stdin) == NULL), false))
      {
	 // non-HTTP compliant message
         aie_sys_log(2);
      }

      /* for explore 4.0 of NT, it sent \r\n before starting, fucking Micro$oft */
      if(!strcmp(buf, "\r\n")) fgets(buf, sizeof(buf), stdin);

      if(strncmp(buf, boundary, (unsigned int)boundarylen) != 0) 
      {
         // String format invalid
         aie_sys_log(3);
      }

      //for(finish = 0, cnt = 0; finish != 1; amount++, cnt++) 
      for(finish = 0, cnt = 0; finish != 1; cnt++) 
      {

        /* parse header */
        name = NULL;
        filename = NULL;
        contenttype = NULL;

        while(fgets(buf, sizeof(buf), stdin)) 
        {
           if(!strcmp(buf, "\r\n")) break;
           else if(!aie_StringNoCaseLenCompare(buf, "Content-Disposition: ", 
		                             strlen("Content-Disposition: "))) 
           {
              /* get name field */
              name = aie_strdup(buf + 
		            strlen("Content-Disposition: form-data; name=\""));
              for(c_count = 0; (name[c_count] != '\"') && (name[c_count] != '\0'); 
		                                                    c_count++);
              name[c_count] = '\0';

            /* get filename field */
            if(strstr(buf, "; filename=\"") != NULL) 
	    {
              int erase;
              filename = aie_strdup(strstr(buf, "; filename=\"") + 
		                                     strlen("; filename=\""));
              for(c_count = 0; (filename[c_count] != '\"') && 
		                       (filename[c_count] != '\0'); c_count++);
              filename[c_count] = '\0';
              /* erase '\' */
              for(erase = 0, c_count = strlen(filename) - 1; c_count >= 0; 
		                                                    c_count--) 
	      {
                if(erase == 1) 
	        {
	           filename[c_count]= ' ';
	        }
                else 
	        {
                  if(filename[c_count] == '\\') 
	          {
                    erase = 1;
                    filename[c_count] = ' ';
                  }
                }
              }
              aie_RemoveSpace(filename);
            }
          }
          else if(!aie_StringNoCaseLenCompare(buf, "Content-Type: ", 
	                                            strlen("Content-Type: "))) 
          {
            contenttype = aie_strdup(buf + strlen("Content-Type: "));
            aie_RemoveSpace(contenttype);
          }
        }
    
        /* get value field */
        for(value = NULL, valuelen = (1024 * 16), c_count = 0; 
	                                           (c = fgetc(stdin)) != EOF; ) 
        {
          if(c_count == 0) 
          {
            value = (char *)aie_malloc(sizeof(char) * valuelen);
            if(value == NULL) 
	    {
	       // Memory allocation fail.
               aie_sys_log(4);
	    }
	    //else
	    //{
	    //   sys_log("%s(%d): aie_parse_multipart_data(): Size[%d] Name[%s]", __FILE__, __LINE__, sizeof(char) * valuelen, name);
	    //}
          }
          else if(c_count == valuelen - 1) 
          {
            char *valuetmp;

            valuelen *= 2;

            /* Besser neues malloc() statt  realloc(). 
	     * Because sometimes it is unstable. */
            valuetmp = (char *)aie_malloc(sizeof(char) * valuelen);
            if (__builtin_expect((valuetmp == NULL), false))
	    {
	       // Memory allocation fail
               aie_sys_log(4);
	    }
	    else
	    {
	       //sys_log("%s(%d): aie_parse_multipart_data(): New Size[%d] Name[%s]", __FILE__, __LINE__, sizeof(char) * valuelen, name);
               memcpy(valuetmp, value, (unsigned int)c_count);
               aie_free(value);
               value = valuetmp;
	    }
          }
          value[c_count++] = (char)c;

          /* check end */
          if((c == '\n') || (c == '-')) 
          {
            value[c_count] = '\0';

            if((c_count - (2 + boundarylen + 2)) >= 0) 
	    {
              if(!strcmp(value + (c_count - (2 + boundarylen + 2)), 
		                                                 rnboundaryrn)) 
	      {
                value[c_count - (2 + boundarylen + 2)] = '\0';
                valuelen = c_count - (2 + boundarylen + 2);
                break;
              }
            }
            if((c_count - (2 + boundaryEOFlen)) >= 0) 
	    {
              if(!strcmp(value + (c_count - (2 + boundaryEOFlen)), 
		                                                rnboundaryEOF)) 
	      {
                value[c_count - (2 + boundaryEOFlen)] = '\0';
                valuelen = c_count - (2 + boundaryEOFlen);
                finish = 1;
                break;
              }
            }

            /* For Micro$oft Explore on MAC, they do not follow rules */
            if((c_count - (boundarylen + 2)) == 0) 
	    {
              char boundaryrn[256];
              sprintf(boundaryrn, "%s\r\n", boundary);
              if(!strcmp(value, boundaryrn)) 
	      {
                value[0] = '\0';
                valuelen = 0;
                break;
              }
            }
            if((c_count - boundaryEOFlen) == 0) 
	    {
              if(!strcmp(value, boundaryEOF)) 
	      {
                value[0] = '\0';
                valuelen = 0;
                finish = 1;
                break;
              }
            }
          }
        }

        if (__builtin_expect((c == EOF), false))
        {
           // Broken stream at end of '%s'."
           aie_sys_log(5, name);
        }
        if (__builtin_expect((strcmp(filename, "") != 0), false))
        {
	   // TODO: Der Wert sollte hier binaer gesetzt werden.
          cgi_vars_base = aie_SetCharCGIValue(cgi_parameter, name, value);
          value = (char *)aie_malloc(sizeof(char) * 20 + 1);
          sprintf(value, "%d", valuelen);
          cgi_vars_base = aie_SetCharCGIValue(cgi_parameter,
	                              aie_strdup(isMultiPartDataSizeCGIVar), 
				      value);
          cgi_vars_base = aie_SetCharCGIValue(cgi_parameter,
	                              aie_strdup(isMultiPartDataNameCGIVar), 
				      filename);
          cgi_vars_base = aie_SetCharCGIValue(cgi_parameter,
	                              aie_strdup(isMultiPartDataTypeCGIVar), 
				      contenttype);
          cnt += 3;
        }
	else
	{
           cgi_vars_base = aie_SetCharCGIValue(cgi_parameter, name, value);
	}
      }
      *cgi_vars = cgi_vars_base;
   }
  return (cgi_vars_base);
}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_iapl_size           = __LINE__;                                  //
/* -------------------------------- EOF ------------------------------------ */


