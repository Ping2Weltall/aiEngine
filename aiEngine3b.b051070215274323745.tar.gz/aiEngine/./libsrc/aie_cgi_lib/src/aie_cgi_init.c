/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_cgi_init.c                                              */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 01.05.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Startet das @Secur Engine und den HTML Generator                          */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_SOCKETS		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
AIE_EXTERN_CGI_GLOBALE_VARIABLEN;
AIE_EXTERN_STATIC_VARIABLES; 
AIE_EXTERN_META_HEAD_INFO                                                    //
AIE_EXTERN_HTML_KEYWORDS;
//AIE_EXTERN_AD_FILES;
//AIE_EXTERN_IMP_BODY_LINKS;
//AIE_EXTERN_STANDARD_IMP;
AIE_EXTERN_PAGE_JAVASCRIPT;
//AIE_EXTERN_CGI_VAR_REMOTE_2_LOCAL;
AIE_EXTERN_PAGE_REC;
AIE_EXTERN_BASIC_REC;
AIE_EXTERN_KNOWN_FRAMES;
AIE_EXTERN_MODULE_2_CGI_PROG;
AIE_EXTERN_PAGE_CGI_DISPATCH;
AIE_EXTERN_FRAME_CGI_DISPATCH;
AIE_EXTERN_FOLLOW_CGI_VARS;
//AIE_EXTERN_KNOWN_MENUES;
//AIE_EXTERN_SUB_MEN_PATHS;
//AIE_EXTERN_CGI_VERSION_INFO;
AIE_EXTERN_BODY_TAG;
									     //
extern char *aIEngine_CGI_Prog;                                              //
extern char *aIEngine_Start_Prog;                                            //
extern bool AIENGINE_CONF_USE_SITEMAPS;
extern bool aie_cgi_did_Sitemap;                                             //
extern const struct aie_aIEngine_env aIEngine_env[];                         //
extern unsigned int aie_size_aIEngine_env;                                   //
extern struct aie_cgi_environment aie_cgi_environment;
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
									     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
									     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
									     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
#if AIE_GENERATE_SITEMAPS
static bool aie_test_generate_sitemap(struct aie_cgi_parameter *cgi_parameter);
#endif
static bool Init_aIEngine_as_CGI_Stage1(struct aie_cgi_parameter 
                                               *cgi_parameter);
#if aie_do_use_keys
static bool aie_Init_aIEngineCodedCGIVars(struct aie_cgi_parameter 
                                                *coded_cgi_parameter, 
					  bool *has_coded);
#endif
									     //
/*****************************************************************************/
#if 0
#undef AIENGINE_LOG_TRACE_INIT_FKT_TRACE
#define AIENGINE_LOG_TRACE_INIT_FKT_TRACE		1
#undef AIENGINE_LOG_TRACE_CLIENT_CRYPT_TRACE
#define AIENGINE_LOG_TRACE_CLIENT_CRYPT_TRACE		1
#undef AIENGINE_LOG_TRACE_RUN_CGI_TRACE
#define AIENGINE_LOG_TRACE_RUN_CGI_TRACE		1
#endif

#if AIE_GENERATE_SITEMAPS
static bool aie_test_generate_sitemap(struct aie_cgi_parameter *cgi_parameter)
{
   bool rc = false;
   if (AIENGINE_CONF_USE_SITEMAPS)
   {
      if (__builtin_expect(((cgi_parameter->cgi_hooks != NULL) &&
		     (cgi_parameter->cgi_hooks->extern_cgi_sitemap_read 
                                                                    != NULL)),
		                                                         true))
      {
          rc = cgi_parameter->cgi_hooks->extern_cgi_sitemap_read();
      }
   } 
   return(rc);
}
#endif

bool aie_CGI_Init(AIE_CGI_STANDARD_FKT_PARAMETER)
{
   bool rc = false;

   // aIEngine_SetProgQueueID(queue_id);
   AIE_FKT_REGISTER_HTML_KEYWORDS;
   AIE_FKT_REGISTER_META_HEAD_INFO;
   //AIE_FKT_REGISTER_AD_FILES;
//   AIE_FKT_REGISTER_IMP_BODY_LINKS;
//   AIE_FKT_REGISTER_STANDARD_IMP;
   AIE_FKT_REGISTER_PAGE_JAVASCRIPT;
//   AIE_FKT_REGISTER_CGI_VAR_REMOTE_2_LOCAL;
   //AIE_FKT_REGISTER_KNOWN_MENUES;
   AIE_FKT_REGISTER_PAGE_REC;
//   AIE_FKT_REGISTER_BASIC_REC;
   AIE_FKT_REGISTER_KNOWN_FRAMES;
   AIE_FKT_REGISTER_MODULE_2_CGI_PROG;
   AIE_FKT_REGISTER_PAGE_CGI_DISPATCH;
   AIE_FKT_REGISTER_FRAME_CGI_DISPATCH;
   AIE_FKT_REGISTER_FOLLOW_CGI_VARS;
   //AIE_FKT_REGISTER_SUB_MEN_PATHS;
   //AIE_FKT_REGISTER_CGI_VERSION_INFO;
   AIE_FKT_REGISTER_BODY_TAG;
      aie_SetStaticAsecurVariablesFromStruct(aie_static_variablen, 
	                                 aie_size_static_variablen);
   if (__builtin_expect((AIE_FKT_INIT_CGI_GLOBALE_VARIABLEN), true))
   {
      aie_SetStaticAsecurVariablesFromStruct(aie_static_variablen, 
	                                 aie_size_static_variablen);
      rc = true;
   }
   return(rc);
}

static bool Init_aIEngine_as_CGI_Stage1(struct aie_cgi_parameter 
                                               *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, "Init_aIEngine_asCGI Stage1" },         
      { AIE_LOG_WARN,      "aIEngine Aufruf mit %s aber in "
	                   "Globalen Variablen %s" },
      { AIE_LOG_ERROR,     "Initialisierung keine Environment Daten!" },
      { AIE_LOG_ERROR,     "Init_aIEngine_asCGI Parameter == NULL Ptr" }
   };
   bool rc = true;
   #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      errno = 0;
#if 0
      aIEngine_Register(AIENGINE_REGISTER_AIENGINE_ENV,
                     (void *)&aIEngine_env[0],
                     aie_size_aIEngine_env);
      aie_init_env(cgi_parameter);
#endif   
      aie_SetAsecurStaticVariables();
      aie_SetAsecurGlobalVariables();

      if (__builtin_expect(
	    ((cgi_parameter->Name != NULL) && (aIEngine_CGI_Prog != NULL)),
	                                                                 true))
      {
         if (__builtin_expect(
	       (strcmp(aIEngine_CGI_Prog, cgi_parameter->Name) != 0), false))
         {
	    // Engine Aufruf mit %s aber in Globalen Variablen %s",
            aie_sys_log(1, cgi_parameter->Name, aIEngine_CGI_Prog);
         }
      }
      else
      {
	 // Engine Aufruf mit %s aber in Globalen Variablen %s
         aie_sys_log(1, cgi_parameter->Name, aIEngine_CGI_Prog);
      }
      randomize();
   
      if (__builtin_expect((cgi_parameter->cgi_environment == NULL), false))
      {
         // Initialisierung keine Environment Daten!
         aie_sys_log(2);
	 rc = false;
      }
   }
   else
   {
      aie_sys_log(3);
      rc = false;
   }
   return(rc);
}

#if aie_do_use_keys
static bool aie_Init_aIEngineCodedCGIVars(struct aie_cgi_parameter 
                                                *coded_cgi_parameter, 
					  bool *has_coded)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, "Init_aIEngineCodedCGIVars" },
      { AIE_LOG_ERROR,     "AIE_AGENT_AIENGINE mit codierten Daten!" },
      { AIE_LOG_SECURITY,  "Decodieren: [%s] from [%s]" },
      { AIE_LOG_TRACE_FKT, "Keine Variablen in Parametern gefunden!" },
      { AIE_LOG_ERROR,     "Init_aIEngineCodedCGIVars Parameter == NULL Ptr" }
   };
   bool rc = true;
   char *coded = NULL;

   #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((coded_cgi_parameter != NULL), true))
   {
      if (__builtin_expect((aie_LoadCGIVariables(coded_cgi_parameter)
                                                                != NULL),true))
      {
         if (__builtin_expect(((coded = 
			aie_GetCharCGIValue(coded_cgi_parameter, 
                                            isCodedCGIVar)) != NULL),true))
         {
            if (AIE_AGENT_AIENGINE)
            {
               // FEHLER: AIE_AGENT_AIENGINE mit codierten Daten!",
               aie_sys_log(1);
	       rc = false;
            }
            else
            {
               #if AIENGINE_LOG_TRACE_CLIENT_CRYPT_TRACE
               char *sptr = aie_do_decode_string(coded);
               // Decodieren: [%s] from [%s]
               aie_sys_log(2, sptr, coded);
               aie_LoadCGIVariablesFromString(sptr, coded_cgi_parameter);
               #else
               aie_LoadCGIVariablesFromString(aie_do_decode_string(coded), 
				                      coded_cgi_parameter);
               #endif
	       //aie_ShowParameter(coded_cgi_parameter);
               *has_coded = true;
            }
         }
      }
      else
      {
         #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
	 // Keine Variablen in Parametern gefunden!
	 aie_sys_log(3);
         #endif
      }
   }
   else
   {
      aie_sys_log(4);
      rc = false;
   }
   return(rc);
}
#endif
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_Init_aIEngine_as_CGI(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, "Init_aIEngine_asCGI" },
      { AIE_LOG_WARN,      "Init_aIEngineCodedCGIVars failed!" },
      { AIE_LOG_ERROR,     "Seite nicht gefunden! [%s]" },
      { AIE_LOG_ERROR,     "Init_aIEngine_asCGI Stage 1 failed!" },
      { AIE_LOG_TRACE_FKT, "Init_aIEngine_asCGI .. done" },
      { AIE_LOG_WARN,      "Keine Variablen in cgi_parameter!" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, "Init_aIEngine_asCGI - Interner Client" },
      { AIE_LOG_TRACE | AIE_LOG_TRACE_FKT, "Request: [%s:%s]" }
   };
   char *cgiQueryString = NULL;
   const char *cgiServerSoftware;
   const char *cgiUserAgent;
   const char *cgiServerName;
   const char *cgiRemoteAddr;
   const char *cgiRemotePort;
   const char *cgiRequestUri;
   const char *cgiRequestMethod;
   bool has_own_query_mem = false;
   #if aie_do_use_keys
   struct aie_cgi_parameter cgi_coded_parameter;
   //struct aie_cgi_variables *coded_cgi_vars_base = NULL;
   bool has_coded = false;
   #endif
   bool rc = true;

   #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
   if (__builtin_expect((AIE_AGENT_AIENGINE) , false))
   {
      aie_sys_log(6);
   }
   else
   {
      aie_sys_log(0);
   }
   #endif
   if (__builtin_expect(Init_aIEngine_as_CGI_Stage1(cgi_parameter), true))
   {
      struct aie_cgi_variables **cgi_vars_base = 
	                                       &cgi_parameter->cgi_variables;
      #if aie_do_use_keys
      memcpy(&cgi_coded_parameter, cgi_parameter, 
	                                    sizeof(struct aie_cgi_parameter));
      cgi_coded_parameter.cgi_variables = NULL;
      #if 0
      if (__builtin_expect((
		  (cgi_coded_parameter.cgi_variables = 
		                        cgi_parameter->cgi_variables) == NULL),
	                                                                 false))
      {
	 aie_ShowParameter(cgi_parameter);
	 aie_sys_log(5);
      }
      #endif
      #endif

      cgiServerSoftware = aie_get_aIEngine_env(AIENGINE_ENV_SERVER_SOFTWARE);
      cgiUserAgent = aie_get_aIEngine_env(AIENGINE_ENV_HTTP_USER_AGENT);
      cgiServerName = aie_get_aIEngine_env(AIENGINE_ENV_SERVER_NAME);
      cgiRemoteAddr = aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_ADDR);
      cgiRemotePort = aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_PORT);
      cgiRequestUri = aie_get_aIEngine_env(AIENGINE_ENV_REQUEST_URI);
      cgiRequestMethod = aie_get_aIEngine_env(AIENGINE_ENV_REQUEST_METHOD);
      cgiQueryString = cgi_parameter->cgi_environment->QueryString;
      #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
      aie_sys_log(7, cgiRequestUri, cgiQueryString);
      #endif

      #if AIE_GENERATE_SITEMAPS
      if (!aie_test_generate_sitemap(cgi_parameter))
      {
      #endif
         printf("Content-Type: text/html%c%c", 10, 10);
         aie_InitBrowserInfo(cgi_parameter);
         if (__builtin_expect(aie_CharEmptyValue(cgiQueryString), false))
         {
            #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
            aie_sys_log(0);
            #endif
            has_own_query_mem = true;
            cgiQueryString = (char *)aie_malloc(AIE_QUERY_STRING_BUF_LEN);
            memset(cgiQueryString, '\0', AIE_QUERY_STRING_BUF_LEN);
         }
         else
         {
            #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
            aie_sys_log(0);
            #endif
         }

         #if aie_do_use_keys
         if (__builtin_expect((AIE_AGENT_AIENGINE) ||
	    (aie_start_key_client(SOCKET_KEYS_ADDRESS_BASE)) != false,true))
         #endif
         {
            #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
            aie_sys_log(0);
            #endif
            if (__builtin_expect((cgiRequestMethod == NULL),false))
            {
               #if aie_do_use_keys
               const char *sptr = NULL;
               static int anzahl = 1;
               #endif
               #if AIE_HAS_VERSION_INFO
               my_version(false);
               #endif
               #if aie_do_use_keys
               anzahl++;
               //if ((rc = load_create_keys(secret)) == true)
               {
                  sptr = aie_do_code_string(aIEngine_GlobalEngineName);
               }
               if ((sptr != NULL) && (*sptr != '\0'))
               {
                  html_vt("\n\n%s\n", aie_do_decode_string(sptr));
               }
               #endif
               rc = false;
            }
            else
            {
               #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
               aie_sys_log(0);
               #endif
               #if aie_do_use_keys
	       if (__builtin_expect(
			(!aie_Init_aIEngineCodedCGIVars(&cgi_coded_parameter, 
		                                       &has_coded)), true))               
	       {
                  aie_sys_log(1);
		  has_coded = false;
	       }
	       else
	       {
		  //aie_ShowParameter(&cgi_coded_parameter);
	       }
               #endif
               #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
               aie_sys_log(0);
               #endif
               if (__builtin_expect((cgi_parameter->cgi_environment != NULL),true))
               {
                  aie_SetAsecurVariable(ASECUR_GLOBAL_VARIABLEN,
                                     AIENGINE_VAR_REMOTE_IP,
                                     0,
                                     cgi_parameter->cgi_environment->RemoteAddr,
                                     NULL);
               }
               aie_SetAsecurVariable(ASECUR_GLOBAL_VARIABLEN,
                                  AIENGINE_VAR_LINKED_FROM,
                                  0,
                                  aIEngine_CGI_Prog,
                                  NULL);
               #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
               aie_sys_log(0);
               #endif
               #if aie_do_use_keys
               if (__builtin_expect(((strcmp("GET",cgiRequestMethod) == 0) &&
                   (cgi_coded_parameter.cgi_variables == NULL)), false))
               #else
               *cgi_vars_base = aie_LoadCGIVariables(cgi_parameter);
               if (__builtin_expect(((strcmp("GET",cgiRequestMethod) == 0) &&
                                      (*cgi_vars_base == NULL)), false))
                   #if 0
                    /* TODO: Strange may also be fixed for coded */
                   ((*cgi_vars_base = 
		               aie_LoadCGIVariables(cgi_parameter)) == NULL))),
		                                                         false))
                   #endif
               #endif
               {
                  if (cgi_parameter->StartPage != NULL)
                  {
                     #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                     aie_sys_log(0);
                     #endif
                     aie_SetCharCGIValue(cgi_parameter, 
			                   aie_strdup(isNameCGIVar), 
			                aie_strdup(cgi_parameter->StartPage));
                  }
                  if (cgi_parameter->StartFrame != NULL)
                  {
                     #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                     aie_sys_log(0);
                     #endif
                     aie_SetCharCGIValue(cgi_parameter, 
			          aie_strdup(isFrameCGIVar), 
				  aie_strdup(cgi_parameter->StartFrame));
                  }
               }
               else
               {
                  char *sptr;
		  if (__builtin_expect((*cgi_vars_base == NULL), false))
                  {
                     //sys_log("%s(%d): %s Size=%s", __FILE__, __LINE__, 
                     //                          cgiRequestMethod,
                     //getenv("CONTENT_LENGTH"));
                  }
                  #if aie_do_use_keys
                  #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                  aie_sys_log(0);
                  #endif
                  if (__builtin_expect((has_coded || 
			            (cgi_coded_parameter.cgi_variables != NULL)), true))
                  {
                     #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                     aie_sys_log(0);
                     #endif
		     if (__builtin_expect((*cgi_vars_base == NULL), true))
		     {
                        #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                        aie_sys_log(0);
                        #endif
		        *cgi_vars_base = cgi_coded_parameter.cgi_variables;
		        //aie_ShowParameter(cgi_parameter);
		     }
		     else
		     {
                        struct aie_cgi_variables *coded_cgi_vars_ptr;
                        #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                        aie_sys_log(0);
                        #endif
                        if (__builtin_expect(((coded_cgi_vars_ptr = 
			      cgi_coded_parameter.cgi_variables) != NULL), 
			                                                 true))
                        {
                           while(coded_cgi_vars_ptr->next != NULL)
		           {
			      coded_cgi_vars_ptr = coded_cgi_vars_ptr->next;
		           }
			   coded_cgi_vars_ptr->next = *cgi_vars_base;
			   *cgi_vars_base = cgi_coded_parameter.cgi_variables;
		        }
                        #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                        aie_sys_log(0);
                        #endif
		     }
	          }
                  #endif
                  #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                  aie_sys_log(0);
                  #endif
                  if (__builtin_expect((
	            (sptr = aie_GetCharCGIValue(cgi_parameter, isErrorCGIVar)) 
		                                               != NULL),false))
                  {
                     html_vt("Fehler: Das folgende Problem trat auf: %s %s(%d)", sptr, 
			                                   __FILE__, __LINE__);
                  }
                  else
                  {
                     #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                     aie_sys_log(0);
                     #endif
                     if ((sptr = aie_GetCharCGIValue(cgi_parameter, isNameCGIVar)) 
			                                               != NULL)
                     {
                        if (strcmp(sptr, isPageNotFoundCGIVal) == 0)
                        {
			   // Seite nicht gefunden! [%s] 
                           aie_sys_log(2, cgiRequestUri);
                        }
                     }
                     #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
                     aie_sys_log(0);
                     #endif
                  }
               }
            }
         #if aie_do_use_keys
         //free_secret_mykey(&secret);
         #endif
         }
         #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
         aie_sys_log(0);
         #endif
         if (has_own_query_mem)
         {
            aie_free(cgiQueryString);
         }
      #if AIE_GENERATE_SITEMAPS
      }
      else
      {
         aie_cgi_did_Sitemap = true;
      }
      #endif
      #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
      aie_LogParameter(cgi_parameter);
      #endif
   }
   else
   {
      // "Init_aIEngine_asCGI Stage 1 failed!
      aie_sys_log(3);
   }
   #if AIENGINE_LOG_TRACE_INIT_FKT_TRACE
   aie_sys_log(4);
   #endif
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
bool aie_Init_aIEngineClient(struct aie_aIEngine_parameter *aIEngine_parameter)
{
   struct aie_cgi_parameter *cgi_parameter;
   bool rc = false;
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_Init_aIEngine" },         
      { AIE_LOG_TRACE, "aie_Init_aIEngine Extern Init Fkt" },         
      { AIE_LOG_TRACE, "aie_Init_aIEngine Extern Init Fkt .. ok" },         
      { AIE_LOG_ERROR, "aie_Init_aIEngine Extern Init Fkt .. fail" },         
      { AIE_LOG_ERROR, "Memory?! Cgi Parameter == NULL!" },
      { AIE_LOG_ERROR, "Engine kann nicht mit NULL initialisiert werden!" },
      { AIE_LOG_TRACE, "aie_Init_aIEngine .. ok" }         
   };
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   // Umleitung von Stderror auf eigene Datei
   fclose(stderr);
   stderr = fopen("/aIEngine/temp/aie_stderr.txt", "a+");
   #ifdef _MUDFLAP
   //setenv("MUDFLAP_OPTIONS", "-mode-check -print-leaks -mode-populate -check-initialization -viol-segv -collect-stats -internal-checking -verbose-violations -abbreviate -ignore-reads", 1);
   fprintf(stderr, "%s: %s", getenv("MUDFLAP_OPTIONS"), __FUNCTION__);
   //setenv("MUDFLAP_OPTIONS", "-mode-check -print-leaks -mode-populate -viol-abort -verbose-violations -collect-stats", 1);
   #endif
   aIEngine_Register(AIENGINE_REGISTER_AIENGINE_ENV,
                     (const void *)&aIEngine_env[0],
                     aie_size_aIEngine_env);
   if (__builtin_expect((aIEngine_parameter != NULL), true))
   {
      if (__builtin_expect((aIEngine_parameter->cgi_parameter == NULL), true))
      {
	 aIEngine_parameter->cgi_parameter = cgi_parameter = 
                                 (struct aie_cgi_parameter *)
	                         aie_malloc(sizeof(struct aie_cgi_parameter));
	 aIEngine_parameter->dyn_cgi_parameter = true;
      }
      else
      {
	 cgi_parameter = aIEngine_parameter->cgi_parameter;
      }
      if (__builtin_expect((cgi_parameter != NULL), true))
      {
	 cgi_parameter->Mode = aIEngine_parameter->aIEngineMode;
         cgi_parameter->Name = aIEngine_parameter->Name;
         cgi_parameter->Titel = aIEngine_parameter->Titel;
         cgi_parameter->StartFrame = aIEngine_parameter->StartFrameCGIVal;
         cgi_parameter->StartPage = aIEngine_parameter->StartPageCGIVal;
         cgi_parameter->cgi_variables = NULL;
         cgi_parameter->cgi_browser_info = NULL;
         cgi_parameter->BytesWritten = 0;
         cgi_parameter->cgi_environment = &aie_cgi_environment;
         cgi_parameter->TraceMemory = aIEngine_parameter->TraceMemory;
	 if (__builtin_expect((aIEngine_parameter->dyn_cgi_parameter), true))
	 {
	    cgi_parameter->cgi_hooks = aIEngine_parameter->cgi_hooks; 
	 }
         rc = true;
         if (__builtin_expect((cgi_parameter->Name != NULL), true))
         {
            aIEngine_Start_Prog = aie_strdup(cgi_parameter->Name);
         }
	 
         aie_init_env(cgi_parameter);

         if (__builtin_expect(((cgi_parameter->cgi_hooks != NULL) &&
		     (cgi_parameter->cgi_hooks->extern_initialization != NULL)),
		                                                          true))
	 {
            #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
            aie_sys_log(1);
            #endif
	    rc = cgi_parameter->cgi_hooks->extern_initialization(cgi_parameter);
	    if (__builtin_expect((!rc), false))
	    {
               aie_sys_log(3);
	    }
            #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
	    else
	    {
               aie_sys_log(2);
	    }
            #endif
	 }
      }
      else
      {
         // Memory?! Cgi Parameter == NULL!
         aie_sys_log(4);
      }
   }
   else
   {
      // Engine kann nicht mit NULL initialisiert werden!
      aie_sys_log(5);
   }
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(6);
   #endif
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int  modul_aie_cgi_init_size     = __LINE__;                                 //
/* -------------------------------- EOF ------------------------------------ */

