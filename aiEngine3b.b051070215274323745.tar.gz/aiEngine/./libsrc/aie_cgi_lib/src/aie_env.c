/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_env.c                                                   */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 05.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 09.01.2005  : ALH           : Anapssung an WinClient CGI wenn keine Daten */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : const char * als const * deklarieren        */
/*.............+...............+.............................................*/
/* 27.12.2003  : ALH           : Neue Funktion  - SetCGIVarsFromProgLink     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_env_version        = "1.0.0";                              //
const char *modul_env                = "Env";                                //
const char *modul_env_date           = __DATE__;                             //
const char *modul_env_time           = __TIME__;                             //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
struct aie_cgi_environment aie_cgi_environment =
{
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL
};

const struct aie_aIEngine_env aIEngine_env[] =                               //
{                                                                            //
   {  &aie_cgi_environment.ServerSoftware,       
                           AIENGINE_ENV_SERVER_SOFTWARE       
   },       
   {  &aie_cgi_environment.ServerName,
                           AIENGINE_ENV_SERVER_NAME
   },
   {  &aie_cgi_environment.GatewayInterface,
                           AIENGINE_ENV_GATEWAY_INTERFACE
   },
   {  &aie_cgi_environment.ServerProtocol,
                           AIENGINE_ENV_SERVER_PROTOCOL
   },
   {  &aie_cgi_environment.ServerPort,
                           AIENGINE_ENV_SERVER_PORT
   },
   {  &aie_cgi_environment.RequestMethod,
                           AIENGINE_ENV_REQUEST_METHOD
   },
   {  &aie_cgi_environment.PathInfo,
                           AIENGINE_ENV_PATH_INFO
   },
   {  &aie_cgi_environment.PathTranslated,
                           AIENGINE_ENV_PATH_TRANSLATED
   },
   {  &aie_cgi_environment.ScriptName,
                           AIENGINE_ENV_SCRIPT_NAME
   },
   {  &aie_cgi_environment.QueryString,
                           AIENGINE_ENV_QUERY_STRING
   },
   {  &aie_cgi_environment.RemoteHost,
                           AIENGINE_ENV_REMOTE_HOST
   },
   {  &aie_cgi_environment.RemoteAddr, 
                           AIENGINE_ENV_REMOTE_ADDR
   },
   {  &aie_cgi_environment.RemotePort,
                           AIENGINE_ENV_REMOTE_PORT
   },
   {  &aie_cgi_environment.AuthType,
                           AIENGINE_ENV_AUTH_TYPE
   },
   {  &aie_cgi_environment.RemoteUser,
                           AIENGINE_ENV_REMOTE_USER
   },
   {  &aie_cgi_environment.RemoteIdent,
                           AIENGINE_ENV_REMOTE_IDENT
   },
   {  &aie_cgi_environment.ContentType,
                           AIENGINE_ENV_CONTENT_TYPE
   },
   {  &aie_cgi_environment.ContentLength,
                           AIENGINE_ENV_CONTENT_LENGTH
   },
   {  &aie_cgi_environment.Accept,
                           AIENGINE_ENV_HTTP_ACCEPT
   },
   {  &aie_cgi_environment.UserAgent,
                           AIENGINE_ENV_HTTP_USER_AGENT
   },
   {  &aie_cgi_environment.Referrer,
                           AIENGINE_ENV_HTTP_REFERER
   },
   {  &aie_cgi_environment.Cookie,
                           AIENGINE_ENV_HTTP_COOKIE
   },
   {  &aie_cgi_environment.RequestUri,
                           AIENGINE_ENV_REQUEST_URI
   }
};                                                                           //
unsigned int aie_size_aIEngine_env = sizeof(aIEngine_env) /                  //
                                     sizeof(struct aie_aIEngine_env);        //

/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/* Bemerkung     :                                                           */
/*...........................................................................*/
bool aie_init_env(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_init_env" },         
      { AIE_LOG_WARN,  "cgi_parameter Environment war nicht gesetzt!" },
      { AIE_LOG_WARN,  "Environment: Keine Referent Index[%d]" },
      { AIE_LOG_WARN,  "Environment: Value nicht gesetzt Index[%d]" },
      { AIE_LOG_ERROR, "Environment NULL Ptr!" },
      { AIE_LOG_ERROR, "Cgi Parameter NULL Ptr!" }
   };
   bool rc = true;
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif

   if (__builtin_expect((cgi_parameter != NULL), true))
   {
      register unsigned int z;
      struct aie_aIEngine_env *env;
      unsigned int size_env;
      if (__builtin_expect(
   	    ((env = getRegistered_aIEngine_env(&size_env)) != NULL),true))
      {
         if (__builtin_expect((cgi_parameter->cgi_environment == NULL), false))
         {
            cgi_parameter->cgi_environment = &aie_cgi_environment;
	    // cgi_parameter Environment war nicht gesetzt!", 
            aie_sys_log(1);
         }
         for(z = 0; z < size_env; z++)
         {
	    if (__builtin_expect((env->value != NULL), true))
	    {
	       if (__builtin_expect((env->var != NULL), true))
	       {
                  *env->var = getenv(env->value);
	          if (__builtin_expect((env != aIEngine_env), false))
	          {
	             for (register unsigned int i = 0; 
			                        i < aie_size_aIEngine_env; i++)
	             {
		        if (__builtin_expect((strcmp(env->value, 
				            aIEngine_env[i].value) == 0), 
			                                                false))
		        {   
		           *aIEngine_env[i].var = *env->var;
		        }
		     }
	          }
	       }
	       else
	       {
	          // Environment: Keine Referent Index[%d]",
                  aie_sys_log(2, z);
	       }
	    }
	    else
	    {
	       // Environment: Value nicht gesetzt Index[%d]",
               aie_sys_log(3, z);
	    }
            env++;
         }
         #if 0
         if (__builtin_expect((cgiContentLengthString != NULL),true))
         {
            cgiContentLength = atoi(cgiContentLengthString);
         }
         if (__builtin_expect((cgiCookie != NULL), false))
         {
            do_log("Cookie", "Value: %s", cgiCookie);
         }
         #endif
      }
      else
      {
         // Environment NULL Ptr!
         aie_sys_log(4);
         rc = false;
      }
   }
   else
   {
      // Cgi Parameter NULL Ptr!
      aie_sys_log(5);
      rc = false;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_ShowEnv(void)
{
   struct aie_aIEngine_env *env;
   unsigned int size_env;
   bool isEngineMyself = AIE_AGENT_AIENGINE;
   if (__builtin_expect(
	    ((env = getRegistered_aIEngine_env(&size_env)) != NULL),true))
   {
      register unsigned int i = 0;
      if (!isEngineMyself)
      {
         bTABLE
      }
      else
      {
	 html_t("\n\n");
      }
      for (i = 0;i < size_env;i++)
      {
         if (!isEngineMyself)
         {
            TBL_STD_ROW_COL_START
	 }
         html_t(env->value);
         if (!isEngineMyself)
         {
            TBL_STD_COL_CHANGE
            bB
         }
	 else
	 {
            html_t("\t");
	 }
         html_t(*env->var);
         if (!isEngineMyself)
         {
            eB
            TBL_STD_COL_ROW_END
         }
	 else
	 {
            html_t("\n");
	 }
         env++;
      }
      if (!isEngineMyself)
      {
         eTABLE
      }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
const char *aie_get_aIEngine_env(const char *name)
{
   struct aie_aIEngine_env *env;
   unsigned int size_env;
   const char *rc_ptr = NULL;
   if (__builtin_expect(
	    ((env = getRegistered_aIEngine_env(&size_env)) != NULL),true))
   {
      register unsigned int i = 0;
      for(i = 0;i < size_env;i++)
      {
         if (__builtin_expect((strcmp(env->value, name) == 0),false))
         {
            rc_ptr =  *env->var;
            break;
         }
         env++;
      }
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_env_size           = __LINE__;                                   //
/* -------------------------------- EOF ------------------------------------ */

