/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_cgimoves.c                                              */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 31.05.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Alle Logmeldungen Anpassen auf WinGui Client*/
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : const char * als const * deklarieren        */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_cgimoves_version    = "1.0.0";                             //
const char *modul_cgimoves            = "CGIMoves";                          //
const char *modul_cgimoves_date       = __DATE__;                            //
const char *modul_cgimoves_time       = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_move_str_cgi_2_var(struct aie_cgi_parameter *cgi_parameter, 
	              struct aie_cgi_str_2_var_move *cgi_str_2_var_move, 
		      unsigned int size)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_move_str_cgi_2_var" },         
      { AIE_LOG_INFO,  "Moveing [%s] Value[%s]" },
      { AIE_LOG_INFO,  "nach Move : [%s] Value[%s]" },
      { AIE_LOG_WARN,  "Nicht vorhanden[%s]" },
      { AIE_LOG_ERROR, "CgiVal NULL PTR?" }, 
      { AIE_LOG_ERROR, "Ziel NULL PTR?" }
   };
   struct aie_cgi_str_2_var_move *cgi_str_2_var_move_ptr = cgi_str_2_var_move;
   char *sptr;
   register unsigned int n = 0;

   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   aie_sys_log(0);
   #endif
   for (n = 0;((n < size) && (cgi_str_2_var_move_ptr != NULL));n++)
   {
	 if (__builtin_expect(
		  ((sptr = cgi_str_2_var_move_ptr->str_var) != NULL), true))
	 {
	    const char *cgi_val;
	    if (__builtin_expect(
		  ((cgi_val = cgi_str_2_var_move_ptr->cgi_var) != NULL),true))
	    {
	       char *value;
	       if ((value = aie_GetCharCGIValue(cgi_parameter, cgi_val)) 
		                                                       != NULL)
	       {
		  // Moveing [%s] Value[%s]
                  aie_sys_log(1, cgi_val, value);
	          strncpy(sptr, value, cgi_str_2_var_move_ptr->len);
		  *(sptr + cgi_str_2_var_move_ptr->len) = '\0';
		  // nach Move : [%s] Value[%s]
                  aie_sys_log(2, cgi_val, value);
	       }
	       else
	       {
		  // Nicht vorhanden[%s]
                  aie_sys_log(3, cgi_val);
	       }
	    }
	    else
	    {
	       // CgiVal NULL PTR?
               aie_sys_log(4);
	    }
	 }
	 else
	 {
	    // Ziel NULL PTR?
            aie_sys_log(5);
	 }
      cgi_str_2_var_move_ptr++;
   }
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_cgimoves_size       = __LINE__;                                  //
/* -------------------------------- EOF ------------------------------------ */

