/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_session.c                                               */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 07.01.2005  : ALH           : Aenderung Session Path fuer Internes Engine */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_session_version     = "1.1.2";                             //
const char *modul_session             = "Session";                           //
const char *modul_session_date        = __DATE__;                            //
const char *modul_session_time        = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static const char *get_session_path(void);                                   //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
static const char *get_session_path(void)
{
   static const char *session_path = NULL;
   if (AIE_AGENT_AIENGINE)
   {
      // TODO: Globaled define variabel
      session_path = "/aIEngine/data/sessions/";
      //check_create_dir(session_path, true);
   }
   else
   {
      if (__builtin_expect((session_path == NULL),false))
      {
         session_path = AIE_MK_DATA("sessions/");
      }
   }
   return(session_path);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_make_session_nr(const char *user)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_make_session_nr User[%s] Ip[%s]" },
      { AIE_LOG_ERROR, "Session Datei [%s] konnte nicht erstellt werden!" }
   };
   static char s[AIE_SESSION_NR_BUF_LEN + 1];
   char session_file[AIE_SESSION_NAME_BUF_LEN + 1];
   char *ptr = s;
   FILE *fptr;
   const char *cgiRemoteAddr = aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_ADDR);

   aie_sys_log(0, user, cgiRemoteAddr);
   sprintf(s, "%s%.2x%s", 
	 aie_get_time_stamp(), 
         rand() % 255,
         user);
   strcpy(session_file, get_session_path());
   strcat(session_file, s);
   if (__builtin_expect(
	    ((fptr = aie_open_write_text_file(session_file)) != NULL),true))
   {
      fprintf(fptr, "%s", cgiRemoteAddr);
      aie_close_file(fptr);
   }
   else
   {
      // Session Datei [%s] konnte nicht erstellt werden!",
      aie_sys_log(1, session_file);
      ptr = NULL;
   }
   return(ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_check_session(const char *session)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_check_session" },
      { AIE_LOG_INFO, "Session existiert und ist gueltig [%s]" },
      { AIE_LOG_SECURITY, "Session Zugriff von falscher IP "
	                  "Zugriff von %s Session %s" },
      { AIE_LOG_SECURITY, "Unbekannte Session! ID[%s]" },
      { AIE_LOG_ERROR,    "session == NULL Ptr" }
   };
   bool rc = false;
   char buf[40];
   char session_file[AIE_SESSION_NAME_BUF_LEN + 1];
   FILE *fptr;
   const char *cgiRemoteAddr = aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_ADDR);
   aie_sys_log(0);

   if (__builtin_expect((session != NULL),true))
   {
      strcpy(session_file, get_session_path());
      strcat(session_file, session);
      if (__builtin_expect(
	       ((fptr = aie_open_read_text_file(session_file)) != NULL),true))
      {
         memset(buf, '\0', sizeof(buf));
         fread(&buf, sizeof(buf), 1, fptr);
         aie_close_file(fptr);
         if (__builtin_expect((strcmp(cgiRemoteAddr, buf) == 0),true))
         {
            aie_sys_log(1, session);
            rc = true;
         }
         else
         {
            BR
            html_static("Orginal IP:");
            html_vt("[%s]", buf);
	    // Session zugriff von falscher IP Zugriff von %s Session %s
            aie_sys_log(2, buf, cgiRemoteAddr);
         }
      }
      else
      {
         // Unbekannte Session! ID[%s]
         aie_sys_log(3, session);
         BR
         html_static("Unbekannte Session!");
      }
   }
   else
   {
      // session == NULL Ptr
      aie_sys_log(4);
   }
   if (__builtin_expect((!rc),false))
   {
      BR
      html_t(session);
      BR
      html_t(cgiRemoteAddr);
      BR
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_delete_session(const char *session)
{
   char session_file[AIE_SESSION_NAME_BUF_LEN + 1];
   memset(session_file, '\0', sizeof(session_file));
   strcpy(session_file, get_session_path());
   strcat(session_file, session);
   aie_delete_file(session_file);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_check_user_has_session(const char *user)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_check_user_has_session" },
      { AIE_LOG_INFO,  "%s:Session %s" }
   };
   struct aie_file_liste *file_liste_base;
   char rc = false;
   char s[AIE_SESSION_NAME_BUF_LEN + 1];

   aie_sys_log(0);

   strcpy(s, get_session_path());
   strcat(s, "????????????????");
   strcat(s, user);
   if (__builtin_expect(
	    ((file_liste_base = aie_read_file_liste(s, &file_liste_base)) 
	                                                        != NULL),true))
   {
      struct aie_file_liste *file_liste_ptr = file_liste_base;
      while(file_liste_ptr != NULL)
      {
         char f[AIE_SESSION_NAME_BUF_LEN + 1];
         //  %s:Session %s
         aie_sys_log(1, user, file_liste_ptr->file);
         strcpy(f, get_session_path());
         strcat(f, file_liste_ptr->file);
         aie_delete_file(f);
         file_liste_ptr = file_liste_ptr->next;
      }
      aie_free_file_liste(&file_liste_base);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_list_sessions(void)
{
   char rc = false;
   char s[AIE_SESSION_NAME_BUF_LEN + 1];
   struct aie_file_liste *file_liste_base = NULL;
   char year[6];
   char month[6];
   char day[6];
   char hour[6];
   char min[6];
   char sec[6];
   char user[30];

   strcpy(s, get_session_path());
   #ifdef __WIN32__
   strcat(s, "*.*");
   #else
   strcat(s, "*");
   #endif
   if (__builtin_expect(
	    ((file_liste_base = aie_read_file_liste(s, &file_liste_base)) 
	                                                        != NULL),true))
   {
      struct aie_file_liste *file_liste_ptr = file_liste_base;
      bTABLE
      TBL_STD_ROW_COL_START
      html_static("Benutzer");
      TBL_STD_COL_CHANGE 
      NBSP
      html_static("Angemeldet seit:");
      TBL_STD_COL_ROW_END
      while(file_liste_ptr != NULL)
      {
	 if (__builtin_expect((*file_liste_ptr->file != '.'),false))
         {
            char *sptr = aie_strdup(file_liste_ptr->file); 
	    strncpy(year, sptr, 4); 
	    *(year + 4) = '\0';
	    strncpy(month, sptr + 4, 2);
	    *(month + 2) = '\0';
	    strncpy(day, sptr + 6, 2);
	    *(day + 2) = '\0';
	    strncpy(hour, sptr + 8, 2);
	    *(hour + 2) = '\0';
	    strncpy(min, sptr + 10, 2);
	    *(min + 2) = '\0';
	    strncpy(sec, sptr + 12, 2);
	    *(sec + 2) = '\0';
	    strcpy(user, sptr + 16);
            TBL_STD_ROW_COL_START
            html_t(user);
            // html_t(file_liste_ptr->file);
            TBL_STD_COL_CHANGE 
            NBSP
	    html_vt("%s.%s.%s %s:%s:%s", day, month, year, hour, min, sec);
	    TBL_STD_COL_ROW_END
            aie_free(sptr);
         }
         file_liste_ptr = file_liste_ptr->next;
      }
      aie_free_file_liste(&file_liste_base);
      eTABLE
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_session_size        = __LINE__;                                  //
/* -------------------------------- EOF ------------------------------------ */

