/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_http.c                                                  */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 12.11.2005  : ALH           : Felder nun im eigenen modul http_fields     */
/*.............+...............+.............................................*/
/* 12.10.2005  : ALH           : Modufikation cgi_parameter fuer Version 3.0 */
/*.............+...............+.............................................*/
/* 13.01.2005  : ALH           : Anpassen aller Logmeldungen fuer WinGUI     */
/*.............+...............+.............................................*/
/* 09.01.2005  : ALH           : Anapssung an WinClient CGI wenn keine Daten */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 23.05.2004  : ALH           : Neu: html_input_textarea                    */
/*.............+...............+.............................................*/
/* 01.05.2004  : ALH           : Auslagern in txtutil.cpp                    */
/*                             : change_br_2_space                           */
/*                             : change_br_2_slash                           */
/*.............+...............+.............................................*/
/* 27.12.2003  : ALH           : Verarbeitung Dispatch Tabelle fuer CGI Prog */
/*                             + Funktionen fuer Linkverarbeitung in eigenes */
/*                               Modul links.cpp verlagert.                  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_ishttpd_version    = "1.6.6";                              //
const char *modul_ishttpd            = "isHttpd";                            //
const char *modul_ishttpd_date       = __DATE__;                             //
const char *modul_ishttpd_time       = __TIME__;                             //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *image_tag_template;                                             //
extern char *MousePicJavaStr_i1_template;                                    //
extern char *MousePicJavaStr_i2_template;                                    //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
bool FlushOut = false;                                                       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct http_textbuf                                                          //
{                                                                            //
   char *txt;                                                                //
   int typ;                                                                  //
   struct http_textbuf *next;                                                //
};                                                                           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static struct http_textbuf *http_text_base = NULL;                           //
static struct http_textbuf *http_text_ptr;                                   //
static bool DirectOut = false;                                               //
static u64 aie_BytesWritten = 0;
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_pic_point(void)
{
   static const char *pic_point =  NULL;
   if (__builtin_expect((pic_point == NULL),false))
   {
      pic_point = AIE_MK_IMAGE("point.gif");
   }
   html_image(pic_point, "point", NULL, 0);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_pic_big_point(void)
{
   static const char *pic_big_point =  NULL;
   if (__builtin_expect((pic_big_point == NULL),false))
   {
      pic_big_point = AIE_MK_IMAGE("big_point.gif");
   }
   html_image(pic_big_point, "point", NULL, 0);
}
/*---------------------------------------------------------------------------*/
#if 0
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_select_auswahl(const char *bereich, const char *file, 
                                         const char *selected, const char *var)
{
   struct aie_select_list *select_list_base = NULL;
   struct aie_select_list *select_list_ptr;
   //char *file_path = CharDynMemory(AIENGINE_MAX_PATH_LENGTH);
   char *file_path = (char *)aie_malloc(AIENGINE_MAX_PATH_LENGTH);
   static const char *data_path = NULL;
   const char *sel = "";
   if (__builtin_expect((data_path == NULL),false))
   {
      data_path = AIE_MK_DATA("");
   }
   strcpy(file_path, data_path);
   if (__builtin_expect((bereich != NULL),true))
   {
      strcat(file_path, bereich);
      strcat(file_path, "/");
   }
   strcat(file_path, file);

   if (__builtin_expect(((select_list_ptr = 
          read_select_list(file_path, &select_list_base)) != NULL),true))
   {
      if (AIE_HTML_MASKE_HAS_FEHLER(var))
      {
         html_vt("<SELECT class=aie_error_auswahl name=\"%s\" size=\"1\">", var);
      }
      else
      {
         html_vt("<SELECT class=aie_auswahl name=\"%s\" size=\"1\">", var);
      }
      while(select_list_ptr != NULL)
      {
        if (selected != NULL)
        {
           if (__builtin_expect(
		    (strcmp(select_list_ptr->val, selected) == 0),false))
           {
              sel = "selected";
           }
           else
           {
              sel = "";
           }
        }
        html_vt("<option %s value=\"%s\">%s</option>", sel, 
	                           select_list_ptr->val, select_list_ptr->txt);
        select_list_ptr = select_list_ptr->next;
      }
      html_static("</select>");
      free_select_list(&select_list_base);
   }
   aie_free(file_path);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static struct aie_select_list *read_select_list(char *file, 
                                                struct aie_select_list 
						       **select_list)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "read_select_list" },         
      { AIE_LOG_ERROR, "Select List [%s] nicht gefunden!" }
   };
   FILE *fptr;
   char buf[123];
   struct aie_select_list *select_list_base = *select_list;
   struct aie_select_list *select_list_ptr = NULL;
   aie_sys_log(0);

   if (__builtin_expect(((fptr = aie_open_read_text_file(file)) != NULL),true))
   {
      char *sptr;
      while(!feof(fptr))
      {
         fgets(buf, sizeof(buf)-1, fptr);
         if ((sptr = strchr(buf, ':')) != NULL)
         {
            *sptr = '\0';
            sptr++;
            if (__builtin_expect((select_list_base == NULL),false))
            {
               select_list_base = (struct aie_select_list *)
		                    aie_malloc(sizeof(struct aie_select_list));
               select_list_ptr = select_list_base;
            }
            else
            {
               select_list_ptr->next = (struct aie_select_list *)
		                    aie_malloc(sizeof(struct aie_select_list));
               select_list_ptr = select_list_ptr->next;
            }
            select_list_ptr->txt = aie_strdup(aie_change_br_2_slash(sptr));
            select_list_ptr->val = aie_strdup(buf);
            select_list_ptr->next = NULL;
         }
      }
      aie_close_file(fptr);
   }
   else
   {
      // Select List [%s] nicht gefunden!
      aie_sys_log(1, file);
   }
   *select_list = select_list_base;
   return(select_list_base);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void free_select_list(struct aie_select_list **select_list)
{
   struct aie_select_list *select_list_base = *select_list;
   struct aie_select_list *select_list_ptr;
   while ((select_list_ptr = select_list_base) != NULL)
   {
      select_list_base = select_list_ptr->next;
      if (__builtin_expect((select_list_ptr->txt != NULL),true))
      {
         aie_free(select_list_ptr->txt);
      }
      if (__builtin_expect((select_list_ptr->val != NULL),true))
      {
         aie_free(select_list_ptr->val);
      }
      aie_free(select_list_ptr);
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_input_nvs(const char *nam, const char *val, const char *size)
{
  const char *css_class = html_check_field(nam);
// 0
  if (val == NULL)
  {
     val = "";
  }
  write_v_html_mask_tag(is_HTML_b, inp_types[0].tag, HT_INPUT, 
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam),
	inp_types[0].typ, nam, val, size);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_input_nvsm(const char *nam, const char *val, const char *size, const char *max)
{
  const char *css_class = html_check_field(nam);
// 1
  if (val == NULL)
  {
     val = "";
  }
  write_v_html_mask_tag(is_HTML_b, inp_types[1].tag, HT_INPUT, 
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam),
	inp_types[1].typ, nam, val, size, max);
}


/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_input_password_ns(const char *nam, const char *size)
{
  const char *css_class = html_check_field(nam);
// 2
  write_v_html_mask_tag(is_HTML_b, inp_types[2].tag, HT_INPUT, 
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam),
	inp_types[2].typ, nam, size);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_input_password_nvsm(const char *nam, const char *val, const char *size, const char *max)
{
  const char *css_class = html_check_field(nam);
// 3
  if (val == NULL)
  {
     val = "";
  }
  write_v_html_mask_tag(is_HTML_b, inp_types[3].tag, HT_INPUT, 
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam), 
	inp_types[3].typ, nam, val, size, max);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_b_checkbox_wfkt(const char *nam, const char *val)
{
  const char *css_class = html_check_field(nam);
  html_static("<");
  write_v_html_mask_tag(is_HTML_t, inp_types[4].tag, HT_INPUT, 
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam), 
	inp_types[4].typ, nam, val);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_e_checkbox_wfkt(void)
{
   html_static(">");
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_checkbox(const char *nam, const char *val)
{
  const char *css_class = html_check_field(nam);
// 4
   write_v_html_mask_tag(is_HTML_b, inp_types[4].tag, HT_INPUT,
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam),
	 inp_types[4].typ, nam, val);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_checkbox_var(const char *nam, const char *val, const char *t)
{
  const char *css_class = html_check_field(nam);
   // 5
   write_v_html_mask_tag(is_HTML_b, inp_types[5].tag, HT_INPUT, 
	css_class, 
	 inp_types[5].typ, nam, val, t);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_submit(const char *t)
{
// 6
    write_v_html_mask_tag(is_HTML_b, inp_types[6].tag, HT_INPUT,
	  inp_types[6].typ, t);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_submit_name(const char *nam, const char *val)
{
  const char *css_class = html_check_field(nam);
// 7
  write_v_html_mask_tag(is_HTML_b, inp_types[7].tag, HT_INPUT,
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam),
       	inp_types[7].typ, nam, val);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_file(const char *nam, const char *val)
{
  const char *css_class = html_check_field(nam);
// 8
   write_v_html_mask_tag(is_HTML_b, inp_types[8].tag, HT_INPUT, 
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam),
	 inp_types[8].typ, nam, val);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_radio(const char *nam, const char *val, bool checked)
{
  const char *css_class = html_check_field(nam);
   int nr = 10;
   if (checked)
   {
      nr = 9;
   }
   write_v_html_mask_tag(is_HTML_b, inp_types[nr].tag, HT_INPUT,
	css_class, aie_StrEmpty(css_class) ? "" : html_error_field_fkt(nam),
	 inp_types[nr].typ, nam, val);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_hidden_inp(const char *nam, const char *val)
{
   // 11
   write_v_html_mask_tag(is_HTML_b, inp_types[11].tag, HT_INPUT,
	 inp_types[11].typ, nam, val);
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_option(const char *val, const char *t, bool selected)
{
   if (__builtin_expect((selected == true),false))
   {
      html_vt("<OPTION VALUE=\"%s\" SELECTED>%s</OPTION>", val, t);
   }
   else
   {
      html_vt("<OPTION VALUE=\"%s\">%s</OPTION>", val, t);
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / 23.05.2004                                          */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_input_textarea(const char *nam, const char *val, 
                         const char *rows, const char *cols)
{
  if (val == NULL)
  {
     val = "";
  }
  //html_vt("<TEXTAREA NAME=\"%s\" ROWS=\"%s\" WRAP=VIRTUAL COLS=\"%s\" LENGTH=\"%d\">", nam, rows, cols,
	// atoi(rows)*atoi(cols));
  if (AIE_HTML_MASKE_HAS_FEHLER(nam))
  {
     html_vt("<TEXTAREA class=aie_error_textarea NAME=\"%s\" ROWS=\"%s\" COLS=\"%s\">%s", nam, rows, cols, val);
  }
  else
  {
     html_vt("<TEXTAREA class=aie_textarea NAME=\"%s\" ROWS=\"%s\" COLS=\"%s\">%s", nam, rows, cols, val);
  }
  html_static("</TEXTAREA>");	
}
/*---------------------------------------------------------------------------*/
#endif
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool html_body_tag(const char *background, const char *funktion, 
                                                struct aie_cgi_parameter 
						                *cgi_parameter)
{
   bool rc = true;
   struct aie_aIEngine_body_tag *aIEngine_body_tag;
   unsigned int size_aIEngine_body_tag;


   html_vt("<%s ", HT_BODY);
   if((background != NULL) && (*background != '\0'))
   {
       html_vt("BACKGROUND=\"%s\" ", AIE_MK_IMAGE(background));
   }
   if((funktion != NULL) && (*funktion != '\0'))
   {
       html_vt("onLoad=\"%s\" ", funktion);
   }
   if (__builtin_expect(
	    ((aIEngine_body_tag = 
    getRegistered_aIEngine_body_tag(&size_aIEngine_body_tag)) != NULL),true))
   {
      register unsigned int i = 0;
      for (i = 0; i < size_aIEngine_body_tag;i++)
      {
         if (__builtin_expect((aIEngine_body_tag->val != NULL),true))
         {
            html_vt("%s=\"%s\" ", aIEngine_body_tag->var, 
		                  aIEngine_body_tag->val);
         }
         aIEngine_body_tag++;
      }
   }
   html_static(">");
   //if (!get_aIEngine_CanCache())
   {
      rc = write_free_http_textbuf(cgi_parameter);
      DirectOut = true; // !get_aIEngine_CanCache();
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_vt(const char *t, ...)
{
   va_list argptr;

   va_start(argptr, t);
   html_argptr_vt(t, argptr);
   va_end(argptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_argptr_vt(const char *t, va_list argptr)
{
   unsigned int buf_size = 128;
   char *buffer = aie_malloc(buf_size);
   //char buffer[4096];
   unsigned int cnt;
   while (buffer != NULL)
   {
      cnt = vsnprintf(buffer, buf_size, t, argptr);
      if (__builtin_expect((cnt >= buf_size),false))
      {
	 // Overflow
	 buf_size = cnt + 1;
	 aie_free(buffer);
         buffer = aie_malloc(buf_size);
         //html_t(overflow);
      }
      else
      {
         html_t(buffer);
	 aie_free(buffer);
	 buffer = NULL;
      }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
#if AIE_DEBUG_WRITE_HTML_STATIC
void _write_static_html(const char *t, const char *file, int line)
#else
void write_static_html(const char *t)
#endif
{
   AIE_LOG_MESSAGES =
   {
      #if AIE_DEBUG_WRITE_HTML_STATIC
      { AIE_LOG_TRACE, "write_static_html @ %s(%d) [%s]" },         
      { AIE_LOG_WARN, "Versuch Leeren String zu schreiben @ %s(%d)" },
      { AIE_LOG_WARN, "Versuch NULL PTR zu schreiben @ %s(%d)" }
      #else
      { AIE_LOG_TRACE, "write_static_html @ [%s]" },         
      { AIE_LOG_WARN, "Versuch Leeren String zu schreiben" },
      { AIE_LOG_WARN, "Versuch NULL PTR zu schreiben" }
      #endif
   };
   #if AIENGINE_LOG_TRACE_HTML
   #if AIE_DEBUG_WRITE_HTML_STATIC
   aie_sys_log(0, file, line, t);
   #else
   aie_sys_log(0, t);
   #endif
   #endif 
   if (__builtin_expect((t != NULL),true))
   {
      if (__builtin_expect((*t != '\0'),true))
      {
         http_textbuf_add(is_HTML_static_t, aie_strdup(t));
      }
      else
      {
         // Versuch Leeren String zu schreiben
         #if AIE_DEBUG_WRITE_HTML_STATIC
         aie_sys_log(1, file, line);
         #else
         aie_sys_log(1);
         #endif
      }
   }
   else
   {
      // Versuch NULL PTR zu schreiben
      #if AIE_DEBUG_WRITE_HTML_STATIC
      aie_sys_log(2, file, line);
      #else
      aie_sys_log(2);
      #endif
   }
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void write_v_html(int typ, const char *t, ...)
{
   unsigned int buf_size = 128;
   //char buffer[4096];
   char *buffer = aie_malloc(buf_size);
   va_list argptr;
   unsigned int cnt;

   va_start(argptr, t);
   while (buffer != NULL)
   {
      cnt = vsnprintf(buffer, buf_size, t, argptr);
      if (__builtin_expect((cnt >= buf_size),false))
      {
	 // Overflow
	 buf_size = cnt + 1;
	 aie_free(buffer);
         buffer = aie_malloc(buf_size);
         //html_t(overflow);
      }
      else
      {
         write_html(typ, buffer);
	 aie_free(buffer);
	 buffer = NULL;
      }
   }
   va_end(argptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void write_html(int typ, const char *t)
{
   char *abuf;
   int offset = 0;
   if (__builtin_expect(((t != NULL) && (*t != '\0')),true))
   {
      unsigned int len = strlen(t);
      if (__builtin_expect(((abuf = (char *)aie_malloc(len + 5)) != NULL),true))
      {
         if (typ != is_HTML_t)
         {
            *abuf = '<';
            offset++;
         }
         if (typ == is_HTML_e)
         {
            *(abuf + offset) = '/';
            offset++;
         }
         memcpy(abuf + offset, t, len);
         offset += len;
         if (typ != is_HTML_t)
         {
            *(abuf + offset) = '>';
            offset++;
         }
         *(abuf + offset) = '\0';
         http_textbuf_add(typ, abuf);
      }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void head_html_vt(const char *t, ...)
{
   unsigned int buf_size = 128;
   char *buffer = aie_malloc(buf_size);
   //char buffer[4096];
   va_list argptr;
   unsigned int cnt;

   va_start(argptr, t);
   while (buffer != NULL)
   {
      cnt = vsnprintf(buffer, buf_size, t, argptr);
      if (__builtin_expect((cnt >= buf_size),false))
      {
	 // Overflow
	 buf_size = cnt + 1;
	 aie_free(buffer);
         buffer = aie_malloc(buf_size);
         //html_t(overflow);
      }
      else
      {
         html_t(buffer);
	 aie_free(buffer);
	 buffer = NULL;
      }
   }
   va_end(argptr);
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void html_image(const char *image, const char *name, const char *alt, int count)
{
   char image_tag[128];
   if (alt == NULL)
   {
     alt="aIEngine";
   }
   if (name == NULL)
   {
     name="aIEngine";
   }
   sprintf(image_tag, image_tag_template, image, alt, name, count);
   write_html(is_HTML_b, image_tag);
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void MousePictureJava(const char *MouseFkt, 
                      const char *name1, const char *image1, 
		      const char *name2, const char *image2, int index_nr)
{
  if (name2 != NULL)
  {
     html_vt(MousePicJavaStr_i2_template, MouseFkt, name1, index_nr, 
	                                     image1, name2, index_nr, image2);
  }
  else
  {
     html_vt(MousePicJavaStr_i1_template, MouseFkt, name1, index_nr, image1);
  }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void http_textbuf_add(int typ, char *t)
{
   static int line_count = 0;
   static bool stopScreenOut = false;
   int len = 0;
   if (stopScreenOut)
   {
      return;
   }
   if (__builtin_expect(((t != NULL) && (*t != '\0')),false))
   {
     if (__builtin_expect(
	      ((DirectOut && (line_count > 20 + (rand()%20))) 
	       || (DirectOut && FlushOut)), true))
     {
        if (write_free_http_textbuf(NULL))
        {
        }
//#ifndef STANDARD_HTML_OUTPUT
           // TODO: Hier einen moeglichen Hook fuer alternative ausgabe 
	   // z.b. Apache mod
           if (__builtin_expect(((len = printf("%s", t)) == EOF),false))
           {
              DirectOut = false;
              stopScreenOut = true;
           }
	   else
	   {
              aie_BytesWritten += len;
	   }
           //if (typ != is_HTML_static_t)
           {
              aie_free(t);
           }
           line_count = 0;
           FlushOut = false;
        //}
     }
     else
     {
        if (__builtin_expect((http_text_base == NULL),false))
        {
           http_text_base = (struct http_textbuf *)
	                              aie_malloc(sizeof(struct http_textbuf));
           http_text_ptr = http_text_base;
        }
        else
        {
           http_text_ptr->next = (struct http_textbuf *)
	                              aie_malloc(sizeof(struct http_textbuf));
           http_text_ptr = http_text_ptr->next;
        }
        if (__builtin_expect((http_text_ptr != NULL),true))
        {
           http_text_ptr->txt = t; //aie_strdup(t);
           http_text_ptr->typ = typ;
           http_text_ptr->next = NULL;
           if (DirectOut)
           {
              line_count++;
           }
        }
        else
        {
          printf("Out of Memory!\n<br>");
        }
     }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool write_free_http_textbuf(struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "write_free_http_textbuf" },
      { AIE_LOG_WARN,  "Keine ausgabedaten?!" }
   };
   bool stopScreenOut = false;
   bool rc = false;

   #if AIENGINE_LOG_TRACE_HTML
   aie_sys_log(0);
   #endif

// No more caching for now
#if 0
   FILE *fptr = NULL;
   bool had_write_error = false;
   char *file_path = NULL;

   if (get_aIEngine_CanCache())
   {
      if ((file_path = make_file_path_cache_name(cgi_vars_base, NULL, true)) != NULL)
      {
         fptr = open_write_binary_file(file_path /*, "wb"*/);
      }
      if ((fptr != NULL) && ((http_text_ptr = http_text_base) != NULL))
      {
          while(http_text_ptr != NULL )
          {
              if (http_text_ptr->txt != NULL)
              {
                 if (fprintf(fptr, "%s", http_text_ptr->txt) == EOF)
                 {
                    had_write_error = true;
                 }
              }
              http_text_ptr = http_text_ptr->next;
          }
          if (close_file(fptr) && !had_write_error)
          {
             rc = true;
          }
          else
          {
             if (file_path != NULL)
             {
                delete_file(file_path);
             }
          }
      }
   }
#endif 
   if (__builtin_expect(((http_text_ptr = http_text_base) != NULL),true))
   {
       while((http_text_ptr = http_text_base) != NULL)
       {
           http_text_base = http_text_ptr->next;
           if (__builtin_expect((http_text_ptr->txt != NULL),true))
           {
              if (__builtin_expect((!stopScreenOut),true))
              {
		 int len;
           // TODO: Hier einen moeglichen Hook fuer alternative ausgabe 
	   // z.b. Apache mod
                 if (__builtin_expect(
			  ((len = printf("%s", http_text_ptr->txt)) == EOF),
			                                                false))
                 {
                    /* stout closed ? */
                    stopScreenOut = true;
                 }
	         else
	         {
		    if (__builtin_expect((cgi_parameter != NULL), false))
		    {
		       cgi_parameter += (aie_BytesWritten + len);
		       aie_BytesWritten = 0;
		    }
		    else
		    {
                       aie_BytesWritten += len;
		    }
	         }
              }
              //if (http_text_ptr->typ != is_HTML_static_t)
              {
                 aie_free(http_text_ptr->txt);
              }
           }
           aie_free(http_text_ptr);
       }
       http_text_base = NULL;
       rc = !stopScreenOut;
   }
   else
   {
      if (__builtin_expect((!DirectOut),false))
      {
         //char *life = GetCharCGIValue(cgi_vars_base, isLifeCGIVar);
         printf("Fehler: %s(%d) Keine Ausgabe Daten erzeugt ?!", __FILE__, __LINE__);
         // Keine ausgabedaten?!
         aie_sys_log(1);
         aie_ShowEnv();
         write_free_http_textbuf(cgi_parameter);
      }
      else
      {
         rc = true;
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_ishttp_size        = __LINE__;                                   //
/* -------------------------------- EOF ------------------------------------ */

