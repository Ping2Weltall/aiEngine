/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_strl_table.c                                            */
/* Library     : aiengine-cgi-3.nn.nn.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 11.11.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_strl_html_table_version = "1.0.0";                         //
const char *modul_strl_html_table         = "Stringlist";                    //
const char *modul_strl_html_table_date    = __DATE__;                        //
const char *modul_strl_html_table_time    = __TIME__;                        //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_strl_html_table(const char *bezeichnung, 
                              const char *width, 
			      const char *css_class,
                              const char *col_width1,
                              const char *col_width2,
                              const char *strl_name, 
                              struct aie_strl_html_table_felder *fields,
			      int size_fields,
                              AIE_CGI_STANDARD_FKT_PARAMETER)
{
   bool rc = true;
   html_static("<TABLE border=0 cellspacing=0 cellpadding=0 ");
   if (__builtin_expect((!aie_StrEmpty(width)), false))
   {
      html_vt("width=\"%s\" ", width);
   }
   if (__builtin_expect((!aie_StrEmpty(css_class)), false))
   {
      html_vt("class=\"%s\" ", css_class);
   }
   html_static(">");
   if (__builtin_expect((!aie_StrEmpty(col_width1)) || 
	                (!aie_StrEmpty(col_width2)), true))
   {
      bTR
      if (!aie_StrEmpty(col_width1))
      {
         html_vt("<TD width=\"%s\" height=\"0\"></TD>", col_width1);
      }
      else
      {
         html_static("<TD height=\"0\"></TD>");
      }
      if (!aie_StrEmpty(col_width2))
      {
         html_vt("<TD width=\"%s\" height=\"0\"></TD>", col_width2);
      }
      else
      {
         html_static("<TD height=\"0\"></TD>");
      }
      eTR
   }
   if (__builtin_expect((!aie_StrEmpty(bezeichnung)), false))
   {
      html_vt("<TR><TD colspan=2>"
                  "<h2>%s</h2>"
	          "</TD></TR>", bezeichnung);
   }
   if (__builtin_expect(
	    ((fields == NULL) || (size_fields == 0) || (strl_name == NULL)),
	                                                                 true))
   {
      rc = false;
   }
   else
   {
      for(register int z = 0; z < size_fields; z++)
      {
	 const char *var = aie_stringlist_value(strl_name,  fields->var);
	 if (__builtin_expect(
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_HR) ==
	                               AIE_STRL_HTML_TABLE_FELD_HR), false))
	 {
	    html_static("\n<TR><TD colspan=2><HR></TD></TR>\n");
	 }
	 if (__builtin_expect(
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_LABEL) ==
	                               AIE_STRL_HTML_TABLE_FELD_LABEL), false))
	 {
	    html_vt("\n<TR><TD colspan=2><b>%s</b></TD></TR>\n", fields->txt);
	 }
	 if (__builtin_expect(
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_TEXT) ==
	                               AIE_STRL_HTML_TABLE_FELD_TEXT), false))
	 {
	    html_vt("\n<TR><TD colspan=2>%s</TD><TR>\n", fields->txt);
	 }
	 if (__builtin_expect((var != NULL), true))
	 {
	       html_static("<TR>");
	       if (__builtin_expect(
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_TXT_2TD) ==
	                            AIE_STRL_HTML_TABLE_FELD_TXT_2TD) ||
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_VAR_2TD) ==
	                            AIE_STRL_HTML_TABLE_FELD_VAR_2TD), false))
	       {
	          bTDc2
	       }
	       else
	       {
	          bTD
	       }
	       if (__builtin_expect(
			((fields->flags & AIE_STRL_HTML_TABLE_FELD_VAR_2TD) 
	                                                         == 0), false))
               {
	          if (__builtin_expect(
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_TXT_CGI_VAR) ==
	                        AIE_STRL_HTML_TABLE_FELD_TXT_CGI_VAR), false))
	          {
		     const char *sptr2 = "";
		     char *tmp = aie_strdup(fields->txt);
		     if (__builtin_expect((tmp != NULL), true))
		     {
		        char *sptr3 = strchr(tmp, '?');
		        sptr2 = tmp;
		        if (sptr3 != NULL)
		        {
			   *sptr3 = '\0';
		        }
	                if (*fields->txt == '@')
		        {
		            sptr2 = aie_CGIValue((fields->txt + 1));
		            if (sptr2 == NULL)
		            {
		               if (sptr3 != NULL)
		               {
			          sptr2 = sptr3;
		               }
		            }
		        }
		        aie_free(tmp);
		     }
	             var = sptr2;
	          }
	          if (fields->format_txt != NULL)
	          {
	             html_vt(fields->format_txt, fields->txt);
	          }
	          else
	          {
	             html_vt("&nbsp;&nbsp;%s", fields->txt);
	          }
	       }
	       if (__builtin_expect(
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_TXT_2TD) == 0) &&
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_VAR_2TD) == 0),
		                                                        false))
	       {
	          if (__builtin_expect(
		      ((fields->flags & 
		                  AIE_STRL_HTML_TABLE_FELD_VAR_ALIGN_RIGHT) ==
                            AIE_STRL_HTML_TABLE_FELD_VAR_ALIGN_RIGHT), false))
	          {
		     eTD
	             bTDar
	          }
	          else
	          {
	             TBL_STD_COL_CHANGE
	          }
	       }
	       else
	       {
		  if (__builtin_expect(
			   ((fields->flags & 
			     AIE_STRL_HTML_TABLE_FELD_VAR_2TD) == 0), false))
		  {
	             if (__builtin_expect((!aie_StrEmpty(fields->txt)), true))
	             {
		        BR
		     }
		  }
	       }
	       if (fields->format_var != NULL)
	       {
	          html_vt(fields->format_var, var);
	       }
	       else
	       {
	          html_vt("%s&nbsp;", var);
	       }
	       //html_vt("%d", strlen(var));
	       if ((fields->flags & AIE_STRL_HTML_TABLE_FELD_EURO) ==
	                            AIE_STRL_HTML_TABLE_FELD_EURO)
	       {
	          html_static("&euro;&nbsp;");
	       }
	       TBL_STD_COL_ROW_END
	 }
	 if (__builtin_expect(
		     ((fields->flags & AIE_STRL_HTML_TABLE_FELD_HR_AFTER) ==
	                               AIE_STRL_HTML_TABLE_FELD_HR_AFTER), false))
	 {
	    html_static("\n<TR><TD colspan=2><HR></TD></TR>\n");
	 }
	 fields++;
      }
   }
   eTABLE
   return(rc);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_strl_html_table_size    = __LINE__;                              //
/* -------------------------------- EOF ------------------------------------ */

