/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : aie_aprio.c                                                 */
/* Library     : aiengine-client-n.nn.nn.so                                  */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 31.03.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Anpassungen an Version 3.0                  */
/*.............+...............+.............................................*/
/* 20.01.2005  : ALH           : Neue Funktion fuer Start/Stop von Servern   */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : const char * als const * deklarieren        */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aprio_version = "1.0.0";                                   //
const char *modul_aprio         = "aPrio";                                   //
const char *modul_aprio_date    = __DATE__;                                  //
const char *modul_aprio_time    = __TIME__;                                  //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_SERVER_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Headerdateien                                                      */
/*...........................................................................*/
#ifndef __WIN32__
#include <unistd.h>
#include <signal.h>
#endif
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static void aie_prio_signal_wait(int has_signal);                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static int prio_run_count = 0;
static bool aie_have_new_prio = false;
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : void                                                      */
/*...........................................................................*/
#ifndef __WIN32__
static void aie_prio_signal_wait(int has_signal)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_INFO, "RunCount: %d Have Signal %d" }
   };
   if (__builtin_expect((has_signal == SIGALRM), false))
   {
      // RunCount: %d Have Signal %d
      aie_sys_log(0, prio_run_count, has_signal);
   }
   aie_have_new_prio = true;
}

bool aie_send_prio_message(const char *prog_name, pid_t pid, int new_prio, 
                                                        bool want_signal)
{
   static int msqid = -1;
   struct prio_msgbuf msgbuf;
   const char *prog = "Unknown";
   bool rc;
   
   aie_have_new_prio = false;
   prio_run_count++;
   signal(SIGALRM, aie_prio_signal_wait);
   signal(SIGUSR1, aie_prio_signal_wait);

   if (msqid < 0)
   {
       msqid = aie_open_queue(MSG_PROG_PRIO);
   }
   memset(&msgbuf, '\0', sizeof(msgbuf));
   if (prog_name != NULL)
   {
      prog = prog_name;
   }
   msgbuf.mtype = MSG_PROG_PRIO;
   strncpy(msgbuf.ipc_prio_msg.prog_name, prog, AIE_LEN_CGI_NAME);
   msgbuf.ipc_prio_msg.pid = pid;
   msgbuf.ipc_prio_msg.new_prio = new_prio;
   msgbuf.ipc_prio_msg.want_signal = want_signal;
   rc = aie_send_queue_nowait(msqid, MSG_PROG_PRIO, &msgbuf, sizeof(msgbuf));
   // Zeitscheibe abgeben 
   sleep(0);
   // Warten bis Signal von Prio Prozess eintrifft ...
   if (__builtin_expect((want_signal && !aie_have_new_prio), false))
   {
      alarm(5);
      //sys_log("%s(%d): Prio Run Count: %d newPrio %d", __FILE__, __LINE__, 
      //	                                            prio_run_count,
      //						    new_prio);
      while (!aie_have_new_prio)
      {
         usleep(200);
      }
      alarm(0);
   }
   //else
   //{
   //   sys_log("%s(%d): Fast Prio : Run Count: %d newPrio %d", __FILE__, 
	//                                                      __LINE__, 
	//                                            ++prio_run_count,
	//					    new_prio);
   //}
   return(rc);
}

bool aie_send_prog_start_stop_message(const char *prog_name, pid_t pid, int typ)
{
   static int msqid = -1;
   struct prio_msgbuf msgbuf;
   if ((prog_name != NULL) && 
	  ((typ == MSG_PROG_START) || 
	   (typ == MSG_PROG_KILL)))
   {
      if (msqid < 0)
      {
          msqid = aie_open_queue(MSG_PROG_PRIO);
      }
      memset(&msgbuf, '\0', sizeof(msgbuf));
      if (typ == MSG_PROG_START)
      {
         msgbuf.mtype = MSG_PROG_START;
         msgbuf.ipc_prog_start_msg.pid = pid;
         strncpy(msgbuf.ipc_prog_start_msg.prog, prog_name, AIE_LEN_PROG_NAME);
      }
      else
      {
         msgbuf.mtype = MSG_PROG_KILL;
         msgbuf.ipc_prog_kill_msg.pid = pid;
         strncpy(msgbuf.ipc_prog_kill_msg.prog, prog_name, AIE_LEN_PROG_NAME);
      } 
      return(aie_send_queue_nowait(msqid, typ, &msgbuf, sizeof(msgbuf)));
   }
   return(false);
}
/*---------------------------------------------------------------------------*/
#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_aprio_size    = __LINE__;                                        //
/* -------------------------------- EOF ------------------------------------ */

