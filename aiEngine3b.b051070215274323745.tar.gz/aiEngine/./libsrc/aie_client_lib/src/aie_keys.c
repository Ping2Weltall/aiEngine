/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_keys.c                                                  */
/* Library     : aiengine-client-3.00.00.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Verwendet die Krypto Bibliothek                                           */
/* Wird nur eingebunden wenn aie_do_use_keys true ist                        */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 20.04.2004  : ALH           : Auslagerung der Routinen in eigenen Server  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_keys_version        = "1.2.0";                             //
const char *modul_keys                = "Key's";                             //
const char *modul_keys_date           = __DATE__;                            //
const char *modul_keys_time           = __TIME__;                            //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_CLIENT_LIB			1
#define swap_hi_lo(a) { char t = *a; *a = *(a + 1); *(a + 1) = t; }          //
#define MAX_SECRET_KEY       512                                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
//#include "aiengine_client.h"                                                 //
//#include "aiengine_server.h"                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
#if aie_do_use_keys                                                          //
extern char *cgiQueryString;                                                 //
                                                                             //
#endif                                                                       //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
#if aie_do_use_keys                                                          //
#endif                                                                       //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
#if aie_do_use_keys                                                          //
#endif                                                                       //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
#if aie_do_use_keys                                                          //
#endif                                                                       //
/*****************************************************************************/

#if aie_do_use_keys
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
const char *aie_do_code_string(const char *s)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_do_code_string [%s]" },
      { AIE_LOG_INFO,  "coded[%s]" }
   };
   aie_sys_log(0, s);
   #endif
   #if 0
   char *rc_ptr = key_client(MSG_KEY_SERVER_REQUEST_CODE, "test", s);
   // coded[%s]
   aie_sys_log(1, rc_ptr);
   return(rc_ptr);
   #endif
   //return(key_client(MSG_KEY_SERVER_REQUEST_CODE, "test", s));
   return(aie_key_client(MSG_KEY_SERVER_REQUEST_CODE, 
	             "aIEngine", s));
	             //aIEngine_GlobalEngineName, s));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_do_decode_string(const char *s)
{
   #if AIENGINE_LOG_TRACE_RUN_CGI_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_do_decode_string [%s]" },         
      { AIE_LOG_INFO,  "Decoded[%s]" }
   };
   aie_sys_log(0, s);
   #endif
#if 0
   char *rc_ptr = key_client(MSG_KEY_SERVER_REQUEST_DECODE, "test", s);;
   sys_log("%s(%d): Decoded[%s]", __FILE__, __LINE__, rc_ptr);
   aie_sys_log(1, rc_ptr);
   return(rc_ptr);
#endif
   //return(key_client(MSG_KEY_SERVER_REQUEST_DECODE, "test", s));
   return(aie_key_client(MSG_KEY_SERVER_REQUEST_DECODE, 
	             "aIEngine", s));
	             //aIEngine_GlobalEngineName, s));
}
/*---------------------------------------------------------------------------*/

#endif
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_keys_size           = __LINE__;                                  //
/* -------------------------------- EOF ------------------------------------ */

