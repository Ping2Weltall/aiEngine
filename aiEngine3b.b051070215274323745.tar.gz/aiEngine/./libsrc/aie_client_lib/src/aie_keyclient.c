/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_keyclient.c                                             */
/* Library     : aiengine-client-n.nn.nn.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 19.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Anpassungen an Version 3.0                  */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_keyclient_version       = "1.0.0";                         //
const char *modul_keyclient               = "KeyClient";                     //
const char *modul_keyclient_date          = __DATE__;                        //
const char *modul_keyclient_time          = __TIME__;                        //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define BACKGROUND_MODUL                                                     //
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
#define AIENGINE_USE_SOCKETS		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Header Dateien                                                     */
/*...........................................................................*/
#include <sys/types.h>                                                       //
#include <sys/socket.h>                                                       //
#ifndef __WIN32__
#include <unistd.h>                                                          //
#endif
#include <signal.h>                                                          //
#include <string.h>                                                          //
#include <stdio.h>                                                           //
#include <stdlib.h>                                                          //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
//#include "aiengine_msg.h"                                                    //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
struct aIEngine_sockets *keyserver_socket = NULL;                            //
                                                                             //
/*****************************************************************************/

#ifndef __WIN32__
bool aie_start_key_client(const char *address)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_start_key_client" },
      { AIE_LOG_ERROR, "Fehler Keyserver Startup: %s" }
   };
   bool rc = true;
   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   // Keyserver Start 
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((keyserver_socket = 
	    aIEngine_StartSocketServer(address, 
	                               MSG_KEY_SERVER_START, 
				       MSG_KEY_SERVER_STOP, 
				       sizeof(struct key_server_msgbuf)))
	 == NULL),false))
   {
      // Fehler Keyserver Startup
      aie_sys_log(1, strerror(errno));
      rc = false;
   }
   return(rc);
}

char *aie_key_client(int request, const char *cgi_name, const char *s)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_key_client [%s]" },
      { AIE_LOG_ERROR, "client: send: %s" },
      { AIE_LOG_INFO,  "Test expect answer" },
      { AIE_LOG_INFO,  "Wait for answer Len %d" },
      { AIE_LOG_ERROR, "Fehler beim Lesen Keyserverreply: %d %s" },
      { AIE_LOG_INFO,  "Have answer [%s]" },
      { AIE_LOG_ERROR, "client: Nicht Initialisiert?: %s" },
      { AIE_LOG_INFO,  "Have answer [%s]" }
   };
   char *rc_ptr = NULL;
   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   // Key Client Request [%s]
   aie_sys_log(0, s);
   #endif
   if (__builtin_expect(
	    ((keyserver_socket != NULL) &&
	     (keyserver_socket->fp != NULL) && 
	     (keyserver_socket->client_socket >= 0)),true))
   {
      struct key_server_msgbuf *answer_buf = 
                             (struct key_server_msgbuf *)keyserver_socket->buf;
      struct key_server_msgbuf *request_buf = 
	                     (struct key_server_msgbuf *)keyserver_socket->buf;
      memset(request_buf, '\0', sizeof(keyserver_socket->len));
      request_buf->mtype = request;
      request_buf->m.ipc_key_server_msg.request = request;
      strncpy(request_buf->m.ipc_key_server_msg.cgi_name, cgi_name, 
      	                                                  AIE_LEN_CGI_NAME);
      if (__builtin_expect((s != NULL),true))
      {
         strncpy(request_buf->m.ipc_key_server_msg.buf, s, 
	                                              AIE_MAX_CRYPT_BLOCKSIZE);
      }
      if (__builtin_expect(
	       (send(keyserver_socket->client_socket, 
		     request_buf, keyserver_socket->len, 0) < 0),false))
      {
          // client: send: %s
          aie_sys_log(1, strerror(errno));
      }
      else
      {
         sleep(0);
         #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
         // Test expect answer
         aie_sys_log(2);
         #endif
	 if (__builtin_expect(((request == MSG_KEY_SERVER_REQUEST_CODE) ||
	                       (request == MSG_KEY_SERVER_GET_CHALLENGE) ||
	     (request == MSG_KEY_SERVER_REQUEST_DECODE)),true))
         {
	    int rc = 0;
	    //errno = 0;
            clearerr(keyserver_socket->fp);
            #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
            // Wait for answer Len %d
            aie_sys_log(3, keyserver_socket->len);
            #endif
            fread(answer_buf, keyserver_socket->len, 1, keyserver_socket->fp);
            if (__builtin_expect(((rc = ferror(keyserver_socket->fp)) != 0), 
		                                                        false))
	    {
                // Fehler beim Lesen Keyserverreply %d %s
                aie_sys_log(4, rc, strerror(errno));
	    }
            rc_ptr = answer_buf->m.ipc_key_server_msg.buf;
            #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
            // Have answer [%s]
            aie_sys_log(5, rc_ptr);
            #endif
         }
      }
   }
   else
   {
      // client: Nicht Initialisiert?: %s
      aie_sys_log(6, strerror(errno));
   }
   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   // Have answer [%s]
   aie_sys_log(7, rc_ptr);
   #endif
   return(rc_ptr);
}

#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_keyclient_size          = __LINE__;                              //
/* -------------------------------- EOF ------------------------------------ */

