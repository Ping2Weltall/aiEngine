/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_socketclient.c                                          */
/* Library     : aiengine-client-n.nn.nn.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 26.04.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Anpassungen an Version 3.0                  */
/*.............+...............+.............................................*/
/* 13.01.2005  : ALH           : Anpassen aller Logmeldungen fuer WinGUI     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_socketclient_version       = "1.0.0";                      //
const char *modul_socketclient               = "SocketClient";               //
const char *modul_socketclient_date          = __DATE__;                     //
const char *modul_socketclient_time          = __TIME__;                     //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define BACKGROUND_MODUL                                                     //
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_SERVER_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
#define AIENGINE_USE_SOCKETS		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Headerdateien                                                      */
/*...........................................................................*/
#include <sys/types.h>                                                       //
#ifndef __WIN32__
#include <unistd.h>                                                          //
#endif
#include <signal.h>                                                          //
#include <string.h>                                                          //
#include <stdio.h>                                                           //
#include <stdlib.h>                                                          //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool SocketServerControl(unsigned int request,                        //
                                struct aIEngine_sockets *socket_data);       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static struct aIEngine_sockets *aIEngine_sockets_base = NULL;                //
                                                                             //
/*****************************************************************************/

#ifndef __WIN32__
void aIEngine_CloseServerSockets(void)
{
   struct aIEngine_sockets *aIEngine_sockets_ptr = aIEngine_sockets_base;
   while(aIEngine_sockets_ptr != NULL)
   {
      aIEngine_sockets_base = aIEngine_sockets_ptr->next;
      //if (aIEngine_sockets_ptr->client_socket >= 0)
      {
         aIEngine_StopSocketServer(aIEngine_sockets_ptr);
      }
      aie_free(aIEngine_sockets_ptr);
      aIEngine_sockets_ptr = aIEngine_sockets_base;
   }
}

struct aIEngine_sockets *aIEngine_OpenSocket(const char *address, 
                                                          unsigned int buflen)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aIEngine_OpenSocket Adr[%s] size[%d]" },         
      { AIE_LOG_ERROR, "Ungueltige Addresse -- NULL --" },
      { AIE_LOG_ERROR, "Out of Memory ?!" },
      { AIE_LOG_ERROR, "client: socket: %s" },
      { AIE_LOG_ERROR, "client: connect: %s" },
      { AIE_LOG_ERROR, "client: fdopen: %s" },
      { AIE_LOG_ERROR, "client: buf Memory Size %d :%s" },
      { AIE_LOG_INFO,  "Socket Adresse[%s] geoeffnet - size[%d]" }
   };
   struct aIEngine_sockets *aIEngine_sockets_ptr = NULL;        
   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   aie_sys_log(0, address, buflen);
   #endif
   if (__builtin_expect((address == NULL),false))
   {
      // Ungueltige Addresse -- NULL --
      aie_sys_log(1);
   }
   else
   {
      if (__builtin_expect(
	       ((aIEngine_sockets_ptr = 
	       (struct aIEngine_sockets *)
	       aie_malloc(sizeof(struct aIEngine_sockets))) == NULL),false))
      {
         // Out of Memory ?!
         aie_sys_log(2);
      }
      else
      {
         aIEngine_sockets_ptr->address = NULL;
         aIEngine_sockets_ptr->saun = NULL;
         aIEngine_sockets_ptr->client_socket = -1;
         aIEngine_sockets_ptr->fp = NULL;
	 if (__builtin_expect(
		  ((aIEngine_sockets_ptr->address = 
		    aie_strdup(address)) == NULL),false))
	 {
             // Out of Memory ?!
             aie_sys_log(2);
	     aie_free(aIEngine_sockets_ptr);
	     aIEngine_sockets_ptr = NULL;
	 }
	 else
	 {
            unsigned int len = sizeof(struct sockaddr)+strlen(address);
            if (__builtin_expect(((aIEngine_sockets_ptr->saun = 
		     (struct sockaddr *)aie_malloc(len + 1)) == NULL),false))
            {
               // Out of Memory ?!
               aie_sys_log(2);
            }
            else
            {
               if (__builtin_expect(
			((aIEngine_sockets_ptr->client_socket = 
			  socket(AF_UNIX, SOCK_STREAM, 0)) < 0), false))
               {
                   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
                   // client: socket: %s
                   aie_sys_log(3, strerror(errno));
                   #endif
	           aie_free(aIEngine_sockets_ptr->address);
	           aie_free(aIEngine_sockets_ptr->saun);
	           aie_free(aIEngine_sockets_ptr);
	           aIEngine_sockets_ptr = NULL;
               }
               else
               {
                  aIEngine_sockets_ptr->saun->sa_family = AF_UNIX;
                  strcpy(aIEngine_sockets_ptr->saun->sa_data, address);
                  if (__builtin_expect(
			   (connect(aIEngine_sockets_ptr->client_socket, 
			    aIEngine_sockets_ptr->saun, len) < 0),false))
                  {
                      // client: connect: %s
                      aie_sys_log(4, strerror(errno));
		      close(aIEngine_sockets_ptr->client_socket);
	              aie_free(aIEngine_sockets_ptr->address);
	              aie_free(aIEngine_sockets_ptr->saun);
	              aie_free(aIEngine_sockets_ptr);
	              aIEngine_sockets_ptr = NULL;
                  }
                  else
                  {
                     if (__builtin_expect(
			      ((aIEngine_sockets_ptr->fp = 
			fdopen(aIEngine_sockets_ptr->client_socket, "w+b"))
		                                         == NULL),false))
	             {
                        // client: fdopen: %s
                        aie_sys_log(5, strerror(errno));
		        close(aIEngine_sockets_ptr->client_socket);
	                aie_free(aIEngine_sockets_ptr->address);
	                aie_free(aIEngine_sockets_ptr->saun);
	                aie_free(aIEngine_sockets_ptr);
	                aIEngine_sockets_ptr = NULL;
		     }
		     else
		     {
			errno = 0; // Zuruecksetzen da fdopen erfolglos 
			           // versucht den Dateizeiger zu setzten
				   // was bei einem Socket nicht funktioniert
                        if (__builtin_expect(
				 ((aIEngine_sockets_ptr->buf = 
				   (void *)aie_malloc(buflen)) == NULL),false))
                        {
                           // client: buf Memory Size %d :%s
                           aie_sys_log(6, buflen, strerror(errno));
		           close(aIEngine_sockets_ptr->client_socket);
	                   aie_free(aIEngine_sockets_ptr->address);
	                   aie_free(aIEngine_sockets_ptr->saun);
	                   aie_free(aIEngine_sockets_ptr);
	                   aIEngine_sockets_ptr = NULL;
                        }
			else
			{
                           aIEngine_sockets_ptr->len = buflen;
                           #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
                           // Socket Adresse[%s] geoeffnet - size[%d]
                           aie_sys_log(7, address, buflen);
                           #endif
			}
		     }
	          }
               }
            }
	 }
      }
   }
   return(aIEngine_sockets_ptr);
}

struct aIEngine_sockets *aIEngine_StartSocketServer(const char *address, 
                                    unsigned int start_msg, 
				    unsigned int stop_msg, 
				    unsigned int buflen)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aIEngine_StartSocketServer Adresse[%s] Buflen[%d]" },
      { AIE_LOG_INFO,  "Client Seite OK Socket[%s]" },
      { AIE_LOG_ERROR, "client: start Socket[%s]: %s" },
      { AIE_LOG_TRACE, "aIEngine_StartSocketServer .. done rc=%d" }
   };
   bool rc = false;
   struct aIEngine_sockets *aIEngine_sockets;

   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   aie_sys_log(0, address, buflen);
   #endif
   if (__builtin_expect(((aIEngine_sockets = 
		  aIEngine_OpenSocket(address, buflen)) != NULL),true))
   {
      aIEngine_sockets->next = aIEngine_sockets_base;
      aIEngine_sockets_base = aIEngine_sockets;
      aIEngine_sockets->start_msg = start_msg;
      aIEngine_sockets->stop_msg = stop_msg;
      if (__builtin_expect((aIEngine_sockets->buf != NULL),true))
      {
         if (__builtin_expect(
	  (SocketServerControl(start_msg, aIEngine_sockets)==true),true))
         {
            #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
            // Client Seite OK Socket[%s]
            aie_sys_log(1, address);
            #endif
            rc = true;
          }
          else
          {
             // client: start Socket[%s]: %s
             aie_sys_log(2, address, strerror(errno));
          }
      }
   }
   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   aie_sys_log(3, rc);
   #endif
   return(aIEngine_sockets);
}

static bool SocketServerControl(unsigned int request, 
                                struct aIEngine_sockets *socket_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "SocketServerControl" },
      { AIE_LOG_ERROR, "client: send: %s" },
      { AIE_LOG_ERROR, "client: Nicht Initialisiert?: %s" }
   };
   bool rc = true;

   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   aie_sys_log(0);
   #endif
   
   if (__builtin_expect(
	    ((socket_data->fp != NULL) && 
	     (socket_data->client_socket >= 0)), true))
   {
      struct common_server_msgbuf *request_buf = 
	                       (struct common_server_msgbuf *)socket_data->buf;
      memset(request_buf, '\0', socket_data->len);
      request_buf->mtype = request;
      if (__builtin_expect((send(socket_data->client_socket, 
	                         request_buf, socket_data->len, 0) < 0), false))
      {
          // client: send: %s
          aie_sys_log(1, strerror(errno));
	  rc = false;
      }
      else
      {
         sleep(0);
      }
   }
   else
   {
      // client: Nicht Initialisiert?: %s
      aie_sys_log(2, strerror(errno));
      rc = false;
   }
   return(rc);
}

void aIEngine_StopSocketServer(struct aIEngine_sockets *socket_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aIEngine_StopSocketServer" },
      { AIE_LOG_ERROR, "SocketServer client: stop: %s" },
      { AIE_LOG_ERROR, "Stop Socket Server mit socket_data == NULL Ptr" }
   };
   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((socket_data != NULL), true))
   {
      if (__builtin_expect((socket_data->client_socket >= 0),true))
      {
         if (__builtin_expect(
	    (!SocketServerControl(socket_data->stop_msg, socket_data)),false))
         {
            // SocketServer client: stop: %s
            aie_sys_log(1, strerror(errno));
         }
      }
      aIEngine_CloseSocket(socket_data); 
   }
   else
   {
      aie_sys_log(2);
   }
}

void aIEngine_CloseSocket(struct aIEngine_sockets *socket_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aIEngine_CloseSocket" },
      { AIE_LOG_ERROR, "CloseSocket Parameter == NULL" }
   };
   #if AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((socket_data != NULL), true))
   {
      if (__builtin_expect((socket_data->client_socket >= 0),true))
      {
         close(socket_data->client_socket);
      }
      socket_data->client_socket = -1;
      if (__builtin_expect((socket_data->saun != NULL),true))
      {
         aie_free(socket_data->saun);
         socket_data->saun = NULL;
      }
      if (__builtin_expect((socket_data->address != NULL),true))
      {
         aie_free(socket_data->address);
         socket_data->address = NULL;
      }
      if (__builtin_expect((socket_data->buf != NULL),true))
      {
         aie_free(socket_data->buf);
         socket_data->buf = NULL;
      }
   }
   else
   {
      aie_sys_log(1);
   }
}
#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_socketclient_size          = __LINE__;                           //
/* -------------------------------- EOF ------------------------------------ */

