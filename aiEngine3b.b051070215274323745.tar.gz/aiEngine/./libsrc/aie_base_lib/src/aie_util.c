/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_util.c                                                  */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Alle Logmeldungen Anpassen auf WinGui Client*/
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*                             : RDummy Routinen fuer sleep und sync         */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Dynamischer Speicher fuer grosse Variablen  */
/*                             : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_util_version = "1.8.0";                                    //
const char *modul_util         = "Util";                                     //
const char *modul_util_date    = __DATE__;                                   //
const char *modul_util_time    = __TIME__;                                   //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define TXT_MOVE_BUF_SIZE	1024
#define TEST_FILE_LEN           255
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#ifndef __WIN32__
#include <unistd.h>
#else
#include <dos.h>
#include <dir.h>
#endif
#include <dirent.h>
#include <sys/stat.h>
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
#if 0
#ifdef __WIN32__
static bool dir_entry_exist(const char *entry, int param);                   //
#else
static bool dir_entry_exist(const char *entry);                              //
#endif
static bool is_file_name(const char *file, const char *find);              //
#endif
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : long                                                      */
/*...........................................................................*/
#if 0
long aie_convert_inp_2_sek(struct aie_time_convert_table timetable[], 
                           int size, char *inp)
{
   long sek = 0;
   register int z = 0;
   for (z = 0;z < size;z++)
   {
      if (__builtin_expect((strcmp(timetable[z].inp, inp) == 0),false))
      {
         sek = timetable[z].sekunden;
      }
   }
   return(sek);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
static bool is_file_name(const char *file, const char *find)
{
   const char *sptr_file = ((file + strlen(file) - 1));
   const char *sptr_find = ((find + strlen(find) - 1));
   bool rc = false;
   if (__builtin_expect((*file != '\0'),true))
   {
      if (*find == '\0')
      {
         sptr_file = file;
         sptr_find = find;
      }
      else
      {
         while ((sptr_file != file))
         {
            if (*sptr_find != '?')
            {
               if (*sptr_find == '*')
               {
                  const char *sptr2 = sptr_find;
                  unsigned int i = 0;
                  if (sptr2 != find)
                  {
                     do
                     {
                        sptr2--;
                        if (*sptr2 != '?')
                        {
                           i++;
                        }
                     } while ((sptr2 != find) && (*sptr2 != '*'));
                  }
                  if ((sptr_file > file) && (i > 0))
                  {
                     if ((*sptr2 == '*'))
                     {
                        sptr2++;
                     }
                     while(sptr_file > file)
                     {
                        sptr_file--;
                        if (*sptr_file == *sptr2)
                        {
                           if (memcmp(sptr_file, sptr2, i - 1) == 0)
                           {
                              sptr_file++;
                              break;
                           }
                        }
                     }
                     if ((sptr_file += (sptr_find - sptr2)) >  file)
                     {
                        sptr_file--;
                     }
                  }
                  if (sptr_find == find)
                  {
                     rc = true;
                     break;
                  }
               }
               else
               {
                  if (*sptr_find != *sptr_file)
                  {
                     break;
                  }
               }
            }
            if (sptr_file != file)
            {
               sptr_file--;
            }
            sptr_find--;
         }
      }
      if ((sptr_file == file) && (sptr_find == find))
      {
         rc = true;
      }
      else
      {
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_make_dir(const char *dir)
{
   if (!aie_dir_exist(dir))
   {
      #ifdef __WIN32__
      return(mkdir(dir) == 0);
      #else
      return(mkdir(dir, /* ACCESSPERMS*/ 0700) == 0);
      #endif
   }
   return(true);

}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_file_exist(const char *file)
{
   #ifdef __WIN32__
   return(dir_entry_exist(file, 0));
   #else
   return(dir_entry_exist(file));
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_dir_exist(const char *dir)
{
   #ifdef __WIN32__
   return(dir_entry_exist(dir, FA_DIREC));
   #else
   return(dir_entry_exist(dir));
   #endif
}
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
/* Funktion      : dir_entry_exist                                           */
/* Bemerkung     : Unter Linux verwenden wir jetzt stat                      */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
#ifdef __WIN32__
static bool dir_entry_exist(const char *entry, int param)
#else
static bool dir_entry_exist(const char *entry)
#endif
{
   #ifdef __WIN32__
   struct ffblk ffblk;
   if (__builtin_expect((entry == NULL),false))
   {
      return(false);
   }
   return(findfirst(entry,&ffblk,param) == 0);
   #else
   struct stat *buf = (struct stat *)aie_malloc(sizeof(struct stat));
   bool rc = false;
   rc = (stat(entry, buf) == 0) ? true : false;
   aie_free(buf);
   return(rc);
   #endif
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_check_create_dir(const char *dir, bool create)
{
   bool rc = true;
   if (!aie_dir_exist(dir))
   {
      if (__builtin_expect((!create),true))
      {
         rc = false;
      }
      else
      {
         if (__builtin_expect((!aie_make_dir(dir)),false))
         {
            rc = false;
         }
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_move_file(const char *in, const char *out)
{
   FILE *fptr_in;
   FILE *fptr_out;
   bool rc = false;
   //char buf[512];
   char *buf = (char *)aie_malloc(TXT_MOVE_BUF_SIZE);
   unsigned int len;
   if (__builtin_expect(
	    ((fptr_in = aie_open_read_binary_file(in)) != NULL),true))
   {
      if (__builtin_expect(
	       ((fptr_out = aie_open_write_binary_file(out)) != NULL),true))
      {
         while(!feof(fptr_in))
         {
            len = fread(buf, 1, TXT_MOVE_BUF_SIZE, fptr_in);
            fwrite(buf, len, 1, fptr_out);
            if (__builtin_expect((len < sizeof(buf)),false))
            {
               break;
            }
         }
         rc = true;
         aie_close_file(fptr_out);
      }
      aie_close_file(fptr_in);
   }
   aie_free(buf);
   if (rc)
   {
      aie_delete_file(in);
   }
   else
   {
     // html_vt("Move Failed %s -> %s<br>", in, out);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_delete_file(const char *file)
{
   bool rc = false;
   #ifdef __WIN32__
   struct ffblk ffblk;
   if (findfirst(file,&ffblk,0) == 0)
   {
      remove(file);
      rc = true;
   }
   #else
      rc = remove(file);
   #endif
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : FILE *                                                    */
/*...........................................................................*/
FILE *aie_open_write_text_file(const char *file)
{
    return(aie_open_file(file, "wt"));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : FILE *                                                    */
/*...........................................................................*/
FILE *aie_open_append_text_file(const char *file)
{
    return(aie_open_file(file, "at"));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : FILE *                                                    */
/*...........................................................................*/
FILE *aie_open_write_binary_file(const char *file)
{
    return(aie_open_file(file, "wb"));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : FILE *                                                    */
/*...........................................................................*/
FILE *aie_open_read_binary_file(const char *file)
{
    return(aie_open_file(file, "rb"));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : FILE *                                                    */
/*...........................................................................*/
FILE *aie_open_read_text_file(const char *file)
{
    return(aie_open_file(file, "rt"));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : FILE *                                                    */
/*...........................................................................*/
FILE *aie_open_file(const char *file, const char *mode)
{
   return(fopen(file, mode));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_close_file(FILE *fptr)
{
   return(fclose(fptr) == 0);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : struct file_liste *                                       */
/*...........................................................................*/
struct aie_file_liste *aie_read_file_liste(const char *name, 
                                           struct aie_file_liste **file_liste)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_read_file_liste Name[%s]" },
      { AIE_LOG_ERROR, "Kein Verzeichniss: [%s]" },
      { AIE_LOG_ERROR, "Out of Memory ?!" },
      { AIE_LOG_ERROR, "Kein Verzeichniss uebergeben oder name == NULL Ptr" }
   };
   struct aie_file_liste *file_liste_base = NULL;
   #ifdef __WIN32__
   struct ffblk ffblk;
   int done;
   struct aie_file_liste *file_liste_ptr;

      if ((done = findfirst(name,&ffblk,0)) == 0)
      {
         while (!done)
         {
            if (file_liste_base == NULL)
            {
               file_liste_base = (struct aie_file_liste *)
		                     aie_malloc(sizeof(struct aie_file_liste));
               file_liste_ptr = file_liste_base;
            }
            else
            {
               file_liste_ptr->next = (struct aie_file_liste *)
		                     aie_malloc(sizeof(struct aie_file_liste));
               file_liste_ptr = file_liste_ptr->next;
            }
            file_liste_ptr->file = aie_strdup(ffblk.ff_name);
            file_liste_ptr->next = NULL;
            done = findnext(&ffblk);
         }
      }
   #else
   #if AIENGINE_LOG_TRACE_FILE_IO_TRACE
   aie_sys_log(0, name);
   #endif
   if (__builtin_expect(((name != NULL) && (*name != '\0')), true))
   {
      char *test = (char *)aie_malloc(TEST_FILE_LEN);
      char *sptr;
      char *dummy = aie_strdup("*\0");
      int len = strlen(name);
      if (__builtin_expect(((test != NULL) && (dummy != NULL)), true))
      {
         char *work_name = aie_strdup(name);
         if (__builtin_expect((work_name != NULL),true))
         {

            if (__builtin_expect(
	             (*(sptr = (work_name + len - 1)) == '/'),false))
            {
               sptr = dummy;
            }
            else
            {
               while ((sptr != work_name) && (*sptr != '/'))
               {
                  sptr--;
               }
            }
            if (sptr != work_name)
            {
               memset(test, '\0', TEST_FILE_LEN);
               if (sptr != dummy)
               {
                  if (*sptr == '/')
                  {
                     *sptr = '\0';
                     sptr++;
                     strncpy(test, sptr, TEST_FILE_LEN - 1);
                  }
	          else
                  {
                     strncpy(test, dummy, TEST_FILE_LEN - 1);
                  }
               }
               else
               {
                  strncpy(test, dummy, TEST_FILE_LEN - 1);
               }
               {
                  struct aie_file_liste *file_liste_ptr = NULL;
                  struct dirent *dirent;
                  DIR *dirp;

                  if (__builtin_expect(
		           ((dirp = opendir(work_name)) != NULL),true))
                  {
                     while ((dirent = readdir(dirp)) != NULL)
                     {
                        if (__builtin_expect(
			   (is_file_name(dirent->d_name, test) == true),false))
                        {
                           if (__builtin_expect(
			            (file_liste_base == NULL),false))
                           {
                              file_liste_base = 
			               (struct aie_file_liste *)
			          aie_malloc(sizeof(struct aie_file_liste));
                              file_liste_ptr = file_liste_base;
                           }
                           else
                           {
                              file_liste_ptr->next = 
			         (struct aie_file_liste *)
			         aie_malloc(sizeof(struct aie_file_liste));
                              file_liste_ptr = file_liste_ptr->next;
                           }
                           file_liste_ptr->file = aie_strdup(dirent->d_name);
                           file_liste_ptr->next = NULL;
                        }
                     }
                     closedir(dirp);
                  }
	          else
                  {
	             // Kein Verzeichniss: [%s]
                     aie_sys_log(1, work_name);
                  }
               }
            }
            aie_free(work_name);
         }
	 else
	 {
	    // Out of Memory ?!
            aie_sys_log(2);
	 }
	 if (__builtin_expect((test != NULL), true))
	 {
            aie_free(test);
	 }
	 if (__builtin_expect((dummy != NULL), true))
	 {
            aie_free(dummy);
	 }
      }
   }
   else
   {
      // Kein Verzeichniss uebergeben oder verzeichnissname == NULL Ptr
      aie_sys_log(3);
   }
   #endif
   return(*file_liste = file_liste_base);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_free_file_liste(struct aie_file_liste **file_liste)
{
   struct aie_file_liste *file_liste_base = *file_liste;
   struct aie_file_liste *file_liste_ptr;

   while((file_liste_ptr = file_liste_base) != NULL)
   {
      file_liste_base = file_liste_ptr->next;
      if (__builtin_expect((file_liste_ptr->file != NULL),true))
      {
         aie_free(file_liste_ptr->file);
      }
      aie_free(file_liste_ptr);
   }
   *file_liste = file_liste_base;
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_dot_dir(const char *file)
{
   bool rc = false;
   if (__builtin_expect(
	    ((strcmp(file, ".") == 0) || (strcmp(file, "..") == 0)),false))
   {
      rc = true;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/


#if AIE_TARGET_IS_LINUX
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : void                                                      */
/*...........................................................................*/
void randomize(void)
{
   srand((unsigned int)getpid());
}
/*---------------------------------------------------------------------------*/
#endif
#ifdef __WIN32__
void sync(void)
{
}

void usleep(int n)
{
   n = n;
}
#endif
#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_util_size    = __LINE__;                                         //
/* -------------------------------- EOF ------------------------------------ */

