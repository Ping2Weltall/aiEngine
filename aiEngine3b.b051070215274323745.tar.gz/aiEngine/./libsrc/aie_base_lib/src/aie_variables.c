/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_variables.c                                             */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_variables_version         = "1.5.0";                       //
const char *modul_variables                 = "Variablen";                   //
const char *modul_variables_date            = __DATE__;                      //
const char *modul_variables_time            = __TIME__;                      //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_LOG_LIB			1
#define VAR_RESULT_BUF_LEN     256                                           //
#define VAR_DYN_MEMORY_SIZE    1024                                          //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *aIEngine_GlobalApplName;                                        //
extern char *aIEngine_Channel;                                               //
extern char *aIEngine_Classification;                                        //
extern char *aIEngine_PageCopyright;                                         //
extern char *aIEngine_Publisher;                                             //
extern char *aIEngine_Author;                                                //
extern char *aIEngine_HomeUrl;                                               //
extern char *aIEngine_Siteinfo;                                              //
extern char *aIEngine_ApplTitle;                                             //
extern char *aIEngine_Description;                                           //
extern char *aIEngine_Language;                                              //
extern char *aIEngine_Email;                                                 //
extern char *aIEngine_Page_type;                                             //
extern char *aIEngine_Audience;                                              //
extern char *aIEngine_Robots;                                                //
extern char *aIEngine_Reply_to;                                              //
extern char *aIEngine_Page_topic;                                            //
extern char *aIEngine_Resource_type;                                         //
extern char *aIEngine_Proxy_keep_alive;                                      //
extern char *aIEngine_Content_type;                                          //
extern char *aIEngine_Content_style_type;                                    //
extern char *aIEngine_Content_language;                                      //
extern char *aIEngine_Revisit_after;                                         //
extern char *aIEngine_Expires;                                               //
extern char *aIEngine_Created;                                               //
extern char *aIEngine_http_doc_date;                                         //
extern char *aIEngine_Support_Email;                                         //
extern char *aIEngine_CGI_Prog;                                              //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static void replace_variables(int typ, char *inp, time_t *t);                //
static char *get_variable_content(int typ, char *variable, char *buf,        //
                                  unsigned int max_len, time_t *t);          //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static struct aie_variable_heap *aie_variable_heap_base = NULL;              //
static struct aie_variables aie_global_asecur_variables[] =                  //
{                                                                            //
  { AIENGINE_VAR_CGI_MYSELF,       NULL, &aIEngine_CGI_Prog,           0  }, //
  { AIENGINE_VAR_T_OFFSET,         aie_variable_fkt_timeoffset, NULL,  3  }, //
  { AIENGINE_VAR_DAY,              aie_variable_fkt_day,     NULL,     0  }, //
  { AIENGINE_VAR_MONTH,            aie_variable_fkt_month,   NULL,     0  }, //
  { AIENGINE_VAR_YEAR,             aie_variable_fkt_year,    NULL,     0  }, //
  { AIENGINE_VAR_ASCDATE,          aie_variable_fkt_ascdate, NULL,     0  }, //
  { AIENGINE_VAR_GLOBAL_APPL_NAME, NULL, &aIEngine_GlobalApplName,     0  },
  { AIENGINE_VAR_CHANNEL,          NULL, &aIEngine_Channel,            0  }, //
  { AIENGINE_VAR_CLASSIFICATION,   NULL, &aIEngine_Classification,     0  }, //
  { AIENGINE_VAR_COPYRIGHT,        NULL, &aIEngine_PageCopyright,      0  }, //
  { AIENGINE_VAR_PUBLISHER,        NULL, &aIEngine_Publisher,          0  }, //
  { AIENGINE_VAR_AUTHOR,           NULL, &aIEngine_Author,             0  }, //
  { AIENGINE_VAR_HOME_URL,         NULL, &aIEngine_HomeUrl,            0  }, //
  { AIENGINE_VAR_SITEINFO,         NULL, &aIEngine_Siteinfo,           0  }, //
  { AIENGINE_VAR_TITLE,            NULL, &aIEngine_ApplTitle,          0  }, //
  { AIENGINE_VAR_DESCRIPTION,      NULL, &aIEngine_Description,        0  }, //
  { AIENGINE_VAR_LANGUAGE,         NULL, &aIEngine_Language,           0  }, //
  { AIENGINE_VAR_EMAIL,            NULL, &aIEngine_Email,              0  }, //
  { AIENGINE_VAR_PAGE_TYP,         NULL, &aIEngine_Page_type,          0  }, //
  { AIENGINE_VAR_AUDIENCE,         NULL, &aIEngine_Audience,           0  }, //
  { AIENGINE_VAR_ROBOTS,           NULL, &aIEngine_Robots,             0  }, //
  { AIENGINE_VAR_REPLY_TO,         NULL, &aIEngine_Reply_to,           0  }, //
  { AIENGINE_VAR_PAGE_TOPIC,       NULL, &aIEngine_Page_topic,         0  }, //
  { AIENGINE_VAR_RESOURCE_TYP,     NULL, &aIEngine_Resource_type,      0  }, //
  { AIENGINE_VAR_PROXY,            NULL, &aIEngine_Proxy_keep_alive,   0  }, //
  { AIENGINE_VAR_CONTENT_TYP,      NULL, &aIEngine_Content_type,       0  }, //
  { AIENGINE_VAR_CONTENT_STYLE,    NULL, &aIEngine_Content_style_type, 0  }, //
  { AIENGINE_VAR_CONTENT_LANGUAGE, NULL, &aIEngine_Content_language,   0  }, //
  { AIENGINE_VAR_REVISIT_AFTER,    NULL, &aIEngine_Revisit_after,      0  }, //
  { AIENGINE_VAR_EXPIRES,          NULL, &aIEngine_Expires,            0  }, //
  { AIENGINE_VAR_CREATED,          NULL, &aIEngine_Created,            0  }, //
  { AIENGINE_VAR_DOCDATE,          NULL, &aIEngine_http_doc_date,      0  }, //
  { AIENGINE_VAR_SUPPORT_EMAIL,    NULL, &aIEngine_Support_Email,      0  }  //
};                                                                           //
unsigned int aie_size_global_asecur_variables =                              //
                                   sizeof(aie_global_asecur_variables) /     //
                                   sizeof(struct aie_variables);             //
                                                                             //
									     //
struct aie_static_variables aie_static_asecur_variables[] =                  //
{                                                                            //
  { AIENGINE_VAR_GENERATOR,            aIEngine_Generator         },         //
  { AIENGINE_VAR_SERVER_VERSION,       aIEngine_ServerVersion     },         //
  { AIENGINE_VAR_GLOBAL_ENGINE_NAME,   aIEngine_GlobalEngineName  },         //
  { AIENGINE_VAR_COPYRIGHT_ENGINE_1,   aIEngine_Copyright_1       },         //
  { AIENGINE_VAR_COPYRIGHT_ENGINE_2,   aIEngine_Copyright_2       },         //
  { AIENGINE_VAR_COPYRIGHT_PAGES_TXT,  aIEngine_Copyright_txt     }          //
};                                                                           //
unsigned int aie_size_static_asecur_variables =                              //
                                   sizeof(aie_static_asecur_variables) /     //
                                   sizeof(struct aie_static_variables);      //
                                                                             //
/*****************************************************************************/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
const char *aie_do_var_variable(const char *inp, ...)
{
   #if !AIENGINE_LOG_NO_LOG
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_do_var_variable Name[%s]" },
      { AIE_LOG_ERROR, "Overflow Size: %d Max: %d" },
      { AIE_LOG_ERROR, "Out of Memory?" },
      { AIE_LOG_ERROR, "Variable == NULL Ptr" }
   };
   #endif
   const char *rc_ptr = NULL;

   #if AIENGINE_LOG_TRACE_VARIABLES
   aie_sys_log(0, inp);
   #endif
   if (__builtin_expect((inp != NULL), true))
   {
      #ifdef AIE_TEST_MEMORY
      char *output = (char *)_aie_malloc(VAR_DYN_MEMORY_SIZE,
	                                                   __FILE__, __LINE__);
      #else
      char *output = (char *)malloc(VAR_DYN_MEMORY_SIZE);
      #endif
      if (__builtin_expect((output != NULL), true))
      {
         strncpy(output, inp, VAR_DYN_MEMORY_SIZE-1);
         if (__builtin_expect(
	       ((rc_ptr =
	         aie_do_variable_funktions(ASECUR_ALL_VARIABLES, inp)) != NULL),
	                                                                 true))
         {
            va_list argptr;
            unsigned int cnt;
            char *work_ptr;

            va_start(argptr, inp);
            if (__builtin_expect(((cnt =
            vsnprintf(output, VAR_DYN_MEMORY_SIZE, rc_ptr, argptr)) >
		                                   VAR_DYN_MEMORY_SIZE),false))
			   {
                #if !AIENGINE_LOG_NO_LOG
                // Overflow Size: %d Max: %d",
               aie_sys_log(1, cnt, VAR_DYN_MEMORY_SIZE);
                #endif
            }
            va_end(argptr);
            if (__builtin_expect(
		                   ((work_ptr = aie_CharDynMemory(cnt + 1)) != NULL),
	                                                                 true))
            {
	            memcpy(work_ptr, output,
	            cnt > VAR_DYN_MEMORY_SIZE ? VAR_DYN_MEMORY_SIZE : cnt);
               *(work_ptr + cnt) = '\0';
               #ifdef AIE_TEST_MEMORY
                  aie_free(output);
               #else
                  free(output);
               #endif
	            rc_ptr = work_ptr;
            }
            else
            {
	            rc_ptr = output;
            }
         }
         else
         {
            rc_ptr = output;
         }
      }
      else
      {
         #if !AIENGINE_LOG_NO_LOG
         aie_sys_log(2, NULL);
         #endif
      }
   }
   else
   {
      #if !AIENGINE_LOG_NO_LOG
      // AIE_LOG_ERROR, "Variable == NULL Ptr"
      aie_sys_log(3, NULL);
      #endif
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
const char *aie_do_variable_funktions(int typ, const char *inp)
{
   static char output[AIE_VARIABLE_MAX_EXPANDED_LEN + 1];
   time_t t;
   const char *rc_ptr = inp;
   if (__builtin_expect((strchr(inp, '$') != NULL),true))
   {
      t = time(NULL);
      strncpy(output, inp, sizeof(output)-1);
      *(output + sizeof(output)-1) = '\0';
      replace_variables(typ, output, &t);
      rc_ptr = output;
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
static void replace_variables(int typ, char *inp, time_t *t)
{
   char *sptr = inp;
   if (__builtin_expect((*sptr != '$'),false))
   {
     sptr = strchr(inp, '$');
   }
   if (__builtin_expect(((sptr != NULL) && (*sptr != '\0')),true))
   {
      if (__builtin_expect((*(sptr+1) == '('),true))
      {
         char *sptr2 = strchr(sptr, ')');
         if (__builtin_expect(((sptr2 != NULL) && (*(sptr2+1)==';')),true))
         {
            char *variable = (char *)aie_malloc((unsigned)((sptr2 - sptr) + 3));
            //if ((sptr2 - sptr) < sizeof(variable))
            {
               char *var_result;
               char *var_result_buf = (char *)aie_malloc(VAR_RESULT_BUF_LEN + 1);
               strncpy(variable, sptr, (unsigned)(sptr2 - sptr)+2);
               *(variable + (sptr2 - sptr) + 2) = '\0';
               //do_log("VarFkt", "Found Variable [%s] ", variable);
               if (__builtin_expect(((var_result =
                        get_variable_content(typ, variable, var_result_buf,
                                                            VAR_RESULT_BUF_LEN,
                                                            t)) != NULL),true))
               {
                  char *right = aie_strdup(sptr2 + 2);
                  //do_log("VarFkt", "Resulte [%s] ", var_result);
                  //do_log("VarFkt", "Right [%s] ", right);
                  strcpy(sptr, var_result);
                  strcat(sptr, right);
                  aie_free(right);
                  sptr2 = sptr;
               }
               aie_free(var_result_buf);
               if (__builtin_expect(
			((sptr = strchr(sptr2, '$')) != NULL),false))
               {
                  replace_variables(typ, sptr, t);
               }
            } 
            aie_free(variable);
         }
     }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
static char *get_variable_content(int typ, char *variable,
                                  char *buf, unsigned int max_len, time_t *t)
{
   char *rc_ptr = NULL;
   struct aie_variable_heap *heap_ptr;

   *buf = '\0';

   if (__builtin_expect(
	    ((heap_ptr = aie_GetAsecurVariable(typ, variable)) != NULL),true))
   {
      if (__builtin_expect((heap_ptr->fkt != NULL),false))
      {
          strncpy(buf, variable, max_len);
          *(buf+max_len) = '\0';
          heap_ptr->fkt(t, buf);
          rc_ptr = buf;
      }
      if (__builtin_expect((heap_ptr->val != NULL),true))
      {
          rc_ptr = strncpy(buf, heap_ptr->val, max_len);
          *(buf+max_len) = '\0';
      }
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_variable_fkt_timeoffset(time_t *t, char *buf)
{
    long offset;
    char *sptr;
    if (__builtin_expect(((sptr = strchr(buf + 3,')')) != NULL),true))
    {
       *sptr = '\0';
       offset = atol(buf + 3);
       *t += offset;
       *buf = '\0';
    }
    return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_variable_fkt_day(time_t *t, char *buf)
{
   struct tm *tm;
   tm = localtime(t);
   sprintf(buf, "%.2d", tm->tm_mday);
    return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_variable_fkt_month(time_t *t, char *buf)
{
   struct tm *tm;
   tm = localtime(t);
   sprintf(buf, "%.2d", tm->tm_mon + 1);
    return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_variable_fkt_year(time_t *t, char *buf)
{
   struct tm *tm;
   tm = localtime(t);
   sprintf(buf, "%.4d", tm->tm_year + 1900);
    return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_variable_fkt_ascdate(time_t *t, char *buf)
{
    char *sptr;
    strcpy(buf, asctime(localtime(t)));
    if (__builtin_expect(((sptr = strchr(buf, '\n')) != NULL),true))
	{
       *sptr = '\0';
    }
    return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_SetAsecurVariable(int typ, const char *var, unsigned int test_len, 
                       const char *val,
                       char *(*fkt)(time_t *t, char *buf))
{
   struct aie_variable_heap *heap_ptr;
   if (((val != NULL) || (fkt != NULL)) && (var != NULL))
   {
      heap_ptr = (struct aie_variable_heap *)
						   aie_malloc(sizeof(struct aie_variable_heap));
      if (__builtin_expect((aie_variable_heap_base == NULL),false))
      {
         heap_ptr->next = NULL;
      }
      else
      {
         heap_ptr->next = aie_variable_heap_base;
      }
      heap_ptr->var = var;
	  heap_ptr->val = val;
      heap_ptr->typ = typ;
      heap_ptr->test_len = test_len;
      heap_ptr->fkt = fkt;
      aie_variable_heap_base = heap_ptr;
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : struct asecur_variable_heap *                             */
/*...........................................................................*/
struct aie_variable_heap *aie_GetAsecurVariable(int typ, const char *var)
{
   struct aie_variable_heap *heap_ptr = aie_variable_heap_base;
   struct aie_variable_heap *rc_ptr = NULL;
   while (heap_ptr != NULL)
   {
	  if  (__builtin_expect(
	   ((((typ == ASECUR_ALL_VARIABLES) || (typ == heap_ptr->typ)) &&
            (strcmp(heap_ptr->var, var) == 0)) ||
              ((heap_ptr->test_len != 0) &&
               (strncmp(heap_ptr->var, var, heap_ptr->test_len) == 0))),false))
      {
         rc_ptr = heap_ptr;
         break;
      }
      else
	  {
         heap_ptr = heap_ptr->next;
      }
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : GetStandardAsecurVariableValue                            */
/* Parameter     : char * - Name der Variable                                */
/* Rueckgabewert : char * - Pointer auf den Inhalt der Variable              */
/*                 NULL   - Falls die Variable nicht gefunden wurde          */
/*...........................................................................*/
const char *aie_GetStandardAsecurVariableValue(const char *var)
{
   #if !AIENGINE_LOG_NO_LOG
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_GetStandardAsecurVariableValue Name[%s]" },
      { AIE_LOG_TRACE_FKT, "GetStandardAsecurVariableValue [%s]=[%s]" },
	  { AIE_LOG_ERROR, "Variable [%s] nicht gesetzt!" }
   };
   #endif
   struct aie_variable_heap *heap_ptr;
   const char *rc_ptr = NULL;

   #if AIENGINE_LOG_TRACE_VARIABLES
   aie_sys_log(0, var);
   #endif
   if (__builtin_expect(
	    ((heap_ptr =
		  aie_GetAsecurVariable(ASECUR_ALL_VARIABLES, var)) != NULL),true))
   {
	  rc_ptr = heap_ptr->val;
      #if AIENGINE_LOG_TRACE_VARIABLES
      aie_sys_log(1, var, rc_ptr);
      #endif
   }
   else
   {
      #if !AIENGINE_LOG_NO_LOG
      // Variable [%s] nicht gesetzt!
	   aie_sys_log(2, var);
      #endif
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_FreeGetAsecurVariableHeap(int typ)
{
   struct aie_variable_heap *heap_ptr;
   if (__builtin_expect((typ == ASECUR_ALL_VARIABLES),true))
   {
      while ((heap_ptr = aie_variable_heap_base) != NULL)
      {
         aie_variable_heap_base = aie_variable_heap_base->next;
         aie_free(heap_ptr);
      }
   }
   else
   {
      struct aie_variable_heap *prev_heap_ptr = NULL;
      heap_ptr = aie_variable_heap_base;
      while (heap_ptr != NULL)
      {
         if (__builtin_expect((heap_ptr->typ == typ),false))
         {
            if (__builtin_expect(
		     (heap_ptr == aie_variable_heap_base),false))
			{
               aie_variable_heap_base = heap_ptr->next;
               aie_free(heap_ptr);
               prev_heap_ptr = NULL;
               heap_ptr = aie_variable_heap_base;
            }
            else
            {
               prev_heap_ptr->next = heap_ptr->next;
               aie_free(heap_ptr);
			   heap_ptr = prev_heap_ptr->next;
            }
         }
         else
         {
            prev_heap_ptr = heap_ptr;
            heap_ptr = heap_ptr->next;
         }
         aie_variable_heap_base = aie_variable_heap_base->next;
         aie_free(heap_ptr);
	  }
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_SetAsecurGlobalVariables(void)
{
   aie_SetAsecurVariablesFromStruct(ASECUR_GLOBAL_VARIABLEN,
                                aie_global_asecur_variables,
                                aie_size_global_asecur_variables);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_FreeAsecurAllVariables(void)
{
   aie_FreeGetAsecurVariableHeap(ASECUR_GLOBAL_VARIABLEN);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : SetAsecurStaticVariables                                  */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_SetAsecurStaticVariables(void)
{
   aie_SetStaticAsecurVariablesFromStruct(aie_static_asecur_variables,
                                        aie_size_static_asecur_variables);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : SetStaticASecurVariablesFromStruct                        */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
//#if __GNUC__
#if 0
void aie_SetStaticAsecurVariablesFromStruct(unsigned int size;
											const struct aie_static_variables
															 variables[size],
							unsigned int size)
#else
void aie_SetStaticAsecurVariablesFromStruct(const struct aie_static_variables
															 variables[],
							unsigned int size)
#endif
{
   register unsigned int z = 0;
   for (; z < size; z++)
   {
      const char *val = variables[z].val;
      const char *var = variables[z].var;
      aie_SetAsecurVariable(ASECUR_GLOBAL_VARIABLEN,
                            var,
                            0,
                            val,
                            NULL);
#if 0
      aie_SetAsecurVariable(ASECUR_GLOBAL_VARIABLEN,
                            variables->var,
                            0,
                            variables->val,
                            NULL);
#endif
      //variables++;
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
//#ifdef __GNUC__
#if 0
void aie_SetAsecurVariablesFromStruct(unsigned int size;
									  int typ,
									  struct aie_variables variables[size],
					  unsigned int size)
#else
void aie_SetAsecurVariablesFromStruct(int typ,
									  struct aie_variables variables[],
					  unsigned int size)
#endif
{
   register unsigned int z = 0;
   for (; z < size; z++)
   {
      aie_SetAsecurVariable(typ,
                        variables[z].var,
                        variables[z].len,
                        variables[z].val ? *variables[z].val : NULL,
                        variables[z].fkt);
      //variables++;
   }
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : Init_aIEngine_cgi_variablen                               */
/* Parameter     : struct aIEngine_cgi_globale_variablen cgi_variablen[]     */
/*                 int size                                                  */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_Init_aIEngine_cgi_variablen(struct aie_aIEngine_cgi_globale_variablen 
                                                               *cgi_variablen, 
				 unsigned int size)
{
   #if !AIENGINE_LOG_NO_LOG
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_Init_aIEngine_cgi_variablen size[%d]" },
      { AIE_LOG_WARN,  "Variable ist NULL?!" },
      { AIE_LOG_WARN,  "Variable [%s] Value[%s] NICHT in struktur" },
      { AIE_LOG_TRACE, "aie_Init_aIEngine_cgi_variablen .. ok" }
   };
   #endif
   register unsigned int i = 0;

   #if AIENGINE_LOG_TRACE_VARIABLES
   aie_sys_log(0, size);
   #endif
   for (; i < size; i++)
   {
      bool found = false;
      register unsigned int z = 0;
      for (; z < aie_size_global_asecur_variables; z++)
      {
         if ((cgi_variablen == NULL) || (cgi_variablen->var == NULL))
	 {
	    // Variable ist NULL?!
            aie_sys_log(1, NULL);
	 }
         if (__builtin_expect(
		  (strcmp(cgi_variablen->var, 
			  aie_global_asecur_variables[z].var) == 0),false))
         {
            if (__builtin_expect(
		     (*aie_global_asecur_variables[z].val != NULL),true))
            {
               aie_free(*aie_global_asecur_variables[z].val);
            }
            if (__builtin_expect((cgi_variablen->val != NULL),true))
            {
               *aie_global_asecur_variables[z].val =
		                             aie_strdup(cgi_variablen->val);
            }
            else
            {
               *aie_global_asecur_variables[z].val = NULL;
            }
	    found = true;
            break;
         }
      }
      if (!found)
      {
         #if !AIENGINE_LOG_NO_LOG
	 // Variable [%s] Value[%s] NICHT in struktur
         aie_sys_log(2, cgi_variablen->var, cgi_variablen->val);
         #endif
      }
      cgi_variablen++;
   }
   #if AIENGINE_LOG_TRACE_VARIABLES
   // finished Init_cgi_variables
   aie_sys_log(3, NULL);
   #endif
   return(true);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : Free_aIEngine_cgi_variablen                               */
/* Parameter     : ohne                                                      */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_Free_aIEngine_cgi_variablen(void)
{
   #if !AIENGINE_LOG_NO_LOG
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_Free_aIEngine_cgi_variablen" },
      { AIE_LOG_INFO,  "Globale Variable [%s] Value[%s]" },
      { AIE_LOG_WARN,  "Globale Variable [%s] war leer!" },
      { AIE_LOG_ERROR, "Globale Variable [%s] nicht gesetzt!" }
   };
   #endif
   register unsigned int z = 0;

   #if AIENGINE_LOG_TRACE_VARIABLES
   aie_sys_log(0, NULL);
   #endif
   for (; z < aie_size_global_asecur_variables; z++)
   {
      if (__builtin_expect((aie_global_asecur_variables[z].val != NULL),true))
      {
         if (__builtin_expect((*aie_global_asecur_variables[z].val != (char)'\0'),
																 true))
         {
            #if AIENGINE_LOG_TRACE_VARIABLES
            // Globale Variable [%s] Value[%s]!
            aie_sys_log(1, aie_global_asecur_variables[z].var,
		           *aie_global_asecur_variables[z].val);
            #endif
            aie_free(*aie_global_asecur_variables[z].val);
         }
	 else
	 {
       #if !AIENGINE_LOG_NO_LOG
	    // Globale Variable [%s] war leer!
		 aie_sys_log(2, aie_global_asecur_variables[z].var);
       #endif
	 }
      }
      else
      {
	 if (__builtin_expect((aie_global_asecur_variables[z].fkt == NULL),
		                                                        false))
	 {
       #if !AIENGINE_LOG_NO_LOG
	    // Globale Variable [%s] nicht gesetzt!",
		 aie_sys_log(3, aie_global_asecur_variables[z].var);
       #endif
	 }
      }
   }
}
/*---------------------------------------------------------------------------*/

void aie_LogAsecurVariables(char *logfile)
{
   struct aie_variable_heap *heap_ptr = aie_variable_heap_base;
   while (heap_ptr != NULL)
   {
      aie_do_log(logfile, "%s(%d): Variable[%s] Value[%s] ", __FILE__,
	                                                     __LINE__,
	                                                     heap_ptr->var, 
							     heap_ptr->val);
      aie_do_log(logfile, "%s(%d): Variable[%s] Wert [%s] ", __FILE__, 
	                                                     __LINE__, 
	                                                     heap_ptr->var,
                                  aie_do_variable_funktions(0, heap_ptr->var));
      heap_ptr = heap_ptr->next;
   }
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_variables_size            = __LINE__;                            //
/* -------------------------------- EOF ------------------------------------ */

