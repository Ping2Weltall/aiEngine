/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_memutil.c                                               */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.06.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : const char * als const * deklarieren        */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aiemem_version         = "1.0.0";                          //
const char *modul_aiemem                 = "AieMem";                         //
const char *modul_aiemem_date            = __DATE__;                         //
const char *modul_aiemem_time            = __TIME__;                         //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_LOG_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
#undef aie_strdup
#undef aie_malloc
#undef aie_free
#undef aie_test_mem_ok
#undef aie_do_test_mem_ok
#undef aie_mem_dump
#undef aie_mem_usage
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
#ifdef AIE_TEST_MEMORY
static struct aie_memory_heap *_aie_get_mem_record(void *ptr,                //
                                                   const char *file,         //
						   unsigned int line);          //
#endif
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
#ifdef AIE_TEST_MEMORY
static struct aie_memory_heap *aie_memory_heap_base = NULL;                  //
static char aie_memory_start[] = "!@~~#";                                    //
static char aie_memory_end[]   = "#~~@!";                                    //
#endif
static int aie_akt_mem_usage = 0;                                            //
static int aie_max_mem_usage = 0;                                            //
                                                                             //
/*****************************************************************************/

//-----------------------------------------------------------------------------
// Die folgenden Routinen nur einbinden wen AIE_TEST_MEMORY vorgegeben wurde
// am besten im make_flags (!)
//-----------------------------------------------------------------------------
#ifdef AIE_TEST_MEMORY

char *_aie_strdup(const char *s, const char *file, unsigned int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "_aie_strdup %s(%d)" },         
      { AIE_LOG_ERROR, "Strdup NULL PTR @ %s(%d)" }
   };
   char *rc_ptr = NULL;
#if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, file, line);
#endif
   if (__builtin_expect((s != NULL),true))
   {
      unsigned int len = strlen(s);

      if (__builtin_expect(
	       ((rc_ptr = 
		 (char *)_aie_malloc(len + 1, file, line)) != NULL),true))
      {
         memcpy(rc_ptr, s, len);
         *(rc_ptr + len) = '\0';
      }
   }
   else
   {
      // Strdup NULL PTR @ %s(%d)
      aie_sys_log(1, file, line);
   }
   return(rc_ptr);
}
//-----------------------------------------------------------------------------

void *_aie_realloc(void *ptr, unsigned int size, const char *file, 
                                                             unsigned int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "_aie_realloc size %d @ %s(%d)" },         
      { AIE_LOG_INFO,  "Size %d old size %d using: %d" },
      { AIE_LOG_ERROR, "Unbekannter Memory Pointer @ %s(%d)" }
   };
   void *rc_ptr = _aie_malloc(size, file, line);
#if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, size, file, line);
#endif
   if (ptr != NULL)
   {
      if (__builtin_expect((rc_ptr != NULL),true))
      {
         struct aie_memory_heap *aie_memory_heap_ptr = 
	                                  _aie_get_mem_record(ptr, file, line);
         if (__builtin_expect((aie_memory_heap_ptr != NULL),true))
         {
	    unsigned int old_size = aie_memory_heap_ptr->size;
            memcpy(rc_ptr, ptr, size > old_size ? old_size : size);
            // Size %d old size %d using: %d
            aie_sys_log(1, size, old_size, size > old_size ? old_size : size);
            _aie_free(ptr, file, line);
         }
         else
         {
	    // Unbekannter Memory Pointer @ %s(%d)
            aie_sys_log(2, file, line);
	    _aie_free(rc_ptr, __FILE__, __LINE__);
            rc_ptr = NULL;
         }
      }
   }
   return(rc_ptr);
}
//-----------------------------------------------------------------------------

void *_aie_malloc(unsigned int size, const char *file, unsigned int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "_aie_malloc @ %s(%d)" },         
      { AIE_LOG_ERROR, "Out of Memory?! @ %s(%d)" },
      { AIE_LOG_ERROR, "No Memory - @ %s(%d) Size[%d]?!" }
   };
   void *rc_ptr = NULL;
   struct aie_memory_heap *aie_memory_heap_ptr = NULL;
#if 0
   static bool detect_recursion = false;
   if (detect_recursion == true)
   {
      printf("Recursion %s(%d) From %s Line: %d Size[%d]\n", __FILE__, __LINE__, 
                                                    file, line, size);
   } 
   detect_recursion = true;
#endif
#if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, file, line);
#endif
   if (__builtin_expect(((size != 0) &&
       (aie_memory_heap_ptr = (struct aie_memory_heap *)
	                malloc(sizeof(struct aie_memory_heap))) != NULL),true))
   {
      register unsigned int real_size = 
	              size + sizeof(aie_memory_start) + sizeof(aie_memory_end);
      //aie_memory_heap_ptr->file = strdup(file);
      if ((aie_memory_heap_ptr->file = 
	                             (char *)malloc(strlen(file) + 1)) != NULL)
      {
         strcpy(aie_memory_heap_ptr->file, file);
      }
      aie_memory_heap_ptr->line = line;
      aie_memory_heap_ptr->size = size;
      aie_memory_heap_ptr->prev = NULL;
      if (__builtin_expect(
	       ((aie_memory_heap_ptr->next = aie_memory_heap_base) 
		                                          != NULL),true))
      {
         aie_memory_heap_base->prev = aie_memory_heap_ptr;
      }
      if (__builtin_expect(
	       ((aie_memory_heap_ptr->ptr = 
		 (void *)malloc(real_size)) == NULL),false))
      {
         // Out of Memory?! @ %s(%d)
         aie_sys_log(1, file, line);
      }
      else
      {
         memcpy(aie_memory_heap_ptr->ptr, aie_memory_start, 
	                                             sizeof(aie_memory_start));
         memcpy((char *)aie_memory_heap_ptr->ptr +
               (real_size - sizeof(aie_memory_end)), aie_memory_end, 
	                                             sizeof(aie_memory_end));
         *(char *)(rc_ptr = (char *)aie_memory_heap_ptr->ptr + 
	                                      sizeof(aie_memory_start)) = '\0';
      }
      aie_memory_heap_base = aie_memory_heap_ptr;
      if ((aie_akt_mem_usage += size) > aie_max_mem_usage)
      {
         aie_max_mem_usage = aie_akt_mem_usage;
      }
   }
   else
   {
      // No Memory - @ %s(%d) Size[%d]?!
      aie_sys_log(2, file, line, size);
   }
#if 0
   detect_recursion = false;
#endif
   return(rc_ptr);
}
//-----------------------------------------------------------------------------

static struct aie_memory_heap *_aie_get_mem_record(void *ptr, const char *file,
                                                   unsigned int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "_aie_get_mem_record %s(%d)" },         
      { AIE_LOG_ERROR, "Memory Empty! @ %s(%d)" },
   };
   struct aie_memory_heap *aie_memory_heap_ptr;
   struct aie_memory_heap *rc_ptr = NULL;
   void *work_ptr = (char *)ptr - sizeof(aie_memory_start);
   
#if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, file, line);
#endif

   if (__builtin_expect(
	    ((aie_memory_heap_ptr = aie_memory_heap_base) == NULL),false))
   {
      // Memory Empty! @ %s(%d)
      aie_sys_log(1, file, line);
   }
   else
   {
      while(aie_memory_heap_ptr != NULL)
      {
         if (aie_memory_heap_ptr->ptr == work_ptr)
         {
	    rc_ptr = aie_memory_heap_ptr;
	    break;
         }
         aie_memory_heap_ptr = aie_memory_heap_ptr->next;
      }
   }
   return(rc_ptr);
}
//-----------------------------------------------------------------------------
bool _aie_do_test_mem_ok(void *ptr, const char *file, unsigned int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_do_text_mem_ok @ %s(%d)" },         
      { AIE_LOG_ERROR, "Memory Empty! @ %s(%d)" }
   };
   struct aie_memory_heap *aie_memory_heap_ptr;
   bool rc = false;
#if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, file, line);
#endif
   if (__builtin_expect((ptr != NULL),true))
   {
      if (__builtin_expect(
	       ((aie_memory_heap_ptr = aie_memory_heap_base) == NULL),false))
      {
         // Memory Empty! @ %s(%d)
         aie_sys_log(1, file, line);
      }
      else
      {
         void *work_ptr = (char *)ptr - sizeof(aie_memory_start);
         while(aie_memory_heap_ptr != NULL)
         {
            if (aie_memory_heap_ptr->ptr == work_ptr)
            {
               rc = _aie_test_mem_ok(aie_memory_heap_ptr, file, line);
	       break;
	    }
	    aie_memory_heap_ptr = aie_memory_heap_ptr->next;
	 }
      }
   }
   return(rc);
}

void _aie_free(void *ptr, const char *file, unsigned int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_free %s(%d)" },         
      { AIE_LOG_ERROR, "Memory Empty! @ %s(%d)" },
      { AIE_LOG_ERROR, "Unbekannter Speicher! @ %s(%d)" },
      { AIE_LOG_ERROR, "NULL PTR dealocation @ %s(%d)" }
   };
   struct aie_memory_heap *aie_memory_heap_ptr;

   #if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, file, line);
   #endif
   if (__builtin_expect((ptr != NULL),true))
   {
      if (__builtin_expect(
	       ((aie_memory_heap_ptr = aie_memory_heap_base) == NULL),false))
      {
         // Memory Empty! @ %s(%d)
         aie_sys_log(1, file, line);
      }
      else
      {
         bool found = false;
         void *work_ptr = (char *)ptr - sizeof(aie_memory_start);
         while(aie_memory_heap_ptr != NULL)
         {
            if (aie_memory_heap_ptr->ptr == work_ptr)
            {
               found = true;
               _aie_test_mem_ok(aie_memory_heap_ptr, file, line);
               free(aie_memory_heap_ptr->ptr);
               if (__builtin_expect(
			(aie_memory_heap_ptr->file != NULL),true))
               {
                  free(aie_memory_heap_ptr->file);
               }
               if (aie_memory_heap_ptr == aie_memory_heap_base)
               {
                  if (__builtin_expect(
			   ((aie_memory_heap_base =
			     aie_memory_heap_ptr->next) != NULL),true))
                  {
                     aie_memory_heap_base->prev = NULL;
                  }
               }
               else
               {
                  if (__builtin_expect(
			   (aie_memory_heap_ptr->next != NULL),true))
                  {
                     aie_memory_heap_ptr->next->prev = 
			                           aie_memory_heap_ptr->prev;
                  }
                  if (aie_memory_heap_ptr->prev != NULL)
                  {
                     aie_memory_heap_ptr->prev->next = 
			                           aie_memory_heap_ptr->next;
                  }
               }
               aie_akt_mem_usage -= aie_memory_heap_ptr->size;
               free(aie_memory_heap_ptr);
               break;
            }
            aie_memory_heap_ptr = aie_memory_heap_ptr->next;
         }
         if (__builtin_expect((!found),false))
         {
            // Unbekannter Speicher! @ %s(%d)
            aie_sys_log(2, file, line);
            //sys_log("%s(%d): Unbekannter Speicher! @ %s(%d)[%s]", __FILE__, 
	    //	                                         __LINE__, file, line,
	    //						 (char *)ptr);
         }
      }
   }
   else
   {
      // NULL PTR dealocation @ %s(%d)
      aie_sys_log(3, file, line);
   }
}
//-----------------------------------------------------------------------------

bool _aie_test_mem_ok(struct aie_memory_heap *aie_memory_heap_ptr, 
                      const char *file, unsigned int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_test_memory_ok %s(%d)" },
      { AIE_LOG_ERROR, "%s(%d): Memory fault %s - Allocated @ %s(%d)" },
   };
   bool rc = true;

#if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, file, line);
#endif
   if (__builtin_expect(
	    (strncmp((char *)aie_memory_heap_ptr->ptr, aie_memory_start, 
	                                    sizeof(aie_memory_start))),false))
   {
      // Memory fault %s - Allocated @ %s(%d)
      aie_sys_log(1, file, line, "Pre", aie_memory_heap_ptr->file, 
	                                        aie_memory_heap_ptr->line);
      rc = false;
   }
   if (__builtin_expect(
	(strncmp((char *)aie_memory_heap_ptr->ptr + aie_memory_heap_ptr->size + 
	                                          sizeof(aie_memory_start),
                          aie_memory_end, sizeof(aie_memory_end))),false))
   {
      // Memory fault %s - Allocated @ %s(%d)
      aie_sys_log(1, file, line, "Post", aie_memory_heap_ptr->file, 
	                                            aie_memory_heap_ptr->line);
   }
   return(rc);
}
//-----------------------------------------------------------------------------
#endif

#ifdef AIE_TEST_MEMORY
bool _aie_mem_dump(const char *file, unsigned int line)
{
   #if !AIENGINE_LOG_NO_LOG
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_mem_dump %s(%d)" },
      { AIE_LOG_ERROR, "Memory Usage %s(%d)" },
      { AIE_LOG_ERROR, "%d Bytes @ %s(%d) Wert[%s]" },
      { AIE_LOG_ERROR, "Allocation %s(%d): Memory leak!" }
   };
   #endif
   bool rc = false;
   struct aie_memory_heap *aie_memory_heap_ptr;

   #if AIENGINE_LOG_TRACE_MEMORY
   #if !AIENGINE_LOG_NO_LOG
   aie_sys_log(0, file, line);
   #endif
   #endif
   if (__builtin_expect(
	    ((aie_memory_heap_ptr = aie_memory_heap_base) != NULL),false))
   {
      rc = true;
      #if !AIENGINE_LOG_NO_LOG
      // Memory Usage %s(%d)
      aie_sys_log(1, file, line);
      #endif
      while(aie_memory_heap_ptr != NULL)
      {
         #if !AIENGINE_LOG_NO_LOG
         //  %d Bytes @ %s(%d) Wert[%s]
         aie_sys_log(2, aie_memory_heap_ptr->size,
                        aie_memory_heap_ptr->file,
                        aie_memory_heap_ptr->line,
	         ((char*)aie_memory_heap_ptr->ptr + sizeof(aie_memory_start)));
         #endif
         aie_memory_heap_ptr = aie_memory_heap_ptr->next;
      }
      #if !AIENGINE_LOG_NO_LOG
      // Allocation %s(%d): Memory leak!
      aie_sys_log(3, file, line);
      #endif
      _aie_mem_usage(file, line);
   }
   return(rc);
}
#endif
//-----------------------------------------------------------------------------

void _aie_mem_usage(const char *file, unsigned int line)
{
   #if !AIENGINE_LOG_NO_LOG
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_mem_usage %s(%d)" },
      { AIE_LOG_ERROR, "Memory @ %s-%d: Akt: %2d Max: %8d" },
   };
   #if AIENGINE_LOG_TRACE_MEMORY
   aie_sys_log(0, file, line);
   #endif

   // Memory @ %s-%d: Akt: %2d Max: %8d",
   aie_sys_log(1, file, line, aie_akt_mem_usage, aie_max_mem_usage);
   #else
   file = file;
   line = line;
   #endif
}
//-----------------------------------------------------------------------------


/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_aiemem_size            = __LINE__;                               //
/* -------------------------------- EOF ------------------------------------ */
