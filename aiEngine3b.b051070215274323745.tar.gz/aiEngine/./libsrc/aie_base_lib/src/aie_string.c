/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_string.c                                                */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 25.10.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_string_version = "1.0.0";                                  //
const char *modul_string         = "String";                                 //
const char *modul_string_date    = __DATE__;                                 //
const char *modul_string_time    = __TIME__;                                 //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define TOLOWER(c) _sch_tolower[(c) & 0xff]                                  //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *aie_is_hex;                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static unsigned char _sch_tolower[256] =
{
   0,  1,  2,  3,   4,  5,  6,  7,   8,  9, 10, 11,  12, 13, 14, 15,
  16, 17, 18, 19,  20, 21, 22, 23,  24, 25, 26, 27,  28, 29, 30, 31,
  32, 33, 34, 35,  36, 37, 38, 39,  40, 41, 42, 43,  44, 45, 46, 47,
  48, 49, 50, 51,  52, 53, 54, 55,  56, 57, 58, 59,  60, 61, 62, 63,
  64,

  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
  'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',

  91, 92, 93, 94, 95, 96,

  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
  'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',

 123,124,125,126,127,

 128,129,130,131, 132,133,134,135, 136,137,138,139, 140,141,142,143,
 144,145,146,147, 148,149,150,151, 152,153,154,155, 156,157,158,159,
 160,161,162,163, 164,165,166,167, 168,169,170,171, 172,173,174,175,
 176,177,178,179, 180,181,182,183, 184,185,186,187, 188,189,190,191,

 192,193,194,195, 196,197,198,199, 200,201,202,203, 204,205,206,207,
 208,209,210,211, 212,213,214,215, 216,217,218,219, 220,221,222,223,
 224,225,226,227, 228,229,230,231, 232,233,234,235, 236,237,238,239,
 240,241,242,243, 244,245,246,247, 248,249,250,251, 252,253,254,255,
};
/*****************************************************************************/

const char *aie_booltostr(bool a)
{
   if (a)
   {
      return("true");
   }
   return("false");
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : int                                                       */
/*...........................................................................*/
int aie_hextoint(const char *hex)
{
    int low = 0;
    int high = 0;
    unsigned int z;
    for (z = 0;z < strlen(aie_is_hex);z++)
    {
       if (__builtin_expect((*(aie_is_hex + z) == *hex),false))
       {
          high = z;
       }
       if (__builtin_expect((*(aie_is_hex + z) == *(hex + 1)),false))
       {
          low = z;
       }
    }
    return(low + (high * 16));
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_StrUpperCase(char *s)
{
   char *sptr;

   if ((sptr = s) != NULL)
   {
      while(*sptr != '\0')
      {
         if (__builtin_expect(
		  ((*sptr >= 'a') && (*sptr <= 'z')),true))
         {
            *sptr -= (char)32; // (char)('a' - 'A');
         }
         sptr++;
      }
   }
   return(s);
}

/*---------------------------------------------------------------------------*/
char *aie_StrLowerCase(char *s)
{
   char *sptr;
   if (__builtin_expect(((sptr = s) != NULL),true))
   {
      while (*sptr != '\0')
      {
         *sptr = TOLOWER(*sptr);
         sptr++;
      }
   }
   return(s);
}
/*---------------------------------------------------------------------------*/

int aie_StringNoCaseCompare(const char *s1, const char *s2) 
{
   const char *s1p, *s2p;

   if(s1 == NULL && s2 == NULL) return (0);
   if((s1p = s1) == NULL) return (*s2 * -1);
   if((s2p = s2) == NULL) return (*s1);
   while ((*s1p != '\0') && (*s2p != '\0') && (TOLOWER(*s1p) == TOLOWER(*s2p)))
   {
      s1p++;
      s2p++;
   }
   return(*s1p - *s2p);
}

int aie_StringNoCaseLenCompare(const char *s1, const char *s2, unsigned int len) 
{
   const char *s1p, *s2p;
   register unsigned int z = 0;

   if(s1 == NULL && s2 == NULL) return (0);
   if((s1p = s1) == NULL) return (*s2 * -1);
   if((s2p = s2) == NULL) return (*s1);
   while ((*s1p != '\0') && (*s2p != '\0') && 
	 (TOLOWER(*s1p) == TOLOWER(*s2p)) && (z <= len))
   {
      s1p++;
      s2p++;
      z++;
   }
   return(*s1p - *s2p);
}

char *aie_RemoveSpace(char *str) 
{
   if (str)
   {
      register unsigned int j;
      register int i;
      for(j = 0; str[j] == ' ' || str[j] == 9 || 
	                               str[j] == '\r' || str[j] == '\n'; j++);
      for(i = 0; str[j] != '\0'; i++, j++) 
      {
         str[i] = str[j];
      }
      for(i--; (i >= 0) && 
	       (str[i] == ' ' || str[i] == 9 || str[i] == '\r' || 
		                                        str[i] == '\n'); i--);
      str[i+1] = '\0';
   }
   return(str);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_string_size    = __LINE__;                                       //
/* -------------------------------- EOF ------------------------------------ */
