/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_txtutil.c                                               */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 01.05.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_txtutil_version    = "1.0.0";                              //
const char *modul_txtutil            = "TxtUtil";                            //
const char *modul_txtutil_date       = __DATE__;                             //
const char *modul_txtutil_time       = __TIME__;                             //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include <ctype.h>                                                           //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct s_umlaute                                                             //
{                                                                            //
   const char escape[9];                                                     //
   const char sort[4];                                                       //
   const char search[4];                                                     //
};                                                                           //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
//static const char *umlaute = "������ߔ����\0";                            //
static const char *umlaute = "�������\0";                            //
                                                                             //
#if 0
static const struct s_umlaute s_umlaute[] =                                  //
{                                                                            //
   { "&Auml;",  "Aze", "Ae" },                                               //
   { "&Ouml;",  "Oze", "Oe" },                                               //
   { "&Uuml;",  "Uze", "Ue" },                                               //
   { "&auml;",  "aze", "ae" },                                               //
   { "&ouml;",  "oze", "oe" },                                               //
   { "&uuml;",  "uze", "ue" },                                               //
   { "&szlig;", "szs", "ss" },                                               //
   { "&auml;",  "aze", "ae" },                                               //
   { "&ouml;",  "oze", "oe" },                                               //
   { "&uuml;",  "uze", "ue" },                                               //
   { "&auml;",  "aze", "ae" },                                               //
   { "&szlig;", "szs", "ss" },                                               //
   { "&#134;",  "uze", "Ue" }                                                //
};                                                                           //
#endif
static const struct s_umlaute s_umlaute[] =                                  //
{                                                                            //
   { "&Auml;",  "A", "Ae" },                                               //
   { "&Ouml;",  "O", "Oe" },                                               //
   { "&Uuml;",  "U", "Ue" },                                               //
   { "&auml;",  "a", "ae" },                                               //
   { "&ouml;",  "o", "oe" },                                               //
   { "&uuml;",  "u", "ue" },                                               //
   { "&szlig;", "s", "ss" },                                               //
   { "&auml;",  "a", "ae" },                                               //
   { "&ouml;",  "o", "oe" },                                               //
   { "&uuml;",  "u", "ue" },                                               //
   { "&auml;",  "a", "ae" },                                               //
   { "&szlig;", "s", "ss" },                                               //
   { "&#134;",  "U", "Ue" }                                                //
};                                                                           //
static const unsigned int s_umlaute_eot = 7;                                 //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_change_char_2_br(char *s, char c)
{
   char *sptr1 = s;
   register unsigned int z = 0;
   bool has_char = false;
   char *tmp = s;
   while(*sptr1 != '\0')
   {
      z++;
      if (*sptr1 == c)
      {
	 z += 4;
	 has_char = true;
      }
      sptr1++;
   }
   if ((has_char && (tmp = aie_CharDynMemory(z + 2)) != NULL))
   {
      char *sptr2 = tmp;
      sptr1 = s;
      while(*sptr1 != '\0')
      {
	 if (__builtin_expect((*sptr1 == c), false))
	 {
	    if ((sptr2 > tmp) && (*(sptr2 - 1) == ' '))
	    {
	       sptr2--;
	    }
	    strcpy(sptr2, "<BR>");
	    sptr2 += 4;
	    if (*(sptr1 + 1) == ' ')
	    {
	       sptr1++;
	    }
	 }
	 else
	 {
	    *sptr2 = *sptr1;
	    sptr2++;
	 }
         sptr1++;
      }
      *sptr2 = '\0';
   } 
   if (tmp == NULL)
   {
      tmp = s;
   }
   return(tmp);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_change_br_2_space(char *s)
{
   char *sptr1 = s;
   unsigned int len;
   while(*sptr1 != '\0')
   {
      if (__builtin_expect((*sptr1 == '<'),false))
      {
         if (__builtin_expect(((len = strlen(sptr1)) > 3),true))
         {
            if (__builtin_expect((*(sptr1 + 3) == '>'),true))
            {
               if (__builtin_expect(
			((*(sptr1 + 1) == 'b') || 
			 (*(sptr1 + 1) == 'B') ),true))
               {
                  if (__builtin_expect(
			   ((*(sptr1 + 2) == 'r') || 
			    (*(sptr1 + 2) == 'R') ),true))
                  {
                     *sptr1 = ' ';
                     sptr1++;
                     memmove(sptr1, sptr1 + 3, len - 3);
                  }
               }
            }
         }
      }
      sptr1++;
   }
   return(s);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Erstellt      : ALH / July 2003                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_change_br_2_slash(char *s)
{
   char *sptr1 = s;
   unsigned int len;
   while(*sptr1 != '\0')
   {
      if (__builtin_expect((*sptr1 == '<'),false))
      {
         if (__builtin_expect(((len = strlen(sptr1)) > 3),true))
         {
            if (__builtin_expect((*(sptr1 + 3) == '>'),true))
            {
               if (__builtin_expect(
			((*(sptr1 + 1) == 'b') || 
			 (*(sptr1 + 1) == 'B') ),true))
               {
                  if (__builtin_expect(
			   ((*(sptr1 + 2) == 'r') || 
			    (*(sptr1 + 2) == 'R') ),true))
                  {
                     memcpy(sptr1, " / ", 3);
                     memmove(sptr1 + 3, sptr1 + 4, len - 3);
                  }
               }
            }
         }
      }
      sptr1++;
   }
   return(s);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : only_digits                                               */
/* Parameter     :                                                           */
/* Erstellt      : ALH / April 2004                                          */
/* Rueckgabewert : bool (true = Parameter enthaelt nur Ziffern)              */
/*...........................................................................*/
bool aie_only_digits(char *word)
{
   bool rc = true;
   char *sptr = word;
   while(*sptr != '\0')
   {
      if (__builtin_expect((strchr("01234567890.-", *sptr) == NULL),false))
      {
	 rc = false;
	 break;
      }
      sptr++;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : CreateSuchWord                                            */
/* Parameter     :                                                           */
/* Erstellt      : ALH / May 2004                                            */
/* Rueckgabewert : char *                                                    */
/* Bemerkung     : Verbraucht Speicher auf Heap                              */
/*                 Der zurueckgegebene Wert muss explizit mit free wieder    */
/*                 freigegeben werden.                                       */
/*...........................................................................*/
char *aie_CreateSuchWord(const char *word)
{
   char *rc_ptr; // = NULL;
   char *esc_word;
   if (__builtin_expect(
	    ((esc_word = aie_EscapeSuchWord(word)) != NULL),true))
   {
      if (__builtin_expect(
	       ((rc_ptr = aie_FixSuchWord(esc_word)) == NULL),false))
      {
	 rc_ptr = aie_strdup(word);
      }
      aie_free(esc_word);
   }
   else
   {
      rc_ptr = aie_strdup(word);
   }
   return(rc_ptr);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : EscapeSuchWord                                            */
/* Parameter     :                                                           */
/* Erstellt      : ALH / April 2004                                          */
/* Rueckgabewert : char *                                                    */
/* Bemerkung     : Verbraucht Speicher auf Heap                              */
/*                 Der zurueckgegebene Wert muss explizit mit free wieder    */
/*                 freigegeben werden.                                       */
/*...........................................................................*/
char *aie_EscapeSuchWord(const char *word)
{

   const char *word_ptr = word;
   char *sptr; // = NULL;
   const char *sptr_umlaute;
   char *sptr2;
   char *buf = (char *)aie_malloc(strlen(word) * 7); 
   int pos = 0;
   if (__builtin_expect((buf != NULL),true))
   {
      if (__builtin_expect(
	       ((word_ptr != NULL) && 
		(*word_ptr != '\0')),true))
      {
         while ((*word_ptr <= ' ') && 
	        (*word_ptr != '\0') && 
		(strchr(umlaute, *word_ptr) == NULL))
         {
	    word_ptr++;
         }
      }
      if (__builtin_expect(
	       ((strchr(word_ptr, '&') == NULL) && 
		((sptr = strchr(word_ptr, ';')) != NULL)),false))
      {
         if (*(sptr + 1) == '\0')
         {
	    *sptr = '\0';
         }
      }
      if (__builtin_expect(
	       (((sptr = strchr(word_ptr, '.')) != NULL)),false))
      {
         if (__builtin_expect((*(sptr + 1) == '\0'),false))
         {
	    *sptr = '\0';
         }
      }
      strcpy(buf, word_ptr);
      sptr_umlaute = umlaute;
      while (*sptr_umlaute != '\0')
      {
         while ((sptr2 = strchr(buf, *sptr_umlaute)) != NULL)
         {
	    char *tmp = aie_strdup(sptr2);
	    if (__builtin_expect((tmp != NULL),true))
	    {
	       strcpy(sptr2, s_umlaute[pos].escape);
	       strcpy(sptr2 + strlen(s_umlaute[pos].escape), tmp + 1);
	       aie_free(tmp);
	    }
	    else
	    {
	       break;
	    }
	 }
	 sptr_umlaute++;
	 pos++;
      }
      *buf = (char)toupper(*buf);
   }
   return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : FixSortWord                                               */
/* Parameter     :                                                           */
/* Erstellt      : ALH / April 2004                                          */
/* Rueckgabewert : char *                                                    */
/* Bemerkung     : Der zurueckgegebene Wert muss explizit mit free wieder    */
/*                 freigegeben werden.                                       */
/*...........................................................................*/
char *aie_FixSortWord(const char *word)
{
   char *sptr;
   char *buf; // = NULL;
   if ((buf = aie_strdup(word)) != NULL)
   {
      unsigned int z;
      for (z = 0;z < s_umlaute_eot; z++)
      {
         while((sptr = strstr(buf, s_umlaute[z].escape)) != NULL)
         {
	    char *tmp = aie_strdup(sptr + strlen(s_umlaute[z].escape));
	    if (__builtin_expect((tmp != NULL),false))
	    {
	       strcpy(sptr, s_umlaute[z].sort);
	       strcpy(sptr + 1, tmp);
	       aie_free(tmp);
	    }
	    else
	    {
	       break;
	    }
         }
      }
      sptr = buf;
      while (*sptr != '\0')
      {
         *sptr = (char)toupper(*sptr);
	 sptr++;
      }
   }
   return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : FixSuchWord                                               */
/* Parameter     :                                                           */
/* Erstellt      : ALH / April 2004                                          */
/* Rueckgabewert : char *                                                    */
/* Bemerkung     : Der zurueckgegebene Wert muss explizit mit free wieder    */
/*                 freigegeben werden.                                       */
/*...........................................................................*/
char *aie_FixSuchWord(const char *word)
{
   char *sptr;
   char *buf = NULL;
   if (word != NULL)
   {
      //buf = word;
      // Der zurueckgegebene Wert muss explizit
      // mit aie_free freigegeben werden.
      if ((buf = aie_strdup(word)) != NULL)
      {
         unsigned int z;
         for (z = 0;z < s_umlaute_eot; z++)
         {
            while((sptr = strstr(buf, s_umlaute[z].escape)) != NULL)
            {
	       char *tmp = aie_strdup(sptr + strlen(s_umlaute[z].escape));
	       if (__builtin_expect((tmp != NULL),true))
	       {
	          strcpy(sptr, s_umlaute[z].search);
	          strcpy(sptr + 2, tmp);
	          aie_free(tmp);
	       }
	       else
	       {
	          break;
	       }
            }
	 }
      }
   }
   return(buf);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : star_line                                                 */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_star_line(size_t c, unsigned int ch)
{
   size_t z;
   for (z = 0; z <= c; z++)
   {
      printf("%c", (char)ch);
   }
   printf("\n");
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      : strip_eol                                                 */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_strip_eol(char *buf)
{
   char *sptr;   
   if (__builtin_expect(
	    ((sptr = strchr(buf, '\n')) != NULL),true))
   {
      *sptr = '\0';
   }
   if (__builtin_expect(
	    ((sptr = strchr(buf, 0x0a)) != NULL),false))
   {
      *sptr = '\0';
   }
   if (__builtin_expect(
	    ((sptr = strchr(buf, 0x0d)) != NULL),false))
   {
      *sptr = '\0';
   }
}
/*---------------------------------------------------------------------------*/
char *aie_escape_line(char *txt)
{
   char *sptr = txt;
   char *out_buf = aie_CharDynMemory(strlen(txt)*3+5);
   char *sptr2 = out_buf;
   bool in_string = false;
   bool first_char = false;
   if (out_buf != NULL)
   {
      while(*sptr != '\0')
      {
         if ((*sptr == '\'') || (*sptr == '\"'))
         {
            in_string = !in_string;
         }
         if ((!in_string) && (*sptr == ' ') && !first_char)
         {
            // Iggy
         }
         else
         {
            if ((!first_char) && (*sptr != ' '))
            {
               first_char = true;
            }
            sprintf(sptr2, "%%%.2X", *sptr);
            sptr2 += 3;
         }
         sptr++;
      }
      // strcat(sptr2, "%0A");
   }
   return(out_buf);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_txtutil_size       = __LINE__;                                   //
/* -------------------------------- EOF ------------------------------------ */

