/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_texte.c                                                 */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*                             : zur Geschwindigkeitsoptimierung             */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "GNU GENERAL PUBLIC LICENCE" Version 2 Licence Terms.                     */ 
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_texte_version    = "1.0.0";                                //
const char *modul_texte            = "Texte";                                //
const char *modul_texte_date       = __DATE__;                               //
const char *modul_texte_time       = __TIME__;                               //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_LOG_LIB			1
#define AIE_TXT_BUF_READ_SIZE 		4096
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/
//#undef AIENGINE_LOG_NO_LOG
//#define AIENGINE_LOG_NO_LOG	0

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : struct file_text *                                        */
/*...........................................................................*/
struct aie_file_text *aie_load_file_text(const char *file,
                                         struct aie_file_text **text)
{
   #if !AIENGINE_LOG_NO_LOG
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_load_file_text file[%s]" },
      { AIE_LOG_ERROR, "Datei %s konnte nicht zum lesen geoeffnet werden!" },
      { AIE_LOG_ERROR, "Out of memory?!" },
      { AIE_LOG_ERROR, "Kein Dateiname oder NULL Ptr" },
   };
   #endif
   FILE *fptr;
   struct aie_file_text *txt_base = *text;
   struct aie_file_text *txt_ptr = NULL;

   #if AIENGINE_LOG_TRACE_FILE_IO_TRACE
   aie_sys_log(0, file);
   #endif
   if (__builtin_expect(((file != NULL) && (*file != '\0')), true))
   {
      if (__builtin_expect((
		        (fptr = aie_open_read_text_file(file)) == NULL),false))
      {
         #if !AIENGINE_LOG_NO_LOG
         // Datei %s konnte nicht zum lesen geoeffnet werden!
         aie_sys_log(1, file);
         #endif
         return(NULL);
      }
      else
      {
         char *buf = (char *)aie_malloc(AIE_TXT_BUF_READ_SIZE + 1);
         memset(buf, '\0', AIE_TXT_BUF_READ_SIZE);

         while(!feof(fptr))
         {
            if ((fgets(buf, AIE_TXT_BUF_READ_SIZE - 1, fptr)) != NULL)
            {
               char *sptr;
               if ((sptr = strchr(buf, '\n')) != NULL)
               {
                  *sptr = '\0';
               }
               if (*(buf) != '\0')
               {
                  if (__builtin_expect((txt_base == NULL),false))
                  {
                     txt_base = (struct aie_file_text *)
		                      aie_malloc(sizeof(struct aie_file_text));
                     txt_ptr = txt_base;
                  }
                  else
                  {
                        txt_ptr->next = (struct aie_file_text *)
			              aie_malloc(sizeof(struct aie_file_text));
                        txt_ptr = txt_ptr->next;
                  }
                  if (__builtin_expect((txt_ptr == NULL),false))
                  {
                     #if !AIENGINE_LOG_NO_LOG
                     // Out of memory?!
                     aie_sys_log(2, NULL);
                     #endif
	             break;
                  }
	          else
	          {
                     txt_ptr->txt = aie_strdup(buf);
                     txt_ptr->next = NULL;
	          }
               }
            }
         }
         aie_free(buf);
         aie_close_file(fptr);
      }
      *text = txt_base;
   }
   else
   {
      #if !AIENGINE_LOG_NO_LOG
      // Kein Dateiname oder NULL Ptr
      aie_sys_log(2, NULL);
      #endif
      return(NULL);
   }
   return(txt_base);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : ohne                                                      */
/*...........................................................................*/
void aie_free_file_text(struct aie_file_text **text)
{
   struct aie_file_text *txt_base = *text;
   struct aie_file_text *txt_ptr;

   if (__builtin_expect(((txt_ptr = txt_base) != NULL),false))
   {
      while (txt_ptr != NULL)
      {
         txt_base = txt_ptr->next;
         if (__builtin_expect((txt_ptr->txt != NULL),true))
         {
            aie_free(txt_ptr->txt);
         }
         aie_free(txt_ptr);
         txt_ptr = txt_base;
      }
   }
   *text = NULL;
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_texte_size       = __LINE__;                                     //
/* -------------------------------- EOF ------------------------------------ */

