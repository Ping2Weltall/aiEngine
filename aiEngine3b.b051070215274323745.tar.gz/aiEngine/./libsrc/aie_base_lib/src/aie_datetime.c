/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_datetime.c                                              */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 12.10.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_datetime_version = "1.0.0";                                //
const char *modul_datetime         = "DateTime";                             //
const char *modul_datetime_date    = __DATE__;                               //
const char *modul_datetime_time    = __TIME__;                               //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#ifndef __isleap
#define __isleap(year) \
  ((year) % 4 == 0 && ((year) % 100 != 0 || (year) % 400 == 0))
#endif
#ifndef __GNUC__
#define dysize(y) (__isleap(y) ? 366 : 365)
#endif
#define dysize(y) (__isleap(y) ? 366 : 365)

/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
//#include <errno.h>                                                           //
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_get_time_stamp(void)
{
   static char tstamp[17];
   time_t t;
   struct tm *tm;
   t = time(NULL);
   tm = localtime(&t);
   sprintf(tstamp, "%.4d%.2d%.2d%.2d%.2d%.2d",
         tm->tm_year + 1900,
         tm->tm_mon + 1,
         tm->tm_mday,
         tm->tm_hour,
         tm->tm_min,
         tm->tm_sec);
   return(tstamp);
}
/*---------------------------------------------------------------------------*/
char *aie_timestamp_2_human_date(char *timestamp)
{
   char year[6];
   char month[6];
   char day[6];
   char hour[6];
   char min[6];
   char sec[6];
   static char human_date[30];

   char *sptr;

   sptr = strdup(timestamp); //  aie_strdup(timestamp);

   strncpy(year, sptr, 4);
   *(year + 4) = '\0';
   strncpy(month, sptr + 4, 2);
   *(month + 2) = '\0';
   strncpy(day, sptr + 6, 2);
   *(day + 2) = '\0';
   strncpy(hour, sptr + 8, 2);
   *(hour + 2) = '\0';
   strncpy(min, sptr + 10, 2);
   *(min + 2) = '\0';
   strncpy(sec, sptr + 12, 2);
   *(sec + 2) = '\0';
   sprintf(human_date, "%s.%s.%s %s:%s:%s", day, month, year, hour, min, sec);
   free(sptr);  //ie_free(sptr);

   return(human_date);
}

#ifndef AIE_SMALLBUILD
int aie_YearOf(time_t date)
{
   struct tm *tm = localtime(&date);
   if (__builtin_expect((tm != NULL), true))
   {
      return(tm->tm_year);
   }
   return(-1);
}

time_t aie_StrToDateTime(const char *s)
{
   int m_days[12] =
   {
       31, 27, 31, 30, 31, 30,
       30, 31, 30, 31, 30, 31 };
   static struct tm tm;
   time_t rc = (time_t)-1;
   register int i;

   if ((!(((s == NULL) || (strlen(s) < 6) || (strlen(s) > 10))) ||
          aie_IsNumber(*s+0) ||
	  ((*(s+1) == '.') && (*(s+2) == '.')) ||
	  ((*(s+2) == '.') && (*(s+3) == '.')) ||
	  ((*(s+1) == '.') && (*(s+5) == '.')) ||
	  ((*(s+2) != '.') && (*(s+1) != '.')) ||
          ((*(s+3) != '.') && (*(s+4) != '.') && (*(s+5) != '.')) ||
	  (
	  ((*(s+2) == '.') && !aie_IsNumber(*(s+1))) ||
	  ((*(s+1) == '.') && !aie_IsNumber(*(s+2))) ||
          ((*(s+3) == '.') && !aie_IsNumber(*(s+2)) &&
	                      !aie_IsNumber(*(s+4)) &&
			      !aie_IsNumber(*(s+5))) ||
	  ((*(s+4) == '.') && !aie_IsNumber(*(s+3)) &&
	                      !aie_IsNumber(*(s+5)) && !aie_IsNumber(*(s+6))) ||
	  ((*(s+5) == '.') && !aie_IsNumber(*(s+4)) &&
	                      !aie_IsNumber(*(s+6)) && !aie_IsNumber(*(s+7)))
	  )
	 ))
   {
      char *sptr;
      char tag[4];
      char mon[4];
      char jahr[5];
      int iTag; // = 0;
      int iMon; // = 0;
      int iJahr; // = 0;
      *(tag + sizeof(tag) - 1) = '\0';
      *(mon + sizeof(mon) - 1) = '\0';
      *(jahr + sizeof(jahr) - 1) = '\0';
      memset(&tm, '\0', sizeof(struct tm));
      strncpy(tag, s, 3);
      if ((sptr = strchr(tag, '.')) != NULL)
      {
	     const char *sptr2 = (s + (sptr - tag) + 1);
	     *sptr = '\0';
	     iTag = atoi(tag);
	     strncpy(mon, sptr2, 3);
        if ((sptr = strchr(mon, '.')) != NULL)
	     {
	        *sptr = '\0';
	        iMon = atoi(mon);
	        sptr2 = (s + strlen(s) - 1);
	        while ((*sptr2 != '.') && (sptr2 > s))
	        {
	           sptr2--;
	        }
	        if (((*sptr2 == '.') && (strlen(sptr2) > 2)))
	        {
	           strncpy(jahr, sptr2 + 1, sizeof(jahr) - 1);
	           if ((sptr = strchr(jahr, '.')) == NULL)
	           {
	              if ((iJahr = atoi(jahr)) > 1900)
	              {
		             iJahr -= 1900;
	              }
	              if ((iMon > 0) && (iMon <= 12))
	              {
		              iMon--;
		              if ((iTag > 0) &&
			               (iTag <= m_days[iMon] + __isleap(iJahr)))
                    {
			              rc = 0;
			              if (iJahr < 30)
                       {
			                 iJahr += 100;
                          for (i = 70; i < iJahr; i++)
			                 {
			                    rc += dysize(i + 1900) * 24 * 60 * 60;
                          }
			              }
                       //iRounds = abs(iJahr - tm2->tm_year);
                       if (iJahr < 70 && iJahr > 30)
			              {
                          for (i = 69; i >= iJahr; i--)
			                 {
			                    rc -= dysize(i + 1900) * 24 * 60 * 60;
			                 }
			                 rc += (iTag + 1) * 24 * 60 * 60;
			              }
			              else
			              {
                          for (i = iJahr; i > 70/*(tm2->tm_year - 70)*/; i--)
			                 {
			                    rc += dysize(i + 1900) * 24 * 60 * 60;
			                 }
			                 rc += (iTag + 1) * 24 * 60 * 60;
			              }
			              for (i = 0; i < iMon; i++)
                       {
			                 rc += m_days[i] * 24 * 60 * 60;
			              }
		                 if (iMon > 1 && __isleap(iJahr + 1900))
			              {
			                 rc += 24 * 60 * 60;
			              }
		              }
		           }
	           }
	        }
	      }
      }

   }
   return(rc);
}

time_t aie_DateOf(time_t t)
{
   struct tm *tm = localtime(&t);
   if (__builtin_expect(tm != NULL, true))
   {
      tm->tm_hour = 0;
      tm->tm_min = 0;
      tm->tm_sec = 0;
      return(mktime(tm));
   }
   return(t);
}

time_t aie_StartOfTheMonth(time_t t)
{
   struct tm *tm = localtime(&t);
   if (__builtin_expect(tm != NULL, true))
   {
      tm->tm_mday = 0;
      tm->tm_hour = 0;
      tm->tm_min = 0;
      tm->tm_sec = 0;
      return(mktime(tm));
   }
   return(t);
}

char *aie_DateToStr(time_t t)
{
   static char tmp[12];
   struct tm *tm = localtime(&t);
   if (__builtin_expect((tm != NULL), true))
   {
      sprintf(tmp, "%.2d.%.2d.%.4d", tm->tm_mday, tm->tm_mon + 1, 
	                             tm->tm_year + 1900);
   }
   else
   {
      strcpy(tmp, "??.??.????");
   }
   return(tmp);
}

void aie_DecodeDate(time_t now, unsigned int *jahr, unsigned int *monat,
                       unsigned int *tag)
{
   struct tm *tm = localtime(&now);
   if (__builtin_expect((tm != NULL), true))
   {
      *jahr = tm->tm_year + 1900;
      *monat = tm->tm_mon + 1;
      *tag = tm->tm_mday;
   }
   else
   {
      *jahr = 0;
      *monat = 0;
      *tag = 0;
   }
}
#endif
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_datetime_size  = __LINE__;                                       //
/* -------------------------------- EOF ------------------------------------ */
