/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_stringlist.c                                            */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 11.11.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_stringlist_version = "1.0.0";                              //
const char *modul_stringlist         = "Stringlist";                         //
const char *modul_stringlist_date    = __DATE__;                             //
const char *modul_stringlist_time    = __TIME__;                             //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
static struct aie_stringlisten *stringlisten_base = NULL;
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : bool                                                      */
/*...........................................................................*/
bool aie_stringlist_replace_add(const char *id, const char *name, 
                                                const char *value)
{
   bool rc = true;
   struct aie_string_liste *strl_ptr = aie_stringlist_read(id);
   while (strl_ptr != NULL)
   {
      if (!aie_StrEmpty(strl_ptr->name) && aie_StrEqual(strl_ptr->name, name))
      {
	 break;
      }
      strl_ptr = strl_ptr->next;
   }
   if (strl_ptr == NULL)
   {
      rc = aie_stringlist_add(id, name, value);
   }
   else
   {
      if (strl_ptr->value != NULL)
      {
	 aie_free(strl_ptr->value);
      } 
      if (value != NULL)
      {
         strl_ptr->value = aie_strdup(value);
      }
      else
      {
	 strl_ptr->value = NULL;
      }
   }
   return(rc);
}

bool aie_stringlist_add(const char *id, const char *name, const char *value)
{
   static char buf[15];
   static int z = 0;
   char *sptr = NULL;
   bool rc = false;
   struct aie_string_liste *strl_ptr; // = NULL;
   unsigned int len = (name != NULL) ? strlen(name) : 0;
   unsigned int len2 = (value != NULL) ? strlen(value) : 0;

   if ((name == NULL) || (*name == '\0'))
   {
      sprintf(buf, "@id:%d", z++);
      name = buf;
      len = strlen(buf);
   }
   if (__builtin_expect((id != NULL) && (value != NULL) && (name != NULL), true))
   {
      if (__builtin_expect((stringlisten_base == NULL), false))
      {
         if (__builtin_expect(
	       ((strl_ptr = aie_malloc(sizeof(struct aie_string_liste)))
		                                               != NULL), true))
         {
	         strl_ptr->next = NULL;
	         if (__builtin_expect(((stringlisten_base =
              aie_malloc(sizeof(struct aie_stringlisten))) != NULL), true))
	         {
	            char *sptr2; // = NULL;
               stringlisten_base->string_liste = strl_ptr;
	            stringlisten_base->next = NULL;
	            stringlisten_base->id = aie_strdup(id);
               if (__builtin_expect((len > 0) &&
                   ((sptr = aie_malloc(len + 1)) != NULL), true) &&
		             (len2 > 0 &&  ((sptr2 = aie_malloc(len2 + 1)) != NULL)))
	            {
		            if (sptr != NULL)
		            {
	                  strcpy(sptr, name);
                     strl_ptr->name = sptr;
		            }
		            if (sptr2 != NULL)
		            {
	                  strcpy(sptr2, value);
                     strl_ptr->value = sptr2;
		            }
	               rc = true;
	            }
	            else
	            {
		            if (sptr != NULL)
		            {
	                  aie_free(sptr);
		            }
	               aie_free(strl_ptr);
	               //strl_ptr = NULL;
	               aie_free(stringlisten_base);
	               stringlisten_base = NULL;
	            }
	         }
	         else
	         {
	            aie_free(strl_ptr);
	            //strl_ptr = NULL;
	         }
         }
      }
      else
      {
         struct aie_stringlisten *ptr = stringlisten_base;
         while (__builtin_expect((ptr != NULL), true))
         {
	        if (__builtin_expect(aie_StrEqual(ptr->id, id), false))
	        {
	           break;
	        }
	        ptr = ptr->next;
         }
         if (ptr == NULL)
         {
            static struct aie_stringlisten *stringlisten_ptr = NULL;
	         if (__builtin_expect(((stringlisten_ptr =
	 	         aie_malloc(sizeof(struct aie_stringlisten))) != NULL), true))
	         {
	            stringlisten_ptr->next = NULL;
               if (__builtin_expect(
	              ((strl_ptr = aie_malloc(sizeof(struct aie_string_liste)))
		                                               != NULL), true))
	            {
		           char *sptr2; // = NULL;
	              stringlisten_ptr->string_liste = strl_ptr;
	              stringlisten_ptr->next = stringlisten_base;
		           strl_ptr->next = NULL;
                 if (__builtin_expect(((len > 0) &&
		               ((sptr = aie_malloc(len + 1)) != NULL) &&
		               (len2 > 0 &&  ((sptr2 = aie_malloc(len2 + 1)) != NULL))), true))
	              {
	                 stringlisten_base = stringlisten_ptr;
	                 stringlisten_base->id = aie_strdup(id);
		              if (sptr2 != NULL)
		              {
	                    strcpy(sptr2, value);
                       strl_ptr->value = sptr2;
		              }
	                 strcpy(sptr, name);
                    strl_ptr->name = sptr;
	                 rc = true;
	              }
	              else
	              {
		              if (sptr != NULL)
		              {
			              aie_free(sptr);
		              }
		              aie_free(stringlisten_ptr);
		              stringlisten_ptr = NULL;
		              aie_free(strl_ptr);
		              //strl_ptr = NULL;
	              }
	         }
	       else
	       {
		   aie_free(stringlisten_ptr);
	       }
	    }
         }
         else
         {
            if (((strl_ptr = ptr->string_liste) == NULL))
	    {
               if (__builtin_expect(
	          ((strl_ptr = aie_malloc(sizeof(struct aie_string_liste)))
		                                               != NULL), true))
	       {
		      char *sptr2; // = NULL;
		      strl_ptr->next = NULL;
            if (__builtin_expect(((len > 0) &&
		       ((sptr = aie_malloc(len + 1)) != NULL) &&
		          (len2 > 0 &&  ((sptr2 = aie_malloc(len2 + 1)) != NULL))), true))
	          {
	             ptr->string_liste = strl_ptr;
	             ptr->id = aie_strdup(id);
		          if (sptr2 != NULL)
		          {
	                strcpy(sptr2, value);
                        strl_ptr->value = sptr2;
		          }
	             strcpy(sptr, name);
                     strl_ptr->name = sptr;
	             rc = true;
	          }
	          else
	          {
		     if (sptr != NULL)
		     {
			     aie_free(sptr);
		     }
		     aie_free(strl_ptr);
		     //strl_ptr = NULL;
	          }
	       }
	    }
	    else
	    {
	       char *sptr2; // = NULL;
          if (__builtin_expect((((sptr = strl_ptr->name) == NULL)), false))
	       {
             if (__builtin_expect(((len > 0) &&
		         ((sptr = aie_malloc(len + 1)) != NULL) &&
		         (len2 > 0 &&  ((sptr2 = aie_malloc(len2 + 1)) != NULL))), true))
	          {
	             strcpy(sptr, name);
                     strl_ptr->name = sptr;
                if (sptr2 != NULL)
		          {
	                strcpy(sptr2, value);
                        strl_ptr->value = sptr2;
		          }
	             rc = true;
	          }
	          else
	          {
		          aie_free(strl_ptr);
                // strl_ptr = NULL;
	          }
	       }
	       else
	       {
	         while (strl_ptr->next != NULL)
	         {
		         strl_ptr = strl_ptr->next;
	         }
            if (__builtin_expect(
	            ((strl_ptr->next =
		                   aie_malloc(sizeof(struct aie_string_liste)))
		                                               != NULL), true))
	         {
                if (__builtin_expect(((len > 0) &&
		             ((sptr = aie_malloc(len + 1)) != NULL) &&
		             (len2 > 0 &&  ((sptr2 = aie_malloc(len2 + 1)) != NULL))), true))
	            {
		            strl_ptr = strl_ptr->next;
		            strl_ptr->next = NULL;
	               strcpy(sptr, name);
                       strl_ptr->name = sptr;
		            if (sptr2 != NULL)
		            {
	                  strcpy(sptr2, value);
                          strl_ptr->value = sptr2;
		            }
	               rc = true;
	            }
	            else
	            {
		            aie_free(strl_ptr->next);
		            strl_ptr->next = NULL;
		            //strl_ptr = NULL;
	            }
	         }
	       }
	    }
	 }
      }
   }
   return(rc);
}

struct aie_string_liste *aie_stringlist_read(const char *id)
{
   struct aie_string_liste *rc_ptr = NULL;
   if ((stringlisten_base != NULL) && (id != NULL))
   {
      struct aie_stringlisten *ptr = stringlisten_base;
      while (ptr != NULL)
      {
	 if (aie_StrEqual(ptr->id, id))
	 {
	    break;
	 }
	 ptr = ptr->next;
      }
      if (ptr != NULL)
      {
	 rc_ptr = ptr->string_liste;
      }
   }
   return(rc_ptr);
}

bool aie_stringlist_has_value(const char *id, const char *value)
{
   bool rc = false;
    struct aie_string_liste *strl_ptr = aie_stringlist_read(id);
    while (strl_ptr != NULL)
    {
       if (aie_StrEqual(strl_ptr->value, value))
       {
	  rc = true;
	  break;
       }
       strl_ptr = strl_ptr->next;
    }
    return(rc);
}

char *aie_stringlist_value(const char *id, const char *name)
{
   char *rc_ptr = NULL;
    struct aie_string_liste *strl_ptr = aie_stringlist_read(id);
    while (strl_ptr != NULL)
    {
       if (aie_StrEqual(strl_ptr->name, name))
       {
	  rc_ptr = strl_ptr->value;
	  break;
       }
       strl_ptr = strl_ptr->next;
    }
    return(rc_ptr);
}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_stringlist_size    = __LINE__;                                   //
/* -------------------------------- EOF ------------------------------------ */

