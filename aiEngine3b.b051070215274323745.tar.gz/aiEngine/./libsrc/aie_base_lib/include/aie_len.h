/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_len.h                                                   */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 02.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Laengenangaben fuer verschiedene Strukturen innerhalb des @Secur Engines  */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_LEN_H                                                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_LEN_H                                                            //

#define AIENGINE_MAX_PATH_LENGTH                256
#define AIENGINE_STD_BUF_SIZE                   512

// Allgemeine Laengenangaben innerhalb des Engines
#define AIE_MIN_PASSWORD_LEN                    8
#define AIE_MAX_PASSWORD_LEN                    20
#define AIE_MIN_USERID_LEN                      10
#define AIE_MAX_USERID_LEN		        50
#define AIE_STANDARD_CGI_VARIABLE_LEN           10
#define AIE_STANDARD_CGI_PAGE_NAME_LEN		AIE_STANDARD_CGI_VARIABLE_LEN
#define AIE_STANDARD_CGI_FRAME_NAME_LEN		AIE_STANDARD_CGI_VARIABLE_LEN
#define AIE_MAX_VAR_LEN 			30                           //
#define AIE_MAX_VAL_LEN				128                          //
#define AIE_STANDARD_IMAGE_NAME_LEN		30
#define AIE_STD_PROG_LEN			25
#define AIE_STD_IP_LEN				25

// Laengen hauptsaechlich verwendet fuer interne Client/Server Telegramme
#define AIE_LEN_MSGSZ    				128

#define AIE_LEN_NAME				30
#define AIE_LEN_VALUE				80
#define AIE_LEN_HTTP 				1024
#define AIE_PASSWORD_HASH_LEN 			1024

#define AIE_LEN_LOGFILE_NAME			80
#define AIE_LEN_LOG_MSG				1024

#define AIE_LEN_MENUEFILE_NAME			132
#define AIE_LEN_MENUE_ENTRY				80
#define AIE_LEN_MENUE_SUBSET			80
#define AIE_LEN_MENUE_FUNKTION			10
#define AIE_LEN_MENUE_SUBKAT			10

#define AIE_LEN_START_DATUM				22
#define AIE_LEN_END_DATUM				22
#define AIE_LEN_SUCHE				80

#define AIE_LEN_CGI_NAME				50
#define AIE_LEN_PROG_NAME				50
#define AIE_LEN_ORT_NAME				50
#define AIE_LEN_PLZ       				5
#define AIE_LEN_INSERAT_NAME			128
#define AIE_LEN_PRODUKT_NAME			80

// Laengen fuer Sitemap Generator 
#define AIE_SITEMAP_GENERATOR_LEN		80
#define AIE_SITEMAP_SERVER_SOFTWARE_LEN		80
#define AIE_SITEMAP_OPERATING_SYSTEM_LEN	80
#define AIE_SITEMAP_URL_LEN			40
#define AIE_SITEMAP_PATH_LEN			2000
#define AIE_SITEMAP_MODUL_LEN			30
#define AIE_SITEMAP_PAGE_LEN			5
#define AIE_SITEMAP_RESULT_LEN			30
#define AIE_SITEMAP_AGENT_LEN			80
#define AIE_SITEMAP_IP_LEN			20
#define AIE_SITEMAP_PORT_LEN			10
#define AIE_SITEMAP_RUN_TIME_LEN		20
#define AIE_SITEMAP_RUN_COUNT_LEN		20
#define AIE_SITEMAP_LINE_LEN			512
#define AIE_SITEMAP_SIZE_LEN			20

// Comapny & Contact Tag
#define AIE_SITEMAP_COMPANY_NAME_LEN		80
#define AIE_SITEMAP_DEPARTMENT_NAME_LEN		80
#define AIE_SITEMAP_EMAIL_LEN			80
#define AIE_SITEMAP_STREET_LEN			80
#define AIE_SITEMAP_ZIPL_LEN			10
#define AIE_SITEMAP_TOWN_LEN			25
#define AIE_SITEMAP_PROVINCE_LEN		20
#define AIE_SITEMAP_COUNTRY_LEN			20
#define AIE_SITEMAP_PHONE_LEN			25
#define AIE_SITEMAP_FAX_LEN			25

#define AIE_SITEMAP_WEBMASTER_LEN		40

// Environment & Robot Tag
#define AIE_SITEMAP_CHANNEL_LEN			80
#define AIE_SITEMAP_CLASSIFICATION_LEN		14
#define AIE_SITEMAP_LANGUAGE_LEN		25
#define AIE_SITEMAP_PUBLISHER_LEN		80
#define AIE_SITEMAP_AUTHOR_LEN			80
#define AIE_SITEMAP_EMAIL_LEN			80
#define AIE_SITEMAP_TITLE_LEN			128
#define AIE_SITEMAP_DESCRIPTION_LEN		255
#define AIE_SITEMAP_KEYWORDS_LEN		512
#define AIE_SITEMAP_INFO_LEN			2048
#define AIE_SITEMAP_AUDIENCE_LEN		8
#define AIE_SITEMAP_ROBOTS_LEN			80
#define AIE_SITEMAP_RESOURCE_TYP_LEN		8
#define AIE_SITEMAP_REVISIT_AFTER_LEN		20

// Laengen innerhalb der Strukturen in dispmain.h
#define AIE_PAGE_REC_PAGE_LEN         		AIE_STANDARD_CGI_PAGE_NAME_LEN 
#define AIE_PAGE_REC_BG_LEN         		15 
#define AIE_PAGE_REC_BODY_FKT_LEN     		25 
#define AIE_BASIC_REC_PAGE_LEN         		AIE_STANDARD_CGI_PAGE_NAME_LEN 
#define AIE_BASIC_REC_BG_LEN         		15 
#define AIE_BASIC_REC_BODY_FKT_LEN     		25 
#define AIE_KNOWN_FRAMES_FRAME_SET_LEN		5 
#define AIE_KNOWN_FRAMES_FRAME_LEN		20
#define AIE_KNOWN_FRAMES_SCROLL_LEN		5 
#define AIE_KNOWN_FRAMES_NAME_LEN		10
#define AIE_KNOWN_FRAMES_SCROLL_A_LEN		5 
#define AIE_KNOWN_FRAMES_TARGET_A_LEN		AIE_STANDARD_CGI_PAGE_NAME_LEN 
#define AIE_KNOWN_FRAMES_NAME_A_LEN		10
#define AIE_KNOWN_FRAMES_SCROLL_B_LEN		5  
#define AIE_KNOWN_FRAMES_TARGET_B_LEN		AIE_STANDARD_CGI_PAGE_NAME_LEN 
#define AIE_KNOWN_FRAMES_NAME_B_LEN		10
#define AIE_PAGE_CGI_DISPATCH_PAGE_LEN		AIE_STANDARD_CGI_PAGE_NAME_LEN 
#define AIE_FRAME_CGI_DISPATCH_FRAME_LEN 	AIE_STANDARD_CGI_FRAME_NAME_LEN	
#define AIE_MODULE_2_CGI_PROG_CGI_PROG_LEN	40
                                                                             //
// Verwendet in isHttpd.h
#define AIE_AIENGINE_BODY_TAG_VAR_LEN		AIE_MAX_VAR_LEN
#define AIE_AIENGINE_BODY_TAG_VAL_LEN		AIE_MAX_VAL_LEN
         
// Verwendet in imp.h
#define AIE_STANDARD_IMP_PAGE_LEN		AIE_STANDARD_CGI_PAGE_NAME_LEN
#define AIE_IMP_BODY_LINKS_TARGET_LEN		AIE_STANDARD_CGI_FRAME_NAME_LEN
#define AIE_IMP_BODY_LINKS_PAGE_LEN		AIE_STANDARD_CGI_PAGE_NAME_LEN
#define AIE_IMP_BODY_LINKS_IMG_0_LEN		AIE_STANDARD_IMAGE_NAME_LEN
#define AIE_IMP_BODY_LINKS_IMG_1_LEN		AIE_STANDARD_IMAGE_NAME_LEN
#define AIE_IMP_BODY_LINKS_ALT_LEN		10
#define AIE_IMP_BODY_LINKS_AD_LEN		5 

// Laengenangaben fuer Strukturen innerhalb von menue.h
#define AIE_KNOWN_MENUES_PAGE_LEN	        AIE_STANDARD_CGI_PAGE_NAME_LEN
#define AIE_KNOWN_MENUES_MENUE_LEN	        40
#define AIE_KNOWN_MENUES_TITEL_LEN	        30
#define AIE_KNOWN_MENUES_TARGET_FRAME_LEN	AIE_STANDARD_CGI_FRAME_NAME_LEN
#define AIE_KNOWN_MENUES_TARGET_PAGE_LEN	AIE_STANDARD_CGI_PAGE_NAME_LEN
#define AIE_KNOWN_MENUES_DOES_LEN		AIE_STANDARD_CGI_VARIABLE_LEN
#define AIE_KNOWN_MENUES_IMAGE_LEN		AIE_STANDARD_IMAGE_NAME_LEN
                                                                             //
// Verwendet in variables.h
#define AIE_ASECUR_VARIABLES_VAR_LEN		AIE_MAX_VAR_LEN
#define AIE_AIENGINE_GLOBALE_VARIABLEN_VAR_LEN	AIE_MAX_VAR_LEN
#define AIE_AIENGINE_GLOBALE_VARIABLEN_VAL_LEN	AIE_MAX_VAL_LEN
#define AIE_ASECUR_STATIC_VARIABLES_VAR_LEN	AIE_MAX_VAR_LEN
#define AIE_ASECUR_STATIC_VARIABLES_VAL_LEN	AIE_MAX_VAL_LEN



// Speicher fuer den QueryString
#define AIE_QUERY_STRING_BUF_LEN		10240
#define AIE_LINK_TAG_BUF_LEN			2048
#define AIE_SESSION_NR_BUF_LEN			64
#define AIE_SESSION_NAME_BUF_LEN		(AIE_SESSION_NR_BUF_LEN + 64)

#define AIE_VARIABLE_MAX_EXPANDED_LEN		2048

#define AIE_LOG_BUFFER_LEN			10240

#define AIE_SQL_BUFFER_LEN			2048
#define AIE_SQL_TABLE_INSERT_BUFFER_LEN		4096
#define AIE_SQL_TABLE_UPDATE_BUFFER_LEN		4096
#define AIE_SQL_DUMP_TABLE_DUMP_NAME_LEN	512

#define AIE_DYN_LINK_TAG_LEN			2048

#define AIE_MAX_CRYPT_BLOCKSIZE			2048
#define AIE_CRYPT_KEY_ID_LEN			8

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

