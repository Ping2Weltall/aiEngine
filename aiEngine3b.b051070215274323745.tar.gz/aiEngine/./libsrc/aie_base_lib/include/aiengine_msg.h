/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aiengine_msg.h                                              */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 01.11.2003                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*---------------------------------------------------------------------------*/
#ifndef AIENGINE_MSG_H
/*---------------------------------------------------------------------------*/
/* Additionl Systemheader                                                    */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIENGINE_MSG_H

#define MSG_BASE_KEY				0x00000000
#define AIENGINE_PROG_QUEUE_ID			0x1a000000

#define MSG_SERVER_START       			'+'
#define MSG_SERVER_REQUEST			'*'
#define MSG_SERVER_STOP        			'-'

#define MSG_PROG_LOG				'@'
#define MSG_KEY_SERVER_START       		MSG_SERVER_START
#define MSG_KEY_SERVER_STOP        		MSG_SERVER_STOP
#define MSG_KEY_SERVER_REQUEST_CODE		'>'
#define MSG_KEY_SERVER_GET_CHALLENGE		'$'
#define MSG_KEY_SERVER_HASH_PASSWORD		'='
#define MSG_KEY_SERVER_REQUEST_DECODE		'<'
#define MSG_DIR_SERVER_REQUEST			MSG_SERVER_REQUEST

#define MSG_PLZ_SERVER_START       		MSG_SERVER_START
#define MSG_PLZ_SERVER_PLZ_REQUEST		MSG_SERVER_REQUEST
#define MSG_PLZ_SERVER_ORT_REQUEST		':'
#define MSG_PLZ_SERVER_STOP        		MSG_SERVER_STOP

#define MSG_PK_SERVER_START       		MSG_SERVER_START
#define MSG_PK_SERVER_PRODUKT_REQUEST		'*'
#define MSG_PK_SERVER_NR_REQUEST		':'
#define MSG_PK_SERVER_DIR_REQUEST		'#'
#define MSG_PK_SERVER_SUCHE_REQUEST     	'~'
#define MSG_PK_SERVER_AKTUELL    		'='
#define MSG_PK_SERVER_INSERAT_REQUEST   	'!'
#define MSG_PK_SERVER_STOP        		MSG_SERVER_STOP

#define MSG_SITEMAP_SERVER_START       		MSG_SERVER_START
#define MSG_SITEMAP_SERVER_MAP_REQUEST		MSG_SERVER_REQUEST
#define MSG_SITEMAP_SERVER_INDEX_REQUEST	':'
#define MSG_SITEMAP_SERVER_URL_SPEICHERN	'='
#define MSG_SITEMAP_SERVER_STOP        		MSG_SERVER_STOP

#define MSG_PROG_PRIO				'0'
#define MSG_PROG_START				'1'
#define MSG_PROG_KILL				'2'
#define MSG_MENUE_READ				'A'
#define MSG_MENUE_SUBSET_READ			'B'
#define MSG_MENUE_TEXT_READ			'C'

#define DIR_SERVER_BUF_LEN			1024



#define MTYPE_EOT				999
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#include "aiengine.h"
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
struct common_server_msgbuf
{
   long    mtype;
};
#if 0
struct ipc_log_msg
{
   char logfile[AIE_LEN_LOGFILE_NAME + 1];
   char log_ip[AIE_STD_IP_LEN + 1];
   char log_prog[AIE_STD_PROG_LEN + 1];
   char log_msg[AIE_LEN_LOG_MSG + 1];
};

#endif
struct ipc_menue_read_msg
{
   char menue[AIE_LEN_MENUEFILE_NAME + 1];
   char subset[AIE_LEN_MENUE_SUBSET + 1];
   int typ;
   pid_t pid;
};

struct ipc_menue_read_item_msg
{
   char menue[AIE_LEN_MENUEFILE_NAME + 1];
   int typ;
   char funktion[AIE_LEN_MENUE_FUNKTION + 1];
   bool eot;
};

struct menue_read_msgbuf
{
   long    mtype;
   union
   {
      struct ipc_menue_read_msg ipc_menue_read_msg;
      struct ipc_menue_read_item_msg ipc_menue_read_item_msg;
   } m;
};

struct ipc_menue_send_msg
{
   char entry[AIE_LEN_MENUE_ENTRY + 1];
   char funktion[AIE_LEN_MENUE_FUNKTION + 1];
   char subkat[AIE_LEN_MENUE_SUBKAT + 1];
   bool eot;
};

struct menue_send_msgbuf
{
   long    mtype;
   union
   {
      struct ipc_menue_send_msg ipc_menue_send_msg;
   } m;
};
#if 0
struct log_msgbuf
{
   long    mtype;
   struct ipc_log_msg ipc_log_msg;
};
#endif
struct ipc_prio_msg
{
   pid_t pid;
   int new_prio;
   bool want_signal;
   char prog_name[AIE_LEN_CGI_NAME + 1];
};

struct ipc_prog_start_msg
{
   pid_t pid;
   char prog[AIE_LEN_PROG_NAME + 1];
};

struct ipc_prog_kill_msg
{
   pid_t pid;
   char prog[AIE_LEN_PROG_NAME + 1];
};

struct prio_msgbuf
{
   long    mtype;
   struct ipc_prio_msg ipc_prio_msg;
   struct ipc_prog_start_msg ipc_prog_start_msg;
   struct ipc_prog_kill_msg ipc_prog_kill_msg;
};

struct ipc_server_control_msg
{
   int request;
};

struct ipc_key_server_msg
{
   int request;
   pid_t pid;
   char cgi_name[AIE_LEN_CGI_NAME + 1];
   char buf[AIE_MAX_CRYPT_BLOCKSIZE + 1];
};

struct ipc_key_server_hash_password_msg
{
   int request;
   pid_t pid;
   char cgi_name[AIE_LEN_CGI_NAME + 1];
   char password[AIE_MAX_PASSWORD_LEN + 1];
   char challenge[AIE_PASSWORD_HASH_LEN + 1];
};

struct key_server_msgbuf
{
   long    mtype;
   union
   {
      struct ipc_server_control_msg ipc_server_control_msg;
      struct ipc_key_server_msg ipc_key_server_msg;
      struct ipc_key_server_hash_password_msg ipc_key_server_hash_password_msg;
   } m;
};

#if 0
struct ipc_dir_server_msg
{
   pid_t pid;
   int request;
   char cgi_name[AIE_LEN_CGI_NAME + 1];
   char dir[AIE_DIR_SERVER_BUF_LEN + 1];
};

struct dir_server_msgbuf
{
   long    mtype;
   union
   {
      struct ipc_server_control_msg ipc_server_control_msg;
      struct ipc_dir_server_msg ipc_dir_server_msg;
   } m;
};
#endif

struct ipc_plz_server_msg
{
   pid_t pid;
   int plz;
   char ort[AIE_LEN_ORT_NAME + 1];
};

struct plz_server_msgbuf
{
   long    mtype;
   union
   {
      struct ipc_server_control_msg ipc_server_control_msg;
      struct ipc_plz_server_msg ipc_plz_server_msg;
   } m;
};

// Produktkatalog
struct ipc_pk_server_msg
{
   pid_t pid;
   bool eot;
   int katnr;
   char produkt[AIE_LEN_PRODUKT_NAME + 1];
};

struct ipc_pk_server_inserat_msg
{
   pid_t pid;
   bool eot;
   int typ;
   char inserat[AIE_LEN_INSERAT_NAME + 1];
};

struct ipc_pk_server_aktuell_msg
{
   pid_t pid;
   bool eot;
   int katnr;
   char funktion[AIE_LEN_MENUE_FUNKTION + 1];
   char start[AIE_LEN_START_DATUM + 1];
   char end[AIE_LEN_END_DATUM + 1];
   char suche[AIE_LEN_SUCHE + 1];
   char plz[AIE_LEN_PLZ + 1];
};

struct pk_server_msgbuf
{
   long    mtype;
   union
   {
      struct ipc_pk_server_msg ipc_pk_server_msg;
      struct ipc_pk_server_inserat_msg ipc_pk_server_inserat_msg;
      struct ipc_pk_server_aktuell_msg ipc_pk_server_aktuell_msg;
   } m;
};

// Sitmaps
struct ipc_sitemap_server_msg
{
   pid_t pid;
   struct aie_sitemap_environment sitemap_environment;
   char url[AIE_SITEMAP_URL_LEN + 1];
   char result[AIE_SITEMAP_RESULT_LEN + 1];
   char agent[AIE_SITEMAP_AGENT_LEN + 1];
   char ip[AIE_SITEMAP_IP_LEN + 1];
   char port[AIE_SITEMAP_PORT_LEN + 1];
};


struct ipc_sitemap_server_answer_msg
{
   char line[AIE_SITEMAP_LINE_LEN + 1];
   bool eot;
};

struct ipc_sitemap_server_save_msg
{
   char url[AIE_SITEMAP_URL_LEN + 1];
   char path[AIE_SITEMAP_PATH_LEN + 1];
   char modul[AIE_SITEMAP_MODUL_LEN + 1];
   int frame;
   char page[AIE_SITEMAP_PAGE_LEN + 1];
   char run_time[AIE_SITEMAP_RUN_TIME_LEN + 1];
   char size[AIE_SITEMAP_SIZE_LEN + 1];
};

struct ipc_sitemap_server_save_reply_msg
{
   int status;
   char url[AIE_SITEMAP_URL_LEN + 1];
};

struct sitemap_server_msgbuf
{
   long    mtype;
   union
   {
      struct ipc_server_control_msg ipc_server_control_msg;
      struct ipc_sitemap_server_save_msg ipc_sitemap_server_save_msg;
      struct ipc_sitemap_server_msg ipc_sitemap_server_msg;
      struct ipc_sitemap_server_answer_msg ipc_sitemap_server_answer_msg;
      struct ipc_sitemap_server_save_reply_msg 
	                                     ipc_sitemap_server_save_reply_msg;
   } m;
};

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
// Keine                                                                     //

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif
/* -------------------------------- EOF ------------------------------------ */
