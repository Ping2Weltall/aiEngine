/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_crc32.h                                                 */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 30.12.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* Special Licence see below:                                                */
/*---------------------------------------------------------------------------*/
/* Borrowed from zlib -- version 1.2.1, November 17th, 2003 - modified(!)

  Copyright (C) 1995-2003 Jean-loup Gailly and Mark Adler

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

  Jean-loup Gailly        Mark Adler
  jloup@gzip.org          madler@alumni.caltech.edu


  The data format used by the zlib library is described by RFCs (Request for
  Comments) 1950 to 1952 in the files http://www.ietf.org/rfc/rfc1950.txt
  (zlib format), rfc1951.txt (deflate format) and rfc1952.txt (gzip format).
*/
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_CRC32_H  

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_CRC32_H 

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
unsigned long aie_crc32(unsigned long crc, char *buf, unsigned len);
#ifdef __cplusplus
}
#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

