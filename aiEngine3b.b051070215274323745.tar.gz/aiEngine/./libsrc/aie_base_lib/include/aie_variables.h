/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_variables.h                                             */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 2003                                                        */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpasung  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*                             : Globale Strukturen jetzt in aie_struct.h    */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_VARIABLES_H                                                      //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_VARIABLES_H                                                      //

#define ASECUR_GLOBAL_VARIABLEN                 0                            //
#define ASECUR_ALL_VARIABLES                    ASECUR_GLOBAL_VARIABLEN      //
                                                                             //
#define AIENGINE_VAR_ASCDATE                    "$(D);"                      //
#define AIENGINE_VAR_AUDIENCE                   "$(AUD);"                    //
#define AIENGINE_VAR_AUTHOR                     "$(AUT);"                    //
#define AIENGINE_VAR_CHANNEL                    "$(CH);"                     //
#define AIENGINE_VAR_CLASSIFICATION             "$(CL);"                     //
#define AIENGINE_VAR_COPYRIGHT                  "$(CR);"                     //
#define AIENGINE_VAR_CONTENT_LANGUAGE           "$(CLANG);"                  //
#define AIENGINE_VAR_CONTENT_STYLE              "$(CSTYP);"                  //
#define AIENGINE_VAR_CONTENT_TYP                "$(CTYP);"                   //
#define AIENGINE_VAR_DAY                        "$(d);"                      //
#define AIENGINE_VAR_DESCRIPTION                "$(DESC);"                   //
#define AIENGINE_VAR_KEYWORDS                   "$(KEYW);"                   //
#define AIENGINE_VAR_EMAIL                      "$(EMAIL);"                  //
#define AIENGINE_VAR_SUPPORT_EMAIL              "$(SUPPORT);"                //
#define AIENGINE_VAR_GENERATOR                  "$(GEN);"                    //
#define AIENGINE_VAR_HOME_URL                   "$(URL);"                    //
#define AIENGINE_VAR_LANGUAGE                   "$(LANG);"                   //
#define AIENGINE_VAR_MONTH                      "$(m);"                      //
#define AIENGINE_VAR_PAGE_TOPIC                 "$(PTOP);"                   //
#define AIENGINE_VAR_PAGE_TYP                   "$(PTYP);"                   //
#define AIENGINE_VAR_PUBLISHER                  "$(PU);"                     //
#define AIENGINE_VAR_REPLY_TO                   "$(REP);"                    //
#define AIENGINE_VAR_RESOURCE_TYP               "$(RTYP);"                   //
#define AIENGINE_VAR_ROBOTS                     "$(ROBOT);"                  //
#define AIENGINE_VAR_PROXY                      "$(PROXY);"                  //
#define AIENGINE_VAR_SERVER_VERSION             "$(VE);"                     //
#define AIENGINE_VAR_SITEINFO                   "$(SI);"                     //
#define AIENGINE_VAR_T_OFFSET                   "$(t);"                      //
#define AIENGINE_VAR_TITLE                      "$(TIT);"                    //
#define AIENGINE_VAR_YEAR                       "$(y);"                      //
                                                                             //
#define AIENGINE_VAR_REVISIT_AFTER              "$(RVISIT);"                 //
#define AIENGINE_VAR_EXPIRES                    "$(EXPIRES);"                //
#define AIENGINE_VAR_CREATED                    "$(CREATED);"                //
#define AIENGINE_VAR_DOCDATE                    "$(DOCDATE);"                //
#define AIENGINE_VAR_CGI_MYSELF                 "$(CGINAME);"                //
                                                                             //
#define AIENGINE_VAR_GLOBAL_ENGINE_NAME         "$(@G_ENAME);"               //
#define AIENGINE_VAR_COPYRIGHT_ENGINE_1         "$(@C_ENGINE1);"             //
#define AIENGINE_VAR_COPYRIGHT_ENGINE_2         "$(@C_ENGINE2);"             //
#define AIENGINE_VAR_COPYRIGHT_PAGES_TXT        "$(@C_P_TXT);"               //
#define AIENGINE_VAR_GLOBAL_APPL_NAME           "$(@GL_A_N);"                //
                                                                             //
//---------
#define AIENGINE_VAR_REMOTE_IP            "$(@REMOTE_IP);"
#define AIENGINE_VAR_LINKED_FROM          "$(@LINKED_FROM);"
#define AIENGINE_VAR_DATA_ROOT            "$(@DATA_ROOT);"
#define AIENGINE_VAR_DATA_DIR             "$(@DATA_DIR);"
#define AIENGINE_VAR_HTDOCS_ROOT          "$(@HTDOCS_ROOT);"
#define AIENGINE_VAR_HTDOCS_DIR           "$(@HTDOCS_DIR);"
#define AIENGINE_VAR_APPL_NAME            "$(@APPL_NAME);"
#define AIENGINE_VAR_IMAGE_PATH           "$(@IMAGE_PATH);"
#define AIENGINE_VAR_MENUE_PATH           "$(@MENUE_PATH);"
#define AIENGINE_VAR_IMAGE_BUTTON_PATH    "$(@IMAGE_BUTTON_PATH);"
#define AIENGINE_VAR_IMAGE_FRAME_PATH     "$(@IMAGE_FRAME_PATH);"
#define AIENGINE_VAR_IMAGE_IMP_PATH       "$(@IMAGE_IMP_PATH);"
#define AIENGINE_VAR_IMAGE_SS_PATH        "$(@IMAGE_SS_PATH);"
#define AIENGINE_VAR_IMAGE_BANNER_PATH    "$(@IMAGE_BANNER_PATH);"
#define AIENGINE_VAR_IMAGE_AD_PATH        "$(@IMAGE_AD_PATH);"
#define AIENGINE_VAR_UPLOAD_PATH          "$(@UPLOAD_PATH);"
#define AIENGINE_VAR_INSERATE_PATH        "$(@INSERATE_PATH);"
#define AIENGINE_VAR_DATA_PATH            "$(@DATA_PATH);"
#define AIENGINE_VAR_HTDOCS_PATH          "$(@HTDOCS_PATH);"
#define AIENGINE_VAR_IMAGE_UPLOAD_PATH    "$(@IMAGE_UPLOAD_PATH);"
#define AIENGINE_VAR_BANNER_DATA_PATH     "$(@BANNER_DATA_PATH);"
#define AIENGINE_VAR_MEN_PATH             "$(@MEN_PATH);"
#define AIENGINE_VAR_SUBMEN_PATH          "$(@SUBMEN_PATH);"
#define AIENGINE_VAR_BANNER_PATH          "$(@BANNER_PATH);"
#define AIENGINE_VAR_DATA_MEN_PATH        "$(@DATA_MEN_PATH);"
#define AIENGINE_VAR_DATA_SUBMEN_PATH     "$(@DATA_SUBMEN_PATH);"
#define AIENGINE_VAR_DATA_BANNER_PATH     "$(@DATA_BANNER_PATH);"


#define AIENGINE_VARS_DATA_PATH                "$(@DATA_ROOT);/$(@DATA_DIR);/$(@APPL_NAME);/"
#define AIENGINE_VARS_HTDOCS_PATH              "$(@HTDOCS_ROOT);/$(@HTDOCS_DIR);/$(@APPL_NAME);"
#define AIENGINE_VARS_IMAGE_UPLOAD_PATH        "$(@HTDOCS_PATH);/$(@IMAGE_PATH);/$(@UPLOAD_PATH);/"
#define AIENGINE_VARS_DATA_MEN_PATH            "$(@DATA_PATH);$(@MEN_PATH);"
#define AIENGINE_VARS_DATA_SUBMEN_PATH         "$(@DATA_PATH);$(@MEN_PATH);/$(@SUBMEN_PATH);"
#define AIENGINE_VARS_DATA_BANNER_PATH         "$(@DATA_PATH);$(@BANNER_PATH);"

#define AIE_IS_VAR_HTDOCS                     "$(@HTDOCS_PATH);/%s"
#define AIE_IS_VAR_IMAGE                      "/$(@IMAGE_PATH);/%s"
#define AIE_IS_VAR_MENUE_IMAGE                "/$(@IMAGE_PATH);/$(@MENUE_PATH);/%s"
#define AIE_IS_VAR_FRAME_IMAGE                "/$(@IMAGE_PATH);/$(@IMAGE_FRAME_PATH);/%s"
#define AIE_IS_VAR_IMP_IMAGE                  "/$(@IMAGE_PATH);/$(@IMAGE_IMP_PATH);/%s"
#define AIE_IS_VAR_BUTTON_IMAGE               "/$(@IMAGE_PATH);/$(@IMAGE_BUTTON_PATH);/%s"
#define AIE_IS_VAR_BANNER_IMAGE               "/$(@IMAGE_PATH);/$(@IMAGE_BANNER_PATH);/%s"
#define AIE_IS_VAR_SS_IMAGE                   "/$(@IMAGE_PATH);/$(@IMAGE_SS_PATH);/%s"
#define AIE_IS_VAR_AD_IMAGE                   "/$(@IMAGE_PATH);/$(@IMAGE_BANNER_PATH);/$(@IMAGE_AD_PATH);/%s"
#define AIE_IS_VAR_DATA                       "$(@DATA_PATH);%s"
#define AIE_IS_VAR_MEN                        "$(@DATA_MEN_PATH);/%s"
#define AIE_IS_VAR_SUBMEN                     "$(@DATA_SUBMEN_PATH);/%s"
#define AIE_IS_VAR_PATH_BANNER                "$(@DATA_BANNER_PATH);/%s"
#define AIE_IS_VAR_IMAGE_UPLOAD_PATH          "$(@IMAGE_UPLOAD_PATH);%s"
#define AIE_IS_VAR_IMAGE_INSERATE_PATH        "$(@IMAGE_INSERATE_PATH);%s"

#define AIE_MK_HTDOCS(a)                      \
                            aie_do_var_variable(AIE_IS_VAR_HTDOCS, a)
#define AIE_MK_IMAGE(a)                       \
                            aie_do_var_variable(AIE_IS_VAR_IMAGE, a)
#define AIE_MK_MENUE_IMAGE(a)                 \
                            aie_do_var_variable(AIE_IS_VAR_MENUE_IMAGE, a)
#define AIE_MK_FRAME_IMAGE(a)                 \
                            aie_do_var_variable(AIE_IS_VAR_FRAME_IMAGE, a)
#define AIE_MK_IMP_IMAGE(a)                   \
                            aie_do_var_variable(AIE_IS_VAR_IMP_IMAGE, a)
#define AIE_MK_BUTTON_IMAGE(a)                \
                            aie_do_var_variable(AIE_IS_VAR_BUTTON_IMAGE, a)
#define AIE_MK_BANNER_IMAGE(a)                \
                            aie_do_var_variable(AIE_IS_VAR_BANNER_IMAGE, a)
#define AIE_MK_SS_IMAGE(a)                    \
                            aie_do_var_variable(AIE_IS_VAR_SS_IMAGE, a)
#define AIE_MK_AD_IMAGE(a)                    \
                            aie_do_var_variable(AIE_IS_VAR_AD_IMAGE, a)
#define AIE_MK_DATA(a)                        \
                            aie_do_var_variable(AIE_IS_VAR_DATA, a)
#define AIE_MK_MEN(a)                         \
                            aie_do_var_variable(AIE_IS_VAR_MEN, a)
#define AIE_MK_SUBMEN(a)                      \
                            aie_do_var_variable(AIE_IS_VAR_SUBMEN, a)
#define AIE_MK_PATH_BANNER(a)                 \
                            aie_do_var_variable(AIE_IS_VAR_PATH_BANNER, a)
#define AIE_MK_IMAGE_UPLOAD_PATH(a)           \
                            aie_do_var_variable(AIE_IS_VAR_IMAGE_UPLOAD_PATH, a)
#define AIE_MK_IMAGE_INSERATE_PATH(a)         \
                            aie_do_var_variable(AIE_IS_VAR_IMAGE_INSERATE_PATH, a)
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#include <time.h>                                                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
struct aie_variable_heap                                                     //
{                                                                            //
   const char *var;                                                          //
   int typ;                                                                  //
   const char *val;                                                          //
   unsigned int test_len;                                                    //
   char *(*fkt)(time_t *t, char *buf);                                       //
   struct aie_variable_heap *next;                                           //
};                                                                           //
                                                                             //
struct aie_aIEngine_cgi_globale_variablen                                    //
{                                                                            //
   //char var[AIE_AIENGINE_GLOBALE_VARIABLEN_VAR_LEN+1];                     //
   //char val[AIE_AIENGINE_GLOBALE_VARIABLEN_VAL_LEN+1];                     //
   const char *var;                                                          //
   /*const*/ char *val;                                                      //
};                                                                           //
                                                                             //
struct aie_variables                                                         //
{                                                                            //
   const char *var;                                                          //
   //const char var[AIE_ASECUR_VARIABLES_VAR_LEN+1];                         //
   char *(*fkt)(time_t *t, char *buf);                                       //
   char **val;                                                               //
   unsigned int len;                                                         //
};                                                                           //
                                                                             //
struct aie_static_variables                                                  //
{                                                                            //
   //char var[AIE_ASECUR_STATIC_VARIABLES_VAR_LEN + 1];                      //
   //char *val[AIE_ASECUR_STATIC_VARIABLES_VAL_LEN + 1];                     //
   const char *var;                                                          //
   const char *val;                                                          //
};                                                                           //
									     //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
const char *aie_do_var_variable(const char *inp, ...);                       //
const char *aie_do_variable_funktions(int typ, const char *inp);             //
char *aie_variable_fkt_timeoffset(time_t *t, char *buf);                     //
char *aie_variable_fkt_day(time_t *t, char *buf);                            //
char *aie_variable_fkt_month(time_t *t, char *buf);                          //
char *aie_variable_fkt_year(time_t *t, char *buf);                           //
char *aie_variable_fkt_ascdate(time_t *t, char *buf);                        //
void aie_SetAsecurVariable(int typ, const char *var, unsigned int test_len,  //
				   const char *val, char *(*fkt)(time_t *t, char *buf));
struct aie_variable_heap *aie_GetAsecurVariable(int typ, const char *var);   //
const char *aie_GetStandardAsecurVariableValue(const char *var);             //
void aie_FreeGetAsecurVariableHeap(int typ);                                 //
void aie_FreeAsecurAllVariables(void);                                       //
void aie_SetAsecurGlobalVariables(void);                                     //
void aie_SetAsecurStaticVariables(void);
#if 0 // #ifndef _GNUC
void aie_SetAsecurVariablesFromStruct(unsigned int size;
				  int typ,                               //
				  struct aie_variables variables[size],          //
						  unsigned int size);                        //
void aie_SetStaticAsecurVariablesFromStruct(unsigned int size;
				   const struct aie_static_variables      //
					 variables[size],                //
						 unsigned int size);         //
#else
void aie_SetAsecurVariablesFromStruct(int typ,                               //
				  struct aie_variables variables[],          //
				  unsigned int size);                        //
void aie_SetStaticAsecurVariablesFromStruct(const struct aie_static_variables      //
						variables[],                //
						 unsigned int size);         //
#endif
bool aie_Init_aIEngine_cgi_variablen(                                        //
		struct aie_aIEngine_cgi_globale_variablen *cgi_variablen,//
			 unsigned int size);                                     //
void aie_Free_aIEngine_cgi_variablen(void);                                  //
void aie_LogAsecurVariables(char *logfile);                                  //
#ifdef __cplusplus
}
#endif
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

