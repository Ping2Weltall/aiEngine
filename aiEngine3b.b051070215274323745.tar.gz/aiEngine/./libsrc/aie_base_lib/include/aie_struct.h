/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_struct.h                                                */
/* Library     : aiengine-3.nn.nn.so                                         */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 02.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Zentrales Include fuer Strukturen                                         */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_STRUCT_H                                                         //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_STRUCT_H                                                         //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
struct aie_known_parameters                                                  //
{                                                                            //
   /*const*/ char *parameter;                                                //
   /*const*/ char *value;                                                    //
};                                                                           //
                                                                             //
struct aie_env                                                               //
{                                                                            //
   char **var;                                                               //
   char *value;                                                              //
};                                                                           //
                                                                             //
struct aie_is_menue                                                          //
{                                                                            //
   char *entry;                                                              //
   char *funktion;                                                           //
   char *subkat;                                                             //
   struct aie_is_menue *next;                                                //
};                                                                           //
                                                                             //
struct aie_file_text                                                         //
{                                                                            //
   char *txt;                                                                //
   struct aie_file_text *next;                                               //
};                                                                           //
                                                                             //
struct aie_benutzer_rechte
{
   u64 overall;
   u64 benutzer_berechtigung;
   u64 benutzer_sperre;
   u64 gruppen_berechtigung;
   u64 gruppen_sperre;
   unsigned long run_count;
   char *valid_until;
};

struct aie_sitemap_contact
{
   char email[AIE_SITEMAP_EMAIL_LEN + 1];
   char street[AIE_SITEMAP_STREET_LEN + 1];
   char zip[AIE_SITEMAP_ZIPL_LEN + 1];
   char town[AIE_SITEMAP_TOWN_LEN + 1];
   char province[AIE_SITEMAP_PROVINCE_LEN + 1];
   char country[AIE_SITEMAP_COUNTRY_LEN + 1];
   char phone[AIE_SITEMAP_PHONE_LEN + 1];
   char fax[AIE_SITEMAP_FAX_LEN + 1];
};

struct aie_sitemap_department
{
   char name[AIE_SITEMAP_DEPARTMENT_NAME_LEN + 1];
   struct aie_sitemap_contact sitemap_contact;
};

struct aie_sitemap_company
{
   char name[AIE_SITEMAP_COMPANY_NAME_LEN + 1];
   struct aie_sitemap_department sitemap_department;
};

struct aie_sitemap_webmaster
{
   char name[AIE_SITEMAP_WEBMASTER_LEN + 1];
   char email[AIE_SITEMAP_EMAIL_LEN + 1];
};

struct aie_sitemap_robot 
{
   char title[AIE_SITEMAP_TITLE_LEN + 1];
   char description[AIE_SITEMAP_DESCRIPTION_LEN + 1];
   char keywords[AIE_SITEMAP_KEYWORDS_LEN + 1];
   char publisher[AIE_SITEMAP_PUBLISHER_LEN + 1];
   char author[AIE_SITEMAP_AUTHOR_LEN + 1];
   char info[AIE_SITEMAP_INFO_LEN + 1];
   char audience[AIE_SITEMAP_AUDIENCE_LEN + 1];
   char channel[AIE_SITEMAP_CHANNEL_LEN + 1];
   char classification[AIE_SITEMAP_CLASSIFICATION_LEN + 1];
   char robots[AIE_SITEMAP_ROBOTS_LEN + 1];
   char resource_typ[ AIE_SITEMAP_RESOURCE_TYP_LEN + 1];
   char revisit_after[AIE_SITEMAP_REVISIT_AFTER_LEN + 1];
};
                                                                             //
struct aie_sitemap_environment
{
   char generator[AIE_SITEMAP_GENERATOR_LEN + 1];
   char server_software[AIE_SITEMAP_SERVER_SOFTWARE_LEN + 1];
   char operating_system[AIE_SITEMAP_OPERATING_SYSTEM_LEN + 1];
   char language[AIE_SITEMAP_LANGUAGE_LEN + 1];
   struct aie_sitemap_webmaster sitemap_webmaster;
   struct aie_sitemap_company sitemap_company;
   struct aie_sitemap_robot sitemap_robot;
};
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

