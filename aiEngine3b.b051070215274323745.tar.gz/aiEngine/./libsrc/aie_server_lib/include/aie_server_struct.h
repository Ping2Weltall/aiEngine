/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_server_struct.h                                         */
/* Library     : aiengine-server-3.nn.nn.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 10.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_SERVER_STRUCT_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_SERVER_STRUCT_H
                                                                             //
#define AIE_SERVER_INIT_TYP_SERVER				0            //
#define AIE_SERVER_INIT_TYP_PREFORK				1            //
#define AIE_SERVER_INIT_TYP_PASTFORK			        2            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Header Includes                                                    */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* @Secur Internet Engine & HTML Generator Header Includes                   */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Module Header Includes                                                    */
/*...........................................................................*/
                                                                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
struct tel_server_socket 
{
   int msgid;
   int socket_id;
   socklen_t socket_len;
   unsigned int timeout;
   long mtype;
   struct sockaddr *saun;
   pid_t server_pid;
   long start_msg;
   long stop_msg;
   bool exit_server;
   int priority;
};

struct tel_server_fkt
{
   const char *address;
   int (*callback_dispatch_fkt)(struct tel_server_fkt *tel_server_fkt);
   struct tel_server_dispatch_list *dispatch_list;
   unsigned int size_dispatch_list;
   int *rc_usr_fkt;
   void *buf;   
   unsigned int buflen;
   struct tel_server_socket *socket;
   bool (*socket_start_callback)(struct tel_server_fkt *tel_server_fkt);
   bool (*socket_stop_callback)(struct tel_server_fkt *tel_server_fkt);
   const char *caller_file;
   unsigned int caller_line;
   struct tel_server_init *tel_server_init;
};

struct tel_server_init
{
   uid_t uid;
   gid_t gid;
   const char *name;
   const char *modul_name;
   const char *modul_version;
   const char *modul_date;
   const char *modul_time;
   const char *author;
   const char *copyright;
   const char *working_dir;
   const char *basis_dir;
   bool (*init_fkt)(struct tel_server_init *is_tel_server_init);
   long start_msg;
   bool (*socket_start_callback)(struct tel_server_fkt *tel_server_fkt);
   long stop_msg;
   bool (*socket_stop_callback)(struct tel_server_fkt *tel_server_fkt);
   bool (*exit_fkt)(struct tel_server_init *is_tel_server_init);
   struct tel_server_dispatch_list *dispatch_list;
   unsigned int size_dispatch_list;
   int *rc_usr_fkt;
   const char *address;
   int priority;
   unsigned int timeout;
   void *buf;   
   unsigned int buflen;
   unsigned int msg_typ;
   const char *caller_file;
   unsigned int caller_line;
   struct tel_server_fkt *is_tel_server_fkt;
};


struct tel_server_dispatch_list
{
   long mtype;
   int (*fkt)(struct tel_server_fkt *is_tel_server_fkt);
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

