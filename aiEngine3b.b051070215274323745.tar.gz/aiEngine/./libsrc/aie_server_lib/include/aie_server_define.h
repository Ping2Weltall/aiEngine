/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aiengine_server_define.h                                    */
/* Library     : aiengine-server-3.nn.nn.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Anpassungen fuer Server Start/Stop durch    */
/*             :               : WinGui Client                               */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_SERVER_DEFINE_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_SERVER_DEFINE_H

#define AIE_SERVER_MAIN				int main(int argc, char *argv[])

#define AIE_SERVER_STANDARD_RUN_PRIORITY	-3
#define AIE_SERVER_STANDARD_END_PRIORITY	3

#define SERVER_STDIO_PRINTF_FMT		"# "
#define SERVER_STDIO_PRINTF_FMT2	"# %s"
#define SERVER_INFO_STARTFAIL 		"%s(%d): Server %s - Startproblem!"
#define SERVER_INFO_SPEICHER 	\
                            "Server %s - malloc - Startproblem!"

#define SERVER_INFO_HEADER 		SERVER_INFO 	\
                                	SERVER_INFO_HEADERDIV

#define SERVER_INFO		\
    SERVER_INFO_FILED_LINE					\
    printf("%s%s - %s - Version %s\n%sBuild : %s %s\n%s%s\n%s%s\n",	\
		                  SERVER_STDIO_PRINTF_FMT, 	\
		                  is_tel_server_init->name,     \
		                  is_tel_server_init->modul_name,	\
		                  is_tel_server_init->modul_version,	\
		                  SERVER_STDIO_PRINTF_FMT, 		\
				  is_tel_server_init->modul_date, 	\
				  is_tel_server_init->modul_time,	\
		                  SERVER_STDIO_PRINTF_FMT, 		\
    				  is_tel_server_init->author,		\
		                  SERVER_STDIO_PRINTF_FMT, 		\
				  is_tel_server_init->copyright);
#define SERVER_INFO_FILED_LINE 	aie_star_line(79, '#');
#define SERVER_INFO_HEADERDIV 	printf("#"); aie_star_line(78, '-');
//#define SERVER_ERROR_MSG_STARTFAIL 
//	  sys_log(SERVER_INFO_STARTFAIL, __FILE__, __LINE__, 
//             	       	                 is_tel_server_init->modul_name);
//#define SERVER_ERROR_MSG_SPEICHER 	
//	  sys_log(SERVER_INFO_SPEICHER, __FILE__, __LINE__,
//                               		is_tel_server_init->modul_name);
//#define SERVER_SERVER_RECEIVE_MSG_FMT 
//         "%s(%d): Pipe moeglicherweise keine Daten .. rc_status[%s]"


#define RC_SERVER_TEL_MSG_OK					0
#define RC_SERVER_TEL_DISPATCH_OK				0
#define RC_SERVER_TEL_SERVER_START				0xf0ff0000
#define RC_SERVER_TEL_USER_FKT					0x00f00000
#define RC_SERVER_TEL_MSG_UNKNOWN				0x00f10000
#define RC_SERVER_TEL_UNKNOWN					0x00f20000
#define RC_SERVER_TEL_FORK_FAIL					0x00f20000
#define RC_SERVER_TEL_DISPATCH_FAIL				0x00f40000
#define RC_SERVER_TEL_SERVER_STOP				0xf1ff0000
#define RC_SOCKET_SERVER_DO_SOCKET_SERVER_ERR_OUTOFMEM		0xf1100000
#define RC_SOCKET_SERVER_DO_SOCKET_SERVER_ERR_INIT_SEND		0xf1110000
#define RC_SOCKET_SERVER_LOOP_WARN_TIMEOUT			0xe0200000
#define RC_SOCKET_SERVER_LOOP_ERR_UNKNOWN			0xf1200000
#define RC_SOCKET_SERVER_LOOP_ERR_OUTOFMEM      		0xf1210000
#define RC_SOCKET_SERVER_LOOP_ERR_OPEN_SOCKET			0xf1220000
#define RC_SOCKET_SERVER_LOOP_ERR_PARAMETER  			0xf1230000
#define RC_SERVER_SOCKET_SERVER_RECEIVE_ERR_RECV		0xf1300000
#define RC_SERVER_SOCKET_SERVER_RECEIVE_ERR_EMPTY		0xf1310000
#define RC_SERVER_SOCKET_SERVER_RECEIVE_ERR_PARAMETER		0xf1320000
#define RC_SERVER_TEL_MSG_FAIL					-1
                                                                             //
// Verwendet in aie_server_log
// TDODO: Sollte nicht konstant sein sondern variabel
#define aIEngine_ErrorLog       "/aIEngine/data/aiengine/logs/ErrorLog.log"

/*---------------------------------------------------------------------------*/
/* System Header Includes                                                    */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* @Secur Internet Engine & HTML Generator Header Includes                   */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Module Header Includes                                                    */
/*...........................................................................*/
                                                                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
// Keine                                                                     //

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

