/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : aie_server_fkt.c                                            */
/* Library     : aiengine-server-3.nn.nn.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*.............+...............+.............................................*/
/* 14.02.2005  : ALH           : Anpassungen an Cygwin                       */
/*             :               : User und Gruppen ID nicht setzten           */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Anpassungen fuer Server Start/Stop durch    */
/*             :               : WinGui Client                               */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_server_fkt_version         = "1.0.0";                      //
const char *modul_server_fkt                 = "ServerFkt";                  //
const char *modul_server_fkt_date            = __DATE__;                     //
const char *modul_server_fkt_time            = __TIME__;                     //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_LOG_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aiengine.h"

/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *aIEngine_Start_Prog;                                            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static bool aie_server_do_init(struct tel_server_init *is_tel_server_init);  //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_server_fkt_init(int argc, char *argv[], 
                         struct tel_server_init *is_tel_server_init)
{
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_server_fkt_init" }
   };
   #endif
   char *sptr;
   bool rc = false;
   //static char isLokal[] = "Lokal\0";
   static char isUnknown[] = "*Unbekannt*\0";

   SERVER_INFO_HEADER
   // TODO: Variable fuer Logger setzen
   //aIEngine_Start_Prog = isLokal;
   #if AIENGINE_LOG_TRACE_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (strlen(argv[0]) > 0)
   {
      sptr = argv[0] + (strlen(argv[0]) - 1);
      while (sptr > argv[0])
      {
         if (*sptr == '/')
         {
            sptr++;
	    break;
         }
         sptr--;
      }
   }
   else
   {
      sptr = isUnknown;
   }
   aIEngine_Start_Prog = aie_strdup(sptr);
   if (argc < 2)
   {
      printf("%sFehler: Falscher Aufruf von : %s\n", SERVER_STDIO_PRINTF_FMT,
	                        argv[0]);
      printf("%sErlaubte Parameter sind (-r = run, -s = Status, -q = Quit)\n", 
	                                 SERVER_STDIO_PRINTF_FMT);

   }
   else
   {
      rc = aie_server_do_init(is_tel_server_init);
   }
   return(rc);
}

static bool aie_server_do_init(struct tel_server_init *is_tel_server_init)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_server_do_init" },
      { AIE_LOG_ERROR, "Fehler Groupen ID  konnte nicht auf "
	               "%d gesetzt werden!" },
      { AIE_LOG_ERROR, "User ID  konnte nicht auf %d gesetzt werden!" },
      { AIE_LOG_ERROR, "%s Verzeichnisstruktur konnte nicht erstellt werden! "
	               "[%s-%s]" },
      { AIE_LOG_ERROR, "Server [%s] Out of Memory?" },
      { AIE_LOG_ERROR, "Server [%s] Startproblem" },
      { AIE_LOG_ERROR, "Server kann nicht mit NULL Ptr gestartet werden!" }
   };
   struct tel_server_socket *tel_server_socket;
   struct tel_server_fkt *is_tel_server_fkt;
   bool rc = true;
   if (__builtin_expect((is_tel_server_init != NULL), true))
   {
      #ifndef AIE_NO_SETGID
      if (__builtin_expect((is_tel_server_init->gid != 0), true))
      {
         setgid(is_tel_server_init->uid);
         if (__builtin_expect((setgid(is_tel_server_init->gid) == 0),true))
         {
            printf("%sGroupID : %d\n", SERVER_STDIO_PRINTF_FMT,
	                        (int)is_tel_server_init->gid);
         }
         else
         {
            // Fehler Groupen ID  konnte nicht auf %d gesetzt werden!
            aie_sys_log(1, (int)is_tel_server_init->gid);
            printf("%sFehler Groupen ID  konnte nicht auf %d gesetzt werden!\n",
	                        SERVER_STDIO_PRINTF_FMT,
	                        (int)is_tel_server_init->gid);
	    rc = false;
         }
      }
      #endif
      #ifndef AIE_NO_SETUID
      if (__builtin_expect((is_tel_server_init->uid != 0), true))
      {
         if (__builtin_expect((setuid(is_tel_server_init->uid) == 0),true))
         {
            printf("%sUserID  : %d\n", SERVER_STDIO_PRINTF_FMT,
	                        (int)is_tel_server_init->uid);
         }
         else
         {
            // User ID  konnte nicht auf %d gesetzt werden!
            aie_sys_log(2, (int)is_tel_server_init->uid);
            printf("%sFehler User ID  konnte nicht auf %d gesetzt werden!\n",
	                        SERVER_STDIO_PRINTF_FMT,
	                        (int)is_tel_server_init->uid);
	    rc = false;
         }
      }
      #endif
      if (__builtin_expect(((is_tel_server_fkt =
	                               (struct tel_server_fkt *)
                                  aie_malloc(sizeof(struct tel_server_fkt)))
                                                                != NULL),true))
      {
         is_tel_server_fkt->socket_start_callback = 
                                     is_tel_server_init->socket_start_callback; 
         is_tel_server_fkt->socket_stop_callback = 
                                     is_tel_server_init->socket_stop_callback; 
         is_tel_server_fkt->address = is_tel_server_init->address; 
         is_tel_server_fkt->dispatch_list = is_tel_server_init->dispatch_list;
         is_tel_server_fkt->size_dispatch_list = 
	                             is_tel_server_init->size_dispatch_list;
         is_tel_server_fkt->rc_usr_fkt = is_tel_server_init->rc_usr_fkt;
         is_tel_server_fkt->buf = is_tel_server_init->buf;
         is_tel_server_fkt->buflen = is_tel_server_init->buflen;
         is_tel_server_fkt->caller_file = is_tel_server_init->caller_file;
         is_tel_server_fkt->caller_line = is_tel_server_init->caller_line;
         is_tel_server_fkt->tel_server_init = is_tel_server_init;
         is_tel_server_init->is_tel_server_fkt = is_tel_server_fkt;
         if (__builtin_expect(((tel_server_socket =
	                               (struct tel_server_socket *)
                                  aie_malloc(sizeof(struct tel_server_socket)))
                                                                != NULL),true))
         {
            is_tel_server_init->is_tel_server_fkt->socket = tel_server_socket;
            is_tel_server_init->is_tel_server_fkt->socket->socket_len = 
	                                             sizeof(struct sockaddr) +
                        strlen(is_tel_server_init->is_tel_server_fkt->address);
            is_tel_server_init->is_tel_server_fkt->socket->priority = 
	                                          is_tel_server_init->priority;
            is_tel_server_init->is_tel_server_fkt->socket->timeout = 
	                                            is_tel_server_init->timeout;
            is_tel_server_init->is_tel_server_fkt->socket->exit_server = false;
            is_tel_server_init->is_tel_server_fkt->socket->start_msg =
	                                         is_tel_server_init->start_msg; 
            is_tel_server_init->is_tel_server_fkt->socket->stop_msg =
	                                         is_tel_server_init->stop_msg; 
            if (__builtin_expect(
		  (server_check_create_tree(is_tel_server_init->working_dir, 
	                            is_tel_server_init->basis_dir)), true))
            {
               if (__builtin_expect((is_tel_server_init->init_fkt != NULL),true))
               {
                  is_tel_server_init->msg_typ = AIE_SERVER_INIT_TYP_SERVER;
                  rc = (*is_tel_server_init->init_fkt)(is_tel_server_init);
               }
            }
            else
            {
	       // %s Verzeichnisstruktur konnte nicht erstellt werden [%s-%s]
               aie_sys_log(3, is_tel_server_init->modul_name,
		           is_tel_server_init->working_dir, 
	                   is_tel_server_init->basis_dir);
                rc = false;
            }
         }
         else
         {
	    // Keinen speicher bekommen 
            aie_sys_log(4, is_tel_server_init->modul_name);
            rc = false;
         }
      }
      else
      {
         // Keinen speicher bekommen 
         aie_sys_log(4, is_tel_server_init->modul_name);
         rc = false;
      }
      if (!rc)
      {
         // Server [%s] Startproblem
         aie_sys_log(5, is_tel_server_init->modul_name);
      }
      SERVER_INFO_HEADERDIV
      printf("%s%s - Version: %s\n", SERVER_STDIO_PRINTF_FMT,
	                         AIENGINE_LANGNAME, AIENGINE_VERSION);
      SERVER_INFO_FILED_LINE
   }
   else
   {
      // Server kann nicht mit NULL Ptr gestartet werden!
      printf("%s", aie_log_msg_select(6));
      aie_sys_log(6);
      rc = false;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
int aie_server_fkt_run(struct tel_server_init *is_tel_server_init)
{
   int rc = -1;
   if (is_tel_server_init->is_tel_server_fkt != NULL)
   {
      if ((is_tel_server_init->is_tel_server_fkt->socket->server_pid = 
	                                                         fork()) == 0)
      {
	 // Wir setzen es hier weil es sollte sich nicht mehr aendern
         setsid();
         aie_do_socket_server(is_tel_server_init->is_tel_server_fkt);
         if (is_tel_server_init->exit_fkt != NULL)
         {
            rc = (*is_tel_server_init->exit_fkt)(is_tel_server_init);
         }
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_server_fkt_exit(struct tel_server_init *is_tel_server_init)
{
   bool rc = true;
   if (aIEngine_Start_Prog != NULL)
   {
      aie_free(aIEngine_Start_Prog);
   }
   if (is_tel_server_init->is_tel_server_fkt != NULL)
   {
      if (is_tel_server_init->is_tel_server_fkt->socket != NULL)
      {
         pid_t server_pid = 
                    is_tel_server_init->is_tel_server_fkt->socket->server_pid;
	 aie_free(is_tel_server_init->is_tel_server_fkt->socket);
	 aie_free(is_tel_server_init->is_tel_server_fkt);
         if (server_pid == 0)
         {
            #ifndef AIE_FAST_SERVER_NO_CLEANUP_EXIT
            if (!aie_mem_dump())
            {
               aie_mem_usage();
	       rc = false;
            }
            #endif
	 }
      }
    }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_server_fkt_size            = __LINE__;                     //
/* -------------------------------- EOF ------------------------------------ */
