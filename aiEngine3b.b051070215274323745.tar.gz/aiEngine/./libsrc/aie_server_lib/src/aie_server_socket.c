/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_server_socket.c                                         */
/* Library     : aiengine-server-3.nn.nn.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.05.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : const char * als const * deklarieren        */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_mysocket_version         = "1.0.0";                        //
const char *modul_mysocket                 = "mySocket";                     //
const char *modul_mysocket_date            = __DATE__;                       //
const char *modul_mysocket_time            = __TIME__;                       //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_LOG_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include <sys/socket.h>
#include <unistd.h>

/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include "aiengine.h"
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
/*****************************************************************************/

void aie_close_socket(int s)
{
   #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_close_socket" }
   };
   aie_sys_log(0);
   #endif
   //shutdown(s, 2);
   //if (shutdown(s, 2) == 0)
   {
      close(s);
   }
}

bool aie_warten_auf_daten(int fd, unsigned int timeout)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,       "aie_warten_auf_daten" },
      { AIE_LOG_SERVER_INFO, "warten_auf_daten: %s" },
      { AIE_LOG_WARN,        "Keine Daten in innerhalb von [%d] Sekunden" }
   };
   bool rc = true;
   fd_set rfds;
   struct timeval tv;
   int retval;
   FD_ZERO(&rfds);
   FD_SET(fd, &rfds);
   #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
   aie_sys_log(0);
   #endif
   tv.tv_sec = timeout;
   tv.tv_usec = 0;
   if (__builtin_expect(
	    ((retval = select(fd + 1, &rfds, NULL, NULL, &tv)) < 0),false))
   {
      // warten_auf_daten: %s
      aie_sys_log(1, strerror(errno));
      rc = false;
   }
   else
   {
      if (__builtin_expect((retval),true))
      {
      }
      /* FD_ISSET(0, &rfds) muBte jetzt true sein. */
      else
      {
         // Keine Datein innerhalb von [%d] Sekunden
         aie_sys_log(0, timeout);
         rc = false;
      }
   }
   return(rc);
}

int aie_do_socket_server(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_do_socket_server" },
      { AIE_LOG_ERROR, "do_socket_server @ %s(%d) :%s" },
      { AIE_LOG_ERROR, "Out of memory? @ %s(%d) :%s" },
      { AIE_LOG_ERROR, "do_socket_server: Parameter == NULL Ptr" }
   };
   const char *file = is_tel_server_fkt->caller_file; 
   unsigned int line = is_tel_server_fkt->caller_line;
   int rc = -1;
   struct sockaddr *saun;

   #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((is_tel_server_fkt != NULL), true))
   {
       if (__builtin_expect(((saun = 
		   (struct sockaddr *)
		         aie_malloc(is_tel_server_fkt->socket->socket_len + 1))
		                                                != NULL),true))
       {
          saun->sa_family = PF_UNIX;
          strcpy(saun->sa_data, is_tel_server_fkt->address);
	    
          if (__builtin_expect(
	      ((is_tel_server_fkt->socket->socket_id =
	                     aie_init_send_socket(is_tel_server_fkt->address, 
				saun, 
				is_tel_server_fkt->socket->socket_len)) < 0),
	                                                                false))
          {
             // do_socket_server @ %s(%d) :%s
              aie_sys_log(1, file, line, strerror(errno));
             is_tel_server_fkt->socket->exit_server = true;
             rc = RC_SOCKET_SERVER_DO_SOCKET_SERVER_ERR_INIT_SEND;
          }
          else
          {
             rc = aie_do_socket_server_loop(is_tel_server_fkt);
          }
          aie_close_socket(is_tel_server_fkt->socket->socket_id);
          aie_free(saun);
       }
       else
       {
          // Out of memory? @ %s(%d) :%s
          aie_sys_log(2, file, line, strerror(errno));
          rc = RC_SOCKET_SERVER_DO_SOCKET_SERVER_ERR_OUTOFMEM;
          is_tel_server_fkt->socket->exit_server = true;
       }
   }
   else
   {
      // do_socket_server: Parameter == NULL Ptr
      aie_sys_log(3);
   }
    return(rc);
}

int aie_do_socket_server_loop(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,       "aie_do_socket_server_loop" },
      { AIE_LOG_ERROR,       "Out of memory? @ %s(%d) :%s" },
      { AIE_LOG_ERROR,       "Fehler beim Oeffnen @ %s(%d): %d" },
      { AIE_LOG_SERVER_INFO, "do_socket_server_loop: Pipe OK! - Warten auf Daten" },
      { AIE_LOG_ERROR,       "do_socket_server_loop: Parameter == NULL Ptr" }
   };
   int me_exit = -1;

   #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((is_tel_server_fkt != NULL), true))
   {
      const char *file = is_tel_server_fkt->caller_file; 
      unsigned int line = is_tel_server_fkt->caller_line;
      struct sockaddr *fsaun = (struct sockaddr *)
                         aie_malloc(is_tel_server_fkt->socket->socket_len + 1);

       if (__builtin_expect((fsaun == NULL),false))
       {
          // Out of memory? @ %s(%d) :%s
          aie_sys_log(1, strerror(errno));
          is_tel_server_fkt->socket->exit_server = true;
          me_exit = RC_SOCKET_SERVER_LOOP_ERR_OUTOFMEM;
       }
       else
       {
          do
          { 
             if (__builtin_expect(((is_tel_server_fkt->socket->msgid = 
		 aie_open_send_socket(is_tel_server_fkt->socket->socket_id, 
			                  fsaun, 
				  &is_tel_server_fkt->socket->socket_len)) < 0), 
		                                                        false))
             {
	        // Fehler beim Oeffnen @ %s(%d): %d
		aie_sys_log(2, file, line, 
		                         is_tel_server_fkt->socket->socket_id);
	        is_tel_server_fkt->socket->exit_server = true;
	        me_exit = RC_SOCKET_SERVER_LOOP_ERR_OPEN_SOCKET;
	        sleep(1);
             }
             else
             {
                #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
                // Pipe OK! - Warten auf Daten
		aie_sys_log(3);
                #endif
                if (__builtin_expect(
		      (!aie_warten_auf_daten(is_tel_server_fkt->socket->msgid, 
			         is_tel_server_fkt->socket->timeout)),false))
	        {
		   // Pipe moeglicherweise keine Daten .. @ %s(%d) %s",
                   aie_sys_log(4, file, line, strerror(errno));
	           //me_exit = true;
	           is_tel_server_fkt->socket->exit_server = true;
		   me_exit = RC_SOCKET_SERVER_LOOP_WARN_TIMEOUT;
	        }
	        else
	        {
		   me_exit = 
		      aie_socket_server_rcv(is_tel_server_fkt);
                }
	        aie_close_socket(is_tel_server_fkt->socket->msgid);
             }
          } while(!is_tel_server_fkt->socket->exit_server);
          aie_free(fsaun);
       }
   }
   else
   {
      // do_socket_server_loop: Parameter == NULL Ptr
      aie_sys_log(4);
      me_exit = RC_SOCKET_SERVER_LOOP_ERR_PARAMETER;
   }
   return(me_exit);
}

int aie_socket_server_rcv(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_socket_server_rcv" },
      { AIE_LOG_ERROR, "Fehler bei Recv beendet .. @ %s(%d): %s" },
      { AIE_LOG_ERROR, "Leere Botschaft maybe eof() @ %s(%d): %s" },
      { AIE_LOG_ERROR, "aie_socket_server_rcv: Parameter == NULL Ptr" }
   };
   const char *file = is_tel_server_fkt->caller_file; 
   unsigned int line = is_tel_server_fkt->caller_line;
   int size;
   int me_exit = -1;

   #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
   aie_sys_log(0);
   #endif

   errno = 0;
   if (__builtin_expect((is_tel_server_fkt != NULL), true))
   {
      if (__builtin_expect(
	    ((size = recv(is_tel_server_fkt->socket->msgid, 
			  is_tel_server_fkt->buf, 
			  is_tel_server_fkt->buflen, MSG_WAITALL)) < 0),false))
      {
          // Fehler bei Recv beendet .. @ %s(%d): %s
         aie_sys_log(1, file, line, strerror(errno));
         me_exit = RC_SERVER_SOCKET_SERVER_RECEIVE_ERR_RECV;
	 is_tel_server_fkt->socket->exit_server = true;
	 // me_exit = true;
      }
      else
      {
         if (__builtin_expect((size == 0),false))
         {
            //  Leere Botschaft maybe eof() @ %s(%d): %s
            aie_sys_log(2, file, line, strerror(errno));
            me_exit = RC_SERVER_SOCKET_SERVER_RECEIVE_ERR_EMPTY;
	    is_tel_server_fkt->socket->exit_server = true;
	    //me_exit = true;
         }
         else
         {
	    is_tel_server_fkt->socket->mtype = 
	                            (long)*((long *)(is_tel_server_fkt->buf));
            me_exit = aie_server_dispatch(is_tel_server_fkt);
         }
      }
   }
   else
   {
      // Parameter == NULL Ptr
      aie_sys_log(3);
      me_exit = RC_SERVER_SOCKET_SERVER_RECEIVE_ERR_PARAMETER;
   }
   return(me_exit);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_mysocket_size            = __LINE__;                       //
/* -------------------------------- EOF ------------------------------------ */
