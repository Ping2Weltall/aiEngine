/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_server_dispatch.c                                       */
/* Library     : aiengine-server-3.nn.nn.so                                  */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 09.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*             :               : Split client_lib into client_lib & cgi_lib  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_server_dispatch_version     = "1.0.0";                     //
const char *modul_server_dispatch             = "ServerDispatch";            //
const char *modul_server_dispatch_date        = __DATE__;                    //
const char *modul_server_dispatch_time        = __TIME__;                    //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_CLIENT_LIB			1
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_LOG_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Headerdateien                                                      */
/*...........................................................................*/
#include <sys/resource.h>
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/

/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      : aie_server_dispatch                                       */
/* Parameter     : int msgid                                                 */
/*                 void *buf                                                 */
/* Rueckgabewert : int (Werte siehe aie_server_define.h)                     */
/*...........................................................................*/
int aie_server_dispatch(struct tel_server_fkt *is_tel_server_fkt)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,       "aie_server_dispatch" },
      { AIE_LOG_SERVER_INFO, "Server start Telegramm" },
      { AIE_LOG_SERVER_INFO, "Session Leader %d" },
      { AIE_LOG_ERROR, "Server Start pastfork init() Fehler!" },
      { AIE_LOG_ERROR, "Server Start fork() Fehler [%s]!" },
      { AIE_LOG_SERVER_INFO, "Server stop Telegramm" },
      { AIE_LOG_ERROR, "Unbekanntes Telegramm @ %s(%d): tel_msg_id[%ld]" },
      { AIE_LOG_ERROR, "server_dispatch: parameter = NULL Ptr" }
   };
   int rc = RC_SERVER_TEL_DISPATCH_OK;
   #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((is_tel_server_fkt != NULL), true))
   {
      struct tel_server_dispatch_list *dispatch_list = 
                                              is_tel_server_fkt->dispatch_list;
      const char *file = is_tel_server_fkt->caller_file; 
      unsigned int line = is_tel_server_fkt->caller_line;
      struct tel_server_init *is_tel_server_init = 
                                            is_tel_server_fkt->tel_server_init;
      bool found = false;

      for (register unsigned int i = 0;
	                        i < is_tel_server_fkt->size_dispatch_list; i++)
      {
         if (__builtin_expect((dispatch_list->mtype == 
		            is_tel_server_fkt->socket->mtype),false))
         {
	    *is_tel_server_fkt->rc_usr_fkt = 
	                              (*dispatch_list->fkt)(is_tel_server_fkt);
	    found = true;
	    break;
         }
         dispatch_list++;
      }
      if (__builtin_expect((found == false), false))
      {
         if (__builtin_expect((is_tel_server_fkt->socket->mtype == 
	                                is_tel_server_fkt->socket->start_msg),
	                                                               true))
         {
	    bool init_rc = true;
	    id_t fork_rc = 0;
            if (__builtin_expect((is_tel_server_init->init_fkt != NULL),true))
            {
               is_tel_server_init->msg_typ = AIE_SERVER_INIT_TYP_PREFORK;
               init_rc = (*is_tel_server_init->init_fkt)(is_tel_server_init);
            }
            #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
	    // Server start Telegramm
            aie_sys_log(1);
            #endif
	    if (__builtin_expect(((init_rc == true) && 
		              ((fork_rc = fork()) > 0)), true))
	    {
	       pid_t my_pid = getpid();
	       aie_send_prio_message("Server", my_pid, 
		                          is_tel_server_fkt->socket->priority,
					  true);
	       sleep(0);
	       if (__builtin_expect(
		     (is_tel_server_fkt->socket_start_callback != NULL), true))
	       {
	          if (__builtin_expect(
	           (is_tel_server_fkt->socket_start_callback(is_tel_server_fkt)), 
		                                                         true))
	          {
	             aie_server_servermode_loop(is_tel_server_fkt);
	          }
	       }
	       else
	       {
	          aie_server_servermode_loop(is_tel_server_fkt);
	       }
               #ifndef __CYGWIN__
	       setpriority(PRIO_PROCESS, 
		        (id_t)my_pid, 
		        AIE_SERVER_STANDARD_END_PRIORITY);
               #endif
	       is_tel_server_fkt->socket->exit_server = true;
	       rc = RC_SERVER_TEL_SERVER_START;
	    }
	    else
	    {
	       if (__builtin_expect((fork_rc == 0), true))
	       {
                  #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
	          pid_t sid = setsid();
 	          // Session Leader %d
                  aie_sys_log(2, sid);
                  #else
	          setsid();
                  #endif
	          rc = RC_SERVER_TEL_SERVER_START;
                  if (__builtin_expect((is_tel_server_init->init_fkt != NULL),true))
                  {
                     is_tel_server_init->msg_typ = AIE_SERVER_INIT_TYP_PASTFORK;
                     if (__builtin_expect(((init_rc = 
		          (*is_tel_server_init->init_fkt)(is_tel_server_init))
		               == false), false))
		     {
	                // Server Start pastfork init() Fehler!
                        aie_sys_log(3);
		     }
                  }
	          if (__builtin_expect((init_rc == true), true))
	          {
	             is_tel_server_fkt->socket->exit_server = false;
	          }
	          else
	          {
	             is_tel_server_fkt->socket->exit_server = true;
	          }
	       }
	       else
	       {
	          // Server Start fork() Fehler [%s]!
                  aie_sys_log(4, strerror(errno));
	          is_tel_server_fkt->socket->exit_server = true;
	          rc = RC_SERVER_TEL_FORK_FAIL;
	       }
	    }
         }
         else
         {
            if (__builtin_expect((is_tel_server_fkt->socket->mtype == 
	                                  is_tel_server_fkt->socket->stop_msg),
		                                                         true))
            {
               #if AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
	       // Server stop Telegramm
               aie_sys_log(5);
               #endif
	       if (is_tel_server_fkt->socket_stop_callback != NULL)
	       {
	          is_tel_server_fkt->socket_stop_callback(is_tel_server_fkt);
	       }
	       rc = RC_SERVER_TEL_SERVER_STOP;
	       is_tel_server_fkt->socket->exit_server = true;
	    }
	    else
	    {
               // Unbekanntes Telegramm %s(%d): tel_msg_id[%ld]", 
               aie_sys_log(6, file, line, is_tel_server_fkt->socket->mtype);
               rc = RC_SERVER_TEL_MSG_UNKNOWN;
	    }
         }
      }
   }
   else
   {
      // TODO: Moeglicherweise sollte hier rc anders gestetz werden aber
      // dieser Zweig sollte nie ausgefuehrt werden.
      // server_dispatch: parameter = NULL Ptr 
      aie_sys_log(7);
   }
   return(rc); 
}
/*---------------------------------------------------------------------------*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
const int   modul_server_dispatch_size        = __LINE__;                    //
/* -------------------------------- EOF ------------------------------------ */
