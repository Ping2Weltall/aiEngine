/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_wingui_session.c                                        */
/* Library     : Core aiengine-nn.nn.nn.a                                    */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 07.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Alle Logmeldungen Anpassen auf WinGui Client*/
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aie_wingui_session_version = "1.0.0";                      //
const char *modul_aie_wingui_session         = "aieWinGuiSession";           //
const char *modul_aie_wingui_session_date    = __DATE__;                     //
const char *modul_aie_wingui_session_time    = __TIME__;                     //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_DB_LIB		1
#define AIENGINE_USE_SQL_WRAP_LIB	1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern struct aie_sql_meta_db aiengine_sql_meta_db;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
static bool SerialhasEntry = false;
static char *SerialValidUntil = NULL;
static long SerialRunCount = 0;
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct callback_data
{
    int dummy;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static int aie_callback_select_modul_registry(void *pArg, int nArg, char **azArg, 
		                                       char **azCol);
static bool check_update_modul_registry(char *Seriennummer, 
                                    struct aie_sql_data *aie_sql_data);
static bool update_modul_registry(char *Seriennummer, char *timestamp, 
                           struct aie_sql_data *aie_sql_data);
static struct aie_sql_data *InitBackgroundDB(void);                          //
bool ExitBackgroundDB(void);                                                 //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
bool aie_wingui_haveRights(char *Seriennummer, char *Session, char *IP,
                           struct aie_cgi_parameter *cgi_parameter)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,         "aie_wingui_haveRights Session[%s]" },
      { AIE_LOG_SECURITY_INFO, "Transaktion von [%s] [%s] [%s] - %p" },
      { AIE_LOG_ERROR,         "Die Registrierungsdatenbank konnte nicht "
	                       "gepr�ft werden!" }
   };
   bool rc = false;
   struct aie_sql_data *aie_sql_data;
   aie_sys_log(0, Session);
   // Transaktion von [%s] [%s] [%s] - %p
   aie_sys_log(1, Seriennummer, Session, IP, cgi_parameter);
   if ((aie_sql_data = InitBackgroundDB()) != NULL)
   {
      rc = check_update_modul_registry(Seriennummer, aie_sql_data);
      ExitBackgroundDB();
   }
   else
   {
      // Fehler: Die Registrierungsdatenbank konnte nicht gepr�ft werden!
      html_static(aie_log_msg_select(2));
      aie_sys_log(2);
      rc = false;
   }
    return(rc);
}

static bool check_update_modul_registry(char *Seriennummer, 
                                    struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "check_update_modul_registry Serial[%s]" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR,    "Out of Memory?" },
      { AIE_LOG_SECURITY, "Versuch mit unbekannter Seriennummer %s "
	                  "zu arbeiten!" }
   };
   bool rc = false;
   aie_sys_log(0, Seriennummer);
   if (Seriennummer != NULL)
   {
      struct callback_data callback_data;
      char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
      if (sql_cmd != NULL)
      {
         *sql_cmd = '\0';
         aie_sql_data->callback = aie_callback_select_modul_registry;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = (void *)&callback_data;

         sprintf(sql_cmd, "SELECT %s, %s FROM %s WHERE %s='%s'", 
			                         is_aie_ValidUntilDateSqlFld,
						 is_aie_RunCountSqlFld,
						 AIE_DB_TABLE_MODUL_REGISTER,
	                                         is_aie_SeriennummerSqlFld,
						 Seriennummer);
         if (!aie_sql_run(aie_sql_data))
         {
	    // TODO: sqlite3 nicht direkt aufrufen fuer andere DB
            // DB Fehler %s[%s]", __FILE__, __LINE__, 
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
         }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
      if(!SerialhasEntry)
      {
         // Versuch mit unbekannter Seriennummer %s zu arbeiten!",
         aie_sys_log(3, Seriennummer);
         html_vt("Fehler: Die Seriennummer ist im System nicht bekannt!\nWenden sie sich bitte an Ihren Support.");
      }
      else
      {
         if ((SerialValidUntil != NULL) && (*SerialValidUntil != '\0'))
         {
            char *timestamp = aie_get_time_stamp();
	    if (strncmp(timestamp, SerialValidUntil, 8) < 0)
	    {
	       html_static("Fehler: Die Gueltigkeitsdauer der von Ihnen eingegebenen Seriennummer ist abgelaufen. Wenden Sie sich bitte an Ihren Provider um eine neue Seriennummer zu erhalten!");
	    }
	    else
	    {
               rc = update_modul_registry(Seriennummer, timestamp, 
		                          aie_sql_data);
	    }
         }
         else
         {
            html_vt("Fehler: Die von Ihnen verwendete Seriennummer konnte nicht ausgewertet werden! Wenden Sie sich bitte an Ihren Support! - OpCode:%ld-%s / ",
		  SerialRunCount, SerialValidUntil);
         }
         if (SerialValidUntil != NULL)
         {
	    aie_free(SerialValidUntil);
         }
      }
   }
   return(rc);
}

static int aie_callback_select_modul_registry(void *pArg, int nArg, 
                                                       char **azArg, 
		                                       char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_callback_select_modul_registry" },
      { AIE_LOG_ERROR, "Keine Callback Daten!" },
      { AIE_LOG_ERROR, "Unbekannte Spalte[%s]" }
   };
   struct aie_sql_data *callback_aie_sql_data = (struct aie_sql_data *)pArg;
   struct callback_data *callback_data = 
                          (struct callback_data *)callback_aie_sql_data->data;
   SerialhasEntry = true;

   if(callback_data == NULL)
   {
     // Keine Callback Daten!
     aie_sys_log(1);
   }
   else
   {
      for(int i=0; i<nArg; i++)
      {
	 if (strcmp(azCol[i], is_aie_ValidUntilDateSqlFld) == 0)
	 {
	    SerialValidUntil = aie_strdup(azArg[i]);
	 }
	 else if (strcmp(azCol[i], is_aie_RunCountSqlFld) == 0)
	 {
	    SerialRunCount = atol(azArg[i]);
	 }
	 else
	 {
	    // Unbekannte Spalte[%s]
            aie_sys_log(2, azCol[i]);
	 }
      }
   }
   return(0);
}

static bool update_modul_registry(char *Seriennummer, char *timestamp,
                           struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "aie_update_modul_registry Seriennummer[%s]" },
      { AIE_LOG_SECURITY, "DB Fehler %s[%s]" },
      { AIE_LOG_ERROR,    "Out of Memory?" }
   };
   bool rc = false;

   aie_sys_log(0, Seriennummer);
   if (Seriennummer != NULL)
   {
      char *sql_cmd = (char *)aie_malloc(1024);
      if (sql_cmd != NULL)
      {
	 char NewRunCount[8];
	 sprintf(NewRunCount, "%ld", (SerialRunCount + 1));
         *sql_cmd = '\0';
         aie_sql_data->callback = NULL;
         aie_sql_data->sql_cmd = sql_cmd;
         aie_sql_data->data = NULL;

         sprintf(sql_cmd, "UPDATE %s SET %s='%s', "
				        "%s='%s' "
				        "WHERE %s='%s'", 
						 AIE_DB_TABLE_MODUL_REGISTER,
						 is_aie_LastRunSqlFld,
                                                 timestamp,
						 is_aie_RunCountSqlFld,
                                                 NewRunCount,
			                         is_aie_SeriennummerSqlFld,
						 Seriennummer);
         if (!aie_sql_run(aie_sql_data))
         {
	    // TODO: sqlite3 Referenz 
            // DB Fehler %s[%s]
            aie_sys_log(1, sqlite3_errmsg(aie_sql_data->sql_db_data->db),
 	                                                              sql_cmd);
         }
	 else
	 {
	    rc = true;
	 }
         aie_free(sql_cmd);
      }
      else
      {
	 // Out of Memory?
         aie_sys_log(2);
      }
   }
   return(rc);
}

static struct aie_sql_data *InitBackgroundDB(void)
{
   return(aie_sql_meta_attach_db(AIE_DB_ID_AIENGINE, &aiengine_sql_meta_db));
}

bool ExitBackgroundDB(void)
{
   return(aie_sql_meta_release_db(&aiengine_sql_meta_db));
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_aie_wingui_session_size    = __LINE__;                           //
/* -------------------------------- EOF ------------------------------------ */

