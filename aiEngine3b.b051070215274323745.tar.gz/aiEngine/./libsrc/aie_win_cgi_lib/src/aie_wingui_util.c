/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_gui_util.c                                              */
/* Library     : Core aiengine-nn.nn.nn.a                                    */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 05.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aie_gui_util_version = "1.0.0";                            //
const char *modul_aie_gui_util         = "aieGuiUtil";                       //
const char *modul_aie_gui_util_date    = __DATE__;                           //
const char *modul_aie_gui_util_time    = __TIME__;                           //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert : char *                                                    */
/*...........................................................................*/
char *aie_wingui_GetScreenCGIVar2FeldName(char *CGIVar,
                            struct aie_wingui_screen_feld_var *screen_feld_var,
			    unsigned int size)
{
   static char Feldname[50];
   const char *LookFor;
   char *rc_ptr = NULL;
   register unsigned int i;
   for (i = 0;(i < size) && (CGIVar != NULL); i++)
   {
      if (strcmp(CGIVar, screen_feld_var->CGIVar) == 0)
      {
         LookFor = NULL;
         switch(screen_feld_var->typ)
         {
            case AIE_SCREEN_TYPE_TEXT:
            {
               LookFor = "Label";
            }
            break;
            case AIE_SCREEN_TYPE_COMBOBOX:
            {
                LookFor = "ComboBox";
            }
            break;
            case AIE_SCREEN_TYPE_EDIT:
            case AIE_SCREEN_TYPE_MASK_EDIT:
            {
                LookFor = "Edit";
            }
            break;
            case AIE_SCREEN_TYPE_MEMO:
            {
                LookFor = "Memo";
            }
            break;
            case AIE_SCREEN_TYPE_IMAGE:
            {
                LookFor = "Image";
            }
         }
         if (LookFor != NULL)
         {
	    char *sptr;
	    memset(Feldname, '\0', sizeof(Feldname));
            strncpy(Feldname, screen_feld_var->Feld, sizeof(Feldname)-1);
            if ((sptr = strstr(Feldname, LookFor)) != NULL)
            {
                 *sptr = '\0';
            }
	    rc_ptr = Feldname;
            break;
	 }
      }
      screen_feld_var++;
   }
   return(rc_ptr);
}

int aie_wingui_GetScreenCGIVarFeldTyp(char *CGIVar,
                            struct aie_wingui_screen_feld_var *screen_feld_var,
			    unsigned int size)
{
   int rc = -1;
   register unsigned int i;
   for (i = 0;(i < size) && (CGIVar != NULL); i++)
   {
      if (strcmp(CGIVar, screen_feld_var->CGIVar) == 0)
      {
         rc = screen_feld_var->typ;
	 break;
      }
      else
      {
	 screen_feld_var++;
      }
   }
   return(rc);
}

char *aie_wingui_GetScreenValueFromCGIVar(char *CGIVar,
                            struct aie_wingui_screen_feld_var *screen_feld_var,
			    unsigned int size)
{
   char *rc_ptr = NULL;
   register unsigned int i;
   for (i = 0;(i < size) && (CGIVar != NULL); i++)
   {
      if (strcmp(CGIVar, screen_feld_var->CGIVar) == 0)
      {
         rc_ptr = screen_feld_var->Value;
         break;
      }
      screen_feld_var++;
   }
   return(rc_ptr);
}


char *aie_wingui_GetComboFeldIdNummer(char *feld, char *value,
                       struct aie_wingui_ComboFeld2List *ComboFeld2List,
		       unsigned int size)
{
   char *rc_ptr = NULL;
   if ((feld != NULL) && (value != NULL))
   {
      if ((*feld != '\0') && (*value != '\0'))
      {
         register unsigned int i;
         for (i = 0; i < size; i++)
         {
            if (strcmp(feld, ComboFeld2List->ComboBox) == 0)
            {
               struct aie_wingui_ComboBoxListing *ComboBoxListe;
               if ((ComboBoxListe = ComboFeld2List->ComboBoxListe) != NULL)
               {
                  register unsigned int z;
                  for (z = 0; z < ComboFeld2List->Size; z++)
                  {
                     if (strcmp(value, ComboBoxListe->Text) == 0)
                     {
                        rc_ptr = ComboBoxListe->Id;
                        break;
                     }
                     else
                     {
                        ComboBoxListe++;
                     }
                  }
               }
               break;
            }
            ComboFeld2List++;
         }
      }
   }
   return(rc_ptr);
}

char *aie_wingui_GetComboFeldIdText(char *feld, char *value,
                       struct aie_wingui_ComboFeld2List *ComboFeld2List,
		       unsigned int size)
{
   char *rc_ptr = NULL;
   if ((feld != NULL) && (value != NULL))
   {
      if ((*feld != '\0') && (*value != '\0'))
      {
         register unsigned int i;
         for (i = 0; i < size; i++)
         {
            if (strcmp(feld, ComboFeld2List->ComboBox) == 0)
            {
               struct aie_wingui_ComboBoxListing *ComboBoxListe;
               if ((ComboBoxListe = ComboFeld2List->ComboBoxListe) != NULL)
               {
                  register unsigned int z;
                  for (z = 0; z < ComboFeld2List->Size; z++)
                  {
                     if ((strcmp(value, ComboBoxListe->Id) == 0) ||
                         (atoi(value) == atoi(ComboBoxListe->Id)))
                     {
                        rc_ptr = ComboBoxListe->Text;
                        break;
                     }
                     else
                     {
                        ComboBoxListe++;
                     }
                  }
               }
               break;
            }
            ComboFeld2List++;
         }
      }
   }
   return(rc_ptr);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_aie_gui_util_size    = __LINE__;                                 //
/* -------------------------------- EOF ------------------------------------ */

