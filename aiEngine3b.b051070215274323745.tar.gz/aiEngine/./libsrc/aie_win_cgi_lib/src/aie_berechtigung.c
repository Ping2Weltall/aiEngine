/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_berechtigung.c                                          */
/* Library     : aiengine_win_cgi-3.nn.nn.so                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 05.10.2003                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#define AIENGINE_USE_BASE_LIB			1

#include "aiengine.h"

struct aie_berechtigungen aie_berechtigungen[] =
{
   { "Keine Berechtigung",
         AIE_BERECHTIGUNG_KEINE,                        false },
   { "Status Monitor",
         AIE_BERECHTIGUNG_STATUS_MONITOR,               false },
   { "Server Start",
         AIE_BERECHTIGUNG_START_SERVER,                 false },
   { "Server Stop",
         AIE_BERECHTIGUNG_STOP_SERVER,                  false },
   { "System Server",
         AIE_BERECHTIGUNG_SYSTEM_SERVER,                false },
   { "Ansicht Gruppen",
         AIE_BERECHTIGUNG_ANSICHT_GRUPPEN,              false },
   { "Ansicht Benutzer",
         AIE_BERECHTIGUNG_ANSICHT_BENUTZER,             false },
   { "Ansicht Berechtigungen",
         AIE_BERECHTIGUNG_ANSICHT_BENUTZER_RECHTE,      false },
   { "Ansicht eigene Module",
         AIE_BERECHTIGUNG_ANSICHT_EIGENE_MODULE,        false },
   { "Ansicht Modul Info",
		 AIE_BERECHTIGUNG_ANSICHT_MODUL_INFO,   false },
   { "Eigene Benutzerdaten �ndern",
         AIE_BERECHTIGUNG_AENDERN_EIGENEN_BENUTZER,     false },
   { "Benutzer sperren",
         AIE_BERECHTIGUNG_SPERREN_BENUTZER,             false },
   { "Neuen Benutzer eintragen",
         AIE_BERECHTIGUNG_NEUER_BENUTZER,               false },
   { "Benutzer �ndern",
         AIE_BERECHTIGUNG_AENDERN_BENUTZER,             false },
   { "Benutzer l�schen",
         AIE_BERECHTIGUNG_LOESCHEN_BENUTZER,            false },
   { "Passworte ansehen/�ndern",
         AIE_BERECHTIGUNG_ANSICHT_AENDERN_USER_PASSWORT,false },
   { "Benutzer Rechte �ndern",
         AIE_BERECHTIGUNG_AENDERN_BENUTZER_RECHTE,      false },
   { "Neue Gruppe anlegen",
		 AIE_BERECHTIGUNG_NEUE_GRUPPE,          false },
   { "Gruppe ver�ndern",
         AIE_BERECHTIGUNG_AENDERN_GRUPPE,               false },
   { "Gruppe sperren",
         AIE_BERECHTIGUNG_SPERREN_GRUPPE,               false },
   { "Gruppe l�schen",
         AIE_BERECHTIGUNG_LOESCHEN_GRUPPE,              false },
   { "Gruppen Rechte �ndern",
         AIE_BERECHTIGUNG_AENDERN_GRUPPEN_RECHTE,       false },
   { "Adminrechte vergeben",
         AIE_BERECHTIGUNG_NEUER_ADMIN,                  false },
   { "SysOP rechte vergeben",
         AIE_BERECHTIGUNG_NEUER_SYSOP,                  false },
   { "Open SQL Select",
         AIE_BERECHTIGUNG_OPEN_SQL_SELECT,              false },
   { "Open SQL Insert",
         AIE_BERECHTIGUNG_OPEN_SQL_INSERT,              false },
   { "Open SQL Update",
         AIE_BERECHTIGUNG_OPEN_SQL_UPDATE,              false },
   { "Open SQL Delete",
         AIE_BERECHTIGUNG_OPEN_SQL_DELETE,              false },
   { "Free Open SQL",
         AIE_BERECHTIGUNG_FREE_OPEN_SQL,                false },
   { "Modul Information �ndern",
         AIE_BERECHTIGUNG_AENDERN_MODUL_INFO,           false },
   { "Modul Information l�schen",
         AIE_BERECHTIGUNG_LOESCHEN_MODUL_INFO,          false },
   { "Ansicht Seriennummern Pool",
         AIE_BERECHTIGUNG_ANSICHT_SERIAL_POOL,          false },
   { "Neue Seriennummern vergeben",
         AIE_BERECHTIGUNG_NEU_SERIENNUMMERN,            false },
   { "Seriennummern �ndern",
         AIE_BERECHTIGUNG_AENDERN_SERIENNUMMERN,        false }
};

unsigned int size_aie_berechtigungen = sizeof(aie_berechtigungen) /
                                       sizeof(struct aie_berechtigungen);

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_berechtigung_size         = __LINE__;                            //
/* -------------------------------- EOF ------------------------------------ */
