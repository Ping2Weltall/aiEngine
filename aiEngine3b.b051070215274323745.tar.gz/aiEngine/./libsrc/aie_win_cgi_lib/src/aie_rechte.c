/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Engine core                                          */
/* Modul       : aie_rechte.c                                                */
/* CGI         : Engine Core                                                 */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 18.01.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_rechte_version   = "1.0.0";                                //
const char *modul_rechte           = "Rechte";                               //
const char *modul_rechte_date      = __DATE__;                               //
const char *modul_rechte_time      = __TIME__;                               //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB		1
#define AIENGINE_USE_CLIENT_LIB		1
#define AIENGINE_USE_DB_LIB		1
#define AIENGINE_USE_SQL_WRAP_LIB	1
#define AIENGINE_USE_LOG_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *cgiUserAgent;                                                   //
extern struct aie_sql_meta_db aiengine_sql_meta_db;                          //
extern struct aie_benutzer_rechte aie_benutzer_rechte;                       //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
static bool hasUserRecord = false;                                           //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static int aie_benutzer_rechte_callback(void *pArg, int nArg, char **azArg,  //
                                                             char **azCol);  //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
                                                                             //
/*****************************************************************************/

u64 aie_get_benutzer_rechte(char *UserId, bool UpdateCount)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "aie_get_benutzer_rechte "
	                  "UserId[%s] Updatecount[%d]" },
      { AIE_LOG_SECURITY, "Benutzerrechte sind schon gesetzt! "
	                  "[%X-%X-%X-%X-%X]" },
      { AIE_LOG_SECURITY, "Fuer Benutzer %s konnten keine Zugriffsrechte "
	                  "ermittelt werden!" },
      { AIE_LOG_SECURITY, "Benutzerberechtigung %s abgelaufen am %s" },
      { AIE_LOG_ERROR,    "Konnte Datenbank nicht oeffnen!" },
      { AIE_LOG_ERROR,    "Out of Memory?!" }
   };
   char *sql_cmd = NULL;
   struct aie_sql_data *aie_sql_data = NULL;
   struct aie_sql_meta_db *aie_sql_meta_db = NULL;

   aie_sys_log(0, UserId, UpdateCount);

   if ((aie_benutzer_rechte.overall != 0L) ||
       (aie_benutzer_rechte.benutzer_berechtigung != 0L) ||
       (aie_benutzer_rechte.benutzer_sperre != 0L) ||
       (aie_benutzer_rechte.gruppen_berechtigung != 0L) ||
       (aie_benutzer_rechte.gruppen_sperre != 0L))
   {
      // Benutzerrechte sind schon gesetzt! [%X-%X-%X-%X-%X]
      aie_sys_log(1, aie_benutzer_rechte.overall,
                     aie_benutzer_rechte.benutzer_berechtigung,
                     aie_benutzer_rechte.benutzer_sperre,
                     aie_benutzer_rechte.gruppen_berechtigung,
                     aie_benutzer_rechte.gruppen_sperre);
   }
   aie_benutzer_rechte.overall = 0L;
   aie_benutzer_rechte.benutzer_berechtigung = 0L;
   aie_benutzer_rechte.benutzer_sperre = 0L;
   aie_benutzer_rechte.gruppen_berechtigung = 0L;
   aie_benutzer_rechte.gruppen_sperre = 0L;
   aie_benutzer_rechte.run_count = 0L;
   aie_benutzer_rechte.valid_until = NULL;

   if (((sql_cmd = aie_malloc(AIE_SQL_BUFFER_LEN)) != NULL) &&
      ((aie_sql_meta_db = aie_malloc(sizeof(struct aie_sql_meta_db))) != NULL))
   {
      hasUserRecord = false;
      *sql_cmd = '\0';
      memcpy(aie_sql_meta_db, &aiengine_sql_meta_db, 
	                                       sizeof(struct aie_sql_meta_db));
      aie_sql_meta_db->aie_sql_data = NULL;
      if ((aie_sql_data = aie_sql_meta_attach_db(AIE_DB_ID_AIENGINE, 
	                                         aie_sql_meta_db)) != NULL)
      {
	 sprintf(sql_cmd, "SELECT a.%s AS a%s, a.%s AS a%s, a.%s, a.%s, b.%s, b.%s "
	                  "FROM %s a, %s b "
		          "WHERE %s = '%s' AND a.%s = b.%s", 
			     is_aie_BerechtigungSqlFld,
			     is_aie_BerechtigungSqlFld,
			     is_aie_SperreSqlFld,
			     is_aie_SperreSqlFld,
                             is_aie_RunCountSqlFld,
			     is_aie_ValidUntilDateSqlFld,
			     is_aie_BerechtigungSqlFld,
			     is_aie_SperreSqlFld,
			     AIE_DB_TABLE_USER,
			     AIE_DB_TABLE_USER_GRUPPEN,
			     is_aie_UserIdSqlFld, UserId,
			     is_aie_UserGruppeSqlFld, is_aie_UserGruppeSqlFld);
	 aie_sql_data->callback = aie_benutzer_rechte_callback;
	 aie_sql_data->sql_cmd = sql_cmd;
	 aie_sql_data->data = NULL;
         //sys_log("%s(%d): Cmd[%s]", __FILE__, __LINE__, sql_cmd);

	 if (!aie_sql_run(aie_sql_data))
	 {
	     // DB Fehler %s[%s]
             aie_sys_log_sql_meta_error(aie_sql_meta_db, sql_cmd);
             if (AIE_AGENT_AIENGINE)
             {
	        html_vt("Fehler: %s\n", aie_sql_meta_error(aie_sql_meta_db)); 
		//	      sqlite3_errmsg(aie_sql_data->sql_db_data->db));
	     }
         }
	 else
	 {
	    if (!hasUserRecord)
	    {
	       // Fuer Benutzer %s konnten keine Zugriffsrechte 
	       // ermittelt werden!
               aie_sys_log(2, UserId);
	    }
	    else
	    {
	       if ((aie_benutzer_rechte.valid_until == NULL) ||
		     (strcmp(aie_benutzer_rechte.valid_until, 
			    aie_get_time_stamp()) < 0))
	       {
                  if (AIE_AGENT_AIENGINE)
                  {
		     html_vt(
			 "Fehler: Ihre Benutzerberechtigung ist abgelaufen! Bitte wenden Sie sich an Ihren Provider!\n");
		  }
		  // Benutzerberechtigung %s abgelaufen am %s
                  aie_sys_log(3, UserId, aie_benutzer_rechte.valid_until);
                  aie_benutzer_rechte.overall = 0L;
                  aie_free(aie_benutzer_rechte.valid_until);
                  aie_benutzer_rechte.valid_until = NULL;
	       }
	       else
	       {
	          u64 tmp = ~(aie_benutzer_rechte.benutzer_sperre |
                          aie_benutzer_rechte.gruppen_sperre);
                  //sys_log("%s(%d): tmp=%LX", __FILE__, __LINE__, tmp);
                  aie_benutzer_rechte.overall = 
                          (aie_benutzer_rechte.benutzer_berechtigung |
                           aie_benutzer_rechte.gruppen_berechtigung) & tmp;
                  //sys_log("%s(%d): Benutzer Rechte=%LX", __FILE__, __LINE__, aie_benutzer_rechte.benutzer_berechtigung);
                  //sys_log("%s(%d): Gruppen Rechte=%LX", __FILE__, __LINE__, aie_benutzer_rechte.gruppen_berechtigung);
	       }
	       if (UpdateCount)
	       {
	          sprintf(sql_cmd, "UPDATE %s "
		                "SET %s = %ld, "
		                "    %s = '%s' "
		                "WHERE %s = '%s'",
			        AIE_DB_TABLE_USER,
                                is_aie_RunCountSqlFld,
	                        aie_benutzer_rechte.run_count + 1,
                                is_aie_LastRunSqlFld,
			        aie_get_time_stamp(),
			        is_aie_UserIdSqlFld, UserId);
	          aie_sql_data->callback = NULL;
	          aie_sql_data->sql_cmd = sql_cmd;
	          aie_sql_data->data = NULL;
	          if (!aie_sql_run(aie_sql_data))
	          {
	             // DB Fehler %s[%s]
                     aie_sys_log_sql_meta_error(aie_sql_meta_db, sql_cmd);
	          }
	       }
	    }
	 }
         aie_sql_meta_release_db(aie_sql_meta_db);
      }
      else
      {
	 // Konnte Datenbank nicht oeffnen!
         aie_sys_log(4);
	 if (AIE_AGENT_AIENGINE)
	 {
	    html_vt("Fehler: Datenbank konnte nicht geoeffnet werden!\n");
	 }
      }
  }
  else
  {
     aie_sys_log(5);
     if (AIE_AGENT_AIENGINE)
     {
        html_vt("Fehler: Hostrechner - Out of Memory?!\n");
     }
  }    
  if (sql_cmd != NULL)
  {
     aie_free(sql_cmd);
  }
  if (aie_sql_meta_db != NULL)
  {
     aie_free(aie_sql_meta_db);
  }
  return(aie_benutzer_rechte.overall);
}

static int aie_benutzer_rechte_callback(void *pArg, int nArg, char **azArg,
                                                             char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "aie_benutzer_rechte_callback" },         
      { AIE_LOG_SECURITY, "Fehler mehr als ein Benutzer Datensatz!" },
      { AIE_LOG_TRACE,    "aie_benutzer_rechte_callback .. done[%LX]" }
   };
   int rc = 0;
   register int z;

   aie_sys_log(0);
   pArg = pArg;
   if (hasUserRecord)
   {
      // Fehler mehr als ein Benutzer Datensatz!
      aie_sys_log(1);
      rc = 1;
   }
   else
   {
      hasUserRecord = true;
      for (z = 0; z < nArg; z++)
      {
         //sys_log("%s(%d): %s=%s", __FILE__, __LINE__, azCol[z], azArg[z]); 
	 if ((azCol[z] != NULL) && (azArg[z] != NULL))
	 { 
	    if (strstr(azCol[z], is_aie_BerechtigungSqlFld) != NULL)
	    {
	       if (*azCol[z] == 'a')
	       {
                  aie_benutzer_rechte.benutzer_berechtigung = 
		                                     hex_str_to_u64(azArg[z]);
	       }
	       else
	       {
                  aie_benutzer_rechte.gruppen_berechtigung = 
		                                     hex_str_to_u64(azArg[z]);
	       }
	    }
	    else if (strstr(azCol[z], is_aie_SperreSqlFld) != NULL)
	    {
	       if (*azCol[z] == 'a')
	       {
                  aie_benutzer_rechte.benutzer_sperre = 
		                                     hex_str_to_u64(azArg[z]);
	       }
	       else
	       {
                  aie_benutzer_rechte.gruppen_sperre = hex_str_to_u64(azArg[z]);
	       }
	    }
	    else if (strstr(azCol[z], is_aie_RunCountSqlFld) != NULL)
	    {
               aie_benutzer_rechte.run_count = atol(azArg[z]);
	    }
	    else if (strstr(azCol[z], is_aie_ValidUntilDateSqlFld) != NULL)
	    {
               aie_benutzer_rechte.valid_until = aie_strdup(azArg[z]);
	    }
	 }
      }
   }
   aie_sys_log(2, aie_benutzer_rechte.benutzer_berechtigung);
   return(rc);
}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_rechte_size      = __LINE__;                                     //
/* -------------------------------- EOF ------------------------------------ */

