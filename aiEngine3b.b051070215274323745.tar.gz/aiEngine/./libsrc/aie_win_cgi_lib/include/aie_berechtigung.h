/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_berechtigung.h                                          */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 16.01.2005                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Enthaelt die Bit Flags fuer verschiedene - wenn nicht gar alle -  Engine  */
/* funktionen.                                                               */
/* Die Konstanten sind doppelt definiert wegen der unterschiedlichen Sufixe  */
/* des *nix und Windoze compilers.                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2006 Alexander Joerg Herrmann                                    */
/*               Email: Ping2Weltall@GMail.com                               */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_BERECHTIGUNG_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_BERECHTIGUNG_H

#if __GNUC__

#define AIE_BERECHTIGUNG_KEINE                          0x0000000000000000L
#define AIE_BERECHTIGUNG_APPL_STANDARD                  AIE_BERECHTIGUNG_KEINE

// Verschidene WinGui Clients
#define AIE_BERECHTIGUNG_STATUS_MONITOR                 0x0000000000000001L
#define AIE_BERECHTIGUNG_WINGUI_APPLICATION             0x0000000000000002L

// Fur Future use
// Reserviert                                           0x0000000000000004L
// Reserviert                                           0x0000000000000008L

// Server funktionen
#define AIE_BERECHTIGUNG_ANSICHT_SERVER                 0x0000000000000010L
#define AIE_BERECHTIGUNG_START_SERVER                   0x0000000000000020L
#define AIE_BERECHTIGUNG_STOP_SERVER                    0x0000000000000040L
#define AIE_BERECHTIGUNG_SYSTEM_SERVER                  0x0000000000000080L

// Berechtigungen fuer verschienden Ansichten
#define AIE_BERECHTIGUNG_ANSICHT_GRUPPEN                0x0000000000000100L
#define AIE_BERECHTIGUNG_ANSICHT_BENUTZER               0x0000000000000200L
#define AIE_BERECHTIGUNG_ANSICHT_BENUTZER_RECHTE        0x0000000000000400L
#define AIE_BERECHTIGUNG_ANSICHT_EIGENE_MODULE          0x0000000000000800L

#define AIE_BERECHTIGUNG_ANSICHT_LOGFILE                0x0000000000001000L

// Fur Future use
// Reserviert                                           0x0000000000002000L
// Reserviert                                           0x0000000000004000L
// Reserviert                                           0x0000000000008000L

// Berechtigungen nur den eigenen Benutzer betreffend
#define AIE_BERECHTIGUNG_AENDERN_EIGENEN_BENUTZER       0x0000000000010000L

// Fur Future use
// Reserviert                                           0x0000000000020000L
// Reserviert                                           0x0000000000040000L
// Reserviert                                           0x0000000000080000L

// Ansicht Open SQL und Select
#define AIE_BERECHTIGUNG_ANSICHT_OPEN_SQL               0x0000000000100000L
#define AIE_BERECHTIGUNG_OPEN_SQL_SELECT                0x0000000000200000L
#define AIE_BERECHTIGUNG_OPEN_SQL_PREDEFINED_SQL        0x0000000000400000L

// Fur Future use
// Reserviert                                           0x0000000000800000L

// Benutzer
#define AIE_BERECHTIGUNG_SPERREN_BENUTZER               0x0000000001000000L
#define AIE_BERECHTIGUNG_NEUER_BENUTZER                 0x0000000002000000L
#define AIE_BERECHTIGUNG_AENDERN_BENUTZER               0x0000000004000000L
#define AIE_BERECHTIGUNG_LOESCHEN_BENUTZER              0x0000000008000000L
#define AIE_BERECHTIGUNG_ANSICHT_AENDERN_USER_PASSWORT  0x0000000010000000L
#define AIE_BERECHTIGUNG_AENDERN_BENUTZER_RECHTE        0x0000000020000000L

// Fur Future use
// Reserviert                                           0x0000000040000000L

// Hintergrund Programme manuell starten
#define AIE_BERECHTIGUNG_BATCHLAUF_APPLICATION          0x0000000080000000L


// Berechtigung fuer Gruppen
#define AIE_BERECHTIGUNG_ZUORDNUNG_BENUTZER_GRUPPEN     0x0000000100000000L
#define AIE_BERECHTIGUNG_AENDERN_GRUPPE                 0x0000000200000000L
#define AIE_BERECHTIGUNG_SPERREN_GRUPPE                 0x0000000400000000L
#define AIE_BERECHTIGUNG_LOESCHEN_GRUPPE                0x0000000800000000L
#define AIE_BERECHTIGUNG_ANSICHT_GRUPPEN_RECHTE         0x0000001000000000L
#define AIE_BERECHTIGUNG_NEUE_GRUPPE                    0x0000002000000000L
#define AIE_BERECHTIGUNG_AENDERN_GRUPPEN_RECHTE         0x0000004000000000L

// Fur Future use
// Reserviert                                           0x0000008000000000L
// Reserviert                                           0x0000010000000000L
// Reserviert                                           0x0000020000000000L
// Reserviert                                           0x0000040000000000L
// Reserviert                                           0x0000080000000000L

// Modul Register
#define AIE_BERECHTIGUNG_ANSICHT_MODUL_INFO             0x0000100000000000L
#define AIE_BERECHTIGUNG_AENDERN_MODUL_INFO             0x0000200000000000L
#define AIE_BERECHTIGUNG_LOESCHEN_MODUL_INFO            0x0000400000000000L

// Fur Future use
// Reserviert                                           0x0000800000000000L

// Seriennummern ohne aendern
#define AIE_BERECHTIGUNG_ANSICHT_SERIAL_POOL            0x0001000000000000L
#define AIE_BERECHTIGUNG_INC_SERIENUMMERN_INSTALL       0x0002000000000000L
#define AIE_BERECHTIGUNG_NEU_SERIENNUMMERN              0x0004000000000000L
#define AIE_BERECHTIGUNG_RESET_SERIENNUMMERN            0x0008000000000000L

// Superuser rechte Vergeben
#define AIE_BERECHTIGUNG_BENUTZER_IST_SUPERUSER         0x0010000000000000L
#define AIE_BERECHTIGUNG_ANSICHT_SUPERUSER              0x0020000000000000L
#define AIE_BERECHTIGUNG_NEUER_ADMIN                    0x0040000000000000L
#define AIE_BERECHTIGUNG_NEUER_SYSOP                    0x0080000000000000L

// Open SQL ohne SELECT s.o. und freischalten der SQL Schnittstelle
#define AIE_BERECHTIGUNG_OPEN_SQL_INSERT                0x0100000000000000L
#define AIE_BERECHTIGUNG_OPEN_SQL_UPDATE                0x0200000000000000L
#define AIE_BERECHTIGUNG_OPEN_SQL_DELETE                0x0400000000000000L
#define AIE_BERECHTIGUNG_FREE_OPEN_SQL                  0x0800000000000000L

// Seriennummern aendern
#define AIE_BERECHTIGUNG_AENDERN_SERIENNUMMERN          0x1000000000000000L
#define AIE_BERECHTIGUNG_LOESCHEN_SERIENNUMMERN         0x2000000000000000L

// Fur Future use
// Reserviert                                           0x4000000000000000L
// Reserviert                                           0x0800000000000000L

#else

#define AIE_BERECHTIGUNG_KEINE                          0x0000000000000000ui64
#define AIE_BERECHTIGUNG_APPL_STANDARD                  AIE_BERECHTIGUNG_KEINE

// Verschidene WinGui Clients
#define AIE_BERECHTIGUNG_STATUS_MONITOR                 0x0000000000000001ui64
#define AIE_BERECHTIGUNG_WINGUI_APPLICATION             0x0000000000000002ui64

// Fur Future use
// Reserviert                                           0x0000000000000004ui64
// Reserviert                                           0x0000000000000008ui64

// Server funktionen
#define AIE_BERECHTIGUNG_ANSICHT_SERVER                 0x0000000000000010ui64
#define AIE_BERECHTIGUNG_START_SERVER                   0x0000000000000020ui64
#define AIE_BERECHTIGUNG_STOP_SERVER                    0x0000000000000040ui64
#define AIE_BERECHTIGUNG_SYSTEM_SERVER                  0x0000000000000080ui64

// Berechtigungen fuer verschienden Ansichten
#define AIE_BERECHTIGUNG_ANSICHT_GRUPPEN                0x0000000000000100ui64
#define AIE_BERECHTIGUNG_ANSICHT_BENUTZER               0x0000000000000200ui64
#define AIE_BERECHTIGUNG_ANSICHT_BENUTZER_RECHTE        0x0000000000000400ui64
#define AIE_BERECHTIGUNG_ANSICHT_EIGENE_MODULE          0x0000000000000800ui64

#define AIE_BERECHTIGUNG_ANSICHT_LOGFILE                0x0000000000001000ui64

// Fur Future use
// Reserviert                                           0x0000000000002000ui64
// Reserviert                                           0x0000000000004000ui64
// Reserviert                                           0x0000000000008000ui64

// Berechtigungen nur den eigenen Benutzer betreffend
#define AIE_BERECHTIGUNG_AENDERN_EIGENEN_BENUTZER       0x0000000000010000ui64

// Fur Future use
// Reserviert                                           0x0000000000020000ui64
// Reserviert                                           0x0000000000040000ui64
// Reserviert                                           0x0000000000080000ui64

// Ansicht Open SQL und Select
#define AIE_BERECHTIGUNG_ANSICHT_OPEN_SQL               0x0000000000100000ui64
#define AIE_BERECHTIGUNG_OPEN_SQL_SELECT                0x0000000000200000ui64
#define AIE_BERECHTIGUNG_OPEN_SQL_PREDEFINED_SQL        0x0000000000400000ui64

// Fur Future use
// Reserviert                                           0x0000000000800000ui64

// Benutzer
#define AIE_BERECHTIGUNG_SPERREN_BENUTZER               0x0000000001000000ui64
#define AIE_BERECHTIGUNG_NEUER_BENUTZER                 0x0000000002000000ui64
#define AIE_BERECHTIGUNG_AENDERN_BENUTZER               0x0000000004000000ui64
#define AIE_BERECHTIGUNG_LOESCHEN_BENUTZER              0x0000000008000000ui64
#define AIE_BERECHTIGUNG_ANSICHT_AENDERN_USER_PASSWORT  0x0000000010000000ui64
#define AIE_BERECHTIGUNG_AENDERN_BENUTZER_RECHTE        0x0000000020000000ui64

// Fur Future use
// Reserviert                                           0x0000000040000000ui64

// Hintergrund Programme manuell starten
#define AIE_BERECHTIGUNG_BATCHLAUF_APPLICATION          0x0000000080000000ui64


// Berechtigung fuer Gruppen
#define AIE_BERECHTIGUNG_ZUORDNUNG_BENUTZER_GRUPPEN     0x0000000100000000ui64
#define AIE_BERECHTIGUNG_AENDERN_GRUPPE                 0x0000000200000000ui64
#define AIE_BERECHTIGUNG_SPERREN_GRUPPE                 0x0000000400000000ui64
#define AIE_BERECHTIGUNG_LOESCHEN_GRUPPE                0x0000000800000000ui64
#define AIE_BERECHTIGUNG_ANSICHT_GRUPPEN_RECHTE         0x0000001000000000ui64
#define AIE_BERECHTIGUNG_NEUE_GRUPPE                    0x0000002000000000ui64
#define AIE_BERECHTIGUNG_AENDERN_GRUPPEN_RECHTE         0x0000004000000000ui64

// Fur Future use
// Reserviert                                           0x0000008000000000ui64
// Reserviert                                           0x0000010000000000ui64
// Reserviert                                           0x0000020000000000ui64
// Reserviert                                           0x0000040000000000ui64
// Reserviert                                           0x0000080000000000ui64

// Modul Register
#define AIE_BERECHTIGUNG_ANSICHT_MODUL_INFO             0x0000100000000000ui64
#define AIE_BERECHTIGUNG_AENDERN_MODUL_INFO             0x0000200000000000ui64
#define AIE_BERECHTIGUNG_LOESCHEN_MODUL_INFO            0x0000400000000000ui64

// Fur Future use
// Reserviert                                           0x0000800000000000ui64

// Seriennummern ohne aendern
#define AIE_BERECHTIGUNG_ANSICHT_SERIAL_POOL            0x0001000000000000ui64
#define AIE_BERECHTIGUNG_INC_SERIENUMMERN_INSTALL       0x0002000000000000ui64
#define AIE_BERECHTIGUNG_NEU_SERIENNUMMERN              0x0004000000000000ui64
#define AIE_BERECHTIGUNG_RESET_SERIENNUMMERN            0x0008000000000000ui64

// Superuser rechte Vergeben
#define AIE_BERECHTIGUNG_BENUTZER_IST_SUPERUSER         0x0010000000000000ui64
#define AIE_BERECHTIGUNG_ANSICHT_SUPERUSER              0x0020000000000000ui64
#define AIE_BERECHTIGUNG_NEUER_ADMIN                    0x0040000000000000ui64
#define AIE_BERECHTIGUNG_NEUER_SYSOP                    0x0080000000000000ui64

// Open SQL ohne SELECT s.o. und freischalten der SQL Schnittstelle
#define AIE_BERECHTIGUNG_OPEN_SQL_INSERT                0x0100000000000000ui64
#define AIE_BERECHTIGUNG_OPEN_SQL_UPDATE                0x0200000000000000ui64
#define AIE_BERECHTIGUNG_OPEN_SQL_DELETE                0x0400000000000000ui64
#define AIE_BERECHTIGUNG_FREE_OPEN_SQL                  0x0800000000000000ui64

// Seriennummern aendern
#define AIE_BERECHTIGUNG_AENDERN_SERIENNUMMERN          0x1000000000000000ui64
#define AIE_BERECHTIGUNG_LOESCHEN_SERIENNUMMERN         0x2000000000000000ui64

// Fur Future use
// Reserviert                                           0x4000000000000000ui64
// Reserviert                                           0x0800000000000000ui64
#endif
// Meta Makros fuer Funktionsgruppen
#define AIE_BERECHTIGUNG_OVERALL_CHANGE_SERVER                               \
						   (AIE_BERECHTIGUNG_START_SERVER |                  \
							AIE_BERECHTIGUNG_STOP_SERVER |                   \
							AIE_BERECHTIGUNG_SYSTEM_SERVER)
#define AIE_BERECHTIGUNG_OVERALL_ANSICHT_SERVER                              \
						   (AIE_BERECHTIGUNG_START_SERVER |                  \
							AIE_BERECHTIGUNG_OVERALL_CHANGE_SERVER)
#define AIE_BERECHTIGUNG_OVERALL_CHANGE_BENUTZER                             \
						   (AIE_BERECHTIGUNG_AENDERN_EIGENEN_BENUTZER |      \
							AIE_BERECHTIGUNG_SPERREN_BENUTZER |              \
							AIE_BERECHTIGUNG_NEUER_BENUTZER |                \
							AIE_BERECHTIGUNG_AENDERN_BENUTZER |              \
							AIE_BERECHTIGUNG_LOESCHEN_BENUTZER |             \
							AIE_BERECHTIGUNG_ANSICHT_AENDERN_USER_PASSWORT | \
							AIE_BERECHTIGUNG_AENDERN_BENUTZER_RECHTE)
#define AIE_BERECHTIGUNG_OVERALL_ANSICHT_BENUTZER                            \
						   (AIE_BERECHTIGUNG_ANSICHT_BENUTZER |              \
							AIE_BERECHTIGUNG_OVERALL_CHANGE_BENUTZER)
#define AIE_BERECHTIGUNG_OVERALL_CHANGE_GRUPPE                               \
						   (AIE_BERECHTIGUNG_NEUE_GRUPPE |                   \
							AIE_BERECHTIGUNG_AENDERN_GRUPPE |                \
                            AIE_BERECHTIGUNG_SPERREN_GRUPPE |                \
                            AIE_BERECHTIGUNG_LOESCHEN_GRUPPE |               \
                            AIE_BERECHTIGUNG_ANSICHT_GRUPPEN_RECHTE |        \
                            AIE_BERECHTIGUNG_AENDERN_GRUPPEN_RECHTE)
#define AIE_BERECHTIGUNG_OVERALL_ANSICHT_GRUPPE                              \
                           (AIE_BERECHTIGUNG_ANSICHT_GRUPPEN |               \
                            AIE_BERECHTIGUNG_OVERALL_CHANGE_GRUPPE)
#define AIE_BERECHTIGUNG_OVERALL_CHANGE_OPEN_SQL                             \
                           (AIE_BERECHTIGUNG_OPEN_SQL_INSERT |               \
                            AIE_BERECHTIGUNG_OPEN_SQL_UPDATE |               \
                            AIE_BERECHTIGUNG_OPEN_SQL_DELETE)
#define AIE_BERECHTIGUNG_OVERALL_ANSICHT_OPEN_SQL                            \
                           (AIE_BERECHTIGUNG_ANSICHT_OPEN_SQL|               \
                            AIE_BERECHTIGUNG_OPEN_SQL_SELECT |               \
                            AIE_BERECHTIGUNG_OVERALL_CHANGE_OPEN_SQL)
#define AIE_BERECHTIGUNG_OVERALL_CHANGE_MODUL_INFO                           \
                           (AIE_BERECHTIGUNG_AENDERN_MODUL_INFO |            \
                            AIE_BERECHTIGUNG_LOESCHEN_MODUL_INFO)
#define AIE_BERECHTIGUNG_OVERALL_ANSICHT_MODUL_INFO                          \
                           (AIE_BERECHTIGUNG_ANSICHT_EIGENE_MODULE |         \
                            AIE_BERECHTIGUNG_ANSICHT_MODUL_INFO |            \
                            AIE_BERECHTIGUNG_OVERALL_CHANGE_MODUL_INFO)
#define AIE_BERECHTIGUNG_OVERALL_SUPERUSER                                   \
                           (AIE_BERECHTIGUNG_NEUER_ADMIN |                   \
                            AIE_BERECHTIGUNG_NEUER_SYSOP)
#define AIE_BERECHTIGUNG_OVERALL_ANSICHT_SERIENNUMMERN                       \
                           (AIE_BERECHTIGUNG_ANSICHT_SERIAL_POOL |           \
                            AIE_BERECHTIGUNG_NEU_SERIENNUMMERN |             \
                            AIE_BERECHTIGUNG_AENDERN_SERIENNUMMERN |         \
                            AIE_BERECHTIGUNG_INC_SERIENUMMERN_INSTALL |      \
                            AIE_BERECHTIGUNG_LOESCHEN_SERIENUMMERN)
#define AIE_BERECHTIGUNG_OVERALL_CHANGE_SERIENNUMMERN                        \
                           (AIE_BERECHTIGUNG_NEU_SERIENNUMMERN |             \
                            AIE_BERECHTIGUNG_AENDERN_SERIENNUMMERN |         \
                            AIE_BERECHTIGUNG_INC_SERIENUMMERN_INSTALL |      \
                            AIE_BERECHTIGUNG_LOESCHEN_SERIENUMMERN)

// Makros zum einfacheren abfragen der Berechtigungen innerhalb der Programme
#define AIE_USER_CAN_GARNICHTS		    ((AIE_BERECHTIGUNG_KEINE & a) != 0)


#define AIE_USER_CAN_STATUS_MONITOR(a)		        \
                                   ((AIE_BERECHTIGUNG_STATUS_MONITOR & a) != 0)
#define AIE_USER_CAN_WINGUI_APPLICATION(a)              \
                               ((AIE_BERECHTIGUNG_WINGUI_APPLICATION & a) != 0)
#define AIE_USER_CAN_ANSICHT_SERVER(a)                  \
                                   ((AIE_BERECHTIGUNG_ANSICHT_SERVER & a) != 0)
#define AIE_USER_CAN_START_SERVER(a) ((AIE_BERECHTIGUNG_START_SERVER & a) != 0)
#define AIE_USER_CAN_STOP_SERVER(a)   ((AIE_BERECHTIGUNG_STOP_SERVER & a) != 0)
#define AIE_USER_CAN_SYSTEM_SERVER(a)                   \
                                    ((AIE_BERECHTIGUNG_SYSTEM_SERVER & a) != 0)
#define AIE_USER_CAN_SPERREN_BENUTZER(a)		\
                                 ((AIE_BERECHTIGUNG_SPERREN_BENUTZER & a) != 0)
#define AIE_USER_CAN_NEUER_BENUTZER(a)		        \
                                   ((AIE_BERECHTIGUNG_NEUER_BENUTZER & a) != 0)
#define AIE_USER_CAN_AENDERN_BENUTZER(a)		\
                                 ((AIE_BERECHTIGUNG_AENDERN_BENUTZER & a) != 0)
#define AIE_USER_CAN_LOESCHEN_BENUTZER(a)		\
                                ((AIE_BERECHTIGUNG_LOESCHEN_BENUTZER & a) != 0)
#define AIE_USER_CAN_ANSICHT_GRUPPEN(a)		        \
                                  ((AIE_BERECHTIGUNG_ANSICHT_GRUPPEN & a) != 0)
#define AIE_USER_CAN_ANSICHT_BENUTZER(a)		\
                                 ((AIE_BERECHTIGUNG_ANSICHT_BENUTZER & a) != 0)
#define AIE_USER_CAN_ANSICHT_BENUTZER_RECHTE(a)	        \
                           ((AIE_BERECHTIGUNG_ANSICHT_BENUTZER_RECHTE & a) != 0)
#define AIE_USER_CAN_AENDERN_EIGENEN_BENUTZER(a)	\
                         ((AIE_BERECHTIGUNG_AENDERN_EIGENEN_BENUTZER & a) != 0)
#define AIE_USER_CAN_ANSICHT_AENDERN_USER_PASSWORT(a)	\
                    ((AIE_BERECHTIGUNG_ANSICHT_AENDERN_USER_PASSWORT & a) != 0)
#define AIE_USER_CAN_AENDERN_BENUTZER_RECHTE(a)	        \
                          ((AIE_BERECHTIGUNG_AENDERN_BENUTZER_RECHTE & a) != 0)
#define AIE_USER_CAN_BATCHLAUF_APPLICATION(a)           \
                            ((AIE_BERECHTIGUNG_BATCHLAUF_APPLICATION & a) != 0)
#define AIE_USER_CAN_ZUORDNUNG_BENUTZER_GRUPPEN(a)      \
                       ((AIE_BERECHTIGUNG_ZUORDNUNG_BENUTZER_GRUPPEN & a) != 0)
#define AIE_USER_CAN_NEUE_GRUPPE(a)   ((AIE_BERECHTIGUNG_NEUE_GRUPPE & a) != 0)
#define AIE_USER_CAN_AENDERN_GRUPPE(a)		        \
                                   ((AIE_BERECHTIGUNG_AENDERN_GRUPPE & a) != 0)
#define AIE_USER_CAN_SPERREN_GRUPPE(a)		        \
                                   ((AIE_BERECHTIGUNG_SPERREN_GRUPPE & a) != 0)
#define AIE_USER_CAN_LOESCHEN_GRUPPE(a)		        \
                                  ((AIE_BERECHTIGUNG_LOESCHEN_GRUPPE & a) != 0)
#define AIE_USER_CAN_ANSICHT_GRUPPEN_RECHTE(a)          \
                           ((AIE_BERECHTIGUNG_ANSICHT_GRUPPEN_RECHTE & a) != 0)
#define AIE_USER_CAN_AENDERN_GRUPPEN_RECHTE(a)	        \
                           ((AIE_BERECHTIGUNG_AENDERN_GRUPPEN_RECHTE & a) != 0)
#define AIE_USER_CAN_ANSICHT_EIGENE_MODULE(a)		\
                            ((AIE_BERECHTIGUNG_ANSICHT_EIGENE_MODULE & a) != 0)
#define AIE_USER_CAN_ANSICHT_LOGFILE(a)                 \
                            ((AIE_BERECHTIGUNG_ANSICHT_LOGFILE & a) != 0)
#define AIE_USER_CAN_ANSICHT_MODUL_INFO(a)		\
                               ((AIE_BERECHTIGUNG_ANSICHT_MODUL_INFO & a) != 0)
#define AIE_USER_CAN_BENUTZER_IST_SUPERUSER(a)          \
                           ((AIE_BERECHTIGUNG_BENUTZER_IST_SUPERUSER & a) != 0)
#define AIE_USER_CAN_ANSICHT_SUPERUSER(a)               \
                                ((AIE_BERECHTIGUNG_ANSICHT_SUPERUSER & a) != 0)
#define AIE_USER_CAN_NEUER_ADMIN(a)   ((AIE_BERECHTIGUNG_NEUER_ADMIN & a) != 0)
#define AIE_USER_CAN_NEUER_SYSOP(a)   ((AIE_BERECHTIGUNG_NEUER_SYSOP & a) != 0)
#define AIE_USER_CAN_OPEN_SQL_SELECT(a)		        \
                                  ((AIE_BERECHTIGUNG_OPEN_SQL_SELECT & a) != 0)
#define AIE_USER_CAN_OPEN_SQL_INSERT(a)		        \
                                  ((AIE_BERECHTIGUNG_OPEN_SQL_INSERT & a) != 0)
#define AIE_USER_CAN_OPEN_SQL_UPDATE(a)		        \
                                  ((AIE_BERECHTIGUNG_OPEN_SQL_UPDATE & a) != 0)
#define AIE_USER_CAN_OPEN_SQL_DELETE(a)		        \
                                  ((AIE_BERECHTIGUNG_OPEN_SQL_DELETE & a) != 0)
#define AIE_USER_CAN_FREE_OPEN_SQL(a)		        \
                                    ((AIE_BERECHTIGUNG_FREE_OPEN_SQL & a) != 0)
#define AIE_USER_CAN_AENDERN_MODUL_INFO(a)		\
                               ((AIE_BERECHTIGUNG_AENDERN_MODUL_INFO & a) != 0)
#define AIE_USER_CAN_ANSICHT_SERIAL_POOL(a)		\
                              ((AIE_BERECHTIGUNG_ANSICHT_SERIAL_POOL & a) != 0)
#define AIE_USER_CAN_RESET_SERIENNUMMERN(a)             \
                               ((AIE_BERECHTIGUNG_RESET_SERIENNUMMERN & a) != 0)
#define AIE_USER_CAN_INC_SERIENUMMERN_INSTALL           \
                         ((AIE_BERECHTIGUNG_INC_SERIENUMMERN_INSTALL & a) != 0)
#define AIE_USER_CAN_NEU_SERIENNUMMERN(a)		\
                                ((AIE_BERECHTIGUNG_NEU_SERIENNUMMERN & a) != 0)
#define AIE_USER_CAN_AENDERN_SERIENNUMMERN(a)		\
                            ((AIE_BERECHTIGUNG_AENDERN_SERIENNUMMERN & a) != 0)
#define AIE_USER_CAN_LOESCHEN_SERIENNUMMERN(a)          \
                            ((AIE_BERECHTIGUNG_LOESCHEN_SERIENNUMMERN & a) != 0)
// Overall Macros
#define AIE_USER_CAN_OVERALL_ANSICHT_SERVER(a)          \
                           ((AIE_BERECHTIGUNG_OVERALL_ANSICHT_SERVER & a) != 0)
#define AIE_USER_CAN_OVERALL_CHANGE_SERVER(a)           \
                            ((AIE_BERECHTIGUNG_OVERALL_CHANGE_SERVER & a) != 0)
#define AIE_USER_CAN_OVERALL_ANSICHT_BENUTZER(a)        \
                         ((AIE_BERECHTIGUNG_OVERALL_ANSICHT_BENUTZER & a) != 0)
#define AIE_USER_CAN_OVERALL_CHANGE_BENUTZER(a)         \
                          ((AIE_BERECHTIGUNG_OVERALL_CHANGE_BENUTZER & a) != 0)
#define AIE_USER_CAN_OVERALL_CHANGE_GRUPPE(a)           \
                            ((AIE_BERECHTIGUNG_OVERALL_CHANGE_GRUPPE & a) != 0)
#define AIE_USER_CAN_OVERALL_ANSICHT_GRUPPE(a)          \
                           ((AIE_BERECHTIGUNG_OVERALL_ANSICHT_GRUPPE & a) != 0)
#define AIE_USER_CAN_OVERALL_CHANGE_OPEN_SQL(a)         \
                          ((AIE_BERECHTIGUNG_OVERALL_CHANGE_OPEN_SQL & a) != 0)
#define AIE_USER_CAN_OVERALL_ANSICHT_OPEN_SQL(a)        \
                         ((AIE_BERECHTIGUNG_OVERALL_ANSICHT_OPEN_SQL & a) != 0)
#define AIE_USER_CAN_OVERALL_ANSICHT_MODUL_INFO(a)      \
                       ((AIE_BERECHTIGUNG_OVERALL_ANSICHT_MODUL_INFO & a) != 0)
#define AIE_USER_CAN_OVERALL_CHANGE_MODUL_INFO(a)       \
                        ((AIE_BERECHTIGUNG_OVERALL_CHANGE_MODUL_INFO & a) != 0)
#define AIE_USER_CAN_OVERALL_SUPERUSER(a)               \
                                ((AIE_BERECHTIGUNG_OVERALL_SUPERUSER & a) != 0)
#define AIE_USER_CAN_OVERALL_ANSICHT_SERIENNUMMERN(a)   \
                    ((AIE_BERECHTIGUNG_OVERALL_ANSICHT_SERIENNUMMERN & a) != 0)
#define AIE_USER_CAN_OVERALL_CHANGE_SERIENNUMMERN(a)    \
                     ((AIE_BERECHTIGUNG_OVERALL_CHANGE_SERIENNUMMERN & a) != 0)

// Vordefinierte Benutzerrechte fuer normale Benutzer und Superuser
#define AIE_BERECHTIGUNG_ADMIN_STANDARD \
                           (AIE_BERECHTIGUNG_WINGUI_APPLICATION |            \
                            AIE_BERECHTIGUNG_STATUS_MONITOR |                \
                            AIE_BERECHTIGUNG_ANSICHT_SERVER |                \
                            AIE_BERECHTIGUNG_START_SERVER |                  \
                            AIE_BERECHTIGUNG_STOP_SERVER |                   \
                            AIE_BERECHTIGUNG_SYSTEM_SERVER |                 \
                            AIE_BERECHTIGUNG_ANSICHT_GRUPPEN |               \
                            AIE_BERECHTIGUNG_ANSICHT_BENUTZER  |             \
                            AIE_BERECHTIGUNG_ANSICHT_BENUTZER_RECHTE |       \
                            AIE_BERECHTIGUNG_ANSICHT_GRUPPEN_RECHTE  |       \
                            AIE_BERECHTIGUNG_ANSICHT_EIGENE_MODULE  |        \
                            AIE_BERECHTIGUNG_ANSICHT_MODUL_INFO  |           \
                            AIE_BERECHTIGUNG_AENDERN_EIGENEN_BENUTZER  |     \
                            AIE_BERECHTIGUNG_SPERREN_BENUTZER  |             \
                            AIE_BERECHTIGUNG_NEUER_BENUTZER   |              \
                            AIE_BERECHTIGUNG_AENDERN_BENUTZER  |             \
                            AIE_BERECHTIGUNG_LOESCHEN_BENUTZER  |            \
                            AIE_BERECHTIGUNG_ANSICHT_AENDERN_USER_PASSWORT  |\
                            AIE_BERECHTIGUNG_AENDERN_BENUTZER_RECHTE  |      \
                            AIE_BERECHTIGUNG_OPEN_SQL_SELECT  |              \
                            AIE_BERECHTIGUNG_BENUTZER_IST_SUPERUSER |        \
                            AIE_BERECHTIGUNG_ANSICHT_SUPERUSER |             \
                            AIE_BERECHTIGUNG_ANSICHT_SERIAL_POOL)

//                            AIE_BERECHTIGUNG_NEU_SERIENNUMMERN | 

#if __GNUC__
#define AIE_BERECHTIGUNG_SYSOP_STANDARD                  0xFFFFFFFFFFFFFFFFL
#else
#define AIE_BERECHTIGUNG_SYSOP_STANDARD                  0xFFFFFFFFFFFFFFFFui64
#endif

#define AIE_BERECHTIGUNG_USER_STANDARD  \
                           (AIE_BERECHTIGUNG_WINGUI_APPLICATION |            \
                            AIE_BERECHTIGUNG_STATUS_MONITOR |                \
                            AIE_BERECHTIGUNG_ANSICHT_SERVER |                \
                            AIE_BERECHTIGUNG_START_SERVER |                  \
                            AIE_BERECHTIGUNG_ANSICHT_GRUPPEN |               \
                            AIE_BERECHTIGUNG_ANSICHT_EIGENE_MODULE  |        \
                            AIE_BERECHTIGUNG_AENDERN_EIGENEN_BENUTZER  |     \
                            AIE_BERECHTIGUNG_ANSICHT_BENUTZER_RECHTE |        \
                            AIE_BERECHTIGUNG_OPEN_SQL_SELECT )


/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
struct aie_berechtigungen
{
   char *text;
   u64 berechtigung;
   bool user_has;
};
                                                                            //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */
