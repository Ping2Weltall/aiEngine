/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_sql.h                                                   */
/* Library     : aiengine-sql_wrap-3.nn.nn.so                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 05.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/* Split der Log Funktionen von log.cpp in verschiedene Programme            */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_SQL_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_SQL_H

#define AIE_SQL_INSERT                  1
#define AIE_SQL_UPDATE                  2
#define AIE_SQL_DELETE                  3

#define AIE_SQL_STANDARD_TIMEOUT	5000

#define AIE_DB_FELD_TYPE_UNKNOWN	-1
#define AIE_DB_FELD_TYPE_INTEGER	1
#define AIE_DB_FELD_TYPE_REAL   	2
#define AIE_DB_FELD_TYPE_NUMERIC	4
#define AIE_DB_FELD_TYPE_TEXT		8
#define AIE_DB_FELD_TYPE_VARCHAR	16
#define AIE_DB_FELD_TYPE_BLOB		32
//Reserved 				64
//Reserved 				128
//Reserved 				256
//Reserved 				512
#define AIE_DB_FELD_TYPE_NOT_NULL	1024
#define AIE_DB_FELD_TYPE_PRIMARY_KEY	2048
#define AIE_DB_FELD_TYPE_UNIQUE		4096

#define AIE_DB_FELD_INT_LEN		-1
#define AIE_DB_FELD_TEXT_LEN		0

#define AIE_INDEX_TYPE_NORMAL		0
#define AIE_INDEX_TYPE_UNIQUE		1
#define AIE_INDEX_TYPE_ASC		2
#define AIE_INDEX_TYPE_DESC		4

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#ifndef AIE_SMALLBUILD
//#include <sqlite3.h>
#define  AIENGINE_SQL_INCLUDE  "/data/data/com.termux/files/home/project/include/sqlite3.h"                         //
#include AIENGINE_SQL_INCLUDE 
 
#endif																			 //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
#ifndef AIE_SMALLBUILD
struct aie_sql_db_data
{
   char *dbf;
   sqlite3 *db;
   int cnt;
   unsigned long timeout;
};

struct aie_sql_data
{
   struct aie_sql_db_data *sql_db_data;
   int (*callback)(void*,int,char**, char**);
   const char *sql_cmd;
   void *data;
   int sql_rc;
};
#endif
																			 //
struct aie_sql_dbid_2_db
{
   int dbid;
   const char *db;
};

struct aie_sql_tableid_2_table
{
   int tableid;
   const char *table;
};

struct aie_sql_indexid_2_index 
{
   int indexid;
   const char *index;
};

struct aie_sql_table_def
{
   const char *feld;
   int len;
   int typ;
};

struct aie_sql_tables
{
   int tableid;
   struct aie_sql_table_def *table_def;
   unsigned int size_table_def;
};

struct aie_sql_index_def
{
   const char *feld;
};

struct aie_sql_index
{
   int indexid;
   int tableid;
   int index_typ;
   struct aie_sql_index_def *index_def;
   int size_index_def;
};

struct aie_sql_db
{
   int dbid;
   struct aie_sql_tables *tables;
   unsigned int size_tables;
   struct aie_sql_index *index;
   unsigned int size_index;
};

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
#ifdef  __GNUC__
struct aie_sql_data *aie_sql_attach_db(const char *db) __attribute__ ((nonnull));
bool aie_sql_release_db(struct aie_sql_data *aie_sql_data)
                                                     __attribute__ ((nonnull));
bool aie_sql_start_transaction(struct aie_sql_data *aie_sql_data)
                                                     __attribute__ ((nonnull));
bool aie_sql_commit(struct aie_sql_data *aie_sql_data)
                                                     __attribute__ ((nonnull));
bool aie_sql_rollback(struct aie_sql_data *aie_sql_data)
                                                     __attribute__ ((nonnull));
bool aie_sql_end_transaction(struct aie_sql_data *aie_sql_data)
                                                     __attribute__ ((nonnull));
bool aie_sql_run(struct aie_sql_data *aie_sql_data) __attribute__ ((nonnull));

bool aie_sql_create_table(struct aie_sql_data *aie_sql_data,
                          const char *table, bool iggy_error,
                          struct aie_sql_table_def *ff_sql_table_def,
                          unsigned int size_table_def)
                                                     __attribute__ ((nonnull));
bool aie_sql_create_index(struct aie_sql_data *aie_sql_data, const char *table,
                          const char *tbl_index, int index_typ,
			  bool iggy_error,
                          struct aie_sql_index_def *ff_sql_index_def,
                          unsigned int size_index_def)
                                                     __attribute__ ((nonnull));
int aie_sql_get_feld_typ(const char *feld,
                      struct aie_sql_table_def *aie_sql_table_def,
                      unsigned int size_table_def) __attribute__ ((nonnull));
#else
struct aie_sql_data *aie_sql_attach_db(const char *db);
bool aie_sql_release_db(struct aie_sql_data *aie_sql_data);
bool aie_sql_start_transaction(struct aie_sql_data *aie_sql_data);
bool aie_sql_commit(struct aie_sql_data *aie_sql_data);
bool aie_sql_rollback(struct aie_sql_data *aie_sql_data);
bool aie_sql_end_transaction(struct aie_sql_data *aie_sql_data);
bool aie_sql_run(struct aie_sql_data *aie_sql_data);

bool aie_sql_create_table(struct aie_sql_data *aie_sql_data,
                          const char *table, bool iggy_error,
                          struct aie_sql_table_def *ff_sql_table_def,
                          unsigned int size_table_def);
bool aie_sql_create_index(struct aie_sql_data *aie_sql_data, const char *table,
                          const char *tbl_index, int index_typ,
			  bool iggy_error,
                          struct aie_sql_index_def *ff_sql_index_def,
                          unsigned int size_index_def);
int aie_sql_get_feld_typ(const char *feld,
                      struct aie_sql_table_def *aie_sql_table_def,
                      unsigned int size_table_def);
#endif
#ifdef __cplusplus
}
#endif
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

