/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_sql_meta.h                                              */
/* Library     : aiengine-sql_wrap-3.nn.nn.so                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 10.09.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/* Split der Log Funktionen von log.cpp in verschiedene Programme            */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 16.01.2005  : ALH           : Neue Struktur aie_meta_datenbasis           */
/*.............+...............+.............................................*/
/* 01.01.2005  : ALH           : Neue Funktion aie_sql_meta_rollback         */
/*.............+...............+.............................................*/
/* 30.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_SQL_META_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_SQL_META_H

#define AIE_SQL_WHERE_EQUAL		0
#define AIE_SQL_WHERE_GREATER		1
#define AIE_SQL_WHERE_GREATER_EQUAL	2
#define AIE_SQL_WHERE_SMALLER		3
#define AIE_SQL_WHERE_SMALLER_EQUAL	4
#define AIE_SQL_WHERE_NOT_EUQAL		5
#define AIE_SQL_WHERE_NOT_NULL		6

#define AIE_SQL_WHERE			0
#define AIE_SQL_WHERE_AND		1
#define AIE_SQL_WHERE_OR		2

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
                                                                             //
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/

struct aie_sql_meta_db
{
   const char *db_path;
   struct aie_sql_dbid_2_db *dbid_2_db;
   unsigned int size_dbid_2_db;
   struct aie_sql_tableid_2_table *tableid_2_table;
   unsigned int size_tableid_2_table;
   struct aie_sql_indexid_2_index *indexid_2_index;
   unsigned int size_indexid_2_index;
   struct aie_sql_db *sql_db;
   unsigned int size_sql_db;
   struct aie_sql_data *aie_sql_data;
};

struct aie_meta_datenbasis
{
   int id;
   const char *name;
   struct aie_sql_meta_db *sql_meta_db;
   u64 min_berechtigung;
};

struct aie_sql_meta_feld_value_list
{
   const char *feld;
   const char *value;
};

struct aie_sql_meta_feld_var_value_list
{
   const char *feld;
   char *value;
};

struct aie_sql_meta_where_value_list
{
   int condition;
   const char *feld;
   int compare;
   const char *value;
};

struct aie_sql_meta_insert
{
   int tableid;
   bool is_in_order;
   struct aie_sql_meta_feld_value_list *sql_meta_feld_value_list;
   unsigned int size_sql_meta_feld_value_list;
   bool fail_iggy;
   struct aie_sql_meta_db *sql_meta_db;
};

struct aie_sql_meta_update
{
   int tableid;
   bool is_in_order;
   struct aie_sql_meta_feld_value_list *sql_meta_feld_value_list;
   unsigned int size_sql_meta_feld_value_list;
   struct aie_sql_meta_where_value_list *sql_meta_where_value_list;
   unsigned int size_sql_meta_where_value_list;
   bool fail_iggy;
   struct aie_sql_meta_db *sql_meta_db;
};
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
#ifdef  __GNUC__
struct aie_sql_data *aie_sql_meta_attach_db(int dbid, struct aie_sql_meta_db
                                                             *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_release_db(struct aie_sql_meta_db *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_start_transaction(struct aie_sql_meta_db *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_commit(struct aie_sql_meta_db *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_rollback(struct aie_sql_meta_db *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_create_table(int tableid, struct aie_sql_meta_db
                                          *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_create_index(int indexid, struct aie_sql_meta_db
                                          *aie_sql_meta_db)
                                           __attribute__ ((nonnull));

bool aie_sql_meta_drop_table(int tableid, struct aie_sql_meta_db
                                          *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_drop_index(int indexid, struct aie_sql_meta_db
                                          *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
const char *aie_sql_meta_get_feld_value(const char *feld,
			                struct aie_sql_meta_feld_value_list
			      		       *sql_meta_feld_value_list,
                                   unsigned int size_sql_meta_feld_value_list)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_table_insert(struct aie_sql_meta_insert
                                      *sql_meta_insert)
                                           __attribute__ ((nonnull));
bool aie_sql_meta_table_update(struct aie_sql_meta_update *sql_meta_update);
char *aie_sql_meta_table_update_sql(struct aie_sql_meta_update *sql_meta_update)
                                           __attribute__ ((nonnull));
char *aie_sql_meta_table_insert_sql(struct aie_sql_meta_insert
				                 *sql_meta_insert)
                                           __attribute__ ((nonnull));
char *aie_sql_meta_gen_table_insert(struct aie_sql_meta_insert
				                 *sql_meta_insert)
                                           __attribute__ ((nonnull));
struct aie_sql_table_def *aie_sql_meta_get_table_def_from_id(int tableid,
                                                unsigned int *size_table_def,
                                                      struct aie_sql_meta_db
                                                      *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
struct aie_sql_index_def *aie_sql_meta_get_index_def_from_id(int indexid,
                                                     int *tableid,
                                                     int *index_typ,
                                                  unsigned int *size_index_def,
                                                     struct aie_sql_meta_db
                                                             *aie_sql_meta_db)
                                           __attribute__ ((nonnull));
const char *aie_sql_meta_get_db_name_from_id(int dbid,
                                    struct aie_sql_meta_db *sql_meta_db)
                                           __attribute__ ((nonnull));
const char *aie_sql_meta_get_table_name_from_id(int tableid,
                                       struct aie_sql_meta_db *sql_meta_db)
                                           __attribute__ ((nonnull));
const char *aie_sql_meta_get_index_name_from_id(int indexid,
                                       struct aie_sql_meta_db *sql_meta_db)
                                           __attribute__ ((nonnull));
const char *aie_sql_meta_error(struct aie_sql_meta_db *sql_meta_db)
                                        __attribute__ ((noinline, nonnull));
bool aie_sql_meta_log_error(struct aie_sql_meta_db *sql_meta_db,
                                   const char *sql_cmd, const char *file,
			        int line) __attribute__ ((noinline, nonnull));
#else
struct aie_sql_data *aie_sql_meta_attach_db(int dbid, struct aie_sql_meta_db
                                                             *aie_sql_meta_db);
bool aie_sql_meta_release_db(struct aie_sql_meta_db *aie_sql_meta_db);
bool aie_sql_meta_start_transaction(struct aie_sql_meta_db *aie_sql_meta_db);
bool aie_sql_meta_commit(struct aie_sql_meta_db *aie_sql_meta_db);
bool aie_sql_meta_rollback(struct aie_sql_meta_db *aie_sql_meta_db);
bool aie_sql_meta_create_table(int tableid, struct aie_sql_meta_db
                                          *aie_sql_meta_db);
bool aie_sql_meta_create_index(int indexid, struct aie_sql_meta_db
                                          *aie_sql_meta_db);

bool aie_sql_meta_drop_table(int tableid, struct aie_sql_meta_db
                                          *aie_sql_meta_db);
bool aie_sql_meta_drop_index(int indexid, struct aie_sql_meta_db
                                          *aie_sql_meta_db);
const char *aie_sql_meta_get_feld_value(const char *feld,
			                struct aie_sql_meta_feld_value_list
			      		       *sql_meta_feld_value_list,
                                   unsigned int size_sql_meta_feld_value_list);
bool aie_sql_meta_table_insert(struct aie_sql_meta_insert
                                      *sql_meta_insert);
bool aie_sql_meta_table_update(struct aie_sql_meta_update *sql_meta_update);
char *aie_sql_meta_table_update_sql(struct aie_sql_meta_update *sql_meta_update);
char *aie_sql_meta_table_insert_sql(struct aie_sql_meta_insert
				                 *sql_meta_insert);
char *aie_sql_meta_gen_table_insert(struct aie_sql_meta_insert
				                 *sql_meta_insert);
struct aie_sql_table_def *aie_sql_meta_get_table_def_from_id(int tableid,
                                                unsigned int *size_table_def,
                                                      struct aie_sql_meta_db
                                                      *aie_sql_meta_db);
struct aie_sql_index_def *aie_sql_meta_get_index_def_from_id(int indexid,
                                                     int *tableid,
                                                     int *index_typ,
                                                  unsigned int *size_index_def,
                                                     struct aie_sql_meta_db
                                                             *aie_sql_meta_db);
const char *aie_sql_meta_get_db_name_from_id(int dbid,
                                    struct aie_sql_meta_db *sql_meta_db);
const char *aie_sql_meta_get_table_name_from_id(int tableid,
                                       struct aie_sql_meta_db *sql_meta_db);
const char *aie_sql_meta_get_index_name_from_id(int indexid,
                                       struct aie_sql_meta_db *sql_meta_db);
const char *aie_sql_meta_error(struct aie_sql_meta_db *sql_meta_db);
bool aie_sql_meta_log_error(struct aie_sql_meta_db *sql_meta_db,
                                   const char *sql_cmd, const char *file,
			        int line);
#endif
#ifdef __cplusplus
}
#endif
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

