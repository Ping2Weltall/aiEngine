/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_sqlfld.h                                                */
/* Library     : aiengine-sql_wrap-3.nn.nn.so                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 30.12.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 16.01.2005  : ALH           : Neue Tabellen fuer Berechtigunen und gruppen*/
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the Software*/
/* and use the modified Software without placing the modifications in the    */
/* Public Domain as long as this modifications are only used within your     */
/* corporation or organization.                                              */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_SQLFLD_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_SQLFLD_H

#define is_aie_SeriennummerSqlFld               "Seriennummer"               //
#define is_aie_ModulNameSqlFld                  "ModulName"                  //
#define is_aie_FreigabeSqlFld                   "Freigabe"                   //
#define is_aie_VornameSqlFld                    "Vorname"                    //
#define is_aie_NachnameSqlFld                   "Nachname"                   //
#define is_aie_FirmaSqlFld                      "Firma"                      //
#define is_aie_StrasseSqlFld                    "Strasse"                    //
#define is_aie_PostleitzahlSqlFld               "Postleitzahl"               //
#define is_aie_OrtSqlFld                        "Ort"                        //
#define is_aie_EmailSqlFld                      "Email"                      //
#define is_aie_TimestampSqlFld                  "Timestamp"                  //
#define is_aie_InstallDateSqlFld                "InstallDate"                //
#define is_aie_RunCountSqlFld                   "RunCount"                   //
#define is_aie_LastRunSqlFld                    "LastRun"                    //
#define is_aie_LastUpdateSqlFld                 "LastUpdate"                 //
#define is_aie_ValidUntilDateSqlFld             "ValidUntilDate"             //
#define is_aie_SerialGenerateDateSqlFld         "GenerateDate"               //
#define is_aie_SerialMaxInstallCountSqlFld      "MaxInstall"                 //
#define is_aie_SerialCurrentInstallCountSqlFld  "InstallCount"               //
#define is_aie_UserIdSqlFld			"UserId"                     //
#define is_aie_UserPasswortSqlFld 		"UserPasswort"               //
#define is_aie_BerechtigungSqlFld 		"Berechtigung"               //
#define is_aie_BerechtigungTextSqlFld		"BerechtigungText"           //
#define is_aie_UserGruppeSqlFld 		"UserGruppe"                 //
#define is_aie_SperreSqlFld 		        "Sperre"                     //

#define is_aie_KeyIDSqlFld 			"KeyID"
#define is_aie_KeyIDHashSqlFld 			"KeyIDHash"
#define is_aie_KeyPrivateSqlFld			"Private"
#define is_aie_KeyPublicSqlFld			"Public"

#define is_aie_HashDayIDSqlFld			"DayID"
#define is_aie_HashIDSqlFld			"ID"
#define is_aie_HashYearSqlFld			"Year"
#define is_aie_HashLoSqlFld			"Lo"
#define is_aie_HashHiSqlFld			"Hi"

#define is_aie_SitemapInfoUrlSqlFld		"Url"
//#define is_aie_SitemapAgentSqlFld
#define is_aie_SitemapInfoPathSqlFld		"Path"
#define is_aie_SitemapInfoRunTimeSqlFld		"RunTime"
#define is_aie_SitemapInfoSizeSqlFld		"Size"
#define is_aie_SitemapInfoLastAccessSqlFld	"LastAccess"

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
struct aie_sql_feld_2_var
{
   char *SqlFld;
   char *Value;
   unsigned int Len;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/


/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */
