/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_sql_util.c                                              */
/* Library     : aiengine-sql_wrap-3.nn.nn.so                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 13.09.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Abstrakte Datenbankschnittstelle fuer SQL                                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Alle Logmeldungen Anpassen auf WinGui Client*/
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sql_util_version = "1.0.0";                                //
const char *modul_sql_util         = "SQLUtil";                              //
const char *modul_sql_util_date    = __DATE__;                               //
const char *modul_sql_util_time    = __TIME__;                               //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_LOG_LIB			1
#define AIENGINE_USE_SQL_WRAP_LIB		1
#define AIE_BUF_SIZE_RELOAD_VALUES			10240		     //
#define AIE_BUF_SIZE_RELOAD_BEZEICHNUNGEN		10240		     //
#define AIE_BUF_SIZE_RELOAD_SQL_CMD			20480		     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Headerdateien                                                      */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
static char *reload_sql_cmd = NULL;                                          //
static char *reload_values = NULL;                                           //
static char *reload_bezeichnungen = NULL;                                    //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
struct dump_table_callback_data
{
   FILE *fptr;
   unsigned long RowCount;
};
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
static int dump_table_callback(void *pArg, int nArg, char **azArg,           //
                                                     char **azCol);          //
static bool aie_sql_init_reload_table(void);                                 //
static void aie_sql_release_reload_table(void);                              //
static bool aie_sql_util_reload_table_record(int tableid,                    //
                                            struct aie_file_text **text_base,//
                                             struct aie_sql_meta_db          //
                                                   *sql_meta_db);            //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/
static int dump_table_callback(void *pArg, int nArg, char **azArg, char **azCol)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "dump_table_callback" },
      { AIE_LOG_ERROR, "Keine Callback Daten!" },
      { AIE_LOG_DB_INFO, "%s = %s" }
   };
   struct aie_sql_data *callback_aie_sql_data = (struct aie_sql_data *)pArg;
   struct dump_table_callback_data *callback_data = 
                          (struct dump_table_callback_data *)
			                           callback_aie_sql_data->data;
   if(callback_data == NULL)
   {
      // Keine Callback Daten!
      aie_sys_log(1);
   }
   else
   {
      register int i = 0;
      fprintf(callback_data->fptr, ">Record:%ld\n", callback_data->RowCount);
      for(i = 0; i<nArg; i++)
      {
	 fprintf(callback_data->fptr, 
	         ">Col:%s:%s\n", azCol[i], azArg[i] ? azArg[i] : "");
         // "%s = %s"
         aie_sys_log(2, azCol[i], azArg[i] ? azArg[i] : "..");
      }
      callback_data->RowCount++;
   }
   return(0);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
char *aie_sql_util_dump_table(int tableid, struct aie_sql_meta_db
                                                 *sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_util_dump_table Id[%d]" },
      { AIE_LOG_DB_INFO, "Dump SQL Table - [%s]-->[%s]" }, 
      { AIE_LOG_ERROR,   "Dump SQL Table - SQL Fehler" },
      { AIE_LOG_ERROR,   "Dump SQL Table - Memory?" },
      { AIE_LOG_ERROR,   "Dump SQL Table  aie_sql_data == NULL!" },
      { AIE_LOG_ERROR,   "Dump SQL Table - Unbekannte Tabelle ID[%d]" }
   };
   struct dump_table_callback_data dump_table_callback_data;
   char *rc_ptr = NULL;
   static char dump_name[AIE_SQL_DUMP_TABLE_DUMP_NAME_LEN];
   const char *table_name = aie_sql_meta_get_table_name_from_id(tableid, 
	                                                        sql_meta_db); 
   aie_sys_log(0, tableid);
   *(dump_name) = '\0';
   if (__builtin_expect((table_name != NULL),true))
   {
      struct aie_sql_data *sql_data;
      if ((sql_data = sql_meta_db->aie_sql_data) != NULL)
      {
	 FILE *fptr;
         char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
         if (sql_cmd != NULL)
	 {
            strcpy(dump_name, sql_meta_db->db_path);
            strcat(dump_name, "/dump/");
            aie_check_create_dir(dump_name, true);
            strcat(dump_name, aie_get_time_stamp());
            strcat(dump_name, ".");
            strcat(dump_name, table_name);
            strcat(dump_name, ".db");
            // Dump SQL Table - [%s]-->[%s]", 
            aie_sys_log(1, table_name, dump_name);
	    sprintf(sql_cmd, "SELECT * FROM %s", table_name);
            sql_data->callback = dump_table_callback;
            sql_data->sql_cmd = sql_cmd;
            sql_data->data = (void *)&dump_table_callback_data;
            if ((fptr = aie_open_write_text_file(dump_name)) != NULL)
            {
	       fprintf(fptr, ">Filename:%s\n", dump_name);
	       fprintf(fptr, ">Datenbank:%s\n", sql_data->sql_db_data->dbf);
	       fprintf(fptr, ">Table:%s\n", table_name);
               dump_table_callback_data.RowCount = 1;
               dump_table_callback_data.fptr = fptr;
	       if (aie_sql_run(sql_data))
	       {
                  rc_ptr = dump_name;
	       }
	       else
	       {
                  // Dump SQL Table - SQL Fehler
                  aie_sys_log(2);
	       }
	       fprintf(fptr, ">EOF:%s\n", dump_name);
	       aie_close_file(fptr);
	    }
	    aie_free(sql_cmd);
         }
         else
         {
            // Dump SQL Table - Memory?
            aie_sys_log(3);
         }
      }
      else
      {
	 // Dump SQL Table  aie_sql_data == NULL!
         aie_sys_log(4);
      }
   }
   else
   {
      // Dump SQL Table - Unbekannte Tabelle ID[%d]
      aie_sys_log(5, tableid);
   }
      
   return(rc_ptr);
}

static bool aie_sql_util_reload_table_record(int tableid,
                                             struct aie_file_text **text_base,
                                             struct aie_sql_meta_db
                                                   *sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "aie_sql_util_reload_table_record Tableid[%d]" },
      { AIE_LOG_DB_INFO,  "Reload Col Name[%s] Value[%s]" },
      { AIE_LOG_ERROR,    "Speicherueberlauf Values!" },
      { AIE_LOG_ERROR,    "Speicherueberlauf Bezeichnungen!" },
      { AIE_LOG_ERROR,    "Speicherueberlauf Sql Cmd!" },
      { AIE_LOG_SECURITY, "Speicherueberlauf SQL[%s]" },
      { AIE_LOG_ERROR,    "Fehler Memory Reload Table sql_data == NULL "
	                  "Table[%s]" }
   };
   bool rc = false;
   const char *table_name = aie_sql_meta_get_table_name_from_id(tableid, 
	                                                  sql_meta_db); 
   struct aie_sql_data *sql_data = NULL;
   struct aie_file_text *text_ptr = *text_base != NULL ? 
                                                    (*text_base)->next : NULL;

   aie_sys_log(0, tableid);
   if (__builtin_expect(((sql_meta_db != NULL) &&
	    ((sql_data = sql_meta_db->aie_sql_data) != NULL)), true))
   {
      char *sptr;
      char *sptr2;
      bool is_first = true;
      *reload_sql_cmd = '\0';
      *reload_bezeichnungen = '\0';
      *reload_values = '\0';
      while(text_ptr != NULL)
      {
         if ((*text_ptr->txt == '>') && 
             (strncmp((text_ptr->txt + 1), "Col:", 4)==0))
         {
            if ((sptr = strchr(text_ptr->txt + 1, ':')) != NULL)
            {
               *sptr = '\0';
               sptr++;
               if ((strcmp((text_ptr->txt + 1), "Col")) == 0)
               {
                  if ((sptr2 = strchr(sptr, ':')) != NULL)
                  {
                     *sptr2 = '\0';
	             sptr2++;
	             if (is_first)
	             {
	                is_first = false;
                     }
	             else
                     {
                        strcat(reload_values, ", ");
                        strcat(reload_bezeichnungen, ", ");
	             }
	             strcat(reload_bezeichnungen, sptr);
	             strcat(reload_values, "\"");
	             strcat(reload_values, sptr2);
	             strcat(reload_values, "\"");
		     // Reload Col Name[%s] Value[%s]
                     aie_sys_log(1, sptr, sptr2);
                  }
                  else
                  {
                      break;
                  }
 	       }
               else
	       {
                  break;
               }
	    }
         }
         else
         {
            break;
         }
         text_ptr = text_ptr->next;
      }
       //if (!is_first)
       {
         if (!aie_do_test_mem_ok(reload_values))
	 {
	    // Speicherueberlauf Values!
	    printf("%s(%d): %s!", __FILE__, __LINE__, aie_log_msg[2].msg);
            aie_sys_log(2);
	 }
         if (!aie_do_test_mem_ok(reload_bezeichnungen))
	 {
	    // Speicherueberlauf Bezeichnungen!
	    printf("%s(%d): %s!", __FILE__, __LINE__, aie_log_msg[3].msg);
            aie_sys_log(3);
		                                             
	 }
         sprintf(reload_sql_cmd, "INSERT INTO %s (%s) VALUES (%s)",
			 table_name, reload_bezeichnungen, reload_values);
         if (!aie_do_test_mem_ok(reload_sql_cmd))
	 {
	    // Speicherueberlauf Sql Cmd!
	    printf("%s(%d): %s!", __FILE__, __LINE__, aie_log_msg[4].msg);
            aie_sys_log(4);
            // Speicherueberlauf SQL[%s]
            aie_sys_log(5, reload_sql_cmd);
            printf("%s(%d): SQL[%s]", __FILE__, __LINE__, reload_sql_cmd);
	    exit(1);
	 }
         sql_data->sql_cmd = reload_sql_cmd;
         rc = aie_sql_run(sql_data);
      }
   }
   else
   {
      // Fehler Memory Reload Table sql_data == NULL Table[%s]
      aie_sys_log(6, table_name);
   }
   *text_base = text_ptr;
   return(rc);
}

static bool aie_sql_init_reload_table(void)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_init_reload_table" },
      { AIE_LOG_ERROR, "Wert != NULL bei initilisierung!" },
      { AIE_LOG_ERROR, "Fehler Memory Reload Table" }
   };
   bool rc = true;

   aie_sys_log(0);
   if ((reload_sql_cmd != NULL) || (reload_bezeichnungen != NULL) ||
	 (reload_values != NULL))
   {
      // Wert != NULL bei initilisierung!
      aie_sys_log(1);
      rc = false;
   }
   reload_sql_cmd = (char *)aie_malloc(AIE_BUF_SIZE_RELOAD_SQL_CMD);
   if (reload_sql_cmd != NULL)
   {
       reload_bezeichnungen = 
	                 (char *)aie_malloc(AIE_BUF_SIZE_RELOAD_BEZEICHNUNGEN);
       if (reload_bezeichnungen != NULL)
       {
          reload_values = 
	                (char *)aie_malloc(AIE_BUF_SIZE_RELOAD_VALUES);
          if (reload_values == NULL)
          {
             // Fehler Memory Reload Table
             aie_sys_log(2);
	  
             rc = false;
             aie_free(reload_bezeichnungen);
	     reload_bezeichnungen = NULL;
             aie_free(reload_sql_cmd);
             reload_sql_cmd = NULL;
          }
       }
       else
       {
          // Fehler Memory Reload Table
          aie_sys_log(2);
	  
          rc = false;
          aie_free(reload_sql_cmd);
          reload_sql_cmd = NULL;
          rc = false;
       }
    }
    else
    {
       // Fehler Memory Reload Table
       aie_sys_log(2);
       rc = false;
    }
    return(rc);
}

static void aie_sql_release_reload_table(void)
{
   if (reload_sql_cmd != NULL)
   {
      aie_free(reload_sql_cmd);
      reload_sql_cmd = NULL;
   }
   if (reload_bezeichnungen != NULL)
   {
      aie_free(reload_bezeichnungen);
      reload_bezeichnungen = NULL;
   }
   if (reload_values != NULL)
   {
      aie_free(reload_values);
      reload_values = NULL;
   }
}
bool aie_sql_util_reload_table(int tableid, char *dump_name,
                                                  struct aie_sql_meta_db
                                                          *sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,         "aie_sql_util_reload_table Id[%d] Name[%s]" },
      { AIE_LOG_DB_INFO,       "Reload SQL Table - [%s]-->[%s]" },
      { AIE_LOG_SECURITY_INFO, "Reload OK Record [%s]" },
      { AIE_LOG_SECURITY,      "Reload Record Failed [%s]" },
      { AIE_LOG_ERROR,         "Reload SQL Tabelle [%s] Init Fehler! "
	                       "Tabelle [%s]" },
      { AIE_LOG_ERROR,         "Reload SQL DumpFile [%s] Nicht gefunden! "
	                       "Tabelle [%s]" },
      { AIE_LOG_ERROR,         "Dump SQL Table - Dump Name == NULL "
	                       "Tabelle[%s]" },
      { AIE_LOG_ERROR,         "Dump SQL Table - Unbekannte Tabelle ID[%d]" },
   };
      bool rc = true;
      const char *table_name = aie_sql_meta_get_table_name_from_id(tableid, 
	       	                                                  sql_meta_db); 
	 
   aie_sys_log(0, tableid, dump_name);
   if (__builtin_expect(((dump_name != NULL) && (table_name != NULL)), true))
   {
      struct aie_file_text *text_base = NULL;
      struct aie_file_text *text_ptr;
      // Reload SQL Table - [%s]-->[%s]
      aie_sys_log(1, dump_name, table_name); 
      if ((aie_file_exist(dump_name)) &&
	  ((text_ptr = aie_load_file_text(dump_name, &text_base)) != NULL))
      {
	 char *sptr;
         if (aie_sql_init_reload_table())
	 {
	    bool is_ok;
	    while(text_ptr != NULL)
	    {
	       is_ok = false;
	       if ((sptr = strchr(text_ptr->txt + 1, '\n')) != NULL)
	       {
	          *sptr = '\0';
	       }
               if (*text_ptr->txt == '>')
	       {
	          if ((sptr = strchr(text_ptr->txt + 1, ':')) != NULL)
	          {
		     *sptr = '\0';
		     sptr++;
		     if ((strcmp((text_ptr->txt + 1), "Record")) == 0)
		     {
                        if (__builtin_expect(
				 (aie_sql_util_reload_table_record(tableid, 
			                                  &text_ptr,
							  sql_meta_db)), true))
		        {
			   // Reload OK Record [%s]
                           aie_sys_log(2, sptr);
		        }
		        else
		        {
			   // Reload Record Failed [%s]
                           aie_sys_log(3, sptr);
			   rc = false;
		        }
			is_ok = true;
		     }
	          }
	       }
	       if (!is_ok)
	       {
	          text_ptr = text_ptr->next;
	       }
	    }
            aie_sql_release_reload_table();
	    aie_free_file_text(&text_base);
	 }
	 else
	 {
             // Reload SQL Tabelle [%s] Init Fehler! Tabelle [%s]
             aie_sys_log(4, dump_name, table_name); 
             rc = false;
	 }
      }
      else
      {
         // Reload SQL DumpFile [%s] Nicht gefunden! Tabelle [%s]
         aie_sys_log(5, dump_name, table_name); 
         rc = false;
      }
   }
   else
   {
      if (__builtin_expect((dump_name == NULL), false))
      {
	 // Dump SQL Table - Dump Name == NULL Tabelle[%s]
         aie_sys_log(6, table_name);
      }
      else
      {
         // Dump SQL Table - Unbekannte Tabelle ID[%d]
         aie_sys_log(7, tableid);
      }
      rc = false;
   }
   return(rc);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_sql_util_size    = __LINE__;                                     //
/* -------------------------------- EOF ------------------------------------ */

