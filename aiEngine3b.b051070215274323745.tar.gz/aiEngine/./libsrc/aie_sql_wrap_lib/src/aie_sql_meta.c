/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_sql_meta.c                                              */
/* Library     : aiengine-sql_wrap-3.nn.nn.so                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 10.09.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Abstrakte Datenbankschnittstelle fuer SQL                                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 03.01.2005  : ALH           : Integer Werte werden wenn nicht vorgegeben  */
/*             :               : bei INSERT nun mit 0 initialisiert.         */
/*.............+...............+.............................................*/
/* 01.01.2005  : ALH           : Neue Funktion aie_sql_meta_rollback         */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sql_meta_version = "1.0.0";                                //
const char *modul_sql_meta         = "MetaSQL";                              //
const char *modul_sql_meta_date    = __DATE__;                               //
const char *modul_sql_meta_time    = __TIME__;                               //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_LOG_LIB			1
#define AIENGINE_USE_SQL_WRAP_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Headerdateien                                                      */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/
//#undef AIENGINE_LOG_NO_LOG
//#define AIENGINE_LOG_NO_LOG	0

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_sql_data *aie_sql_meta_attach_db(int dbid, struct aie_sql_meta_db
                                                             *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,   "aie_sql_meta_attach_db Id[%d]" },
      { AIE_LOG_ERROR,   "Moeglicherweise bereits eine Meta Datenbank "
	                 "geoeffnet!" },
      { AIE_LOG_ERROR,   "Datenbank Fehler beim Oeffnen --> \"%s\"" },
      { AIE_LOG_DB_INFO, "Datenbank %s geoeffnet" },
      { AIE_LOG_ERROR,   "Out of Memory?" },
      { AIE_LOG_ERROR,   "Datenbank Id[%d] nicht gefunden!" },
      { AIE_LOG_ERROR,   "Kein Datenbank OS Pfad angegeben!" }
   };
   struct aie_sql_data *aie_sql_data = NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, dbid);
   #endif
   if (__builtin_expect((aie_sql_meta_db->aie_sql_data != NULL), false))
   {
      // Moeglicherweise bereits eine Meta Datenbank geoeffnet!
      aie_sys_log(1);
   }
   if (__builtin_expect((aie_sql_meta_db->db_path != NULL),true))
   {
      const char *database = aie_sql_meta_get_db_name_from_id(dbid,
                                                              aie_sql_meta_db);
      if (__builtin_expect((database != NULL),true))
      {
         char *db_name;
         if (__builtin_expect(
		  ((db_name = (char *)aie_malloc(AIENGINE_MAX_PATH_LENGTH)) 
		                                                    != NULL),
		                                                      true))
         {
            sprintf(db_name, "%s/%s", aie_sql_meta_db->db_path, database);
            if (__builtin_expect(
		     ((aie_sql_data = aie_sql_attach_db(db_name)) == NULL),
		                                                        false))
            {
               // Datenbank Fehler beim Oeffnen --> \"%s\"\n",
               aie_sys_log(2, db_name);
            }
            else
            {
               aie_sql_data->callback = NULL;
	       aie_sql_data->data = NULL;
	       aie_sql_data->sql_rc = 0;
               #if AIENGINE_LOG_TRACE_DB_META_TRACE
               // Datenbank %s geoeffnet
               aie_sys_log(3, db_name);
               #endif
	    }
	    aie_free(db_name);
         }
         else
         {
             // Out of Memory?
            aie_sys_log(4);
         }
      }
      else
      {
         // Datenbank Id[%d] nicht gefunden!
         aie_sys_log(5, dbid);
      }
   }
   else
   {
      // Kein Datenbank OS Pfad angegeben!
      aie_sys_log(6);
   }
   aie_sql_meta_db->aie_sql_data = aie_sql_data;
   return(aie_sql_data);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_meta_release_db(struct aie_sql_meta_db *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_relaese_db" },
      { AIE_LOG_ERROR, "Meta DB Null Ptr!" }
   };
   bool rc = false;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((aie_sql_meta_db != NULL), true))
   {
      if (__builtin_expect((aie_sql_meta_db->aie_sql_data != NULL), true))
      {
          rc = aie_sql_release_db(aie_sql_meta_db->aie_sql_data);
	  aie_sql_meta_db->aie_sql_data = NULL;
      }
      else
      {
         // Meta DB Null Ptr!
         aie_sys_log(1);
      }
   }
   else
   {
      // Meta DB Null Ptr!
      aie_sys_log(1);
   }
   return(rc);
}

bool aie_sql_meta_start_transaction(struct aie_sql_meta_db *aie_sql_meta_db)
{
   if (__builtin_expect((aie_sql_meta_db->aie_sql_data != NULL),true))
   {
      return(aie_sql_start_transaction(aie_sql_meta_db->aie_sql_data));
   }
   return(false);
}

bool aie_sql_meta_commit(struct aie_sql_meta_db *aie_sql_meta_db)
{
   if (__builtin_expect((aie_sql_meta_db->aie_sql_data != NULL),true))
   {
      return(aie_sql_commit(aie_sql_meta_db->aie_sql_data));
   }
   return(false);
}

bool aie_sql_meta_rollback(struct aie_sql_meta_db *aie_sql_meta_db)
{
   if (__builtin_expect((aie_sql_meta_db->aie_sql_data != NULL),true))
   {
      return(aie_sql_rollback(aie_sql_meta_db->aie_sql_data));
   }
   return(false);
}

bool aie_sql_meta_create_table(int tableid, struct aie_sql_meta_db
                                                   *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_create_table Id[%d] %s" },
      { AIE_LOG_ERROR, "Fehler Meta SQL Table Def Create Table "
	               "ID[%d] Table [%s]!" },
      { AIE_LOG_ERROR, "Fehler Meta SQL Create Table ID[%d] Table [%s]!" },
      { AIE_LOG_ERROR, "Create Table ID[%d] Table ID nicht gefunden!" }
   };
   bool rc = true;
   const char *table = aie_sql_meta_get_table_name_from_id(tableid, 
                                                            aie_sql_meta_db); 
   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, tableid, table);
   #endif
    if (__builtin_expect((table != NULL),true))
    {
       unsigned int size_table_def = 0;
       struct aie_sql_table_def *table_def =
	    aie_sql_meta_get_table_def_from_id(tableid, &size_table_def,
                                                         aie_sql_meta_db); 
       if (__builtin_expect(((table_def == NULL) ||
		             (size_table_def <= 0)),false))
       {
          // Fehler Meta SQL Table Def Create Table ID[%d] Table [%s]!
          aie_sys_log(1, tableid, table);
	  rc = false;
       }
       else
       {
          if (__builtin_expect(
		   (!aie_sql_create_table(aie_sql_meta_db->aie_sql_data, 
					  table, 
		                          true,
                                           table_def,
                                           size_table_def)),false))
	  {
             // Fehler Meta SQL Create Table ID[%d] Table [%s]!
             aie_sys_log(2, tableid, table);
	     rc = false;
	  }
       }
    }
    else
    {
       // Create Table ID[%d] Table ID nicht gefunden!
       aie_sys_log(3, tableid);
       rc = false;
    }
    return(rc);
}
	    
bool aie_sql_meta_create_index(int indexid, struct aie_sql_meta_db
                                                   *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_create_index Id[%d] Name[%s]" },
      { AIE_LOG_ERROR, "Fehler Meta SQL Table Def Create index "
	               "IndexID[%d] index [%s] TableID[%d]!" },
      { AIE_LOG_ERROR, "Fehler Meta SQL Create index "
		       "IndexID[%d] index [%s] Tableid[%d]!" }, 
      { AIE_LOG_ERROR, "Fehler Meta SQL Create index Table nicht gefunden "
	               "IndexID[%d] index [%s] Tableid[%d]!" }, 
      { AIE_LOG_ERROR, "Create Table IndexID[%d] Table ID nicht gefunden!" }
   };
   bool rc = true;
   const char *index_name = aie_sql_meta_get_index_name_from_id(indexid, 
                                                            aie_sql_meta_db); 
   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, indexid, index_name);
   #endif
    if (__builtin_expect((index_name != NULL),true))
    {
       unsigned int size_index_def = 0;
       int tableid = 0;
       int index_typ = 0;
       struct aie_sql_index_def *index_def =
	    aie_sql_meta_get_index_def_from_id(indexid, &tableid, &index_typ,
		                               &size_index_def,
                                               aie_sql_meta_db); 
       if (__builtin_expect(((index_def == NULL) ||
		             (size_index_def <= 0) ||
			     (tableid <= 0)),false))
       {
          // Fehler Meta SQL Table Def Create index 
	  // IndexID[%d] index [%s] TableID[%d]!", 
          aie_sys_log(1, indexid, index_name, tableid);
	  rc = false;
       }
       else
       {
          const char *table_name = aie_sql_meta_get_table_name_from_id(tableid, 
                                                              aie_sql_meta_db); 
	  if (__builtin_expect((table_name != NULL),true))
	  {
             if (__builtin_expect(
		   (!aie_sql_create_index(aie_sql_meta_db->aie_sql_data,
					  table_name, 
					  index_name, 
					  index_typ,
		                          true,
                                           index_def,
                                           size_index_def)),false))
	     {
                // Fehler Meta SQL Create index 
		// IndexID[%d] index [%s] Tableid[%d]!", 
                aie_sys_log(2, indexid, index_name, tableid);
	        rc = false;
	     }
	  }
	  else
	  {
             // Fehler Meta SQL Create index Table nicht gefunden "
	     //                "IndexID[%d] index [%s] Tableid[%d]!", 
             aie_sys_log(3, indexid, index_name, tableid);
	     rc = false;
	  }
       }
    }
    else
    {
       // Create Table ID[%d] Table ID nicht gefunden!",
       aie_sys_log(4, indexid);
       rc = false;
    }
    return(rc);
}
/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_meta_drop_table(int tableid, struct aie_sql_meta_db
                                                *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_drop_table Id[%d] Name[%s]" },
      { AIE_LOG_ERROR, "Fehler DROP TABLE %d:%s" },
      { AIE_LOG_ERROR, "Out of Memory?" },
      { AIE_LOG_ERROR, "Fehler sql_data == NULL / DROP TABLE %d:%s" },
      { AIE_LOG_ERROR, "DROP TABLE Fehler TableID[%d] nicht gefunden!" }
   };
   bool rc = false;
   const char *table_name =
              aie_sql_meta_get_table_name_from_id(tableid, aie_sql_meta_db);

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, tableid, table_name);
   #endif
   if (__builtin_expect((table_name != NULL), true))
   {
      if (__builtin_expect((aie_sql_meta_db->aie_sql_data != NULL),true))
      {
         char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
	 
         if (__builtin_expect((sql_cmd != NULL),true))
         {
            aie_sql_meta_db->aie_sql_data->sql_cmd = sql_cmd;

            sprintf(sql_cmd, "DROP TABLE %s", table_name);
            if (__builtin_expect((!(rc = 
			   aie_sql_run(aie_sql_meta_db->aie_sql_data))),false))
	    {
               // Fehler DROP TABLE %d:%s
               aie_sys_log(1, tableid, table_name);
	    }
	    aie_free(sql_cmd);
         }       
         else
         {
            // Out of Memory?
            aie_sys_log(2);
         }
      }
      else
      {
         // Fehler sql_data == NULL / DROP TABLE %d:%s", 
         aie_sys_log(3, tableid, table_name);
      }
   }
   else
   {
      // DROP TABLE Fehler TableID[%d] nicht gefunden!
      aie_sys_log(4, tableid);
   }
   return(rc);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_meta_drop_index(int indexid, struct aie_sql_meta_db
                                                *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_drop_index Id[%d] Name[%s]" },
      { AIE_LOG_ERROR, "Fehler DROP INDEX %d:%s" },
      { AIE_LOG_ERROR, "Out of Memory?" },
      { AIE_LOG_ERROR, "Fehler sql_data == NULL / DROP INDEX %d:%s" },
      { AIE_LOG_ERROR, "DROP INDEX Fehler IndexID[%d]" }
   };
   bool rc = false;
   const char *index_name =
              aie_sql_meta_get_index_name_from_id(indexid, aie_sql_meta_db);

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, indexid, index_name);
   #endif
   if (__builtin_expect((index_name != NULL), true))
   {
      if (__builtin_expect((aie_sql_meta_db->aie_sql_data != NULL),true))
      {
         char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
	 
         if (__builtin_expect((sql_cmd != NULL),true))
         {
            aie_sql_meta_db->aie_sql_data->sql_cmd = sql_cmd;

            sprintf(sql_cmd, "DROP INDEX %s", index_name);
            if (__builtin_expect((!(rc = 
			   aie_sql_run(aie_sql_meta_db->aie_sql_data))),false))
	    {
               // Fehler DROP INDEX %d:%s
               aie_sys_log(1, indexid, index_name);
	    }
	    aie_free(sql_cmd);
         }       
         else
         {
            // Out of Memory?
            aie_sys_log(2);
         }
      }
      else
      {
         // Fehler sql_data == NULL / DROP INDEX %d:%s
         aie_sys_log(3, indexid, index_name);
      }
   }
   else
   {
      // DROP INDEX Fehler IndexID[%d]
      aie_sys_log(4, indexid);
   }
   return(rc);
}

bool aie_sql_meta_table_insert(struct aie_sql_meta_insert *sql_meta_insert)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "aie_sql_meta_table_insert" },
      { AIE_LOG_SECURITY, "Fehler SQL Meta Insert! [%s]" },
      { AIE_LOG_ERROR,    "Fehler SQL Meta Table Insert TableID[%d]" }
   };
   bool rc = true;
   struct aie_sql_meta_db *sql_meta_db = NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((sql_meta_insert != NULL) &&
	    ((sql_meta_db = sql_meta_insert->sql_meta_db) != NULL) &&
	    (sql_meta_db->aie_sql_data != NULL)),
	                                                              true))
   {
      char *table_insert_sql = aie_sql_meta_table_insert_sql(sql_meta_insert);
      if (__builtin_expect((table_insert_sql != NULL), true))
      {
         sql_meta_db->aie_sql_data->sql_cmd = table_insert_sql;
         if (__builtin_expect(
	          (!aie_sql_run(sql_meta_db->aie_sql_data)),false))
         {
            // Fehler SQL Meta Insert! [%s]
            aie_sys_log(1, table_insert_sql);
	    rc = false;
         }
      }
      else
      {
	 rc = false;
      }
   }
   else
   {
      // Fehler SQL Meta Table Insert TableID[%d]
      aie_sys_log(2, sql_meta_insert->tableid);
      rc = false;
   }
   return(rc);
}

bool aie_sql_meta_table_update(struct aie_sql_meta_update *sql_meta_update)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "aie_sql_meta_table_update" },
      { AIE_LOG_SECURITY, "Fehler SQL Meta Update! [%s]" },
      { AIE_LOG_ERROR,    "Fehler SQL Meta Table Update TableID [%d]" }
   };
   bool rc = true;
   struct aie_sql_meta_db *sql_meta_db = NULL;
   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect(((sql_meta_update != NULL) &&
	    ((sql_meta_db = sql_meta_update->sql_meta_db) != NULL) &&
	    (sql_meta_db->aie_sql_data != NULL)),
	                                                              true))
   {
      const char *table_update_sql = 
	                      aie_sql_meta_table_update_sql(sql_meta_update);
      if (__builtin_expect((table_update_sql != NULL), true))
      {
         sql_meta_db->aie_sql_data->sql_cmd = table_update_sql;
         if (__builtin_expect(
	          (!aie_sql_run(sql_meta_db->aie_sql_data)),false))
         {
            // Fehler SQL Meta Update! [%s]
            aie_sys_log(1, table_update_sql);
	    rc = false;
         }
      }
      else
      {
	 rc = false;
      }
   }
   else
   {
      // Fehler SQL Meta Table Update TableID [%d]
      aie_sys_log(2, sql_meta_update->tableid);
      rc = false;
   }
   return(rc);
}

const char *aie_sql_meta_get_feld_value(const char *feld,
			                struct aie_sql_meta_feld_value_list
			      		       *sql_meta_feld_value_list,
                                    unsigned int size_sql_meta_feld_value_list)
{
   // TODO: NULL Ptr Check 
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_get_feld_value Feld[%s]" },
      { AIE_LOG_ERROR, "SQL Meta kein Wert fuer Feld [%s]" }
   };
   const char *rc_ptr = NULL;
   register unsigned int z = 0;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, feld);
   #endif
   for (z = 0; z < size_sql_meta_feld_value_list;z++)
   {
      if (strcmp(feld, sql_meta_feld_value_list->feld) == 0)
      {
	 rc_ptr = sql_meta_feld_value_list->value;
	 break;
      }
      sql_meta_feld_value_list++;
   }
   if (rc_ptr == NULL)
   {
      // SQL Meta kein Wert fuer Feld [%s]
      aie_sys_log(1, feld);
   }
   return(rc_ptr);
}

char *aie_sql_meta_table_insert_sql(struct aie_sql_meta_insert *sql_meta_insert)
{
   // TODO: NULL Ptr Check 
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_table_insert_sql Table[%s]" },
      { AIE_LOG_ERROR, "Fehler Meta SQL Table Def Gen Table Insert "
	               "TableID[%d] Table [%s]!" },
      { AIE_LOG_ERROR, "Fehler Anzahl Insert Value zu Feldern "
                       "Felder[%d] Values[%d]" },
      { AIE_LOG_ERROR, "Sql Meta Insert Feld Unterschied Index z=%d %s != %s" },
      { AIE_LOG_ERROR, "meta_table_insert Table == NULL? Id=%d" }
   };
   static char table_insert_sql[AIE_SQL_TABLE_INSERT_BUFFER_LEN];
   char *rc_ptr = NULL;
   const char *value = NULL;
   int tableid = sql_meta_insert->tableid;
   bool is_in_order = sql_meta_insert->is_in_order;
   bool fail_iggy = sql_meta_insert->fail_iggy;
   struct aie_sql_meta_db  *sql_meta_db = sql_meta_insert->sql_meta_db;
   struct aie_sql_meta_feld_value_list *sql_meta_feld_value_list =
                                     sql_meta_insert->sql_meta_feld_value_list;
   unsigned int size_sql_meta_feld_value_list =
                                sql_meta_insert->size_sql_meta_feld_value_list;
   const char *table = aie_sql_meta_get_table_name_from_id(tableid,
                                                            sql_meta_db);

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, table);
   #endif
   *(table_insert_sql) = '\0';

    if (__builtin_expect((table != NULL),true))
    {
       unsigned int size_table_def = 0;
       struct aie_sql_table_def *table_def =
	    aie_sql_meta_get_table_def_from_id(tableid, &size_table_def,
                                                         sql_meta_db);
       if (__builtin_expect(((table_def == NULL) ||
		             (size_table_def <= 0)),false))
       {
          // Fehler Meta SQL Table Def Gen Table Insert
	  //        TableID[%d] Table [%s]!
          aie_sys_log(1, tableid, table);
       }
       else
       {
	  if ((size_table_def != size_sql_meta_feld_value_list) && is_in_order)
	  {
	     // Fehler Anzahl Insert Value zu Feldern
             // Felder[%d] Values[%d]
             aie_sys_log(2, size_table_def, size_sql_meta_feld_value_list);

	  }
	  else
	  {
             register unsigned int z = 0;
	     strcpy(table_insert_sql, "INSERT ");
	     if (fail_iggy)
	     {
	         strcat(table_insert_sql, "OR IGNORE ");
	     }
	     strcat(table_insert_sql, "INTO ");
	     strcat(table_insert_sql, table);
	     strcat(table_insert_sql, " VALUES (");
             for (z = 0; z < size_table_def; z++)
             {
	        int typ = table_def->typ;
		if (is_in_order)
		{
		   if (strcmp(table_def->feld,
			      sql_meta_feld_value_list->feld) == 0)
		   {
		      value = sql_meta_feld_value_list->value;
		   }
		   else
		   {
		      // Sql Meta Insert Feld Unterschied Index z=%d %s != %s
                      aie_sys_log(3, z, table_def->feld, 
			                sql_meta_feld_value_list->feld);
		   }
		}
		else
		{
		   value = aie_sql_meta_get_feld_value(table_def->feld,
			                        sql_meta_feld_value_list,
			                        size_sql_meta_feld_value_list);
		}
	        if (z > 0)
	        {
	           strcat(table_insert_sql, ", \n");
	        }
                if (((typ & AIE_DB_FELD_TYPE_INTEGER) != 0) ||
                    ((typ & AIE_DB_FELD_TYPE_REAL) != 0) ||
                    ((typ & AIE_DB_FELD_TYPE_NUMERIC) != 0))
	        {
		   if (__builtin_expect(
			          ((value != NULL) && (*value != '\0')),true))
		   {
	              strcat(table_insert_sql, value);
		   }
		   else
		   {
	              strcat(table_insert_sql, "0");
		   }
	        }
	        else
	        {
	   	   if (__builtin_expect((value != NULL),true))
		   {
		      const char *sptr = value; 
		      char *sptr2 = strchr(table_insert_sql, '\0');
		      *sptr2 = '\'';
		      sptr2++;
                      while (*sptr != '\0')
		      {
			 *sptr2 = *sptr;
			 sptr2++;
			 if ((*sptr == '\'') || (*sptr == '"'))
			 {
			    *sptr2 = *sptr;
			    sptr2++;
			 }
			 sptr++;
		      }
		      *sptr2 = '\'';
		      sptr2++;
		      *sptr2 = '\0';
		   }
		   else
		   {
	              strcat(table_insert_sql, "NULL");
		   }
	        }
		if (is_in_order)
		{
	           sql_meta_feld_value_list++;
		}
                table_def++;
	     }
             strcat(table_insert_sql, "\n);\n");
             rc_ptr = table_insert_sql;
          }
       }
   }
   else
   {
      // Table == NULL?
      aie_sys_log(4, tableid);
   }
   return(rc_ptr);
}

char *aie_sql_meta_table_update_sql(struct aie_sql_meta_update *sql_meta_update)
{
   // TODO: NULL Ptr Check 
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_table_update_sql Tableid[%d]" },
      { AIE_LOG_ERROR, "Fehler Meta SQL Table Def Gen Table Insert "
	               "TableID[%d] Table [%s]!" },
      { AIE_LOG_ERROR, "Fehler Anzahl Insert Value zu Feldern "
	               "Felder[%d] Values[%d]" },
      { AIE_LOG_ERROR, "meta_table_update_sql Table == NULL? Id[%d]" }
   };
   static char table_update_sql[AIE_SQL_TABLE_UPDATE_BUFFER_LEN];
   char *rc_ptr = NULL;
   const char *value = NULL;
   int tableid = sql_meta_update->tableid;
   bool is_in_order = sql_meta_update->is_in_order;
   bool fail_iggy = sql_meta_update->fail_iggy;
   struct aie_sql_meta_db  *sql_meta_db = sql_meta_update->sql_meta_db;
   struct aie_sql_meta_feld_value_list *sql_meta_feld_value_list =
                                     sql_meta_update->sql_meta_feld_value_list;
   unsigned int size_sql_meta_feld_value_list =
                                sql_meta_update->size_sql_meta_feld_value_list;
   const char *table = aie_sql_meta_get_table_name_from_id(tableid,
                                                            sql_meta_db);

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, tableid);
   #endif
   *(table_update_sql) = '\0';

    if (__builtin_expect((table != NULL),true))
    {
       unsigned int size_table_def = 0;
       struct aie_sql_table_def *table_def_base = 
	    aie_sql_meta_get_table_def_from_id(tableid, &size_table_def,
                                                         sql_meta_db);
       struct aie_sql_table_def *table_def = table_def_base;
       if (__builtin_expect(((table_def == NULL) ||
		             (size_table_def <= 0)),false))
       {
          // Fehler Meta SQL Table Def Gen Table Insert
	  //      TableID[%d] Table [%s]!
          aie_sys_log(1, tableid, table);
       }
       else
       {
	  if ((size_table_def != size_sql_meta_feld_value_list) && is_in_order)
	  {
	     // Fehler Anzahl Insert Value zu Feldern
	     // Felder[%d] Values[%d]
             aie_sys_log(2, size_table_def, size_sql_meta_feld_value_list);

	  }
	  else
	  {
             register unsigned int z = 0;
	     strcpy(table_update_sql, "UPDATE ");
	     if (__builtin_expect((fail_iggy),true))
	     {
	         strcat(table_update_sql, "OR INSERT ");
	     }
	     //strcat(table_update_sql, " ");
	     strcat(table_update_sql, table);
	     strcat(table_update_sql, " SET ");
             for (z = 0; z < size_table_def; z++)
             {
	        int typ = table_def->typ;
                value = aie_sql_meta_get_feld_value(table_def->feld,
			                        sql_meta_feld_value_list,
			                        size_sql_meta_feld_value_list);
	        if (__builtin_expect((z > 0),false))
	        {
	           strcat(table_update_sql, ", \n");
	        }
                strcat(table_update_sql, table_def->feld);
                strcat(table_update_sql, " = ");
                if (((typ & AIE_DB_FELD_TYPE_INTEGER) != 0) ||
                    ((typ & AIE_DB_FELD_TYPE_REAL) != 0) ||
                    ((typ & AIE_DB_FELD_TYPE_NUMERIC) != 0))
	        {
		   if (__builtin_expect(
			          ((value != NULL) && (*value != '\0')),true))
		   {
	              strcat(table_update_sql, value);
		   }
		   else
		   {
	              strcat(table_update_sql, "0");
		   }
	        }
	        else
	        {
	   	   if (__builtin_expect(
			          (value != NULL),true))
		   {
	              strcat(table_update_sql, " \"");
	              strcat(table_update_sql, value);
	              strcat(table_update_sql, "\"");
		   }
		   else
		   {
	              strcat(table_update_sql, "NULL");
		   }
	        }
		if (is_in_order)
		{
	           sql_meta_feld_value_list++;
		}
                table_def++;
	     }
             strcat(table_update_sql, " ");
	     if (__builtin_expect(
	            (sql_meta_update->sql_meta_where_value_list != NULL),true))
	     {
		struct aie_sql_meta_where_value_list *where_value_list =
		                    sql_meta_update->sql_meta_where_value_list;
                for (z = 0; 
		     z < sql_meta_update->size_sql_meta_where_value_list; z++)
                {
	           int typ = table_def->typ;
		   value = where_value_list->value;
                   if ((typ = aie_sql_get_feld_typ(
			       where_value_list->feld, 
			       table_def_base,
			       size_table_def)) != AIE_DB_FELD_TYPE_UNKNOWN)
		   {
	              if (__builtin_expect((z == 0),false))
	              {
	                 strcat(table_update_sql, "WHERE \n");
	              }
		      else
		      {
		         switch(where_value_list->condition)
		         {
			    case AIE_SQL_WHERE_AND:
			    {
                               strcat(table_update_sql, " AND ");
			    }
			    break;
			    case AIE_SQL_WHERE_OR:
			    {
                               strcat(table_update_sql, " OR ");
			    }
			    break;
			 }
		      }
                      strcat(table_update_sql, 
			       where_value_list->feld);
		      switch(where_value_list->compare)
		      {
			 case AIE_SQL_WHERE_EQUAL:
			 {
                            strcat(table_update_sql, " = ");
			 }
			 break;
			 case AIE_SQL_WHERE_GREATER:
			 {
                            strcat(table_update_sql, " > ");
			 }
			 break;
			 case AIE_SQL_WHERE_GREATER_EQUAL:
			 {
                            strcat(table_update_sql, " >= ");
			 }
			 break;
			 case AIE_SQL_WHERE_SMALLER:
			 {
                            strcat(table_update_sql, " < ");
			 }
			 break;
			 case AIE_SQL_WHERE_SMALLER_EQUAL:
			 {
                            strcat(table_update_sql, " <= ");
			 }
			 break;
			 case AIE_SQL_WHERE_NOT_EUQAL:
			 {
                            strcat(table_update_sql, " != ");
			 }
			 break;
			 case AIE_SQL_WHERE_NOT_NULL:
			 {
                            strcat(table_update_sql, " NOT NULL ");
			 }
			 break;
		      }
		      if (__builtin_expect(
			       (where_value_list->condition != 
			    AIE_SQL_WHERE_NOT_NULL), true))
		      {
                         if (((typ & AIE_DB_FELD_TYPE_INTEGER) != 0) ||
                             ((typ & AIE_DB_FELD_TYPE_REAL) != 0) ||
                             ((typ & AIE_DB_FELD_TYPE_NUMERIC) != 0))
	                 {
		            if (__builtin_expect(
			          ((value != NULL) && (*value != '\0')),true))
		            {
	                       strcat(table_update_sql, value);
		            }
		            else
		            {
	                       strcat(table_update_sql, "0");
		            }
	                 }
	                 else
	                 {
	   	            if (__builtin_expect(
		   	          (value != NULL),true))
		            {
	                       strcat(table_update_sql, " \"");
	                       strcat(table_update_sql, value);
	                       strcat(table_update_sql, "\"");
		            }
		            else
		            {
	                       strcat(table_update_sql, "NULL");
		            }
			 }
	              }
                      where_value_list++;
		   }
		   else
		   {
                      *table_update_sql = '\0';
		      break;
		   }
		}
	     }
             rc_ptr = table_update_sql;
          }
       }
   }
   else
   {
      // Table == NULL?
      aie_sys_log(3, tableid);
   }
   return(rc_ptr);
}

char *aie_sql_meta_gen_table_insert(struct aie_sql_meta_insert *sql_meta_insert)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_gen_table_insert Id[%d]" }, 
      { AIE_LOG_ERROR, "Fehler Meta SQL Table Def Gen Table Insert "
	               "TableID[%d] Table [%s]!" },
      { AIE_LOG_ERROR, "meta_gen_table_insert Table == NULL?" }
   };
   int tableid = sql_meta_insert != NULL ? sql_meta_insert->tableid : -1;
   bool fail_iggy = sql_meta_insert != NULL ? 
                                            sql_meta_insert->fail_iggy : false;
   struct aie_sql_meta_db  *sql_meta_db = sql_meta_insert != NULL ? 
                                          sql_meta_insert->sql_meta_db : NULL;
   static char table_insert[AIE_SQL_TABLE_INSERT_BUFFER_LEN];
   char *rc_ptr = NULL;
   const char *table = tableid > 0 ? 
                        aie_sql_meta_get_table_name_from_id(tableid,
                                                            sql_meta_db) : NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, tableid);
   #endif
   *(table_insert) = '\0';
    if (__builtin_expect((table != NULL),true))
    {
       unsigned int size_table_def = 0;
       struct aie_sql_table_def *table_def =
	    aie_sql_meta_get_table_def_from_id(tableid, &size_table_def,
                                                         sql_meta_db);
       if (__builtin_expect(((table_def == NULL) ||
		             (size_table_def <= 0)),false))
       {
          // Fehler Meta SQL Table Def Gen Table Insert
	  //        "TableID[%d] Table [%s]!
          aie_sys_log(1, tableid, table);
       }
       else
       {
          register unsigned int z = 0;
	  strcpy(table_insert, "INSERT ");
	  if (fail_iggy)
	  {
	      strcat(table_insert, "OR IGNORE ");
	  }
	  strcat(table_insert, "INTO ");
	  strcat(table_insert, table);
	  strcat(table_insert, " VALUES (");
          for (z = 0; z < size_table_def; z++)
          {
	     int typ = table_def->typ;
	     if (z > 0)
	     {
	        strcat(table_insert, ", \n");
	     }
             if (((typ & AIE_DB_FELD_TYPE_INTEGER) != 0) ||
                 ((typ & AIE_DB_FELD_TYPE_REAL) != 0) ||
                 ((typ & AIE_DB_FELD_TYPE_NUMERIC) != 0))
	     {
	        strcat(table_insert, " %s");
	     }
	     else
	     {
	        strcat(table_insert, " \"%s\"");
	     }
             table_def++;
	  }
      }
      strcat(table_insert, "\n);\n");
      rc_ptr = table_insert;
   }
   else
   {
      // Table == NULL?
      aie_sys_log(2, tableid);
   }
   return(rc_ptr);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
const char *aie_sql_meta_get_db_name_from_id(int dbid, 
                                             struct aie_sql_meta_db 
					            *sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_get_db_name_from_id Id[%d]" },
      { AIE_LOG_ERROR, "Meta Table ID == %p Size[%d]!" },
      { AIE_LOG_ERROR, "Meta DB Ptr == NULL!" }
   };
   const char *rc_ptr = NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, dbid);
   #endif
   if (__builtin_expect((sql_meta_db != NULL), true))
   {
      struct aie_sql_dbid_2_db *dbid_2_db = sql_meta_db->dbid_2_db;
      unsigned int size_dbid_2_db = sql_meta_db->size_dbid_2_db;
      if (__builtin_expect(
	    ((dbid_2_db != NULL) && (size_dbid_2_db > 0)), true))
      {
         register unsigned int z = 0;
         for (z = 0; z < size_dbid_2_db; z++)
         {
	    if (__builtin_expect((dbid_2_db->dbid == dbid), false))
	    {
	       rc_ptr = dbid_2_db->db;
	       break;
	    }
	    dbid_2_db++;
         }
      }
      else
      {
         // Meta Table ID == %p Size[%d]!
         aie_sys_log(1, dbid_2_db, size_dbid_2_db);
      }
   }
   else
   {
      // Meta DB Ptr == NULL!
      aie_sys_log(2);
   }
   return(rc_ptr);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_sql_table_def *aie_sql_meta_get_table_def_from_id(int tableid,
                                                unsigned int *size_table_def, 
                                                struct aie_sql_meta_db 
						       *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_get_table_def_from_id Id[%d]" },
      { AIE_LOG_WARN,  "Warnung DB %d Tabellen == 0" },
      { AIE_LOG_WARN,  "Warnung DB %d keine Tabellen!" },
      { AIE_LOG_ERROR, "MetaDB - Keine DB Info" },
      { AIE_LOG_ERROR, "MetaDB Ptr == NULL!" }
   };
   struct aie_sql_table_def *aie_table_def = NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, tableid);
   #endif
   if (__builtin_expect((aie_sql_meta_db != NULL), true))
   {
      struct aie_sql_db *sql_db = aie_sql_meta_db->sql_db;
      unsigned int size_sql_db = aie_sql_meta_db->size_sql_db;
      if (__builtin_expect(((sql_db != NULL)  && (size_sql_db > 0)), true))
      {
	 register unsigned int z = 0;
	 for(z = 0;z < size_sql_db;z++)
	 {
            struct aie_sql_tables *tables;
            if (__builtin_expect(((tables = sql_db->tables) != NULL),true))
            {
                unsigned int size_tables = sql_db->size_tables;
		if (__builtin_expect((size_tables > 0),true))
		{
		   register unsigned int y = 0;
		   for(y = 0; y < size_tables; y++)
		   {
		      if (__builtin_expect((tables->tableid == tableid), 
			                                                false))
		      {
                         if (__builtin_expect((size_table_def != NULL),true))
			 {
			    *size_table_def = tables->size_table_def;
			 }
			 aie_table_def = tables->table_def;
			 break;
		      }
		      tables++;
		   }

		}
		else
		{
	          // Warnung DB %d Tabellen == 0
                  aie_sys_log(1, sql_db->dbid);
		}
            }
	    else
	    {
	       // Warnung DB %d keine Tabellen!
                aie_sys_log(2, sql_db->dbid);
	    }
	    sql_db++;
	 }
      }
      else
      {
         // MetaDB - Keine DB Info
         aie_sys_log(3);
      }
   }
   else
   {
      // MetaDB Ptr == NULL!
      aie_sys_log(4);
   }
   return(aie_table_def);
}


/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_sql_index_def *aie_sql_meta_get_index_def_from_id(int indexid,
                                                         int *tableid, 
                                                         int *index_typ, 
                                                unsigned int *size_index_def, 
                                                struct aie_sql_meta_db 
						       *aie_sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,   "aie_sql_meta_get_index_def_from_id Id[%d]" },
      { AIE_LOG_WARN,    "Warnung DB %d Indizies == 0" },
      { AIE_LOG_DB_INFO, "Warnung DB %d keine Indizies!" },
      { AIE_LOG_ERROR,   "Meta DB - Keine DB Info" },
      { AIE_LOG_ERROR,   "Meta DB Ptr == NULL!" }
   };
   struct aie_sql_index_def *aie_index_def = NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, indexid);
   #endif
   if (__builtin_expect((aie_sql_meta_db != NULL), true))
   {
      struct aie_sql_db *sql_db = aie_sql_meta_db->sql_db;
      unsigned int size_sql_db = aie_sql_meta_db->size_sql_db;
      if (__builtin_expect(((sql_db != NULL)  && (size_sql_db > 0)), true))
      {
	 register unsigned int z = 0;
	 for(z = 0;z < size_sql_db;z++)
	 {
            struct aie_sql_index *tbl_index;
            if (__builtin_expect(((tbl_index = sql_db->index) != NULL),true))
            {
                unsigned int size_index = sql_db->size_index;
		if (__builtin_expect((size_index > 0),true))
		{
		   register unsigned int y = 0;
		   for(y = 0; y < size_index; y++)
		   {
		      if (__builtin_expect((tbl_index->indexid == indexid), 
			                                                false))
		      {
			 if (__builtin_expect((tableid != NULL),true))
			 {
			    *tableid = tbl_index->tableid;
			 }
			 if (__builtin_expect((index_typ != NULL),true))
			 {
			    *index_typ = tbl_index->index_typ;
			 }
			 if (__builtin_expect((size_index_def != NULL),true))
			 {
			    *size_index_def = tbl_index->size_index_def;
			 }
			 aie_index_def = tbl_index->index_def;
			 break;
		      }
		      tbl_index++;
		   }

		}
		else
		{
	          // Warnung DB %d Indizies == 0
                  aie_sys_log(1, sql_db->dbid);
		}
            }
	    else
	    {
	       // Warnung DB %d keine Indizies!
               aie_sys_log(2, sql_db->dbid);
	    }
	    sql_db++;
	 }
      }
      else
      {
         // Meta DB - Keine DB Info
         aie_sys_log(3);
      }
   }
   else
   {
      // Meta DB Ptr == NULL!
      aie_sys_log(4);
   }
   return(aie_index_def);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
const char *aie_sql_meta_get_table_name_from_id(int tableid, 
                                                struct aie_sql_meta_db 
						       *sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_get_table_name_from_id Id[%d]" },
      { AIE_LOG_ERROR, "Meta Table ID == %p Size[%d]!" },
      { AIE_LOG_ERROR, "Meta DB Ptr == NULL!" }
   };
   const char *rc_ptr = NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, tableid);
   #endif
   if (__builtin_expect((sql_meta_db != NULL), true))
   {
      struct aie_sql_tableid_2_table *tableid_2_table = 
                                                 sql_meta_db->tableid_2_table;
      unsigned int size_tableid_2_table = sql_meta_db->size_tableid_2_table;

      if (__builtin_expect(
	    ((tableid_2_table != NULL) && (size_tableid_2_table > 0)), true))
      {
         register unsigned int z = 0;
         for (z = 0; z < size_tableid_2_table; z++)
         {
	    if (__builtin_expect((tableid_2_table->tableid == tableid), false))
	    {
	       rc_ptr = tableid_2_table->table;
	       break;
	    }
	    tableid_2_table++;
         }
      }
      else
      {
         //  Meta Table ID == %p Size[%d]!
         aie_sys_log(1, tableid_2_table, size_tableid_2_table);
      }
   }
   else
   {
      // Meta DB Ptr == NULL!
      aie_sys_log(2);
   }
   return(rc_ptr);
}

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
const char *aie_sql_meta_get_index_name_from_id(int indexid, 
                                                struct aie_sql_meta_db 
						       *sql_meta_db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_meta_get_index_name_from_id Id[%d]" },
      { AIE_LOG_ERROR, "Meta Table ID == %p Size[%d]!" },
      { AIE_LOG_ERROR, "Meta DB Ptr == NULL!" }
   };
   const char *rc_ptr = NULL;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, indexid);
   #endif
   if (__builtin_expect((sql_meta_db != NULL), true))
   {
      struct aie_sql_indexid_2_index *indexid_2_index = 
                                                 sql_meta_db->indexid_2_index;
      unsigned int size_indexid_2_index = sql_meta_db->size_indexid_2_index;

      if (__builtin_expect(
	    ((indexid_2_index != NULL) && (size_indexid_2_index > 0)), true))
      {
         register unsigned int z = 0;
         for (z = 0; z < size_indexid_2_index; z++)
         {
	    if (__builtin_expect((indexid_2_index->indexid == indexid), false))
	    {
	       rc_ptr = indexid_2_index->index;
	       break;
	    }
	    indexid_2_index++;
         }
      }
      else
      {
         // Meta Table ID == %p Size[%d]!
         aie_sys_log(1, indexid_2_index, size_indexid_2_index);
      }
   }
   else
   {
      // Meta DB Ptr == NULL!
      aie_sys_log(2);
   }
   return(rc_ptr);
}

const char *aie_sql_meta_error(struct aie_sql_meta_db *sql_meta_db)
{
   const char *rc_ptr = NULL;
   if (__builtin_expect(
	 (sql_meta_db != NULL && sql_meta_db->aie_sql_data != NULL &&
	 sql_meta_db->aie_sql_data->sql_db_data != NULL &&
	 sql_meta_db->aie_sql_data->sql_db_data->db != NULL), true))
   {
      rc_ptr = sqlite3_errmsg(sql_meta_db->aie_sql_data->sql_db_data->db);
   }
   return(rc_ptr);
}

bool aie_sql_meta_log_error(struct aie_sql_meta_db *sql_meta_db, 
                                   const char *sql_cmd, const char *file,
				   int line)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_log_meta_error @ %s(%d)" },         
      { AIE_LOG_DB_ERROR, "SQL Fehler[%s] Cmd:[%s]" },
      { AIE_LOG_DB_ERROR, "Meta DB Ptr == NULL : SQL Cmd:[%s]" }
   };
   bool rc = true;

   #if AIENGINE_LOG_TRACE_DB_META_TRACE
   aie_sys_log(0, file, line);
   #endif
   if (__builtin_expect(
	 (sql_meta_db != NULL && sql_meta_db->aie_sql_data != NULL &&
	 sql_meta_db->aie_sql_data->sql_db_data != NULL &&
	 sql_meta_db->aie_sql_data->sql_db_data->db != NULL), true))
   {
      rc = aie_logger(&aie_log_msg[1], file, line, 
	    sqlite3_errmsg(sql_meta_db->aie_sql_data->sql_db_data->db), 
	    sql_cmd);
   }
   else
   {
      rc = aie_logger(&aie_log_msg[2], file, line, sql_cmd);
   }
   return(rc);
}
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_sql_meta_size    = __LINE__;                                     //
/* -------------------------------- EOF ------------------------------------ */

