/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_sql.c                                                   */
/* Library     : aiengine-sql_wrap-3.nn.nn.so                                */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 05.08.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Abstrakte Datenbankschnittstelle fuer SQL                                 */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_sql_version = "1.0.0";                                     //
const char *modul_sql         = "aSQL";                                      //
const char *modul_sql_date    = __DATE__;                                    //
const char *modul_sql_time    = __TIME__;                                    //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_SQL_WRAP_LIB		1
#define AIENGINE_USE_LOG_LIB			1
                                                                             //
/*---------------------------------------------------------------------------*/
/* System Headerdateien                                                      */
/*...........................................................................*/
#ifndef __WIN32__
#include <unistd.h>                                                          //
#endif
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
//#include AIENGINE_SQL_INCLUDE                                                //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
#include <stdarg.h>                                                          //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
/*****************************************************************************/
//#undef AIENGINE_LOG_NO_LOG
//#define AIENGINE_LOG_NO_LOG	0

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
struct aie_sql_data *aie_sql_attach_db(const char *db)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_attach_db [%s]" },
      { AIE_LOG_ERROR, "Datenbank Fehler beim Oeffnen --> \"%s\": %s" },
      { AIE_LOG_ERROR, "Memory Fehler beim Oeffnen --> \"%s\"" },
      { AIE_LOG_ERROR, "Datenbankname == NULL!" }
   };
   struct aie_sql_data *aie_sql_data = NULL;

   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0, db);
   #endif
   if (__builtin_expect((db != NULL), true))
   {
      aie_sql_data = aie_malloc(sizeof(struct aie_sql_data));
      if (__builtin_expect((aie_sql_data != NULL), true))
      {
         struct aie_sql_db_data *aie_sql_db_data = NULL;
         aie_sql_data->callback = NULL;
         aie_sql_data->sql_cmd = NULL;
         aie_sql_data->data = NULL;
         aie_sql_data->sql_rc = SQLITE_OK;
				 
         aie_sql_db_data = aie_malloc(sizeof(struct aie_sql_db_data));
         if (__builtin_expect((aie_sql_db_data != NULL), true))
         {
	    aie_sql_data->sql_db_data = aie_sql_db_data;
            aie_sql_db_data->dbf = aie_strdup(db);
            aie_sql_db_data->timeout = AIE_SQL_STANDARD_TIMEOUT;
            aie_sql_db_data->cnt = 0;
            sqlite3_open(aie_sql_db_data->dbf, &aie_sql_db_data->db);
            if (__builtin_expect(
		  (SQLITE_OK != sqlite3_errcode(aie_sql_db_data->db)), false))
            {
	       // Datenbank Fehler beim Oeffnen --> \"%s\": %s",
               aie_sys_log(1, db, sqlite3_errmsg(aie_sql_db_data->db));
	       sqlite3_close(aie_sql_db_data->db);
	       if (aie_sql_db_data->dbf != NULL)
	       {
	          aie_free(aie_sql_db_data->dbf);
	       }
	       aie_free(aie_sql_db_data);
	       aie_free(aie_sql_data);
	       aie_sql_data = NULL;
	    }
	 }
	 else
	 {
	    // Memory Fehler beim Oeffnen --> \"%s\""
            aie_sys_log(2, db);
	 }
      }
      else
      {
	 // Memory Fehler beim Oeffnen --> \"%s\""
         aie_sys_log(2, db);
      }
   }
   else
   {
      // Datenbankname == NULL!
      aie_sys_log(3);
   }
   return(aie_sql_data);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_release_db(struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_release_db" },
      { AIE_LOG_ERROR, "release_db Parameter == NULL!" }
   };
   bool rc = true;

   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((aie_sql_data != NULL), true))
   {
      struct aie_sql_db_data *aie_sql_db_data = aie_sql_data->sql_db_data;
      if (__builtin_expect((aie_sql_db_data != NULL), true))
      {
         sqlite3_close(aie_sql_db_data->db);
         if (aie_sql_db_data->dbf != NULL)
         {
            aie_free(aie_sql_db_data->dbf);
         }
         aie_free(aie_sql_data->sql_db_data);
      }
      aie_free(aie_sql_data);
   }
   else
   {
      // release_db Parameter == NULL!
      aie_sys_log(1);
      rc = false;
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_start_transaction(struct aie_sql_data *aie_sql_data)
{
   #if AIENGINE_LOG_TRACE_DB_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_start_transaction" }
   };
   #endif
   bool rc;

   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0);
   #endif
   aie_sql_data->sql_cmd = "BEGIN TRANSACTION";
   rc = aie_sql_run(aie_sql_data);
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_commit(struct aie_sql_data *aie_sql_data)
{
   #if AIENGINE_LOG_TRACE_DB_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_commit" }
   };
   #endif
   bool rc;
   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0);
   #endif
   aie_sql_data->sql_cmd = "COMMIT TRANSACTION";
   rc = aie_sql_run(aie_sql_data);
   sync();
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_rollback(struct aie_sql_data *aie_sql_data)
{
   #if AIENGINE_LOG_TRACE_DB_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_rollback" }         
   };
   #endif
   bool rc;

   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0);
   #endif

   aie_sql_data->sql_cmd = "ROLLBACK TRANSACTION";
   rc = aie_sql_run(aie_sql_data);
   sync();
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_end_transaction(struct aie_sql_data *aie_sql_data)
{
   #if AIENGINE_LOG_TRACE_DB_TRACE
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_end_transaction" }
   };
   #endif
   bool rc;

   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0);
   #endif

   aie_sql_data->sql_cmd = "END TRANSACTION";
   rc = aie_sql_run(aie_sql_data);
   sync();
   return(rc);
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_sql_run(struct aie_sql_data *aie_sql_data)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE,    "aie_sql_run" },
      { AIE_LOG_SECURITY, "SQL Fehler %d:%s:[%s]" },
      { AIE_LOG_WARN,     "SQL Warnung %s" },
      { AIE_LOG_ERROR,    "aie_sql_run aufruf mit NULL Ptr" }
   };
   bool rc = true;
   char *ErrMsg = NULL;
   unsigned long ErrorCounter = 0L;
   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0);
   #endif
   if (__builtin_expect((aie_sql_data != NULL), true))
   {
      int sql_rc = 0;
      bool done = false;
      while(!done)
      {
         if (__builtin_expect((
                               (aie_sql_data->sql_rc =
	                        sqlite3_exec(aie_sql_data->sql_db_data->db,
				             aie_sql_data->sql_cmd,
				             aie_sql_data->callback,
			                     aie_sql_data,
				             &ErrMsg)) == SQLITE_OK), true))
	 {
	    done = true;
	 }
	 else
	 {
            if (__builtin_expect(((aie_sql_data->sql_rc != SQLITE_BUSY) &&
	         (sql_rc != SQLITE_LOCKED)), false))
	    {
	       // SQL Fehler %d:%s:[%s]
               aie_sys_log(1, aie_sql_data->sql_rc, ErrMsg, 
		              aie_sql_data->sql_cmd);
	       done = true;
	       rc = false;
	    }
	    else
	    {
	       // SQL Warnung %s
               aie_sys_log(2, ErrMsg);
	       free(ErrMsg);
	       ErrMsg = NULL;
	       usleep(aie_sql_data->sql_db_data->timeout);
	       ErrorCounter++;
	       if (ErrorCounter > 100)
	       {
		  sleep(1);
	       }
	       if (ErrorCounter > 110)
	       {
		  done = true;
		  rc = false;
	       }
	    }
	 }
      }
   }
   else
   {
      // aie_sql_run aufruf mit NULL Ptr
      aie_sys_log(3);
   }
   if (ErrMsg != NULL)
   {
      sqlite3_free(ErrMsg);
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/
bool aie_sql_create_table(struct aie_sql_data *aie_sql_data,
                      const char *table, bool iggy_error,
                      struct aie_sql_table_def *aie_sql_table_def,
                      unsigned int size_table_def)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_create_table [%s]" },
      { AIE_LOG_ERROR, "Create Table \"%d\": %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" }
   };
   char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
   bool rc = true;

   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0, table);
   #endif

   if (__builtin_expect((sql_cmd != NULL), true))
   {
      register unsigned int z = 0;
      aie_sql_data->sql_cmd = sql_cmd;
      sprintf(sql_cmd, "CREATE TABLE %s (\n", table);
      for (z = 0; z < size_table_def; z++)
      {
	 int typ = aie_sql_table_def->typ;
	 if (z > 0)
	 {
	    strcat(sql_cmd, ", \n");
	 }
	 strcat(sql_cmd, aie_sql_table_def->feld);
         if ((typ & AIE_DB_FELD_TYPE_INTEGER) != 0)
	 {
	    strcat(sql_cmd, " INTEGER");
	 }
         if ((typ & AIE_DB_FELD_TYPE_REAL) != 0)
	 {
	    strcat(sql_cmd, " REAL");
	 }
         if ((typ & AIE_DB_FELD_TYPE_NUMERIC) != 0)
	 {
	    strcat(sql_cmd, " NUMERIC");
	 }
         if ((typ & AIE_DB_FELD_TYPE_TEXT) != 0)
	 {
	    strcat(sql_cmd, " TEXT");
	 }
         if ((typ & AIE_DB_FELD_TYPE_VARCHAR) != 0)
	 {
	    strcat(sql_cmd, " VARCHAR");
	 }
         if ((typ & AIE_DB_FELD_TYPE_BLOB) != 0)
	 {
	    strcat(sql_cmd, " BLOB");
	 }
         if ((typ & AIE_DB_FELD_TYPE_NOT_NULL) != 0)
	 {
	    strcat(sql_cmd, " NOT NULL");
	 }
         if ((typ & AIE_DB_FELD_TYPE_PRIMARY_KEY) != 0)
	 {
	    strcat(sql_cmd, " PRIMARY KEY");
	 }
         if ((typ & AIE_DB_FELD_TYPE_UNIQUE) != 0)
	 {
	    strcat(sql_cmd, " UNIQUE");
	 }
         aie_sql_table_def++;
      }
      strcat(sql_cmd, "\n);");
      if (__builtin_expect((!aie_sql_run(aie_sql_data)), false))
      {
          if (__builtin_expect((!iggy_error), true))
	  {
             // Create Table \"%d\": %s[%s]
             aie_sys_log(1, aie_sql_data->sql_rc,
                            sqlite3_errmsg(aie_sql_data->sql_db_data->db),
	                    sql_cmd);
            rc = false;
	  }
      }
      aie_free(sql_cmd);
   }
   else
   {
      // Out of Memory?
      aie_sys_log(2);
      rc = false;
   }
   return(rc);
}

int aie_sql_get_feld_typ(const char *feld, 
                      struct aie_sql_table_def *aie_sql_table_def,
                      unsigned int size_table_def)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_get_feld_typ Feld[%s]" },
      { AIE_LOG_ERROR, "Feld [%s] nicht gefunden!" }
   };
   bool found = false;
   int typ = AIE_DB_FELD_TYPE_UNKNOWN;

   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0);
   #endif
   for (register unsigned int z = 0; z < size_table_def; z++)
   {
      if (__builtin_expect((strcmp(feld, aie_sql_table_def->feld)==0),false))
      {
         typ = aie_sql_table_def->typ;
         found = true;
	 break;
      }
      aie_sql_table_def++;
   }
   if (__builtin_expect((!found),false))
   {
      // Feld [%s] nicht gefunden!
      aie_sys_log(1, feld);
   }
   return(typ);
}

bool aie_sql_create_index(struct aie_sql_data *aie_sql_data, 
                      const char *table, const char *tbl_index, int index_typ,
		      bool iggy_error,
                      struct aie_sql_index_def *aie_sql_index_def,
                      unsigned int size_index_def)
{
   AIE_LOG_MESSAGES =
   {
      { AIE_LOG_TRACE, "aie_sql_create_index Tabelle[%s] Index[%s]" },
      { AIE_LOG_ERROR, "Create Index \"%d\": %s[%s]" },
      { AIE_LOG_ERROR, "Out of Memory?" }
   };
   char *sql_cmd = (char *)aie_malloc(AIE_SQL_BUFFER_LEN);
   bool rc = true;
   register unsigned int z = 0;
	 
   #if AIENGINE_LOG_TRACE_DB_TRACE
   aie_sys_log(0, table, tbl_index);
   #endif
   if (sql_cmd != NULL)
   {
      aie_sql_data->sql_cmd = sql_cmd;
      strcpy(sql_cmd, "CREATE "); 
      if ((index_typ & AIE_INDEX_TYPE_UNIQUE) != 0)
      {
         strcat(sql_cmd, " UNIQUE ");
      }
      strcat(sql_cmd, "INDEX ");
      strcat(sql_cmd, tbl_index);
      strcat(sql_cmd, " ON ");
      strcat(sql_cmd, table);
      strcat(sql_cmd, " (\n");
      for (z = 0; z < size_index_def; z++)
      {
	 if (z > 0)
	 {
	    strcat(sql_cmd, ", ");
	 }
	 strcat(sql_cmd, aie_sql_index_def->feld);
         aie_sql_index_def++;
      }
      strcat(sql_cmd, "\n) ");
      if ((index_typ & AIE_INDEX_TYPE_DESC) != 0)
      {
         strcat(sql_cmd, " DESC ");
      }
      //printf(" SQL[%s]\n", sql_cmd);
      if (!aie_sql_run(aie_sql_data))
      {
          if (!iggy_error)
	  {
             // Create Index \"%d\": %s[%s]
             aie_sys_log(1, aie_sql_data->sql_rc,
                            sqlite3_errmsg(aie_sql_data->sql_db_data->db),
	                    sql_cmd);
            rc = false;
	  }
      }
      aie_free(sql_cmd);
   }
   else
   {
      // Out of Memory?
      aie_sys_log(2);
      rc = false;
   }
   return(rc);
}

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_sql_size    = __LINE__;                                          //
/* -------------------------------- EOF ------------------------------------ */

