/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : version.c                                                   */
/* Library     : aiengine-db-3.nn.nn.so                                      */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 30.12.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 16.01.2005  : ALH           : Neue Tabellen fuer Berechtigunen und gruppen*/
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_aie_db_version        = "1.0.0";                           //
const char *modul_aie_db                = "aie_DB";                          //
const char *modul_aie_db_date           = __DATE__;                          //
const char *modul_aie_db_time           = __TIME__;                          //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
#define AIENGINE_USE_DB_LIB			1
#define AIENGINE_USE_SQL_WRAP_LIB		1
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#include "aiengine.h"                                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
static struct aie_sql_dbid_2_db aie_sql_dbid_2_db[] = 
{
   { AIE_DB_ID_AIENGINE,  	AIE_DB_AIENGINE 	},
   { AIE_DB_ID_KEYS,      	AIE_DB_KEYS     	}
};

static struct aie_sql_tableid_2_table aie_sql_tableid_2_table[] =
{
   { AIE_DB_TABLE_ID_SERIAL_POOL, 	   AIE_DB_TABLE_SERIAL_POOL }, 
   { AIE_DB_TABLE_ID_REGISTER, 		   AIE_DB_TABLE_REGISTER }, 
   { AIE_DB_TABLE_ID_MODUL_REGISTER, 	   AIE_DB_TABLE_MODUL_REGISTER },
   { AIE_DB_TABLE_ID_BERECHTIGUNGEN,       AIE_DB_TABLE_BERECHTIGUNGEN },
   { AIE_DB_TABLE_ID_USER_GRUPPEN,         AIE_DB_TABLE_USER_GRUPPEN },
   { AIE_DB_TABLE_ID_GRUPPEN_BERECHTIGUNG, AIE_DB_TABLE_GRUPPEN_BERECHTIGUNG },
   { AIE_DB_TABLE_ID_USER, 	           AIE_DB_TABLE_USER },
   { AIE_DB_TABLE_ID_KEYS,	     	   AIE_DB_TABLE_KEYS },
   { AIE_DB_TABLE_ID_HASH,	     	   AIE_DB_TABLE_HASH }
};

static struct aie_sql_indexid_2_index aie_sql_indexid_2_index[] =
{
   { AIE_DB_INDEX_ID_SERIAL_POOL, 
      AIE_DB_INDEX_SERIAL_POOL
   },
   { AIE_DB_INDEX_ID_REGISTER, 
      AIE_DB_INDEX_REGISTER
   },
   { AIE_DB_INDEX_ID_MODUL_REGISTER, 
      AIE_DB_INDEX_MODUL_REGISTER
   },
   { AIE_DB_INDEX_ID_USER, 
      AIE_DB_INDEX_USER
   },
   { AIE_DB_INDEX_ID_KEYS_KEY_ID,
      AIE_DB_INDEX_KEYS_KEY_ID
   },
   { AIE_DB_INDEX_ID_HASH_ID,
      AIE_DB_INDEX_HASH_ID
   }
};

static struct aie_sql_table_def aie_sql_table_def_serial_pool[] =
{
   { is_aie_SeriennummerSqlFld, 
      AIE_DB_FELD_TYPE_TEXT,	AIE_DB_FELD_TYPE_TEXT     |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL  },
   { is_aie_ModulNameSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_FreigabeSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_InstallDateSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_SerialGenerateDateSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_SerialMaxInstallCountSqlFld, 
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_SerialCurrentInstallCountSqlFld, 
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_ValidUntilDateSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT      }
};

static struct aie_sql_table_def aie_sql_table_def_register[] =
{
   { is_aie_SeriennummerSqlFld, 
      AIE_DB_FELD_TYPE_TEXT,	AIE_DB_FELD_TYPE_TEXT     |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL  },
   { is_aie_ModulNameSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_FreigabeSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_UserIdSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_FirmaSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_VornameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_NachnameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_StrasseSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_PostleitzahlSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_OrtSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_EmailSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_InstallDateSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_LastRunSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_LastUpdateSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_RunCountSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_SerialMaxInstallCountSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_SerialCurrentInstallCountSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_ValidUntilDateSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT      }
};

static struct aie_sql_table_def aie_sql_table_def_modul_register[] =
{
   { is_aie_SeriennummerSqlFld,
      AIE_DB_FELD_TYPE_TEXT,	AIE_DB_FELD_TYPE_TEXT     |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL  },
   { is_aie_ModulNameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_FreigabeSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_UserIdSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_FirmaSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_VornameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_NachnameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_StrasseSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_PostleitzahlSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_OrtSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_EmailSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_InstallDateSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_LastRunSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_LastUpdateSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_RunCountSqlFld, 
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_SerialMaxInstallCountSqlFld, 
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_SerialCurrentInstallCountSqlFld, 
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_ValidUntilDateSqlFld, 
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT      }
};

static struct aie_sql_table_def aie_sql_table_def_berechtigungen[] =
{
   { is_aie_BerechtigungSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	    |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL   },
   { is_aie_BerechtigungTextSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	    }
};

static struct aie_sql_table_def aie_sql_table_def_user_gruppen[] =
{
   { is_aie_UserGruppeSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	    |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL },
   { is_aie_SperreSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_BerechtigungSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   }
};

static struct aie_sql_table_def aie_sql_table_def_user[] =
{
   { is_aie_UserIdSqlFld,
      AIE_DB_FELD_TYPE_TEXT,	AIE_DB_FELD_TYPE_TEXT     |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL  },
   { is_aie_UserGruppeSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_SperreSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_BerechtigungSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_UserPasswortSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_FirmaSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_VornameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_NachnameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_StrasseSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_PostleitzahlSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_OrtSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_EmailSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_InstallDateSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_SeriennummerSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_ModulNameSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_FreigabeSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_LastRunSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_LastUpdateSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_RunCountSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_ValidUntilDateSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT      }
};

static struct aie_sql_index_def aie_sql_index_serial_pool[] =
{
   { is_aie_ModulNameSqlFld }
};

static struct aie_sql_index_def aie_sql_index_register[] =
{
   { is_aie_UserIdSqlFld }
};

static struct aie_sql_index_def aie_sql_index_modul_register[] =
{
   { is_aie_UserIdSqlFld }
};

static struct aie_sql_index_def aie_sql_index_user[] =
{
   { is_aie_SeriennummerSqlFld }
};


static struct aie_sql_index aie_sql_aiengine_index[] =
{
   {
      AIE_DB_INDEX_ID_SERIAL_POOL,
      AIE_DB_TABLE_ID_SERIAL_POOL,
      AIE_INDEX_TYPE_NORMAL,
      aie_sql_index_serial_pool,
      sizeof(aie_sql_index_serial_pool) /
	 sizeof(struct aie_sql_index_def)
   },
   {
      AIE_DB_INDEX_ID_REGISTER,
      AIE_DB_TABLE_ID_REGISTER,
      AIE_INDEX_TYPE_NORMAL,
      aie_sql_index_register,
      sizeof(aie_sql_index_register) /
	 sizeof(struct aie_sql_index_def)
   },
   {
      AIE_DB_INDEX_ID_MODUL_REGISTER,
      AIE_DB_TABLE_ID_MODUL_REGISTER,
      AIE_INDEX_TYPE_NORMAL,
      aie_sql_index_modul_register,
      sizeof(aie_sql_index_modul_register) /
	 sizeof(struct aie_sql_index_def)
   },
   {
      AIE_DB_INDEX_ID_USER,
      AIE_DB_TABLE_ID_USER,
      AIE_INDEX_TYPE_NORMAL,
      aie_sql_index_user,
      sizeof(aie_sql_index_user) /
	 sizeof(struct aie_sql_index_def)
   }
};

static struct aie_sql_tables aie_sql_aiengine_tables[] =
{
   { AIE_DB_TABLE_ID_SERIAL_POOL,
      aie_sql_table_def_serial_pool,
      sizeof(aie_sql_table_def_serial_pool) /
	 sizeof(struct aie_sql_tables)
   },
   { AIE_DB_TABLE_ID_REGISTER,
      aie_sql_table_def_register,
      sizeof(aie_sql_table_def_register) /
	 sizeof(struct aie_sql_tables)
   },
   { AIE_DB_TABLE_ID_MODUL_REGISTER,
        aie_sql_table_def_modul_register,
        sizeof(aie_sql_table_def_modul_register) /
	   sizeof(struct aie_sql_tables)
   },
   { AIE_DB_TABLE_ID_BERECHTIGUNGEN,
        aie_sql_table_def_berechtigungen,
        sizeof(aie_sql_table_def_berechtigungen) /
	   sizeof(struct aie_sql_tables)
   },
   { AIE_DB_TABLE_ID_USER_GRUPPEN,
        aie_sql_table_def_user_gruppen,
        sizeof(aie_sql_table_def_user_gruppen) /
	   sizeof(struct aie_sql_tables)
   },
   { AIE_DB_TABLE_ID_USER,
        aie_sql_table_def_user,
        sizeof(aie_sql_table_def_user) /
	   sizeof(struct aie_sql_tables)
   }
};

static struct aie_sql_table_def aie_sql_table_def_keys[] =
{
   { is_aie_KeyIDSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER    |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL },
   { is_aie_KeyIDHashSqlFld,	
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_KeyPrivateSqlFld,	
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_KeyPublicSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT      },
   { is_aie_TimestampSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_RunCountSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   }
};

static struct aie_sql_index_def aie_sql_index_keys_key_id[] =
{
   { is_aie_KeyIDHashSqlFld }
};

static struct aie_sql_table_def aie_sql_table_def_hash[] =
{
   { is_aie_HashDayIDSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER    |
                               	AIE_DB_FELD_TYPE_PRIMARY_KEY |
                               	AIE_DB_FELD_TYPE_UNIQUE      |
                               	AIE_DB_FELD_TYPE_NOT_NULL },
   { is_aie_HashIDSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT  |
                               	AIE_DB_FELD_TYPE_NOT_NULL },
   { is_aie_HashYearSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   },
   { is_aie_HashLoSqlFld,	
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_HashHiSqlFld,	
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_TimestampSqlFld,
      AIE_DB_FELD_TEXT_LEN,	AIE_DB_FELD_TYPE_TEXT	   },
   { is_aie_RunCountSqlFld,
      AIE_DB_FELD_INT_LEN,	AIE_DB_FELD_TYPE_INTEGER   }
};

static struct aie_sql_index_def aie_sql_index_hash_id[] =
{
   { is_aie_HashIDSqlFld }
};

static struct aie_sql_index aie_sql_keys_index[] =
{
   {
      AIE_DB_INDEX_ID_KEYS_KEY_ID,
      AIE_DB_TABLE_ID_KEYS,
      AIE_INDEX_TYPE_UNIQUE,
      aie_sql_index_keys_key_id,
      sizeof(aie_sql_index_keys_key_id) /
	 sizeof(struct aie_sql_index_def)
   },
   {
      AIE_DB_INDEX_ID_HASH_ID,
      AIE_DB_TABLE_ID_HASH,
      AIE_INDEX_TYPE_UNIQUE,
      aie_sql_index_hash_id,
      sizeof(aie_sql_index_hash_id) /
	 sizeof(struct aie_sql_index_def)
   }
};

static struct aie_sql_tables aie_sql_keys_tables[] =
{
   { AIE_DB_TABLE_ID_KEYS,
        aie_sql_table_def_keys,
        sizeof(aie_sql_table_def_keys) /
	   sizeof(struct aie_sql_tables)
   },
   { AIE_DB_TABLE_ID_HASH,
        aie_sql_table_def_hash,
        sizeof(aie_sql_table_def_hash) /
	   sizeof(struct aie_sql_tables)
   }
};

static struct aie_sql_db aie_sql_db[] =
{
   { AIE_DB_ID_AIENGINE,    aie_sql_aiengine_tables, 
                                              sizeof(aie_sql_aiengine_tables) /
                  	                      sizeof(struct aie_sql_tables),
                            aie_sql_aiengine_index,
			                      sizeof(aie_sql_aiengine_index) /
                  		              sizeof(struct aie_sql_index) 
   },
   { AIE_DB_ID_KEYS,        aie_sql_keys_tables, 
                                              sizeof(aie_sql_keys_tables) /
                  	                      sizeof(struct aie_sql_tables),
                            aie_sql_keys_index,
			                      sizeof(aie_sql_keys_index) /
                  		              sizeof(struct aie_sql_index) 
   }
};

#ifdef __DLL__
struct aie_sql_meta_db __export aiengine_sql_meta_db =
#else
struct aie_sql_meta_db aiengine_sql_meta_db =
#endif
{
   AIE_DB_PATH,
   aie_sql_dbid_2_db, 	        sizeof(aie_sql_dbid_2_db) /
                  		sizeof(struct aie_sql_dbid_2_db),
   aie_sql_tableid_2_table, 	sizeof(aie_sql_tableid_2_table) / 
                        	sizeof(struct aie_sql_tableid_2_table),
   aie_sql_indexid_2_index, 	sizeof(aie_sql_indexid_2_index) / 
                        	sizeof(struct aie_sql_indexid_2_index),
   aie_sql_db, 			sizeof(aie_sql_db) /
               			sizeof(struct aie_sql_db),
   NULL
};

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int modul_aie_db_size                = __LINE__;                             //
/* -------------------------------- EOF ------------------------------------ */
