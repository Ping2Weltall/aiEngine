/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_db.h                                                    */
/* Library     : aiengine-db-3.nn.nn.so                                      */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 30.12.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 16.01.2005  : ALH           : Neue Tabellen fuer Berechtigunen und gruppen*/
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_DB_H                                                             //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_DB_H                                                             //
									     //
#ifndef AIENGINE_DATABASE_DIR
#define AIE_DB_PATH   				"/aIEngine/data/aiengine/db"
#warning Datenbank Verzeichniss nicht definiert!
#else
#define AIE_DB_PATH   				AIENGINE_DATABASE_DIR
#endif
#ifndef AIENGINE_DATABASE_TEMP_DIR
#define AIE_DB_TEMP_PATH			"/aIEngine/temp/aiengine/db"
#warning Datenbank Temp Verzeichniss nicht definiert!
#else
#define AIE_DB_TEMP_PATH			AIENGINE_DATABASE_TEMP_DIR
#endif
#ifndef AIENGINE_DATABASE
#define AIE_DB_AIENGINE				"aIEngine.db"
#warning Datenbank name nicht definiert!
#else
#define AIE_DB_AIENGINE				AIENGINE_DATABASE
#define AIE_DB_KEYS    				"aie_keys.db"
#define AIE_DB_SITEMAPS				"aie_sitemaps.db"
#endif

#define AIE_DB_TABLE_SERIAL_POOL		"SerialPool"
#define AIE_DB_TABLE_REGISTER			"Register"
#define AIE_DB_TABLE_MODUL_REGISTER		"ModulRegister"
#define AIE_DB_TABLE_BERECHTIGUNGEN 		"Berechtigungen"
#define AIE_DB_TABLE_USER_GRUPPEN 		"UserGruppen"
#define AIE_DB_TABLE_GRUPPEN_BERECHTIGUNG 	"GruppenBerechtigung"
#define AIE_DB_TABLE_USER		        "User"
#define AIE_DB_TABLE_SITEMAP_INFO		"SitemapInfo"
#define AIE_DB_TABLE_KEYS        		"Keys"
#define AIE_DB_TABLE_HASH 			"Hash"

#define AIE_DB_INDEX_SERIAL_POOL		"index_Serial_Pool"
#define AIE_DB_INDEX_REGISTER			"index_Register_serial"
#define AIE_DB_INDEX_MODUL_REGISTER		"index_ModulRegister_serial"
#define AIE_DB_INDEX_USER		        "index_User"
#define AIE_DB_INDEX_SITEMAP_INFO_URL		"index_SitemapInfo_Url"
#define AIE_DB_INDEX_SITEMAP_INFO_PATH		"index_SitemapInfo_Path"
#define AIE_DB_INDEX_KEYS_KEY_ID      		"index_Keys_KeyId"
#define AIE_DB_INDEX_HASH_ID      		"index_Hash_HashId"

#define AIE_DB_ID_AIENGINE					100
#define AIE_DB_ID_KEYS    					200
#define AIE_DB_ID_SITEMAPS					300

#define AIE_DB_TABLE_ID_SERIAL_POOL				100
#define AIE_DB_TABLE_ID_REGISTER				101
#define AIE_DB_TABLE_ID_MODUL_REGISTER				102
#define AIE_DB_TABLE_ID_BERECHTIGUNGEN				110 
#define AIE_DB_TABLE_ID_USER_GRUPPEN				120
#define AIE_DB_TABLE_ID_GRUPPEN_BERECHTIGUNG 			121
#define AIE_DB_TABLE_ID_USER					130
#define AIE_DB_TABLE_ID_SITEMAP_INFO				200
#define AIE_DB_TABLE_ID_KEYS        				300
#define AIE_DB_TABLE_ID_HASH					310

#define AIE_DB_INDEX_ID_SERIAL_POOL				100
#define AIE_DB_INDEX_ID_REGISTER				110
#define AIE_DB_INDEX_ID_MODUL_REGISTER				120
#define AIE_DB_INDEX_ID_USER					130
#define AIE_DB_INDEX_ID_SITEMAP_INFO_URL			200
#define AIE_DB_INDEX_ID_SITEMAP_INFO_PATH			201
#define AIE_DB_INDEX_ID_KEYS_KEY_ID      			300
#define AIE_DB_INDEX_ID_HASH_ID      				310

/*---------------------------------------------------------------------------*/
/* Includes fuer Headerdateien                                               */
/*...........................................................................*/
#ifndef AIE_SMALLBUILD
#include AIENGINE_SQL_INCLUDE
#endif
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
                                                                             //
                                                                             //
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */
