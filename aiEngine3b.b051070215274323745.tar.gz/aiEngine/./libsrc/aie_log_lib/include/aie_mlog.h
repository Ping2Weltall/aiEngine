/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aie_mlog.h                                                  */
/* Library     : aiengine-log-3.00.00.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 31.03.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/* Split der Log Funktionen von log.cpp in verschiedene Programme            */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 28.12.2004  : ALH           : Window Kompatible Borland C++ Lib anpassen  */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 31.03.2004  : ALH           : Split von log.cpp in log.cpp, flog.cpp,     */
/*                               qlog.cpp und mlog.cpp                       */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIE_MLOG_H 

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIE_MLOG_H

#define AIE_LOG_ERROR				0x1
#define AIE_LOG_WARN				0x2
#define AIE_LOG_DB_ERROR			0x4
#define AIE_LOG_SECURITY			0x8
#define AIE_LOG_CGI_ERROR			0x10
#define AIE_LOG_CGI_WARN			0x20
#define AIE_LOG_TRACE				0x40
#define AIE_LOG_TRACE_FKT			0x80
#define AIE_LOG_INFO				0x100
#define AIE_LOG_CGI_INFO			0x200
#define AIE_LOG_SERVER_INFO			0x400
#define AIE_LOG_DB_INFO				0x800
#define AIE_LOG_SECURITY_INFO			0x1000

#define AIE_LOG_PERFORMANCE			0x8000

#define AIE_LOG_LEVEL_ALL		    	0xFFFF

#define AIE_LOG_LEVEL_STANDARD			AIE_LOG_ERROR | \
												AIE_LOG_WARN |  \
												AIE_LOG_CGI_ERROR |  \
						AIE_LOG_DB_ERROR

#define AIE_LOG_LEVEL_STANDARD_SECURE		AIE_LOG_ERROR | \
												AIE_LOG_WARN |  \
												AIE_LOG_CGI_ERROR |  \
						AIE_LOG_DB_ERROR | \
						AIE_LOG_SECURITY

#define aie_log_msg_select(a)	aie_log_msg[a].msg
//#if !AIENGINE_LOG_NO_LOG
#ifndef __GNUC__
#ifndef AIENGINE_LOG_NO_LOG
#define AIENGINE_LOG_NO_LOG		1
#else
#if !AIENGINE_LOG_NO_LOG
#define aie_sys_log(a, args...)	   aie_logger(&aie_log_msg[a],__FILE__,__LINE__, ##args) //## __VA_ARGS__)
#endif
#endif



#else

#if AIENGINE_TEST_LOG_MSG_SIZE || (!AIENGINE_OPTIMIZE_SPEED && \
								   !AIENGINE_OPTIMIZE_SIZE)
#define aie_sys_log(a, ...)	(sizeof(aie_log_msg) < a ) ||                    \
								AIENGINE_LOG_NO_LOG ||                       \
								((aie_loglevel & aie_log_msg[a].loglevel)==0)    \
								? :                                          \
								aie_logger(&aie_log_msg[a], __FILE__, __LINE__,  \
													   ## __VA_ARGS__)
#else
#if AIENGINE_OPTIMIZE_SIZE && AIENGINE_OPTIMIZE_SPEED
   #define aie_sys_log(a, ...)	AIENGINE_LOG_NO_LOG ||                       \
				aie_log_msg[a].loglevel > 0x10 \
				? : \
				aie_logger(aie_log_msg + a, __FILE__, __LINE__,  \
													   ## __VA_ARGS__)
#else
   #if AIENGINE_OPTIMIZE_SPEED
   #define aie_sys_log(a, ...)	AIENGINE_LOG_NO_LOG ||                       \
				((aie_loglevel & aie_log_msg[a].loglevel)==0)    \
								? :                                          \
				aie_logger(aie_log_msg + a, __FILE__, __LINE__,  \
													   ## __VA_ARGS__)
   #else
   #if AIENGINE_OPTIMIZE_SIZE
   #define aie_sys_log(a, ...)	AIENGINE_LOG_NO_LOG ? :                      \
				aie_logger(aie_log_msg + a, __FILE__, __LINE__,  \
													   ## __VA_ARGS__)
   #endif
   #endif
#endif
#endif
//#endif
#endif

/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#if AIE_TARGET_IS_LINUX
#include "aie_qlog.h"
#else
#include "aie_flog.h"
#endif
/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
//#if !AIENGINE_LOG_NO_LOG
struct aie_log_msg
{
   const int loglevel;
   const char *msg;
};
//#endif
//#define AIE_LOG_MESSAGES	const struct aie_log_msg aie_log_msg[]
#define AIE_LOG_MESSAGES	const struct aie_log_msg aie_log_msg[]
/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
#ifdef __cplusplus
extern "C" {
#endif
#if 0
bool _do_log(const char *file_path, const char *msg, va_list argptr);
#if AIENGINE_USE_DEPRECATED
bool sys_log(const char *msg, ...);
#else
bool sys_log(const char *msg, ...)
                            #ifdef __GNUC__
                            #if !AIENGINE_LOG_NO_LOG
                            __attribute__ ((deprecated))
                            #endif
                            #endif
                            ;

#endif
#endif
bool aie_logger(const struct aie_log_msg *log_msg, const char *file,
                                                   int line, ...)
                                   #ifndef __WIN32__
                                   __attribute__ ((noinline))
                                   //__attribute__ ((noinline, nonnull))
                                   #endif
                                   ;
#ifdef __cplusplus
}
#endif

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */

