/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Include     : aiengine_log.h                                              */
/* Library     : aiengine-log-3.00.00.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 03.10.2006                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Include Datei fuer den @Secur(tm) Internet Engine & HTML Generator core   */
/* Alles z.Zt. bur "Documented by Source" :) - Have fun ..                   */
/* Split der Log Funktionen von log.cpp in verschiedene Programme            */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
#ifndef AIENGINE_LOG_H

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*...........................................................................*/
#define AIENGINE_LOG_H

#if !AIENGINE_LOG_NO_LOG
#define AIENGINE_TEST_LOG_MSG_SIZE	        0 && \
                                            !AIENGINE_OPTIMIZE_SIZE && \
                                            !AIENGINE_OPTIMIZE_SPEED

#define AIENGINE_LOG_MSG_ON			(1)
#define AIENGINE_LOG_MSG_OFF			(1)    //(AIENGINE_LOG_NO_LOG)

#define AIENGINE_LOG_TRACE_ALL			(0)    //AIENGINE_LOG_MSG_OFF

#ifndef AIENGINE_LOG_TRACE_MEMORY
#define AIENGINE_LOG_TRACE_MEMORY		(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                                                !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_HTML
#define AIENGINE_LOG_TRACE_HTML  		(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_LINK
#define AIENGINE_LOG_TRACE_LINK  		(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_CGI_VALUES
#define AIENGINE_LOG_TRACE_CGI_VALUES  		(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_INIT_FKT_TRACE
#define AIENGINE_LOG_TRACE_INIT_FKT_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_RUN_CGI_TRACE
#define AIENGINE_LOG_TRACE_RUN_CGI_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_SHOW_FKT_TRACE
#define AIENGINE_LOG_TRACE_SHOW_FKT_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_QUEUE_TRACE
#define AIENGINE_LOG_TRACE_QUEUE_TRACE		(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif


#ifndef AIENGINE_LOG_TRACE_SOCKET_TRACE
#define AIENGINE_LOG_TRACE_SOCKET_TRACE		(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE
#define AIENGINE_LOG_TRACE_SOCKET_CLIENT_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE
#define AIENGINE_LOG_TRACE_SOCKET_SERVER_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_SERVER_TRACE
#define AIENGINE_LOG_TRACE_SERVER_TRACE		(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_SERVER_HASH_TRACE
#define AIENGINE_LOG_TRACE_SERVER_HASH_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE
#define AIENGINE_LOG_TRACE_SERVER_CRYPT_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_CLIENT_CRYPT_TRACE
#define AIENGINE_LOG_TRACE_CLIENT_CRYPT_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_DB_TRACE
#define AIENGINE_LOG_TRACE_DB_TRACE		(AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_DB_META_TRACE
#define AIENGINE_LOG_TRACE_DB_META_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_BROWSER_TRACE
#define AIENGINE_LOG_TRACE_BROWSER_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_VARIABLES
#define AIENGINE_LOG_TRACE_VARIABLES  	        (!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                                                !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif

#ifndef AIENGINE_LOG_TRACE_FILE_IO_TRACE
#define AIENGINE_LOG_TRACE_FILE_IO_TRACE	(!AIENGINE_LOG_MSG_OFF && \
						!AIENGINE_OPTIMIZE_SIZE && \
                  !AIENGINE_OPTIMIZE_SPEED) || \
						AIENGINE_LOG_TRACE_ALL
#endif
#endif
/*---------------------------------------------------------------------------*/
/* Includes                                                                  */
/*...........................................................................*/
#include "aie_log.h"
#include "aie_mlog.h"
#include "aie_flog.h"

/*---------------------------------------------------------------------------*/
/* Strukturen                                                                */
/*...........................................................................*/
// Keine                                                                     //

/*---------------------------------------------------------------------------*/
/* Protoypen                                                                 */
/*...........................................................................*/
// Keine                                                                     //

/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
#endif                                                                       //
/* -------------------------------- EOF ------------------------------------ */
 
