/*****************************************************************************/
/* @Secur(tm) Internet Engine & HTML Generator                Version  3.0.0 */
/* http://www.aIEngine.org                     Email: webmaster@aiengine.org */
/*---------------------------------------------------------------------------*/
/* Projekt     : @Secur Internet Engine & HTML Generator                     */
/* Modul       : aie_qlog.c                                                  */
/* Library     : aiengine-log-3.00.00.so                                     */
/* Autor       : Alexander J. Herrmann                                       */
/* Erstellt    : 31.03.2004                                                  */
/*...........................................................................*/
/* Bemerkung                                                                 */
/* Split der Log Funktionen von log.cpp in verschiedene Programme            */
/*---------------------------------------------------------------------------*/
/* Aenderungen                                                               */
/* dd.mm.yyyy  : Author        : Modifikation                                */
/*.............+...............+.............................................*/
/*             :               :                                             */
/*.............+...............+.............................................*/
/* 12.12.2006  : ALH           : Changes for Version 3.0                     */
/*.............+...............+.............................................*/
/* 14.01.2005  : ALH           : Der Modulname (CGI) wird nun mitverschickt  */
/*             :               : Abfangen einer Recursion  Logmeldung in Log */
/*.............+...............+.............................................*/
/* 04.08.2004  : ALH           : Fuer Version 2.0 alle Module und Header     */
/*                             : nun Namen die mit aie_ beginnen um konflikte*/
/*                             : mit den Applikationssourcen zu verhindern.  */
/*.............+...............+.............................................*/
/* 02.08.2004  : ALH           : Alle cpp in c und alle hpp in h (c99)       */
/*.............+...............+.............................................*/
/* 11.06.2004  : ALH           : Dynamischer Speicher fuer grosse Variablen  */
/*                             : Konstanten als const deklarieren            */
/*.............+...............+.............................................*/
/* 31.03.2004  : ALH           : Split von log.cpp in log.c  , flog.c  ,     */
/*                               qlog.c   und mlog.c                         */
/*---------------------------------------------------------------------------*/
/*    THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED   */
/*    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF   */
/*            MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.          */
/*                This program is NOT FREE SOFTWARE in common!               */
/* But as it has a dual Licence so it may still fit your needs as long as it */
/* is used for non-profit purposes including educational use. You're also    */
/* allowed to redistribute it and/or modify it under the included            */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 - see COPYING.LESSER.     */
/* A exception is that any output like Webpages, Scripts do not automaticly  */
/* fall under the copyright of this package, but belong to whoever generated */
/* them and may be sold commercialy and may be aggregatet with this Software */
/* as long as the Software itself is distributed under the Licence terms.    */
/* C subroutines (or comparable compiled subroutines in other languages)     */
/* supplied by you and linked into this Software in order to extend the      */
/* functionality of this Software shall not be considered part of this       */
/* Software and should not alter the Software in any way that would cause it */
/* to fail the regression tests for this Software.                           */
/* Another exception to the above Licence is that you can modify the and use */
/* the modified Software without placing the modifications in the Public     */
/* Domain as long as this modifications are only used within your corporation*/
/* or organization.                                                          */
/*---------------------------------------------------------------------------*/
/* In case that you would like to use it in aggregate with commercial        */
/* programs and/or as part of a larger (possibly commercial) software        */
/* distribution than you should contact the Copyright Holder first.          */
/* Same if you have plans which would violate one or more of the included    */
/* "LESSER GNU GENERAL PUBLIC LICENCE" Version 2.1 Licence Terms.            */
/*---------------------------------------------------------------------------*/
/* (C) 1995-2007 Alexander Joerg Herrmann                                    */
/*               Email: alexander.herrmann@aiengine.org                      */ 
/*               http://www.aIEngine.org                                     */ 
/* @Secur(tm)    (r) 2000-2007 @Secur Trademark DE 399 55 393                */
/* (C) 1998-2004 ECLIPSE Software & Multimedia GmbH                          */
/*...........................................................................*/
/* Alle Rechte vorbehalten                               All rights reserved */
/*****************************************************************************/
const char *modul_qflog_version = "1.0.0";                                   //
const char *modul_qflog         = "QLog";                                    //
const char *modul_qflog_date    = __DATE__;                                  //
const char *modul_qflog_time    = __TIME__;                                  //
/*---------------------------------------------------------------------------*/
/* Lokale definitionen fuer das Modul                                        */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Globales Include fuer @Secur Internet Engine & HTML Generator             */
/*...........................................................................*/
#define AIENGINE_USE_BASE_LIB			1
//#if !AIENGINE_LOG_NO_LOG
//#if AIE_TARGET_IS_LINUX
#define AIENGINE_USE_SERVER_LIB			1
#define AIENGINE_USE_CLIENT_LIB			1
#define AIENGINE_USE_LOG_LIB			1
//#endif
//#endif
#include "aiengine.h"
/*---------------------------------------------------------------------------*/
/* Lokale Include's fuer das Modul                                           */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Externe globale Variablen des CGI's                                       */
/*...........................................................................*/
extern char *aIEngine_Start_Prog;                                            //
extern char *aIEngine_IP_Addresse;                                           //
extern char *aIEngine_GlobalApplName;                                        //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale globale Variablen fuer das CGI                                     */
/*...........................................................................*/
// Keine                                                                     //
/*---------------------------------------------------------------------------*/
/* Lokale strukturen                                                         */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Lokale statische Funktionsprototypen fuer das Modul                       */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*---------------------------------------------------------------------------*/
/* Statische variablen global fuer das Modul                                 */
/*...........................................................................*/
// Keine                                                                     //
                                                                             //
/*****************************************************************************/

#if AIE_TARGET_IS_LINUX
#if !AIENGINE_LOG_NO_LOG

/*---------------------------------------------------------------------------*/
/* Funktion      :                                                           */
/* Parameter     :                                                           */
/* Rueckgabewert :                                                           */
/*...........................................................................*/
bool aie_log_2_queue(const char *file_path, const char *outp)
{
   static int msqid = -1;
   struct aie_log_msgbuf msgbuf;
   bool rc = false;
   static bool is_allready_in_log = false;
   if (!is_allready_in_log)
   {
      is_allready_in_log = true;
      { 
         const char *aie_modul_name = aIEngine_Start_Prog;
	 const char *aie_modul_ip = aIEngine_IP_Addresse;
	 //                       aie_get_aIEngine_env(AIENGINE_ENV_REMOTE_ADDR);
	 if (aie_modul_name == NULL)
	 {
	    aie_modul_name = aIEngine_GlobalApplName;
            //      aie_GetStandardAsecurVariableValue(AIENGINE_VAR_CGI_MYSELF); 
	 }
         if (__builtin_expect((msqid < 0),false))
         {
            msqid = aie_open_queue(MSG_PROG_LOG);
         }
         if (__builtin_expect((msqid >= 0),true))
         {
            memset(&msgbuf, '\0', sizeof(msgbuf));
            strncpy(msgbuf.ipc_log_msg.logfile, file_path, 
		    AIE_LEN_LOGFILE_NAME);
            if (aie_modul_name != NULL)
	    {
	       char *short_modul_name = aie_strdup(aie_modul_name);
	       if (short_modul_name != NULL)
	       {
	          char *sptr = short_modul_name + strlen(short_modul_name) - 1;
	          while (sptr > short_modul_name)
	          {
		     if (*sptr == '.')
		     {
		        *sptr = '\0';
		        break;
		     }
		     sptr--;
	          }
	          if (strncmp(short_modul_name, "/cgi-bin/", 9) == 0)
	          {
                     strncpy(msgbuf.ipc_log_msg.log_prog, short_modul_name + 9,
		                                          AIE_STD_PROG_LEN);
	          }
	          else
	          {
                     strncpy(msgbuf.ipc_log_msg.log_prog, short_modul_name, 
		                                          AIE_STD_PROG_LEN);
	          }
		  aie_free(short_modul_name);
	       }
	       else
	       {
                  strncpy(msgbuf.ipc_log_msg.log_prog, "OOM", AIE_STD_PROG_LEN);
	       }
	    }
	    else
	    {
               strncpy(msgbuf.ipc_log_msg.log_prog, "???", AIE_STD_PROG_LEN);
	    }
            if (aie_modul_ip != NULL)
	    {
               strncpy(msgbuf.ipc_log_msg.log_ip, aie_modul_ip, 
		                                          AIE_STD_IP_LEN);
	    }
	    else
	    {
	       char tmp[10];
	       sprintf(tmp, "pid %d", getpid());
               //strncpy(msgbuf.ipc_log_msg.log_ip, "???", AIE_STD_IP_LEN);
               strncpy(msgbuf.ipc_log_msg.log_ip, tmp, AIE_STD_IP_LEN);
	    }
            strncpy(msgbuf.ipc_log_msg.log_msg, outp, AIE_LEN_LOG_MSG);
#if AIE_LOG_QUEUE_NO_WAIT
            rc = aie_send_queue_nowait(msqid, MSG_PROG_LOG, &msgbuf, 
		                                            sizeof(msgbuf));
#else
            rc = aie_send_queue_wait(msqid, MSG_PROG_LOG, &msgbuf, 
		                                            sizeof(msgbuf));
#endif
         }
      }
      is_allready_in_log = false;
   }
   else
   {
      FILE *fptr;
      if (__builtin_expect(
	    ((fptr = aie_open_append_text_file(file_path)) != NULL),true))
      {
         char tmp[80];
         sprintf(tmp, "%s(%d): Logrecursion!", __FILE__, __LINE__);
         fprintf(fptr, "%s/Loging[%s]\n", aie_get_time_stamp(), tmp);
         fprintf(fptr, "%s/Loging[%s]\n", aie_get_time_stamp(), outp);
         aie_close_file(fptr);
      }
   }
   return(rc);
}
/*---------------------------------------------------------------------------*/
#endif
#endif
/* -------------- @Secur (tm) Internet Engine & HTML Generator ------------- */
int   modul_qlog_size    = __LINE__;                                         //
/* -------------------------------- EOF ------------------------------------ */

